﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.Storage;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Application
{
    public class XmlStorageHandler : IRequestHandler<XmlStorageRequest, XmlStorageResponse>
    {
        IRepository _storageClient;
        public XmlStorageHandler(IRepository repository)
        {
            _storageClient = repository;
        }

        public async Task<XmlStorageResponse> Handle(XmlStorageRequest request, CancellationToken cancellationToken)
        {
            return await _storageClient.StoreXml(request);            
        }
    }
}
