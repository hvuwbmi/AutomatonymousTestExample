﻿using AcordSubmissions.Domain.Entities.DriverImportErrors;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Application
{
    public class RetrieveImportErrorsHandler : IRequestHandler<RetrieveImportErrorsRequest, RetrieveImportErrorsResponse>
    {
        IRepository _storageClient;        
        private ILogger<RetrieveImportErrorsHandler> _logger;

        public RetrieveImportErrorsHandler(IRepository repository, ILogger<RetrieveImportErrorsHandler> logger)
        {
            _storageClient = repository;                   
            _logger = logger;
        }
        public async Task<RetrieveImportErrorsResponse> Handle(RetrieveImportErrorsRequest request, CancellationToken cancellationToken)
        {
            return await _storageClient.RetrieveDuckUploadValidationErrors(request);
        }
    }
}
