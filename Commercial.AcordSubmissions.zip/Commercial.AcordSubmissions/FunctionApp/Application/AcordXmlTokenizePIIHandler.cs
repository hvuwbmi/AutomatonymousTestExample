using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using AcordSubmissions.Domain.Entities.Enums;
using System.Collections.Generic;
using System.Threading.Tasks;
using System.Xml;
using MediatR;
using System.Threading;
using System;
using System.Text.RegularExpressions;
using System.Text;
using Microsoft.Extensions.Logging;
using AcordSubmissions.Domain.Entities.Storage;

namespace AcordSubmissions.Application
{
    public class AcordXmlTokenizePIIHandler : IRequestHandler<AcordXmlTokenizePIIRequest, AcordXmlTokenizePIResponse>
    {
        private IMediator _mediator;
        private ILogger<AcordXmlTokenizePIIHandler> _logger;
        private IRepository _storageClient;
        private ICommonLogService _commonLogService;
        private string _division;
        private string _emailRowKey;
        private const string _missingDivision = "MissingDivision";
        private const string _missingEmailId = "MissingEmailId";

        public AcordXmlTokenizePIIHandler(IMediator mediator, ICommonLogService commonLogService, ILogger<AcordXmlTokenizePIIHandler> logger,IRepository repository)
        {
            _mediator = mediator;
            _commonLogService = commonLogService;
            _storageClient = repository;
            _logger = logger;
        }

        public async Task<AcordXmlTokenizePIResponse> Handle(AcordXmlTokenizePIIRequest request, CancellationToken cancellationToken)
        {
            _logger.Log(LogLevel.Information, "AcordXmlTokenizePIIHandler: Enter...");
            // get division and email row key now for use throughout
            var rs = new AcordXmlTokenizePIResponse();

            _division = GetDivision(request.AcordXml);
            
            _emailRowKey = GetGuidForDivision(request.AcordXml);
         
            _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Got EmailKey {_emailRowKey} and Division {_division}...");

            var statusCodeNode = request.AcordXml.SelectSingleNode("/FormServerResponse/Status/StatusCode");
            var statusDescNode = request.AcordXml.SelectSingleNode("/FormServerResponse/Status/StatusDesc");

            await _storageClient.StoreSubmissionEvents(BuildRequestForSubmissionEventsStorage("RECEIVED_TURNSTILE_RESPONSE", statusCodeNode.InnerText, statusDescNode.InnerText));

            // log 
            // get an update teh confidence index
            string confidenceIndex = GetConfidenceIndex(request.AcordXml);
            if (!_emailRowKey.Equals(_missingEmailId))
            {
                await _storageClient.UpdateConfidenceIndex(new UpdateEmailTableRequest { ConfidenceIndex = confidenceIndex, RowKey = _emailRowKey });
            }

            var businessName = GetBusinessName(request.AcordXml);

            rs.Division = _division;
            rs.EmailRowKey = _emailRowKey;
            rs.ConfidenceIndex = confidenceIndex;
            rs.BusinessName = businessName;

            // If the xml in the request is an error xml, call the common log and return a bad request response          
            if (statusCodeNode.InnerText != "0")
            {
                _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Status Code from C5 was {statusCodeNode.InnerText}. Send to Teams and store Xml... ");
                rs = InvalidC5Xml(statusCodeNode.InnerText, statusDescNode.InnerText, confidenceIndex, businessName);

                if (rs.ResponseCode == ResponseCode.Success)
                {
                    // store the error XML to blob
                    await StoreXmlToBlob(XmlType.Acord, request.AcordXml);
                }

                return rs;
            }


            //create list of Driver's Licenses
            var numbers = ExtractDriversLicenses(request.AcordXml);
            //call tokenize function which returns dictionary
            var tokenizationError = new StringBuilder();
            if (numbers.Count > 0)
            {
                // Log tokenizarion start with total count of DL#s
                await _storageClient.StoreSubmissionEvents(BuildRequestForSubmissionEventsStorage("TOKENIZATION_START ", string.Empty, string.Empty, numbers.Count));

                _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Extracted {numbers.Count} drivers licenses and call tokenize... ");
                var response = await _mediator.Send(new PIITokenizeRequest { Items = numbers });
                _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Return from Parallel calls to Tokenize API Response: Tokenized {response.Results.Count} DL#s");

                //update acord xml
                var tokenizedDriversLicenseCount = 0;
                foreach (var result in response.Results)
                {
                    //use xpath to find the correct node based on the innertext = key
                    //replace the inner text with the value from the dictionary
                    try
                    {                        
                        var numberNode = request.AcordXml.SelectSingleNode("//LicensePermitNumber[text()=\"" + result.Id + "\"]");
                        if (numberNode != null)
                        {
                            if (result.Status == true && !string.IsNullOrEmpty(result.Token))
                            {
                                tokenizedDriversLicenseCount++;
                                _logger.Log(LogLevel.Information, "AcordXmlTokenizePIIHandler: Update DL with tokenized value");
                                numberNode.InnerText = result.Token;
                            }
                            else
                            {
                                _logger.Log(LogLevel.Information, "AcordXmlTokenizePIIHandler: Tokenize failed. DL Set to Empty");
                                ProcessTokenizationErrors(request.AcordXml, numberNode, tokenizationError);
                                numberNode.InnerText = string.Empty;
                            }
                        }
                        else
                        {
                            _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Unable to locate the node for Driver with ID: {result.Id}");
                        }
                      
                    }
                    catch (Exception e)
                    {
                        _logger.Log(LogLevel.Information, $"AcordXmlTokenizePIIHandler: Updating Token value threw an exception {e.Message}");
                        rs.ResponseCode = ResponseCode.ServerError;
                        rs.ExceptionResult = e;

                        return rs;
                    }

                }

                await _storageClient.StoreSubmissionEvents(BuildRequestForSubmissionEventsStorage("TOKENIZATION_COMPLETE ", string.Empty, string.Empty, 0, tokenizedDriversLicenseCount));
            }
            else
            {
                await _storageClient.StoreSubmissionEvents(BuildRequestForSubmissionEventsStorage("TOKENIZATION_SKIP ", string.Empty, string.Empty, 0, 0));
            }

            // save ACordXml now after tokenization
            rs.AcordXml = request.AcordXml;

            if (tokenizationError.Length > 0)
            {
                // report via common log
                // add division and EMail Id to the message
                tokenizationError.Insert(0, $"Tokenization Errors for {_division} - {_emailRowKey}" + Environment.NewLine);
                ReportToCommonLog(tokenizationError.ToString());
            }

            AddDivisionElement(request.AcordXml);

            // store the ACORD before we process it.
            var storageRequest = new XmlStorageRequest()
            {
                XmlType = XmlType.Acord,
                RowKey = _emailRowKey,
                Xml = request.AcordXml
            };

            await _mediator.Send(storageRequest);

            await _storageClient.StoreSubmissionEvents(BuildRequestForSubmissionEventsStorage("ACORD_XML_STORED ", string.Empty, string.Empty, 0, 0));
            rs.SubmitToPenguin = true;
            return rs;

        }

        private void ProcessTokenizationErrors(XmlDocument doc, XmlNode licensePermitNumber, StringBuilder errorMessage)
        {
            // add error to Driver node
            var lastName = "Not Found";
            var firstName = "notFound";
            var driverNode = licensePermitNumber.ParentNode.ParentNode.ParentNode;
            if (driverNode != null)
            {
                _logger.Log(LogLevel.Information, "ProcessTokenizationErrors: Found Driver Node....");
                //add new attribute
                XmlAttribute attr = doc.CreateAttribute("LicenseTokenizeError");
                attr.Value = "true";
                //Add the attribute to the node     
                driverNode.Attributes.SetNamedItem(attr);

                // build message to user
                // get last name and first name
                var nameInfoNode = driverNode.ChildNodes[1].ChildNodes[0];
                
                if (nameInfoNode != null)
                {
                    _logger.Log(LogLevel.Information, "ProcessTokenizationErrors: Found Name Information....");
                    var lastNameNopde = nameInfoNode.SelectSingleNode(".//Surname");
                    if (lastNameNopde != null)
                    {
                        lastName = lastNameNopde.InnerText;
                        _logger.Log(LogLevel.Information, $"ProcessTokenizationErrors: Found Last Name {lastName} ...");
                    }

                    var firstNameNode = nameInfoNode.SelectSingleNode(".//GivenName");
                    if (firstNameNode != null)
                    {
                        firstName = firstNameNode.InnerText;
                        _logger.Log(LogLevel.Information, $"ProcessTokenizationErrors: Found First Name {firstName} ...");
                    }

                    _logger.Log(LogLevel.Information, $"Drivers License Number for  Last Name: {lastName}, First Name: {firstName}. Failed to Tokenize and was cleared.");
                    errorMessage.AppendLine($"Drivers License Number for  Last Name: {lastName}, First Name: {firstName}. Failed to Tokenize and was cleared.");
                }
                else
                {
                    _logger.Log(LogLevel.Information, "ProcessTokenizationErrors: Missing Name Information....");
                    errorMessage.AppendLine($"Drivers License Number for Last Name: {lastName}, First Name: {firstName}. Failed to Tokenize and was cleared.");
                }
               
               
            }
            else
            {
                _logger.Log(LogLevel.Information, "ProcessTokenizationErrors: Missing Driver Node....");
                errorMessage.AppendLine($"Drivers License Number for Last Name: {lastName}, First Name: {firstName}. Failed to Tokenize and was cleared.");
            }
        }

        private string GetDivision(XmlDocument xml)
        {
            var result = _missingDivision;

            if (xml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'EmailID_" + Division.Argent + "')]") != null)
            { return Division.Argent; };
            if (xml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'EmailID_" + Division.WBCL + "')]") != null)
            { return Division.WBCL; };
            if (xml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'EmailID_" + Division.NSI + "')]") != null)
            { return Division.NSI; };

            return result;
        }

        private string GetGuidForDivision(XmlDocument xml)
        {
            var filenameNode = xml.SelectSingleNode("/FormServerResponse/Status/Messages/Message/FileName[contains(text(),'EmailID_')]");

            if (filenameNode != null && !string.IsNullOrWhiteSpace(filenameNode.InnerText))
            {
                var separated = filenameNode.InnerText.Split("_");
                var rowGuid = separated[separated.Length - 1].Split(".")[0];
                return rowGuid;
            }
            return _missingEmailId;
        }

        private string GetBusinessName(XmlDocument xml)
        {
            var textNode = xml.SelectSingleNode("/FormServerResponse" +
                "/ReturnPayload" +
                "/ACORD" +
                "/InsuranceSvcRq" +
                "/*" + // Any node (Should be *PolicyQuoteInqRq but you can't do that
                "/InsuredOrPrincipal[count(@*)=0]" + // Any InsuredOrPrincipal node with zero attributes
                "/GeneralPartyInfo" +
                "/NameInfo" +
                "/CommlName" +
                "/CommercialName");
            return textNode == null ? "MissingBusinessName" : textNode.InnerText;
        }

        private void AddDivisionElement(XmlDocument xml)
        {           
            var divisionElement = xml.CreateElement("Division");
            if (_division == "WBCL") { _division = "CommercialLines"; }
            divisionElement.InnerText = _division;
            var node = xml.SelectSingleNode("/FormServerResponse/ProcessDetails");
            node.AppendChild(divisionElement);

            // find all products and add Division in Policy/PolicyExt for each one
            var products = xml.SelectNodes("/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/*[contains(local-name(), 'PolicyQuoteInqRq')]");
            foreach (XmlNode product in products)
            {
                string productName = product.LocalName;
                var productPolicyNode = xml.SelectSingleNode("/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/" + productName + "/Policy");
                var policyExt = xml.CreateElement("PolicyExt");
                var division = xml.CreateElement("Division");
                var acordSubmissionData = xml.CreateElement("AcordSubmissionData");
                var acordSubmissionRowKey = xml.CreateElement("AcordSubmissionRowKey");

                // set xmlns attribute as it is currently needed by MapForce
                division.SetAttribute("xmlns", "");
                division.InnerText = _division;

                acordSubmissionRowKey.InnerText = _emailRowKey;

                acordSubmissionData.AppendChild(acordSubmissionRowKey);

                policyExt.AppendChild(division);
                policyExt.AppendChild(acordSubmissionData);
                productPolicyNode.AppendChild(policyExt);
            }            
        }

        private AcordXmlTokenizePIResponse InvalidC5Xml(string statusCode, string statusDescription, string confidenceIndex, string businessName)
        {
            var response = new AcordXmlTokenizePIResponse();

            // Log to teams            
            ReportToCommonLog($"{statusCode}: {statusDescription} For {_division}_{_emailRowKey} Confidence Index: {confidenceIndex}" +
                $"\nBusiness name: {businessName}");

            response.ResponseCode = ResponseCode.Success;
            response.ResponseMessage = "Invalid Connect5 Xml " + statusCode + ":" + statusDescription;
            response.SubmitToPenguin = false;

            return response;
        }

        private async Task StoreXmlToBlob(XmlType type, XmlDocument xml)
        {
            var storageRequest = new XmlStorageRequest()
            {
                XmlType = type,
                RowKey = _emailRowKey,
                Xml = xml

            };

            await _mediator.Send(storageRequest);
        }

        private void ReportToCommonLog(string message)
        {
            var rq = new CommonLogServiceRq();
            rq.severity = "Information";
            rq.message = message;
            rq.extendedProperties = new List<CommonLogExtendedProperty>();
            rq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
            _commonLogService.CommonLog(rq);
        }
        private List<string> ExtractDriversLicenses(XmlDocument doc)
        {
            var licenseNumberNodes = doc.SelectNodes("//License");
            var numbers = new List<string>();
          
            foreach (XmlNode licenseNumberNode in licenseNumberNodes)
            {
                var driver = string.Empty;
                var state = string.Empty;                
                foreach (XmlNode license in licenseNumberNode.ChildNodes)
                {
                    if (license.Name == "LicensePermitNumber")
                    {
                        driver = license.InnerText;                       
                    }
                    if (license.Name == "StateProvCd")
                    {
                        state = license.InnerText;
                    }
                }
                string scrubbedDriver;
                if (!string.IsNullOrEmpty(driver))
                {
                    if (state == "WY")
                    {
                        scrubbedDriver = GetReplacement(driver.Trim());
                    }
                    else
                    {
                        scrubbedDriver = Regex.Replace(driver.Trim(), "[ -]+", "");
                    }
                   
                    numbers.Add(scrubbedDriver);
                    licenseNumberNode["LicensePermitNumber"].InnerText = scrubbedDriver;
                }
            }

            return numbers;
        }

        private static string GetReplacement(string input)
        {
            // get postion 7 char
            var pos7char = input.Substring(6, 1);
            var license = string.Empty;
            if (pos7char == "-")
            {
                license = input.Remove(6, 1);
            }
            else
            {
                license = input;
            }

            // replace all spaces and dashes
            var replacedLicense = Regex.Replace(license, "[ -]+", "");
            if (pos7char == "-")
            {
                replacedLicense = replacedLicense.Substring(0, 6) + pos7char + replacedLicense.Substring(6, replacedLicense.Length - 6);
            }
            return replacedLicense;
        }

        private static string GetConfidenceIndex(XmlDocument doc)
        {
            string score = doc.SelectSingleNode("/FormServerResponse/Status/ConfidenceIndex").InnerText;

            return score;
        }

        private SubmissionEventsRequest BuildRequestForSubmissionEventsStorage(string submissionEvent, string httpStatus, string errorDescription, int totalCount = 0, int count = 0)
        {
            var rq = new SubmissionEventsRequest()
            {
                Event = submissionEvent,
                EmailId = _emailRowKey,
                TotalCount = totalCount,
                Count = count
            };

            if (httpStatus.Equals("0"))
            {
                rq.Status = "200";
            }
            else if (!string.IsNullOrEmpty(httpStatus))
            {
                rq.ErrorDescription = errorDescription;
                rq.Status = httpStatus;
            }          

            return rq;
        }


    }
}

