﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Application
{
    public class RetrieveConfidenceIndexHandler : IRequestHandler<RetrieveConfidenceIndexRequest, RetrieveConfidenceIndexResponse>
    {
        IRepository _storageClient;
        private ILogger<RetrieveConfidenceIndexHandler> _logger;

        public RetrieveConfidenceIndexHandler(IRepository repository, ILogger<RetrieveConfidenceIndexHandler> logger)
        {
            _storageClient = repository;
            _logger = logger;
        }
        public async Task<RetrieveConfidenceIndexResponse> Handle(RetrieveConfidenceIndexRequest request, CancellationToken cancellationToken)
        {
            return await _storageClient.RetrieveConfidenceIndex(request);
        }
    }
}