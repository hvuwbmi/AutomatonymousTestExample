﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.Enums;
using AcordSubmissions.Domain.Entities.Storage;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml;

namespace AcordSubmissions.Application
{
    public class SubmitToPenguinHandler : IRequestHandler<ForwardToMapperRq, ForwardToMapperRs>
    {
        private IMediator _mediator;
        private ILogger<SubmitToPenguinHandler> _logger;
        private IRepository _storageClient;

        private ICommonLogService _commonLogService;
        private IForwardToMapperService _forwardToPenguinService;

        private string _emailRowKey;
        private string _division;
        private string _confidenceIndex;
        private string _businessName;
        private string _mappingTarget = "Penguin";
        private readonly string USE_WBMI_FOR_TRANSFORMS_KEY = "UseWbmiTransforms";
        private readonly bool _useWbmiTransforms;

        private List<string> _nsiValidLobs = new List<string>();
        private List<string> _wbclValidLobs = new List<string>();
        private List<string> _argentValidLobs = new List<string>();
        private List<string> _allLobs = new List<string>()
        {
            "AircraftPolicyQuoteInqRq",
            "AirportFBOPolicyQuoteInqRq",
            "AviationPkgPolicyQuoteInqRq",
            "BoilerMachineryPolicyQuoteInqRq",
            "BOPPolicyQuoteInqRq",
            "CommlAutoPolicyQuoteInqRq",
            "CommlInlandMarinePolicyQuoteInqRq",
            "CommlPkgPolicyQuoteInqRq",
            "CommlPropertyPolicyQuoteInqRq",
            "CommlUmbrellaPolicyQuoteInqRq",
            "CrimePolicyQuoteInqRq",
            "CyberLiabilityPolicyQuoteInqRq",
            "DirectorsAndOfficersPolicyQuoteInqRq",
            "EPLIPolicyQuoteInqRq",
            "ErrorsAndOmissionsPolicyQuoteInqRq",
            "GeneralLiabilityPolicyQuoteInqRq",
            "ProductsLiabilityPolicyQuoteInqRq",
            "WorkCompPolicyQuoteInqRq",
            "FarmPolicyQuoteInqRq",
            "DwellFirePolicyQuoteInqRq",
            "HomePolicyQuoteInqRq",
            "PersAutoPolicyQuoteInqRq",
            "PersInlandMarinePolicyQuoteInqRq",
            "PersPkgPolicyQuoteInqRq",
            "PersUmbrellaPolicyQuoteInqRq",
            "WatercraftPolicyQuoteInqRq"
        };

        public SubmitToPenguinHandler(IMediator mediator, ICommonLogService commonLogService, ILogger<SubmitToPenguinHandler> logger, IForwardToMapperService forwardToPenguinService, IRepository storageClient)
        {
            _storageClient = storageClient;
            _forwardToPenguinService = forwardToPenguinService;
            _mediator = mediator;
            _commonLogService = commonLogService;
            _logger = logger;

            _useWbmiTransforms = true;
            if (Environment.GetEnvironmentVariable(USE_WBMI_FOR_TRANSFORMS_KEY) != null)
            {
                _useWbmiTransforms = Environment.GetEnvironmentVariable(USE_WBMI_FOR_TRANSFORMS_KEY) == "true";
            }

            if (_useWbmiTransforms)
            {
                _mappingTarget = "DCT";
            }

        }
        public async Task<ForwardToMapperRs> Handle(ForwardToMapperRq request, CancellationToken cancellationToken)
        {
            SetupLinesOfBusiness();
            _emailRowKey = request.EmailRowKey;
            _division = request.Division;
            _confidenceIndex = request.ConfidenceIndex;
            _businessName = request.BusinessName;
            _logger.Log(LogLevel.Information, $"ForwardToPEnguin Handler: Emal Key: {_emailRowKey}");
            _logger.Log(LogLevel.Information, $"ForwardToPEnguin Handler: Division: {_division}");

            return await SendACORDBydivision(request.AcordXml);
        }

        private async Task<ForwardToMapperRs> SendACORDBydivision(XmlDocument acordXml)
        {
            var isArgent = acordXml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'Argent')]");
            var isWBCL = acordXml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'WBCL')]");
            var isNSI = acordXml.SelectSingleNode("//Status/Messages/Message/FileName[contains(text(),'NSI')]");
            ForwardToMapperRs rs = null;

            if (isArgent != null)
            {
                if (isArgent.InnerText.Length > 1)
                {
                    _logger.Log(LogLevel.Information, "Division is Argent...");
                    foreach (var lob in _argentValidLobs)
                    {
                        var xmlToSendToPenguin = CreatePolicyDocument(acordXml, lob);

                        XmlNodeList nodes = xmlToSendToPenguin.SelectNodes($"/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/{lob}");
                        if (nodes.Count > 0)
                        {
                            // yes we have this LOB, so process it                           
                            _logger.Log(LogLevel.Information, $"SendACORDBydivision: Call submit-to-penguin API for LOB {lob}");
                            rs = await SendToMapper(xmlToSendToPenguin, lob);
                        }
                    }

                    await LogUnsupportedLinesOfBusiness(acordXml, _argentValidLobs);
                }
            }
            else if (isWBCL != null)
            {
                if (isWBCL.InnerText.Length > 1)
                {
                    _logger.Log(LogLevel.Information, "Division is WBCL...");
                    foreach (var lob in _wbclValidLobs)
                    {
                        var xmlToSendToPenguin = CreatePolicyDocument(acordXml, lob);

                        XmlNodeList nodes = xmlToSendToPenguin.SelectNodes($"/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/{lob}");
                        if (nodes.Count > 0)
                        {
                            // yes we have this LOB, so process it
                            _logger.Log(LogLevel.Information, $"SendACORDBydivision: Call submit-to-penguin API for LOB {lob}");
                            rs = await SendToMapper(xmlToSendToPenguin, lob);
                        }
                    }

                    await LogUnsupportedLinesOfBusiness(acordXml, _wbclValidLobs);
                }
            }
            else if (isNSI != null)
            {
                if (isNSI.InnerText.Length > 1)
                {
                    _logger.Log(LogLevel.Information, "Division is NSI...");
                    // send it
                    foreach (var lob in _nsiValidLobs)
                    {
                        var xmlToSendToPenguin = CreatePolicyDocument(acordXml, lob);

                        XmlNodeList nodes = xmlToSendToPenguin.SelectNodes($"/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/{lob}");
                        if (nodes.Count > 0)
                        {
                            // yes we have this LOB, so process it
                            _logger.Log(LogLevel.Information, $"SendACORDBydivision: Call submit-to-penguin API for LOB {lob}");
                            rs = await SendToMapper(xmlToSendToPenguin, lob);
                            _logger.Log(LogLevel.Information, $"SendACORDBydivision: Call to submit-to-penguin API Result: {rs.ResponseCode}");
                        }
                    }

                    await LogUnsupportedLinesOfBusiness(acordXml, _nsiValidLobs);
                }
            }
            else
            {
                // Log to teams
                var infoMsg = new StringBuilder();
                infoMsg.AppendLine($"NO DIVISION IN ACORD XML For: {_division}_{_emailRowKey} Confidence Index: {_confidenceIndex}");
                infoMsg.Append($"Business Name: {_businessName}");

                var clResponse = await SendToCommonLogInfo(infoMsg.ToString());

                rs = new ForwardToMapperRs()
                {
                    ResponseCode = clResponse.ResponseCode,
                    ResponseMessage = clResponse.ResponseMessage
                };
            }

            return rs;
        }

        private async Task LogUnsupportedLinesOfBusiness(XmlDocument acordXml, List<string> lobsToSkip)
        {
            foreach (var lob in _allLobs)
            {
                if (lobsToSkip.Find(l => l == lob) == null)
                {
                    var xmlToSendToPenguin = CreatePolicyDocument(acordXml, lob);

                    XmlNodeList nodes = xmlToSendToPenguin.SelectNodes($"/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/{lob}");
                    if (nodes.Count > 0)
                    {
                        await _storageClient.StoreSubmissionLOB(BuildRequestForSubmissionLOBStorage(lob));
                    }
                }
            }
        }

        private XmlDocument CreatePolicyDocument(XmlDocument acordXml, string lobToCreate)
        {
            // strip out all except and move to new document            
            // make a deep copy
            var processXml = (XmlDocument)acordXml.CloneNode(true);
            foreach (var lob in _allLobs)
            {
                if (!lob.Equals(lobToCreate))
                {
                    XmlNodeList nodes = processXml.SelectNodes($"/FormServerResponse/ReturnPayload/ACORD/InsuranceSvcRq/{lob}");
                    if (nodes.Count > 0)
                    {
                        for (int i = nodes.Count - 1; i >= 0; i--)
                        {
                            nodes[i].ParentNode.RemoveChild(nodes[i]);
                        }
                    }
                }
            }


            return processXml;
        }

        private async Task<ForwardToMapperRs> SendToMapper(XmlDocument xmlToSend,string lob)
        {
            var request = new ForwardToMapperRq
            {
                XmlToMap = xmlToSend,
                LOB = lob,
                UseWbmiTransforms = _useWbmiTransforms
            };

            var mapTarget = lob == "WorkCompPolicyQuoteInqRq" ? "Penguin" : _mappingTarget;
            var submissionLOBStorageRs = await _storageClient.StoreSubmissionLOB(BuildRequestForSubmissionLOBStorage(lob));

            await _storageClient.StoreSubmissionLOBEvents(BuildRequestForSubmissionLOBEventsStorage("MAPPING_STARTED", submissionLOBStorageRs.SubmissionLOBRowKey,   0, string.Empty, mapTarget, string.Empty));

            var rs = _forwardToPenguinService.Submit(request).Result;
            _logger.Log(LogLevel.Information, $"SendToPenguin Result: {rs.ResponseCode}");
            var httpStatus = (int)rs.HttpStatusCode;

            if (rs.ResponseCode == ResponseCode.Success && rs.ReturnValue.StartsWith("<session>"))
            {
                _logger.Log(LogLevel.Information, "SendToPenguin: Returned session xml, store to DuckXml Table and Blob");
                await _storageClient.StoreSubmissionLOBEvents(BuildRequestForSubmissionLOBEventsStorage("MAPPING_COMPLETE", submissionLOBStorageRs.SubmissionLOBRowKey, httpStatus, rs.ResponseMessage, mapTarget, string.Empty));

                var duckXml = new XmlDocument();
                duckXml.LoadXml(rs.ReturnValue);
                var storageRequest = new XmlStorageRequest()
                {
                    XmlType = XmlType.Duck,
                    RowKey = _emailRowKey,
                    Xml = duckXml

                };

                await _mediator.Send(storageRequest);
                await _storageClient.StoreSubmissionLOBEvents(BuildRequestForSubmissionLOBEventsStorage("STORAGE_DCTXML", submissionLOBStorageRs.SubmissionLOBRowKey, 0, string.Empty, mapTarget, string.Empty));
            }
            else if (rs.ResponseCode == ResponseCode.Success)
            {
                // asume WC
                _logger.Log(LogLevel.Information, "SendToPenguin: Success and assuming WC....");
                var wcResponse = JsonConvert.DeserializeObject<WorkCompPenguinResponse>(rs.ReturnValue);
                _logger.Log(LogLevel.Information, $"SendToPenguin:Returned Values: {wcResponse.PolicyNumber}, {wcResponse.CustomerNumber}");
                await _storageClient.StoreSubmissionLOBEvents(BuildRequestForSubmissionLOBEventsStorage("MAPPING_COMPLETE", submissionLOBStorageRs.SubmissionLOBRowKey, httpStatus, rs.ResponseMessage, mapTarget, wcResponse.PolicyNumber));
            }
            else if (rs.ResponseCode != ResponseCode.Success)
            {
                string httpErrorMessage;
                if (rs.ResponseMessage.Contains("message"))
                {
                    var httpError = JsonConvert.DeserializeObject<HttpClientErrorResponse>(rs.ResponseMessage);
                    httpErrorMessage = httpError.Message;
                }
                else
                {
                    httpErrorMessage = rs.ResponseMessage;
                }


                await _storageClient.StoreSubmissionLOBEvents(BuildRequestForSubmissionLOBEventsStorage("MAPPING_COMPLETE", submissionLOBStorageRs.SubmissionLOBRowKey, httpStatus, httpErrorMessage, mapTarget, string.Empty));

                var errorMsg = new StringBuilder();
                errorMsg.AppendLine($"Send to Penguin Failed for Line of Business {request.LOB}: {httpErrorMessage}");
                errorMsg.Append($"For: {_division}_{_emailRowKey} Confidence Index: {_confidenceIndex} Business Name: {_businessName}");

                await SendToCommonLogError(errorMsg.ToString());
            }

            return rs;
        }

        private SubmissionLOBRequest BuildRequestForSubmissionLOBStorage(string lob)
        {
            var rq = new SubmissionLOBRequest()
            {
                LOB = lob,
                EmailId = _emailRowKey
            };


            return rq;
        }

        private SubmissionLOBEventsRequest BuildRequestForSubmissionLOBEventsStorage(string submissionEvent, string submissionLobRowKey, int httpStatus, string errorDescription, string target, string policyNumber)
        {
            var rq = new SubmissionLOBEventsRequest()
            {
                Event = submissionEvent,
                EmailId = _emailRowKey,
                Target = target,
                PolicyNumber = policyNumber,
                LOBRowKey = submissionLobRowKey
            };

            if (httpStatus > 0)
            {
                rq.Status = httpStatus.ToString();
                if (httpStatus != 200)
                {
                    rq.ErrorDescription = errorDescription;
                }
                else
                {
                    rq.ErrorDescription = string.Empty;
                }
            }
            else
            {
                rq.Status = string.Empty;
                rq.ErrorDescription = string.Empty;
            }

            return rq;
        }

        private void SetupLinesOfBusiness()
        {
            var enabledLobs = string.Empty;
            if (Environment.GetEnvironmentVariable("NSIEnabledLOBs") != null)
            {
                enabledLobs = Environment.GetEnvironmentVariable("NSIEnabledLOBs");
                _logger.Log(LogLevel.Information, $"Got the NSIEnabledLobs variable: Value: {enabledLobs}");
                var validLobs = enabledLobs.Split(",");
                _logger.LogInformation($"Build valid LOBS list for NSI...");
                BuildLobLists(validLobs, _nsiValidLobs);
            }
            else
            {
                _logger.Log(LogLevel.Information, $"No variable set for NSIEnabledLobs. Using Default:CommlPkgPolicyQuoteInqRq...");
                _nsiValidLobs.Add("CommlPkgPolicyQuoteInqRq");
            }


            if (Environment.GetEnvironmentVariable("WBCLEnabledLOBs") != null)
            {
                enabledLobs = Environment.GetEnvironmentVariable("WBCLEnabledLOBs");
                _logger.Log(LogLevel.Information, $"Got the WBCLEnabledLOBs variable: Value: {enabledLobs}");
                var validLobs = enabledLobs.Split(",");
                _logger.LogInformation($"Build valid LOBS list for WBCL...");
                BuildLobLists(validLobs, _wbclValidLobs);
            }
            else
            {
                _logger.Log(LogLevel.Information, $"No variable set for WBCLEnabledLOBs. Using Default:CommlPkgPolicyQuoteInqRq...");
                _wbclValidLobs.Add("CommlPkgPolicyQuoteInqRq");
            }


            if (Environment.GetEnvironmentVariable("ArgentEnabledLOBs") != null)
            {
                enabledLobs = Environment.GetEnvironmentVariable("ArgentEnabledLOBs");
                _logger.Log(LogLevel.Information, $"Got the ArgentEnabledLOBs variable: Value: {enabledLobs}");
                var validLobs = enabledLobs.Split(",");
                _logger.LogInformation($"Build valid LOBS list for Argent...");
                BuildLobLists(validLobs, _argentValidLobs);
            }
            else
            {
                _logger.Log(LogLevel.Information, $"No variable set for ArgentEnabledLOBs. Using Default:WorkCompPolicyQuoteInqRq...");
                _argentValidLobs.Add("WorkCompPolicyQuoteInqRq");
            }

        }

        private void BuildLobLists(string[] lobList, List<string> validLobs)
        {
            foreach (var item in lobList)
            {
                switch (item)
                {
                    case "CPP":
                        _logger.LogInformation($"Adding CommlPkgPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("CommlPkgPolicyQuoteInqRq");
                        break;
                    case "WC":
                        _logger.LogInformation($"Adding WorkCompPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("WorkCompPolicyQuoteInqRq");
                        break;
                    case "PROP":
                        _logger.LogInformation($"Adding PropertyPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("PropertyPolicyQuoteInqRq");
                        break;
                    case "GL":
                        _logger.LogInformation($"Adding GeneralLiabilityPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("GeneralLiabilityPolicyQuoteInqRq");
                        break;
                    case "INM":
                        _logger.LogInformation($"Adding InlandMarinePolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("InlandMarinePolicyQuoteInqRq");
                        break;
                    case "AUTO":
                        _logger.LogInformation($"Adding CommlAutoPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("CommlAutoPolicyQuoteInqRq");
                        break;
                    case "BOP":
                        _logger.LogInformation($"Adding BOPPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("BOPPolicyQuoteInqRq");
                        break;
                    case "UMB":
                        _logger.LogInformation($"Adding CommlUmbrellaPolicyQuoteInqRq to validLobs list...");
                        validLobs.Add("CommlUmbrellaPolicyQuoteInqRq");
                        break;
                    default:
                        break;
                }
            }
        }

        private async Task<BaseResponse> SendToCommonLogInfo(string message)
        {
            return await SendToCommonLog("Information", message);
        }

        private async Task<BaseResponse> SendToCommonLogError(string message)
        {
            return await SendToCommonLog("Error", message);
        }

        private async Task<BaseResponse> SendToCommonLog(string severity, string message)
        {
            var rq = new CommonLogServiceRq
            {
                severity = severity,
                message = message,
                extendedProperties = new List<CommonLogExtendedProperty>()
                {
                    new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" }
                }
            };
            return await _commonLogService.CommonLog(rq);
        }
    }
}

