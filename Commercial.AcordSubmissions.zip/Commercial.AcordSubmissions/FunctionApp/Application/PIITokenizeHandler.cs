﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Application
{
    public class PIITokenizeHandler : IRequestHandler<PIITokenizeRequest, PIITokenizeResponse>
    {
        private ILogger<PIITokenizeHandler> _logger;
        public const string TokenizeProcessCode = "Tokenize";
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Naming", "CA1704:IdentifiersShouldBeSpelledCorrectly", MessageId = "Detokenize", Justification = "spelled appropriately")]
        public const string DetokenizeProcessCode = "Detokenize";

        private const int TOKEN_MINIMUM_LENGTH = 8;
        private const char PADDING_CHARACTER = '@';
        const string TOKENIZE_APPLICATION = "AcordSubmission";
        const string TOKENIZE_APPCONTEXT = "TokenizeDriversLicense";
        const string DETOKENIZE_APPCONTEXT = "DeTokenizeDriversLicense";
        const string TOKENIZE_CALLER = "Azure";
        const string USERNAME = "AzureAdmin";
        private ITokenizerService _tokenizerService;
      
        private const string DETOKENIZE_DELAY = "DetokenizeDelay";       
        private int _detokenizeDelay = 0;
        public PIITokenizeHandler(ITokenizerService tokenizerService, ILogger<PIITokenizeHandler> logger = null)
        {
            _tokenizerService = tokenizerService;
            _logger = logger;         

            _detokenizeDelay = 0;
            if (Environment.GetEnvironmentVariable(DETOKENIZE_DELAY) != null)
            {
                _detokenizeDelay = Convert.ToInt32(Environment.GetEnvironmentVariable(DETOKENIZE_DELAY));
            }
        }

        public async Task<PIITokenizeResponse> Handle(PIITokenizeRequest request,  CancellationToken cancellationToken)
        {
            if (request.Detokenize)
            {
                IEnumerable<string> distinctIdentifiers = request.Items.ToList().Distinct();
                distinctIdentifiers = distinctIdentifiers.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
                var tempResult = new ConcurrentBag<TokenizeResult>();
                
                var startProcess = DateTime.Now;
                _logger?.LogInformation($"Detokenize process running in Parallelwith a {_detokenizeDelay} miilisecond delay....");
                Parallel.ForEach(distinctIdentifiers, dlvalue =>
                {
                    var token = DeTokenize(dlvalue, USERNAME, TOKENIZE_APPLICATION, TOKENIZE_CALLER, DETOKENIZE_APPCONTEXT);
                    tempResult.Add(token.Result);
                });               

                TimeSpan duration = DateTime.Now - startProcess;
                _logger?.LogInformation($"Detokenize process tool {duration.TotalSeconds} seconds to run....");
                var returnValue = tempResult.ToList();

                return await Task.FromResult(new PIITokenizeResponse { Results = returnValue });
            }
            else
            {
                IEnumerable<string> distinctIdentifiers = request.Items.ToList().Distinct();
                distinctIdentifiers = distinctIdentifiers.Where(s => !string.IsNullOrWhiteSpace(s)).ToList();
                var tempResult = new ConcurrentBag<TokenizeResult>();

                Parallel.ForEach(distinctIdentifiers, dlvalue =>
                {
                    var token = Tokenize(dlvalue, USERNAME, TOKENIZE_APPLICATION, TOKENIZE_CALLER, TOKENIZE_APPCONTEXT);
                    tempResult.Add(token.Result);
                });

                var returnValue = tempResult.ToList();

                return await Task.FromResult(new PIITokenizeResponse { Results = returnValue });
            }
           
        }

        private async Task<TokenizeResult> Tokenize(string rawDriversLicense, string userName, string application, string caller, string appContext)
        {
            try
            {
                var paddedDriversLicense = Pad(rawDriversLicense);
                var rq = new TokenizeServiceRq
                {
                    data = paddedDriversLicense,
                    requestedBy = userName,
                    application = application,
                    caller = caller,
                    applicationContext = appContext
                };
              
                var rs = await _tokenizerService.Tokenize(rq);
                if (rs.ResponseCode != ResponseCode.Success)
                {
                    return new TokenizeResult
                    {
                        Id = rawDriversLicense,
                        Status = false,
                        Token = null
                    };
                }
                else
                {
                    return new TokenizeResult
                    {
                        Id = rawDriversLicense,
                        Status = true,
                        Token = rs.data
                    };
                }

            }
            catch (Exception ex)
            {
                return new TokenizeResult
                {
                    Id = rawDriversLicense,
                    Status = false,
                    Exception = ex
                };
            }
        }

        private async Task<TokenizeResult> DeTokenize(string rawDriversLicense, string userName, string application, string caller, string appContext)
        {
            try
            {
                var paddedDriversLicense = Pad(rawDriversLicense);
                var rq = new TokenizeServiceRq
                {
                    data = paddedDriversLicense,
                    requestedBy = userName,
                    application = application,
                    caller = caller,
                    applicationContext = appContext
                };
                
                var rs = await _tokenizerService.DeTokenize(rq);
                if (string.IsNullOrEmpty(rs.data))
                {
                    _logger?.LogInformation($"DL# {paddedDriversLicense} Detokenized to blank");
                }
                if (_detokenizeDelay > 0)
                {                    
                    Thread.Sleep(_detokenizeDelay);
                }
               
                return new TokenizeResult
                {
                    Id = rawDriversLicense,
                    Status = true,
                    Token = rs.data
                };

            }
            catch (Exception ex)
            {
                return new TokenizeResult
                {
                    Id = rawDriversLicense,
                    Status = false,
                    Exception = ex
                };
            }
        }

        private static string Pad(string input)
        {
            if (string.IsNullOrEmpty(input))
            {
                throw new ArgumentNullException("input");
            }

            string output = string.Empty;
            output = input.Length < TOKEN_MINIMUM_LENGTH
                ? input.PadLeft(TOKEN_MINIMUM_LENGTH, PADDING_CHARACTER)
                : input;

            return output;
        }

    }
}
