﻿using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using AcordSubmissions.Domain.Interfaces;
using MediatR;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Application
{
    public class DuckXmlTableQueryHandler : IRequestHandler<DuckXmlTableQueryRequest, DuckXmlTableQueryResponse>
    {
        IRepository _storageClient;
        public DuckXmlTableQueryHandler(IRepository repository)
        {
            _storageClient = repository;
        }

        public async Task<DuckXmlTableQueryResponse> Handle(DuckXmlTableQueryRequest request, CancellationToken cancellationToken)
        {
            return await _storageClient.QueryDuckXml(request);            
        }
    }
}
