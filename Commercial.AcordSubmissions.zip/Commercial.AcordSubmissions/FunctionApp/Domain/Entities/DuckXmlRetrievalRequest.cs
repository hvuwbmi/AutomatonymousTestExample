﻿using MediatR;

namespace AcordSubmissions.Domain.Entities
{
    public class DuckXmlRetrievalRequest : IRequest<DuckXmlRetrievalResponse>
    {
        public string RowKey { get; set; }

    }
}
