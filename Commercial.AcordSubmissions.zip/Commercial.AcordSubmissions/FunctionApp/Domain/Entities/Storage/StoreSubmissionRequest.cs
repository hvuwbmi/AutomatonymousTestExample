﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StoreSubmissionRequest
    {
        public string EmailId { get; set; }
    }
}
