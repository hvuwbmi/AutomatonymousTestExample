﻿using AcordSubmissions.Domain.Entities.Enums;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class SubmissionEventsRequest : BaseSubmissionEventRequest
    {
        public int TotalCount { get; set; }
        public int Count { get; set; }
    }
}

