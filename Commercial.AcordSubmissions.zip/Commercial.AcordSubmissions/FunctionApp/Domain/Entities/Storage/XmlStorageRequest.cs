﻿using AcordSubmissions.Domain.Entities.Enums;
using MediatR;
using System.Xml;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class XmlStorageRequest : IRequest<XmlStorageResponse>
    {
        public XmlDocument Xml { get; set; }

        public string RowKey { get; set; }

        public XmlType XmlType { get; set; }

    }
}
