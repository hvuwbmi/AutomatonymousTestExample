﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StoreSubmissionEventsRequest : StoreSubmissionRequest
    {       
        public string Event { get; set; }

        public int Count { get; set; }
        public int TotalCount { get; set; }

        public string Status { get; set; }
        public string ErrorDescription { get; set; }
    }
}
