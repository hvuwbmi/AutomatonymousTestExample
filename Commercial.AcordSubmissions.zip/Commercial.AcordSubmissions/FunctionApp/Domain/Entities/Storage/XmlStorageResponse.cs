﻿namespace AcordSubmissions.Domain.Entities.Storage
{
    public class XmlStorageResponse : BaseResponse
    {       
       
    }
}
