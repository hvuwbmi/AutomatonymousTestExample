﻿using Dynamitey.DynamicObjects;
using System.Collections.Generic;
using System.Xml;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StorageRequest
    {
        public XmlDocument Xml { get; set; }
        public string Value { get; set; }
        public string PartitionKey { get; set; }
        public string RowKey { get; set; }
        public string BlobRowKey { get; set; }
        public string TableName { get; set; }
        public string BlobContainer { get; set; }
        public bool StoreTable { get; set; }
        public bool StoreBlob { get; set; }
        public bool CreateBlobWithNewRowKey { get; set; }

        // for data retrieval
        public Dictionary<string,string> QueryTableParameters { get; set; }
    }
}
