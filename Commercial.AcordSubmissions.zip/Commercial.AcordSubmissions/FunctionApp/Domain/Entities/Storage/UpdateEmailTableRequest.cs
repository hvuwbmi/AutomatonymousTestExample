﻿using MediatR;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class UpdateEmailTableRequest : IRequest<BaseResponse>
    {
        public string ConfidenceIndex { get; set; }

        public string RowKey { get; set; }

    }
}
