﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class SubmissionLOBEventsRequest : BaseSubmissionEventRequest
    {
        public string Target { get; set; }
        public string PolicyNumber { get; set; }

        public string LOBRowKey { get; set; }
    }
}
