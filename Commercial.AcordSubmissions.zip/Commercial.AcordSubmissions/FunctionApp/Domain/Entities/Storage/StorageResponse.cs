﻿using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StorageResponse : BaseResponse
    {
        public string Data { get; set; }
        public string RowKey { get; set; }

        // for table queries
        public Dictionary<string, string> QueryResults { get; set; }
        public List<DuckXmlSubmission> Submissions { get; set; }
    }
}
