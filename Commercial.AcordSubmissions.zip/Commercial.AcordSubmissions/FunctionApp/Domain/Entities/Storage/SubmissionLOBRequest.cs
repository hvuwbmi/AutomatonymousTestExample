﻿using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class SubmissionLOBRequest : BaseSubmissionEventRequest
    {
        public string LOB { get; set; }
    }
}
