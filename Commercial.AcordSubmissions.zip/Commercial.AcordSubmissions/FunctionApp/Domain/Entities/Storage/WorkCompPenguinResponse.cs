﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class WorkCompPenguinResponse
    {
        public string PolicyNumber { get; set; }
        public string CustomerNumber { get; set; }
    }
}
