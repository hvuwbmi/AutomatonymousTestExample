﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class BaseSubmissionEventRequest
    {
        public string EmailId { get; set; }
        public string Event { get; set; }
        public string Status { get; set; }
        public string ErrorDescription { get; set; }    
    }
}
