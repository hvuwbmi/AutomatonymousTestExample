﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StoreSubmissionLOBRequest : StoreSubmissionRequest
    {
        public string LOB { get; set; }
        
    }
}
