﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class SubmissionLOBResponse : BaseResponse
    {
        public string SubmissionLOBRowKey { get; set; }
    }
}
