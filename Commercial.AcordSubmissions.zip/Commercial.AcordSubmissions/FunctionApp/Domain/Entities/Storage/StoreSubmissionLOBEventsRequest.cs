﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Storage
{
    public class StoreSubmissionLOBEventsRequest : StoreSubmissionRequest
    {
        public string RowKey { get; set; }
        public string Event { get; set; }

        public string Status { get; set; }
        public string ErrorDescription { get; set; }

        public string Target { get; set; }
        public string PolicyNumber { get; set; }
    }
}
