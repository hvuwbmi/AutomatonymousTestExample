﻿namespace AcordSubmissions.Domain.Entities
{
    public class CommonLogServiceRs : BaseResponse
    {
        public bool Status { get; set; }
    }
}
