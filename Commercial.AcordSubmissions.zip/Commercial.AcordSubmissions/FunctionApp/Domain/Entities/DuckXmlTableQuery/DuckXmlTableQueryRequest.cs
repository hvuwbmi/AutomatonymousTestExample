﻿using MediatR;
using System;

namespace AcordSubmissions.Domain.Entities.DuckXmlTableQuery
{
    [Serializable]
    public class DuckXmlTableQueryRequest : IRequest<DuckXmlTableQueryResponse>
    {
        public string NumberOfRows { get; set; } //Page size
        public string SearchCriterion { get; set; }
        public string Page { get; set; }
    }
}
