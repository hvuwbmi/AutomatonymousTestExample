﻿namespace AcordSubmissions.Domain.Entities.DuckXmlTableQuery
{
    public class DuckXmlSubmission
    {
        public string RowKey { get; set; }
        public string Address { get; set; }
        public string AgencyName { get; set; }
        public string BusinessName { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string DateTime { get; set; }
        public string Zipcode { get; set; }
    }
}
