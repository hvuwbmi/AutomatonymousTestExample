﻿using System;
using System.Collections.Generic;
using Newtonsoft.Json;

namespace AcordSubmissions.Domain.Entities.DuckXmlTableQuery
{
    [Serializable]
    public class DuckXmlTableQueryResponse : BaseResponse
    {
        public int Total { get; set; }
        public int Start { get; set; }
        public int End { get; set; }
        [JsonProperty(PropertyName = "submission")]
        public List<DuckXmlSubmission> Submissions { get; set; }
   
    }
}
