﻿namespace AcordSubmissions.Domain.Entities.DuckXmlTableQuery
{
    public class JsonWrapper
    {
        public DuckXmlTableQueryResponse AcordSubmissions { get; set; }
    }
}
