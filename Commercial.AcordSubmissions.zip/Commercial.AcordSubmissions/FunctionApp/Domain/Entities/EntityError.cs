﻿using System.Collections.Generic;

namespace AcordSubmissions.Domain.Entities
{
    public class EntityError
    {
        public string Id { get; set; }

        public string Description { get; set; }

        public List<ValidationError> PropertyErrors { get; set; }
    }
}
