﻿namespace AcordSubmissions.Domain.Entities
{
    public class ValidationErrorsStorageResponse : BaseResponse
    {
        public string BlobRowKey { get; set; }
    }
}
