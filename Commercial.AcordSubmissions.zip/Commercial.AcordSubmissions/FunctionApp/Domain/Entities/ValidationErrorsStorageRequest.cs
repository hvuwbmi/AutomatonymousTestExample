﻿using AcordSubmissions.Domain.Entities.Enums;

namespace AcordSubmissions.Domain.Entities
{
    public class ValidationErrorsStorageRequest
    {
        public string AcordSubmissionRowKey { get; set; }
        public string ValidationErrorsData { get; set; }
        public string Type { get; set; }

    }
}
