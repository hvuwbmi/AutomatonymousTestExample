﻿using System;
using System.Net;
using Newtonsoft.Json;

namespace AcordSubmissions.Domain.Entities
{
    public enum ResponseCode
    {
        Success,
        Failure,
        Warning,
        BadRequest,
        ServerError
    }
    public class BaseResponse
    {
        [JsonIgnore]
        public ResponseCode ResponseCode { get; set; }
        public string Response { get; set; }

        public string ResponseMessage { get; set; }

        public Exception ExceptionResult { get; set; }

        public HttpStatusCode HttpStatusCode { get; set; }
    }
}
