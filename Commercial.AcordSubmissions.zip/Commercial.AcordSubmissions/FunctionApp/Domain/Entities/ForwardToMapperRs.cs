﻿using System.Net;

namespace AcordSubmissions.Domain.Entities
{
    public class ForwardToMapperRs : BaseResponse	
	{	
		public string ReturnValue { get; set; }		
	}
}
