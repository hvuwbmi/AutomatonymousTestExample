﻿namespace AcordSubmissions.Domain.Entities.DriverImportErrors
{
    public class RetrieveImportErrorsResponse : BaseResponse
    {
        public string ErrorsHtml { get; set; }
    }
}
