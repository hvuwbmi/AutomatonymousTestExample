﻿using MediatR;

namespace AcordSubmissions.Domain.Entities.DriverImportErrors
{
    public class RetrieveImportErrorsRequest : IRequest<RetrieveImportErrorsResponse>
    {
        public string RowKey { get; set; }

        public string Type { get; set; }
    }
}
