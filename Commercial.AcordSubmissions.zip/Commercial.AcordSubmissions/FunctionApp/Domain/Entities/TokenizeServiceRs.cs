﻿namespace AcordSubmissions.Domain.Entities
{
    public class TokenizeServiceRs : BaseResponse
    {
        public string data { get; set; }

    }
}
