﻿using System.Collections.Generic;

namespace AcordSubmissions.Domain.Entities
{
    public class PIITokenizeResponse
		{
				public List<TokenizeResult> Results { get; set; }
		}
}
