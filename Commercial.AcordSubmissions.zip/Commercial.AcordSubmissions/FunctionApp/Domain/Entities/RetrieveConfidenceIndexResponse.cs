﻿namespace AcordSubmissions.Domain.Entities
{
    public class RetrieveConfidenceIndexResponse : BaseResponse
    {
        public string ConfidenceIndex { get; set; }
    }
}
