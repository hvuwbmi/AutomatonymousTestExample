﻿namespace AcordSubmissions.Domain.Entities
{
    public class ValidationErrorsJsonWrapper
    {
        public ValidationErrors Errors { get; set; }
    }
}
