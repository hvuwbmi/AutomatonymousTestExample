﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities
{
    public class HttpClientErrorResponse
    {
        public string StatusCode { get; set; }
        public string Message { get; set; }
    }
}
