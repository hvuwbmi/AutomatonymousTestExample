﻿namespace AcordSubmissions.Domain.Entities
{
    public class TokenizeServiceRq
    {
        public string scheme
        {
            get
            {
                return "DriversLicense";
            }

        }

        public string data { get; set; }

        public string requestedBy { get; set; }

        public string application { get; set; }

        public string caller { get; set; }

        public string applicationContext { get; set; }
    }
}
