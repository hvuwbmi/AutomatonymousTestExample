﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Xml;

namespace AcordSubmissions.Domain.Entities
{
    public class AcordXmlTokenizePIResponse : BaseResponse
    {
        public XmlDocument AcordXml { get; set; }
        public string Division { get; set; }
        public string EmailRowKey { get; set; }
        public string ConfidenceIndex { get; set; }
        public string BusinessName { get; set; }
        public bool SubmitToPenguin { get; set; }
    }
}
