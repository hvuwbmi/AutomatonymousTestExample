﻿using System;

namespace AcordSubmissions.Domain.Entities
{
    public class TokenizeResult
    {
				public string Id { get; set; }
				public bool Status { get; set; }
        public Exception Exception { get; set; }
        public string Token { get; set; }
    }
}
