﻿using MediatR;

namespace AcordSubmissions.Domain.Entities
{
    public class RetrieveConfidenceIndexRequest : IRequest<RetrieveConfidenceIndexResponse>
    {
        public string RowKey { get; set; }
    }
}
