﻿using System.Collections.Generic;

namespace AcordSubmissions.Domain.Entities
{
    public class ValidationErrors
    {        
        public List<EntityError> EntityErrors { get; set; }
    }
}
