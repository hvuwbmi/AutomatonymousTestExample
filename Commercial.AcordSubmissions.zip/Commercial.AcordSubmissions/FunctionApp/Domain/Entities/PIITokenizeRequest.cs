﻿using System.Collections.Generic;
using MediatR;

namespace AcordSubmissions.Domain.Entities
{
    public class PIITokenizeRequest : IRequest<PIITokenizeResponse>
	{
        public IEnumerable<string> Items { get; set; }
        public bool Detokenize { get; set; }
    }
}
