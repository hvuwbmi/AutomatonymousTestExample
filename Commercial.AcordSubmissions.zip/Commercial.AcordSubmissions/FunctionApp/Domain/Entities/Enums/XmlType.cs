﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Enums
{
    public enum XmlType
    {
        Acord,
        Duck
    }
}
