﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Enums
{
    public enum SubmissionEventType
    {
        SubmissionEvent,
        SubmissionLOB,
        SubmissionLOBEvent
    }
}
