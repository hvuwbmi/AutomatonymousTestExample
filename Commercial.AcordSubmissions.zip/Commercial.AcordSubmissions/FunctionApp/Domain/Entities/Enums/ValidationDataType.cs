﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities.Enums
{
    public class ValidationDataType
    {
        public const string DriverType = "Drivers";
        public const string VehicleType = "Vehicles";
    }
}
