﻿using MediatR;
using System.Xml;

namespace AcordSubmissions.Domain.Entities
{
		public class AcordXmlTokenizePIIRequest : IRequest<AcordXmlTokenizePIResponse>
		{
				public XmlDocument AcordXml { get; set; }
		}
}
