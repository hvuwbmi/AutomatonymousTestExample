﻿using System.Xml;
using MediatR;

namespace AcordSubmissions.Domain.Entities
{
    public class ForwardToMapperRq : IRequest<ForwardToMapperRs>
	{	
		public XmlDocument AcordXml { get; set; }
		public XmlDocument XmlToMap { get; set; }
		public string Division { get; set; }
		public string EmailRowKey { get; set; }
		public string ConfidenceIndex { get; set; }
		public string BusinessName { get; set; }
		public string LOB { get; set; }
		public bool UseWbmiTransforms { get; set; }
	}
}
