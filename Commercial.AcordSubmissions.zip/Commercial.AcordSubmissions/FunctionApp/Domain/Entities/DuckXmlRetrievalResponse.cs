﻿namespace AcordSubmissions.Domain.Entities
{
    public class DuckXmlRetrievalResponse : BaseResponse
    {
        public string DuckXml { get; set; }

    }
}
