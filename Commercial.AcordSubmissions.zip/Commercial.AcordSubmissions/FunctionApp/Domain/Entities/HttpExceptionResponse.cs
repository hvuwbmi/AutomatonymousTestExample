﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Domain.Entities
{
    public class HttpExceptionResponse
    {
        public string Message { get; set; }

        public string ExceptionMessage { get; set; }

        public string ExceptionType { get; set; }
        public string StackTrace { get; set; }
    }
}
