﻿namespace AcordSubmissions.Domain.Entities
{
    public class ValidationError
    {
        public string IdRef { get; set; }
        public string PropertyName { get; set; }        
        public string ErrorType { get; set; }
        
        public string AdditionalInfo { get; set; }
        public string Message { get; set; }

        public string LabelText { get; set; }
    }
}
