﻿using AcordSubmissions.Domain.Entities;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface ITokenizerService
    {
        Task<TokenizeServiceRs> Tokenize(TokenizeServiceRq rq);

        Task<TokenizeServiceRs> DeTokenize(TokenizeServiceRq rq);
    }
}
