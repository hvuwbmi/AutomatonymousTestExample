﻿using AcordSubmissions.Domain.Entities;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface ICommonLogService
    {
        Task<BaseResponse> CommonLog(CommonLogServiceRq rq);
    }
}
