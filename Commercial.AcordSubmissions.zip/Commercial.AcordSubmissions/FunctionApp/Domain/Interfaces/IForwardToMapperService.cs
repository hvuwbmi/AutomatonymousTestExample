﻿using AcordSubmissions.Domain.Entities;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface IForwardToMapperService
    {				
        Task<ForwardToMapperRs> Submit(ForwardToMapperRq request);
    }
}
