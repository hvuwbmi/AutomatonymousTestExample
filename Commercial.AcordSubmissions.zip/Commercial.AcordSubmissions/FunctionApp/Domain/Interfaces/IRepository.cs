﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.DriverImportErrors;
using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using AcordSubmissions.Domain.Entities.Storage;
using AcordSubmissions.Domain.Entities.UpdateSubmissionEmail;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface IRepository
    {
        Task<XmlStorageResponse> StoreXml(XmlStorageRequest request);        

        Task<DuckXmlTableQueryResponse> QueryDuckXml(DuckXmlTableQueryRequest request);        

        Task<BaseResponse> StoreSubmissionEvents(SubmissionEventsRequest request);

        Task<SubmissionLOBResponse> StoreSubmissionLOB(SubmissionLOBRequest request);

        Task<BaseResponse> StoreSubmissionLOBEvents(SubmissionLOBEventsRequest request);

        Task<RetrieveImportErrorsResponse> RetrieveDuckUploadValidationErrors(RetrieveImportErrorsRequest request);
       
        Task<BaseResponse> UpdateConfidenceIndex(UpdateEmailTableRequest request);

        Task<RetrieveConfidenceIndexResponse> RetrieveConfidenceIndex(RetrieveConfidenceIndexRequest request);

    }
}
