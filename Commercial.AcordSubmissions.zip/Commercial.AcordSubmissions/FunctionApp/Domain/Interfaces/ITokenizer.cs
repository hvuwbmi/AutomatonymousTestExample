﻿using AcordSubmissions.Domain.Entities;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface ITokenizer
    {
        Task<Dictionary<string, TokenizeResult>> Tokenize(List<string> identifiers);
    }
}
