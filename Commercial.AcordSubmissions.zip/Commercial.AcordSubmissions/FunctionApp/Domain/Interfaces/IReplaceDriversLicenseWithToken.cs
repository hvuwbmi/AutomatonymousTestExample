﻿using Microsoft.Extensions.Logging;
using System.Threading.Tasks;

namespace AcordSubmissions.Domain.Interfaces
{
    public interface IReplaceDriversLicenseWithToken
    {
        Task<string> Replace(string xml);
    }
}
