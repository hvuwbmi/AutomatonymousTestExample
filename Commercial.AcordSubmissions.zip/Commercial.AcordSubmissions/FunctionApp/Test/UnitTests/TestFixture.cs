﻿using AcordSubmissions.Application;
using AcordSubmissions.Domain.Interfaces;
using AcordSubmissions.Infrastructure.CommonLogService;
using AcordSubmissions.Infrastructure.ForwardToPenguinService;
using AcordSubmissions.Infrastructure.Functions.Clients;
using AcordSubmissions.Infrastructure.StorageService;
using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Reflection;
using System.Text;

namespace AcordSubmissions.Test.UnitTest
{
    public class TestFixture
    {
        private static ServiceProvider _provider;

        static TestFixture()
        {
            var services = new ServiceCollection();
            Configure(services);

            _provider = services.BuildServiceProvider();
        }

        public static void SetControllerContext(ControllerBase controller)
        {
            controller.ControllerContext = new ControllerContext
            {
            };
        }

        public static T GetInstance<T>()
        {
            T result = _provider.GetRequiredService<T>();
            ControllerBase controllerBase = result as ControllerBase;
            if (controllerBase != null)
            {
                SetControllerContext(controllerBase);
            }
            return result;

        }

        public static ServiceCollection Configure(IServiceCollection services)
        {
            services.AddMediatR(typeof(AcordXmlTokenizePIIHandler).GetTypeInfo().Assembly);
            services.AddSingleton<IRepository, StorageClient>();
            services.AddSingleton<ILoggerFactory, LoggerFactory>();
            services.AddSingleton(typeof(ILogger<>), typeof(Logger<>));

            services.AddHttpClient<IForwardToMapperService, ForwardToMapperServiceClient>(client =>
            {
                client.BaseAddress = new Uri("https://qa-api.wbmi.com");
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");
            });

            services.AddHttpClient<ITokenizerService, TokenizerServiceClient>(client =>
            {
                client.BaseAddress = new Uri("https://qa-api.wbmi.com");
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");
            });

            services.AddHttpClient<ICommonLogService, CommonLogServiceClient>(client =>
            {
                client.BaseAddress = new Uri("https://qa-api.wbmi.com");
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");
            });
           
            return (ServiceCollection)services;

        }
    }
}
