﻿using Microsoft.Azure.Cosmos.Table;

namespace AcordSubmissions.Test.UnitTest.Model
{
    public class DuckXmlTable : TableEntity
    {
        public string BusinessName { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public string Zipcode { get; set; }
        public string AgencyName { get; set; }
        public string BlobStorageKey { get; set; }
    }


}
