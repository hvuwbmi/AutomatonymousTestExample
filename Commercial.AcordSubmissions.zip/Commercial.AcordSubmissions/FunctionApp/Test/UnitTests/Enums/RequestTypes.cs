﻿using System;

namespace AcordSubmissions.Test.UnitTest.Enums
{
    // The [Flags] attribute sets this enum to be used like a set of flags
    // RequestTypes.Package | RequestTypes.WorkComp = 0b101
    // Docs: https://docs.microsoft.com/en-us/dotnet/api/system.flagsattribute?view=netcore-3.1
    [Flags]
    public enum RequestTypes
    {
        None = 0,                                   // 0b00000000
        Package = 1,                                // 0b00000001
        Auto = 2,                                   // 0b00000010
        WorkComp = 4,                               // 0b00000100
        PackageAndWorkComp = Package | WorkComp,    // 0b00000101
        AutoAndWorkComp = Auto | WorkComp,          // 0b00000110
    }

    public static class RequestTypesExtensions
    {

        public static int GetDuckRouteCount(this RequestTypes types)
        {
            return (types & (RequestTypes.Auto | RequestTypes.Package)).GetRequestCount();
        }

        public static int GetPenguinRouteCount(this RequestTypes types)
        {
            return (types & (RequestTypes.WorkComp)).GetRequestCount();
        }

        public static int GetRequestCount(this RequestTypes types)
        {
            int iCount = 0;

            // Loop while types is not zero
            while (types != RequestTypes.None)
            {
                // Decrement types by 1
                types &= types - 1;

                iCount++;
            }
            return iCount;
        }
    }
}
