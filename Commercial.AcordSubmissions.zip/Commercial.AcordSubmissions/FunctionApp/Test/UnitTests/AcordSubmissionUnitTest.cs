using AcordSubmissions.Application;
using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using FluentAssertions;
using Moq;
using System;
using System.Collections.Generic;
using Xunit;
using System.Threading;

namespace AcordSubmissions.Test.UnitTest
{
    public class UnitTest1
    {
        //[Fact]
        //public async void AcordXmlTokenizePIIHandler_SuccessTest()
        //{
        //    // Arrange
        //    const string xmlIn = "<xml><LicensePermitNumber>1</LicensePermitNumber><LicensePermitNumber>2</LicensePermitNumber></xml>";
        //    var xmlDocIn = new XmlDocument();
        //    xmlDocIn.LoadXml(xmlIn);
        //    const string xmlOut = "<xml><LicensePermitNumber>A</LicensePermitNumber><LicensePermitNumber>B</LicensePermitNumber></xml>";
        //    var forwardToPenguinServiceMock = new Mock<IForwardToPenguinService>();
        //    forwardToPenguinServiceMock.Setup(x => x.Submit(xmlIn)).Returns(Task.FromResult(xmlOut));
        //    var CommonLogServiceMock = new Mock<ICommonLogS>();
        //    forwardToPenguinServiceMock.Setup(x => x.Submit(xmlIn)).Returns(Task.FromResult(xmlOut));

        //    var mockResponse = new PIITokenizeResponse
        //    {
        //        Results = new List<TokenizeResult>
        //                    {
        //                            { new TokenizeResult { Id = "1", Status = true, Token = "A" } },
        //                            { new TokenizeResult { Id = "2", Status = true, Token = "B" } }
        //                    }
        //    };
        //    var mockTaskResponse = Task.FromResult(mockResponse);

        //    var mediatorMock = new Mock<IMediator>();
        //    mediatorMock.Setup(x => x.Send(It.IsAny<PIITokenizeRequest>(), It.IsAny<CancellationToken>())).Returns(mockTaskResponse);
        //    //<-- return Task to allow await to continue
        //    //.Verifiable("Notification was not sent.");


        //    // Act
        //    var sut = new AcordXmlTokenizePIIHandler(mediatorMock.Object, forwardToPenguinServiceMock.Object);
        //    var response = await sut.Handle(new AcordXmlTokenizePIIRequest { AcordXml = xmlDocIn }, new CancellationToken());

        //    // Assert
        //    response.Should().NotBeNull();
        //    response.TokenizedAcordXml.OuterXml.Should().Be(xmlOut);
        //}

        //[Fact]
        //public async void AcordXmlTokenizePIIHandler_FailureTest()
        //{
        //    const string xmlIn = "<xml><LicensePermitNumber>1</LicensePermitNumber><LicensePermitNumber>2</LicensePermitNumber></xml>";
        //    var xmlDoc = new XmlDocument();
        //    xmlDoc.LoadXml(xmlIn);
        //    const string xmlOut = "<xml><LicensePermitNumber></LicensePermitNumber><LicensePermitNumber></LicensePermitNumber></xml>";

        //    // create mock forward to penguin service
        //    var forwardToPenguinServiceMock = new Mock<IForwardToPenguinService>();
        //    forwardToPenguinServiceMock.Setup(x => x.Submit(xmlIn)).Returns(Task.FromResult(xmlOut));


        //    // build the mediator
        //    var mockResponse = new PIITokenizeResponse
        //    {
        //        Results = new List<TokenizeResult>
        //                {
        //                    {new TokenizeResult{Id = "1",Status = false, Exception = new Exception(), Token = null} },
        //                    {new TokenizeResult{Id = "2", Status = false, Exception = new Exception(), Token = null} }
        //                }
        //    };

        //    var mockTaskResponse = Task.FromResult(mockResponse);

        //    var mediatorMock = new Mock<IMediator>();
        //    mediatorMock.Setup(x => x.Send(It.IsAny<PIITokenizeRequest>(), It.IsAny<CancellationToken>())).Returns(mockTaskResponse);
        //    //


        //    // call to handler
        //    var sut = new AcordXmlTokenizePIIHandler(mediatorMock.Object, forwardToPenguinServiceMock.Object);
        //    var response = await sut.Handle(new AcordXmlTokenizePIIRequest { AcordXml = xmlDoc }, new CancellationToken());

        //    response.Should().NotBeNull();
        //    response.TokenizedAcordXml.OuterXml.Should().Be(xmlOut);
        //}

        //[Fact]
        //public async void AcordXmlTokenizePIIHandler_SuccessAndFailureTest()
        //{
        //    const string xmlIn = "<xml><LicensePermitNumber>1</LicensePermitNumber><LicensePermitNumber>2</LicensePermitNumber></xml>";
        //    var xmlDoc = new XmlDocument();
        //    xmlDoc.LoadXml(xmlIn);
        //    const string xmlOut = "<xml><LicensePermitNumber>A</LicensePermitNumber><LicensePermitNumber></LicensePermitNumber></xml>";

        //    // create mock forward to penguin service
        //    var forwardToPenguinServiceMock = new Mock<IForwardToPenguinService>();
        //    forwardToPenguinServiceMock.Setup(x => x.Submit(xmlIn)).Returns(Task.FromResult(xmlOut));


        //    // build the mediator
        //    var mockResponse = new PIITokenizeResponse
        //    {
        //        Results = new List<TokenizeResult>
        //                {
        //                    {new TokenizeResult{Id = "1",Status = true, Exception = null, Token = "A"} },
        //                    {new TokenizeResult{Id = "2", Status = false, Exception = new Exception(), Token = null} }
        //                }
        //    };

        //    var mockTaskResponse = Task.FromResult(mockResponse);

        //    var mediatorMock = new Mock<IMediator>();
        //    mediatorMock.Setup(x => x.Send(It.IsAny<PIITokenizeRequest>(), It.IsAny<CancellationToken>())).Returns(mockTaskResponse);
        //    //


        //    // call to handler
        //    var sut = new AcordXmlTokenizePIIHandler(mediatorMock.Object, forwardToPenguinServiceMock.Object);
        //    var response = await sut.Handle(new AcordXmlTokenizePIIRequest { AcordXml = xmlDoc }, new CancellationToken());

        //    response.Should().NotBeNull();
        //    response.TokenizedAcordXml.OuterXml.Should().Be(xmlOut);
        //}

        [Fact]
        public void PIITokenizeHander_SuccessTest()
        {
            // Arrange
            var tokenizerServiceMock = new Mock<ITokenizerService>();
            tokenizerServiceMock.Setup(x => x.Tokenize(It.IsAny<TokenizeServiceRq>())).ReturnsAsync(new TokenizeServiceRs { data = Guid.NewGuid().ToString() });
            // Act
            var sut = new PIITokenizeHandler(tokenizerServiceMock.Object);
            var response = sut.Handle(new PIITokenizeRequest { Items = new List<string> { "1", "2" } }, new CancellationToken());

            // Assert
            response.Should().NotBeNull();
            response.Result.Results.Should().HaveCount(2);
            response.Result.Results.Find(x => x.Id == "@@@@@@@1").Token.Should().HaveLength(36);
        }

        //  [Fact]
        //  public void PrivateMethod_Sample()
        //  {
        //// Arrange
        //var iAcordSubmissionCallsMock = new Mock<IForwardToPenguinService>();
        //var iTokenizerMock = new Mock<ITokenizer>();

        //var type = typeof(AcordXmlTokenizePIIHandler);
        //var tokenizer = Activator.CreateInstance(type, iAcordSubmissionCallsMock.Object, iTokenizerMock.Object);
        //var method = type.GetMethods(BindingFlags.NonPublic | BindingFlags.Instance)
        //		.Where(m => m.Name == "ExtractDriversLicenses" && m.IsPrivate)
        //		.First();
        //		var xml = new XmlDocument();
        //		xml.LoadXml("<xml/>");
        //// Act
        //var result = (List<string>)method.Invoke(tokenizer, new object[] { xml });
        //// Assert
        //result.Should().Equal(new List<string>()); 
        //  }

        [Theory]
        [InlineData(2, 2, 4)]
        [InlineData(0, 0, 0)]
        [InlineData(int.MinValue, -1, int.MaxValue)]
        public void SomeTheoryTest(int x, int y, int expected)
        {
            Assert.Equal(expected, x + y);
        }
    }
}
