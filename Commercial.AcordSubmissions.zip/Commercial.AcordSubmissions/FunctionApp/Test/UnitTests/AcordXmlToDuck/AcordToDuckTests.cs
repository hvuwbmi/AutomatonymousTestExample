﻿using System;
using System.Text;
using Xunit;
using System.Net.Http;
using System.Xml;
using Newtonsoft.Json.Linq;
using Microsoft.Data.SqlClient;
using System.Data;
using Org.XmlUnit.Builder;
using Xunit.Abstractions;
using System.Threading.Tasks;

namespace AcordSubmissions.Test.UnitTest.AcordToDuckXml
{
    public class AcordToDctValidationTest
    {
        private static HttpClient _httpClient;
        private readonly string _apiRouteWC = "/commercial/acord-private/api/v1/import/agencyport";
        private readonly string _apiRoute = "/commercial/acord-transformation-private/transform";
        private readonly ITestOutputHelper output;

        public AcordToDctValidationTest(ITestOutputHelper output)
        {
            this.output = output;
        }

        #region WorkCompTests

        [Theory]
        [InlineData("ForgingsAndStampingsAcordXml.xml", "WorkComp", "ForgingsAndStampingsDctBaselineQA.xml")]
        public async void WorkComp_Forgings_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, true, GetWorkCompDctXmlFromResponseBody, dir);
        }

        [Theory]
        [InlineData("InterialMorrisonAcordXml.xml", "WorkComp", "InterialMorrisonDctBaselineQA.xml")]
        public async void WorkComp_InterialMorrison_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, true, GetWorkCompDctXmlFromResponseBody, dir);
        }

        [Theory]
        [InlineData("AmerequipHickoryAcordXml.xml", "WorkComp", "AmerequipHickoryDctBaselineQA.xml")]
        public async void WorkComp_AmerequipHickory_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, true, GetWorkCompDctXmlFromResponseBody, dir);
        }

        #endregion

        #region PackageTests

        [Theory]
        [InlineData("ProvidenceDriverAcordXml.xml", "Driver", "ProvidenceDctBaselineQA.xml")]
        public async void Package_Providence_Driver_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, false, GetPackageDctXmlFromResponseBody, dir);
        }

        [Theory]
        [InlineData("OctopusVehicleAcordXml.xml", "Vehicle", "OctopusVehicleDctBaselineQA.xml")]
        public async void Package_Octopus_Vehicle_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, false, GetPackageDctXmlFromResponseBody, dir);
        }


        [Theory]
        [InlineData("ShesEletricContractorsEquipmentAcordXml.xml", "ContractorsEquipment", "ShesEletricContractorsEquipmentDctBaseline.xml")]
        public async void Package_ShesEletric_ContractorsEquipment_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, false, GetPackageDctXmlFromResponseBody, dir);
        }

        [Theory]
        [InlineData("ParadigmResidentialContractingAcordXml.xml", "Location", "ParadigmResidentialContractingDctBaseline.xml")]
        public async void Package_ParadigmResidentialContracting_Locations_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, false, GetPackageDctXmlFromResponseBody, dir);
        }
        #endregion

        #region Auto
        [Theory]
        [InlineData("StickShiftAutoMonoAcordXml.xml", "Auto", "StickShiftAutoMonoDctBaseline.xml")]
        public async void Auto_StickShift_TestAsync(string acordgoldenXml, string name, string baselineDuck)
        {
            var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            await TestWrapperAsync(acordgoldenXml, name, baselineDuck, false, GetPackageDctXmlFromResponseBody, dir);
        }


        #endregion

        #region TestWrappers

        private async Task TestWrapperAsync(string acordgoldenXml, string name, string baselineDuck, bool useWCRoute, GetDctXml getDctXml, string dir)
        {
            //Load in the AcordXml
            //var dir = Environment.CurrentDirectory + @"\TestData\AcordXml\";
            var acordXml = new XmlDocument();
            acordXml.Load(dir + acordgoldenXml);

            //Load baseline duck xml
            var baseXml = new XmlDocument();
            baseXml.Load(dir + baselineDuck);

            string apiRoute = useWCRoute ? _apiRouteWC : _apiRoute;
            var rq = new HttpRequestMessage(HttpMethod.Post, apiRoute);
            var result = await TransformXmlRequest(acordXml, rq);

            //grab json response
            var rsBody = await result.Content.ReadAsStringAsync();

            //checks if api call was a success
            if (result.IsSuccessStatusCode)
            {
                //Compare Xml Nodes
                var dctXml = getDctXml(rsBody);
                CompareXml(dctXml, name, baseXml);
            }
        }

        private Task<HttpResponseMessage> TransformXmlRequest(XmlDocument acordXml, HttpRequestMessage rq)
        {
            //Set up HttpClient to make call to acord api with acordXml
            _httpClient = new HttpClient
            {
                //BaseAddress = new Uri("https://dev-api.wbmi.com/")
                BaseAddress = new Uri("https://qa-api.wbmi.com/"),

            };
            //_httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "70f322c158f14fc1a997aa9d6c8c2e71");//dev
            _httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");//qa
            //var rq = new HttpRequestMessage(HttpMethod.Post, _apiRoute);
            rq.Content = new StringContent(acordXml.OuterXml, Encoding.UTF8, "application/xml");
            _httpClient.Timeout = TimeSpan.FromMinutes(30);
            //make http call
            return _httpClient.SendAsync(rq);
        }

        #endregion

        #region GetDuckXmlFromResponseBody

        private delegate XmlDocument GetDctXml(string responseBody);

        private XmlDocument GetPackageDctXmlFromResponseBody(string responseBody)
        {
            XmlDocument xml = new XmlDocument();
            xml.LoadXml(responseBody);
            return xml;
        }

        private XmlDocument GetWorkCompDctXmlFromResponseBody(string responseBody)
        {
            JObject obj = JObject.Parse(responseBody);
            JToken policyNumToken = obj["policyNumber"];
            output.WriteLine("Policy Number: " + policyNumToken.ToString());

            // Grab Duck Xml from db
            return GetPolicyXmlFromDb(policyNumToken.ToString());
        }

        #endregion

        #region CompareXmlNodes

        private void CompareXml(XmlDocument dctXml, string name, XmlDocument baseXml)
        {
            Assert.True(AccountNode(dctXml, baseXml));
            Assert.True(AgencyDetailsNode(dctXml, baseXml));
            Assert.True(PolicyLineNode(dctXml, baseXml));
            Assert.True(EffectiveExpirationDateNode(dctXml, name));
        }

        public bool AccountNode(XmlNode dctXml, XmlNode baseXml)
        {
            //Compare duck xml from response to baseline
            //Compare account page
            var currentAccount = dctXml.SelectSingleNode("//account");
            var baselineAccount = baseXml.SelectSingleNode("//account");
            output.WriteLine("Account Node");
            return CompareNode(currentAccount, baselineAccount);
        }

        public bool AgencyDetailsNode(XmlNode dctXml, XmlNode baseXml)
        {
            //Compare Agency Details
            var currentAgency = dctXml.SelectSingleNode("//agencyDetails");
            var baselineAgency = baseXml.SelectSingleNode("//agencyDetails");
            output.WriteLine("Agency Details Node");
            return CompareNode(currentAgency, baselineAgency);
        }

        public bool PolicyLineNode(XmlNode dctXml, XmlNode baseXml)
        {
            //Compare policy/line Info
            var currentPolicyLineInfo = dctXml.SelectSingleNode("//policy/line");
            var baselinePolicyLineInfo = baseXml.SelectSingleNode("//policy/line");
            output.WriteLine("policy/line Node");
            return CompareNode(currentPolicyLineInfo, baselinePolicyLineInfo);
        }

        public bool EffectiveExpirationDateNode(XmlNode dctXml, string name)

        {
            //Compare policy/EffectiveDate
            var currentEffectiveDate = dctXml.SelectSingleNode("//policy/EffectiveDate").InnerText;
            output.WriteLine("policy/EffectiveDate Node");
            bool pass = false;
            if (name == "WorkComp")
            {
                pass = Convert.ToDateTime(currentEffectiveDate) >= DateTime.Today;

            }
            else
            {
                pass = true;
            }


            if (pass)
            {
                //Compare policy/ExpirationDate
                var currentExpirationDate = dctXml.SelectSingleNode("//policy/ExpirationDate").InnerText;
                output.WriteLine("policy/ExpirationDate Node");
                return Convert.ToDateTime(currentExpirationDate) == (Convert.ToDateTime(currentEffectiveDate).AddYears(1));
            }
            return pass;
        }

        private bool CompareNode(XmlNode dctXml, XmlNode baseXml)
        {
            var diffbuilder = DiffBuilder.Compare(baseXml).WithTest(dctXml)
                .WithAttributeFilter(a => a.Equals("id"))
                .WithNodeFilter(n => !(n.Name.Equals("LastVerified") ||
                                        n.Name.Equals("AvailableNumberIDForNumber") ||
                                        n.Name.Equals("OverriddenDate") ||
                                        n.Name.Equals("ClearedDateTimeStamp") ||
                                        n.Name.Equals("dValue") ||
                                        n.Name.Equals("TempLocationId") ||
                                        n.Name.Equals("LineStateID") ||
                                        n.Name.Equals("LocationID") ||
                                        n.Name.Equals("AdditionalInterestsID") ||
                                        n.Name.Equals("NCCIID") ||
                                        n.Name.Equals("SubscriptionDate") ||
                                        n.Name.Equals("EligibilityDate") ||
                                        n.Name.Equals("Period") ||
                                        n.Name.Equals("ExperienceModEffectiveDateDefault") ||
                                        n.Name.Equals("PendingRateChangeEffectiveDateDefault") ||
                                        n.Name.Equals("QLMPSubscriptionDateDefault") ||
                                        n.Name.Equals("QLMPEligibilityDateDefault") ||
                                        n.Name.Equals("NormalAnniversaryRatingDay") ||
                                        n.Name.Equals("PeriodEndDate") ||
                                        n.Name.Equals("PeriodStartDate") ||
                                        n.Name.Equals("sValue") ||
                                        n.Name.Equals("TransactionIDWhenAdded")))
                 .Build();

            if (diffbuilder.HasDifferences())
            {
                foreach (var diff in diffbuilder.Differences)
                {
                    output.WriteLine(diff.Comparison.ToString() + Environment.NewLine);
                }
            }
            return !diffbuilder.HasDifferences();
        }

        #endregion

        private XmlDocument GetPolicyXmlFromDb(string policyNum)
        {
            string connectionString = "";
            //qa
            connectionString = "Data Source=172.17.0.4,50690;User ID=ATest01SQL; Password=Cc7uCwzBH8; Initial Catalog=ExampleData";
            //dev
            //connectionString = "Data Source=172.17.3.140,51455;User ID=dctsqluser; Password=orange#5; Initial Catalog=ExampleData";

            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = new SqlCommand("SELECT TOP 1 CAST(DECOMPRESS(ZippedXML) AS XML) from history with(nolock) where policyNumber = @policyNum ORDER BY TransactionDate DESC", connection);
            command.Parameters.Add(new SqlParameter("@policyNum", policyNum));
            command.CommandTimeout = 300;

            connection.Open();

            SqlDataAdapter adapter = new SqlDataAdapter(command);
            DataSet data = new DataSet();

            adapter.Fill(data);

            connection.Close();

            string policy = data.Tables[0].Rows[0].ItemArray[0].ToString();

            XmlDocument doc = new XmlDocument();
            doc.LoadXml(policy);
            return doc;
        }

    }
}
