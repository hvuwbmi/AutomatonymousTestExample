﻿using Microsoft.Data.SqlClient;
using System;
using System.Data;

namespace AcordSubmissions.Test.UnitTest
{
    public static class DatabaseManager
    {
        //ToDo - Figure out configuration to handle testing different environments
        private const string _connString = "Data Source=172.17.0.4,50690;User ID=ATest01SQL; Password=Cc7uCwzBH8;Initial Catalog=ExampleIDORealtime";
        private static string ExampleIDOConnectionString
        {
            get { return _connString; }
        }

        public static DataSet GetExampleIDORealtimePoliciesSinceTime(string name, DateTime startTime)
        {
            string queryString = "SELECT dcparty.Name, wbpolicy.* " +
                                 "FROM[ExampleIDORealtime].[dbo].[WBView_DC_PartyAssociation_LatestSession] partyassociation WITH(NOLOCK) " +
                                 "JOIN[ExampleIDORealtime].[dbo].[DC_Party] dcparty WITH(NOLOCK) on partyassociation.PartyId = dcparty.PartyId " +
                                 "JOIN[ExampleIDORealtime].[dbo].[WB_Policy] wbpolicy WITH(NOLOCK) on partyassociation.PolicyId = wbpolicy.PolicyId " +
                                 "WHERE wbpolicy.ClearedIdentificationDateTimeStamp > @startTime " +
                                 "AND dcparty.Name LIKE '%' + @name + '%' " +
                                 "ORDER BY ClearedIdentificationDateTimeStamp DESC";
            using (var dataSet = new DataSet())
            {
                using (var connection = new SqlConnection(ExampleIDOConnectionString))
                {
                    using (var command = new SqlCommand(queryString, connection))
                    {
                        command.Parameters.Add(new SqlParameter("startTime", startTime));
                        command.Parameters.Add(new SqlParameter("name", name));
                        command.Connection.Open();

                        using (var adapter = new SqlDataAdapter(command))
                        {
                            adapter.Fill(dataSet);
                        }
                        command.Connection.Close();

                    }
                }

                return dataSet;
            }
        }
    }
}
