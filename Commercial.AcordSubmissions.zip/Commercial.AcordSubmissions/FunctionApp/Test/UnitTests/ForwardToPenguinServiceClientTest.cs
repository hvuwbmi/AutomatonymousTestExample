﻿using System;
using System.Net.Http;
using AcordSubmissions.Infrastructure.ForwardToPenguinService;
using Xunit;

namespace AcordSubmissions.Test.UnitTest
{
    public class ForwardToPenguinServiceClientTest
    {
        private static HttpClient _httpClient;
        static ForwardToPenguinServiceClientTest()
        {
            _httpClient = new HttpClient
            {
                BaseAddress = new Uri("https://dev-api.wbmi.com/"),
            };
            _httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "70f322c158f14fc1a997aa9d6c8c2e71");
        }

        [Fact]
        public async void SuccessTest()
        {
            var client = new ForwardToPenguinServiceClient(_httpClient);
            //var response = await client.Submit(AcordXMLHelper.GetAcordXML());
            //response.Should().NotBeNull();
        }
    }
}


