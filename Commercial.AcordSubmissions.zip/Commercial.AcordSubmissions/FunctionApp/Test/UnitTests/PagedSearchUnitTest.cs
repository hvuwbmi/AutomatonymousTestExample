using FluentAssertions;
using AcordSubmissions.Infrastructure.StorageService.PagedSearch;
using System.Collections.Generic;
using System.Linq;
using Xunit;

namespace PagedSearchTests
{
    public class PagedSearchUnitTest
	{
		[Fact]
		public void SingleSearchValueTest()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "F", C = "G", D = "H"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = "A" },
				PageSize = 10,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var deleg = ExpressionBuilder.GetAnyExpression<TestObj>(rq.Filters, rq.Columns);
			var result = data.AsQueryable().Where(deleg).Skip(rq.Start).Take(rq.PageSize).ToList();
			result.Should().HaveCount(1);
			result[0].A.Should().Be("A");
		}

        [Fact]
        public void SingleSearchValueTest_CaseInsensitive()
        {
            var data = new List<TestObj2>
            {
                new TestObj2 { ColA = "a", ColB = "B", ColC = "C", ColD = "D"},
                new TestObj2 { ColA = "E", ColB = "F", ColC = "G", ColD = "H"},
                new TestObj2 { ColA = "I", ColB = "J", ColC = "K", ColD = "L"},
            };

            var rq = new PagedRequest
            {
                Search = new Search { Value = "A" },
                PageSize = 10,
                Columns = new List<Column>
                {
                    new Column { Data = "ColA" },
                    new Column { Data = "ColB" },
                    new Column { Data = "ColC" },
                    new Column { Data = "ColD"}
                }
            };

            var deleg = ExpressionBuilder.GetAnyExpression<TestObj2>(rq.Filters, rq.Columns);
            var result = data.AsQueryable().Where(deleg).Skip(rq.Start).Take(rq.PageSize).ToList();
            result.Should().HaveCount(1);
            result[0].ColA.Should().Be("a");
        }


        [Fact]
		public void MultipleSearchValueTest()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "A", C = "G", D = "B"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = "A B" },
				PageSize = 10,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var deleg = ExpressionBuilder.GetAnyExpression<TestObj>(rq.Filters, rq.Columns);
			var result = data.AsQueryable().Where(deleg).Skip(rq.Start).Take(rq.PageSize).ToList();
			result.Should().HaveCount(2);
			result[0].A.Should().Be("A");
			result[0].B.Should().Be("B");
			result[1].B.Should().Be("A");
			result[1].D.Should().Be("B");
		}

		[Fact]
		public void SingleSearchValue_GetPaged_Test()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "F", C = "G", D = "H"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = "A" },
				PageSize = 10,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(1);
			result.RecordsTotal.Should().Be(3);
			result.RecordsFiltered.Should().Be(1);
			result.IndexOfFirstItemOnPage.Should().Be(1);
			result.IndexOfLastItemOnPage.Should().Be(1);
			result.Data.Should().HaveCount(1);
			result.Data[0].A.Should().Be("A");
		}

		[Fact]
		public void MultipleSearchValue_GetPaged_Test()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "A", C = "G", D = "B"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = "A B" },
				PageSize = 5,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(1);
			result.RecordsTotal.Should().Be(3);
			result.RecordsFiltered.Should().Be(2);
			result.IndexOfFirstItemOnPage.Should().Be(1);
			result.IndexOfLastItemOnPage.Should().Be(2);
			result.Data.Should().HaveCount(2);
			result.Data[0].A.Should().Be("A");
			result.Data[0].B.Should().Be("B");
			result.Data[1].B.Should().Be("A");
			result.Data[1].D.Should().Be("B");
		}

		[Fact]
		public void MultipleSearchValue_MultiplePages_GetPaged_Test()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "A", C = "G", D = "B"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
				new TestObj { A = "A", B = "N", C = "O", D = "B"},
				new TestObj { A = "Q", B = "B", C = "A", D = "T"},
				new TestObj { A = "B", B = "V", C = "W", D = "A"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = "A B" },
				PageSize = 2,
				Start = 0,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(5);
			result.IndexOfFirstItemOnPage.Should().Be(1);
			result.IndexOfLastItemOnPage.Should().Be(2);
			result.Data.Should().HaveCount(2);
			result.Data[0].A.Should().Be("A");
			result.Data[0].B.Should().Be("B");
			result.Data[1].B.Should().Be("A");
			result.Data[1].D.Should().Be("B");

			rq.Start = 1;
			result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(5);
			result.IndexOfFirstItemOnPage.Should().Be(3);
			result.IndexOfLastItemOnPage.Should().Be(4);
			result.Data.Should().HaveCount(2);
			result.Data[0].A.Should().Be("A");
			result.Data[0].D.Should().Be("B");
			result.Data[1].C.Should().Be("A");
			result.Data[1].B.Should().Be("B");

			rq.Start = 2;
			result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(5);
			result.IndexOfFirstItemOnPage.Should().Be(5);
			result.IndexOfLastItemOnPage.Should().Be(5);
			result.Data.Should().HaveCount(1);
			result.Data[0].D.Should().Be("A");
			result.Data[0].A.Should().Be("B");
		}

		[Fact]
		public void NoSearchValue_MultiplePages_GetPaged_Test()
		{
			var data = new List<TestObj>
			{
				new TestObj { A = "A", B = "B", C = "C", D = "D"},
				new TestObj { A = "E", B = "A", C = "G", D = "B"},
				new TestObj { A = "I", B = "J", C = "K", D = "L"},
				new TestObj { A = "A", B = "N", C = "O", D = "B"},
				new TestObj { A = "Q", B = "B", C = "A", D = "T"},
				new TestObj { A = "B", B = "V", C = "W", D = "A"},
			};

			var rq = new PagedRequest
			{
				Search = new Search { Value = string.Empty },
				PageSize = 2,
				Start = 0,
				Columns = new List<Column>
				{
					new Column { Data = "A" },
					new Column { Data = "B" },
					new Column { Data = "C" },
					new Column { Data = "D"}
				}
			};

			var result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(6);
			result.IndexOfFirstItemOnPage.Should().Be(1);
			result.IndexOfLastItemOnPage.Should().Be(2);
			result.Data.Should().HaveCount(2);
			result.Data[0].A.Should().Be("A");
			result.Data[0].B.Should().Be("B");
			result.Data[1].B.Should().Be("A");
			result.Data[1].D.Should().Be("B");

			rq.Start = 1;
			result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(6);
			result.IndexOfFirstItemOnPage.Should().Be(3);
			result.IndexOfLastItemOnPage.Should().Be(4);
			result.Data.Should().HaveCount(2);
			result.Data[0].A.Should().Be("I");
			result.Data[0].B.Should().Be("J");
			result.Data[1].A.Should().Be("A");
			result.Data[1].D.Should().Be("B");

			rq.Start = 2;
			result = data.AsQueryable().GetPaged(rq);
			result.PageCount.Should().Be(3);
			result.RecordsTotal.Should().Be(6);
			result.RecordsFiltered.Should().Be(6);
			result.IndexOfFirstItemOnPage.Should().Be(5);
			result.IndexOfLastItemOnPage.Should().Be(6);
			result.Data.Should().HaveCount(2);
			result.Data[0].C.Should().Be("A");
			result.Data[0].B.Should().Be("B");
			result.Data[1].D.Should().Be("A");
			result.Data[1].A.Should().Be("B");
		}
	}
}
