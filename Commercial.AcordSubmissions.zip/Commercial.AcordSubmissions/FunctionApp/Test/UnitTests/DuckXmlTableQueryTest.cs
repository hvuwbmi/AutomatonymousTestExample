using System.Threading.Tasks;
using Xunit;
using Microsoft.Azure.Cosmos.Table;
using System.Linq;

namespace DuckXmlTableQuery.Test.UnitTest
{
    public class DuckXmlTableQuery
    {
        private static readonly string DuckXmlTableName = "DuckXmlFromPenguin";
        private static readonly string DuckXmlPartitionKey = "DCTXML";
        private readonly string STORAGE_ACCOUNT_CONNECTION_STRING_KEY = "storage_account_connection_string";
        private static readonly string _connectionString = "DefaultEndpointsProtocol=https;AccountName=clappdevsa;AccountKey=BDxzhDCMol1VIjzoLMQudT3+dm0jpPAke1El4N4BYxO0Di+O4QpAa2UOuzTUTQWN/z9V2DlGEIWc3rGnVNimPw==;EndpointSuffix=core.windows.net;";
        private CloudStorageAccount _storageAccount;


        [Fact]
        public void TableQueryTest()
        {
            var table = CreateTableAsync(DuckXmlTableName).Result;
            string filter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, DuckXmlPartitionKey);
            var query = new TableQuery<DuckXmlTable>().Where(filter).OrderByDesc("Timestamp");
            
            var rows = table.ExecuteQuery(query).Take(50).ToList();
            
            Assert.NotEmpty(rows);
        }


        private async Task<CloudTable> CreateTableAsync(string tableName)
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);

            CloudTableClient tableClient = _storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            CloudTable table = tableClient.GetTableReference(tableName);

            await table.CreateIfNotExistsAsync();
            return table;
        }

        class DuckXmlTable : TableEntity
        {
            public string BusinessName { get; set; }
            public string Address1 { get; set; }
            public string City { get; set; }
            public string State { get; set; }
            public string Zipcode { get; set; }
            public string AgencyName { get; set; }
            public string BlobStorageKey { get; set; }
        }


    }
}
