﻿using AcordSubmissions.Test.UnitTest.Enums;
using AcordSubmissions.Test.UnitTest.Model;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Storage.Blob;
using StorageCredentials = Microsoft.Azure.Storage.Auth.StorageCredentials;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Mail;
using System.Threading;
using System.Threading.Tasks;

namespace AcordSubmissions.Test.UnitTest.EndToEnd
{
    public class EndToEndFunctions
    {
        private static readonly Random rnd = new Random();
        private static readonly string DuckXmlTableName = "DuckXmlFromPenguin";
        private static readonly string DuckXmlPartitionKey = "DCTXML";
        private readonly string STORAGE_ACCOUNT_CONNECTION_STRING_KEY = "storage_account_connection_string";
        //private static readonly string _connectionString = "DefaultEndpointsProtocol=https;AccountName=clappdevsa;AccountKey=BDxzhDCMol1VIjzoLMQudT3+dm0jpPAke1El4N4BYxO0Di+O4QpAa2UOuzTUTQWN/z9V2DlGEIWc3rGnVNimPw==;EndpointSuffix=core.windows.net;";
        private static readonly string _accountName = "clappqasa";
        private static readonly string _accountKey = "72Xx9eULWzqPcbumZCj/xMRoab+ZUmnjPPW9FajVNMRhkgzG8hnhNSsH5OYUSaINykrzHegjMr8IXgTQGO3pUg==";
        private static readonly string _connectionString = $"DefaultEndpointsProtocol=https;AccountName={_accountName};AccountKey={_accountKey};EndpointSuffix=core.windows.net;";
        private static CloudStorageAccount _storageAccount;

        private static void SendEmail(string recipients, string subject, string body, string attachment)
        {
            Thread.Sleep(1000 * 60 * rnd.Next(2, 18)); // 1000 ms * 60 = 60 seconds = 1 minute * random delay
            MailMessage message = new MailMessage();
            message.From = new MailAddress("TestAutomation@wbmi.com");

            foreach (string recipient in recipients.Split(';').Where(x => !string.IsNullOrEmpty(x)).ToList())
            {
                message.To.Add(recipient);
            }

            message.Subject = subject;

            if (!string.IsNullOrEmpty(attachment))
            {
                message.Attachments.Add(new Attachment(attachment) { Name = Path.GetFileName(attachment) });
            }

            var smtpClient = new SmtpClient("smtp.wbmi.com");
            smtpClient.Send(message);
            message.Dispose();

        }

        public static DataSet SubmitWorkCompAcord(string email, string acordPdfFile, string name)
        {
            DataSet policyData = new DataSet();
            var startTime = DateTime.Now;
            Console.WriteLine("Submitting " + acordPdfFile + " to " + email + "...");
            //TODO:  Real EMAIL with attachment
            SendEmail(email, $"testing from unit test: {name}", "Acord WC Submission", @"TestData\AcordPDFs\WorkComp\" + acordPdfFile);
            Console.WriteLine("Querying ExampleDataIDORealtime...");


            //TODO: LOOP / Timeout To Check For Policy
            //5000 miliseconds X 120 iterations = 600000 miliseconds is 10 minutes
            var policyFound = false;
            var checkcount = 0;
            while (!policyFound && checkcount < 120)
            {
                Thread.Sleep(5000);
                policyData = DatabaseManager.GetExampleIDORealtimePoliciesSinceTime(name, startTime);
                policyFound = policyData.Tables[0].Rows.Count > 0;
                checkcount++;
            }
            return policyData;

        }

        public static DuckXmlTable SubmitAcord(string email, string acordPdfFile, string name, RequestTypes type)
        {
            var duckXmlList = new List<DuckXmlTable>();
            var startTime = DateTime.Now;
            Console.WriteLine("Submitting " + acordPdfFile + " to " + email + "...");

            string filePath = "";
            string submissionMessage = "";
            switch (type)
            {
                case RequestTypes.Package:
                {
                    filePath = @"TestData\AcordPDFs\Package\";
                    submissionMessage = "Acord PKG Submission";
                    break;
                }
                case RequestTypes.Auto:
                {
                    filePath = @"TestData\AcordPDFs\Auto\";
                    submissionMessage = "Acord Auto Submission";
                    break;
                }
            }
            //TODO:  Real EMAIL with attachment
            SendEmail(email, $"testing from unit test: {name}", submissionMessage, filePath + acordPdfFile);
            Console.WriteLine("Querying DuckXmlFromPenguin");

            //TODO: LOOP / Timeout To Check For Policy
            var policyFound = false;
            var checkcount = 0;

            var table = CreateTableAsync(DuckXmlTableName).Result;
            var query = table.CreateQuery<DuckXmlTable>().Where(d => d.PartitionKey == DuckXmlPartitionKey
                                                    && d.Timestamp > startTime
                                                    && d.BusinessName == name);
            while (!policyFound && checkcount < 120)
            {
                Thread.Sleep(5000);
                duckXmlList = query.ToList();
                policyFound = duckXmlList.Count > 0;
                checkcount++;
            }

            return duckXmlList.FirstOrDefault();
        }


        public static bool CheckContainerForDctXml(string emailID)
        {
            var uri = new Uri("https://clappqasa.blob.core.windows.net/dctxml-from-penguin");
            var storageCredentials = new StorageCredentials(_accountName, _accountKey);
            var container = new CloudBlobContainer(uri, storageCredentials);

            if (container.Exists())
            {
                var blob = container.GetBlockBlobReference(emailID);
                if (blob.Exists())
                    return true;
            }

            return false;
        }

        public static async Task<CloudTable> CreateTableAsync(string tableName)
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);

            CloudTableClient tableClient = _storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            CloudTable table = tableClient.GetTableReference(tableName);

            await table.CreateIfNotExistsAsync();
            return table;
        }

        public static string CreateEmailId()
        {
            // Copied from AcordSubmissionEmailListener.Application.EmailHelper
            // https://alexandrebrisebois.wordpress.com/2013/03/01/storing-windows-azure-storage-table-entities-in-descending-order/#comments
            var rnd = new Random();

            var inverseTimeKey = DateTime
              .MaxValue
              .Subtract(DateTime.UtcNow)
              .TotalMilliseconds
              .ToString(CultureInfo.InvariantCulture);
            var randomNumber = rnd.Next(999).ToString();
            return string.Format("{0}{1}", "00" + inverseTimeKey, randomNumber);
        }
    }
}
