﻿using AcordSubmissions.Test.UnitTest.Enums;
using System;
using Xunit;

namespace AcordSubmissions.Test.UnitTest.EndToEnd
{
    #region WorkCompTest

    public class WorkCompForgingsStampingsTest
    {
        [Theory]
        [InlineData("Forgings Stampings 2019 WC application_Acord 130.pdf", "Forgings", EndToEndTest.ARG_QA)]
        public void WorkComp_Forgings_Submission_Test(string acordPdfFile, string name, string email) =>
            EndToEndTest.TestWorkCompSubmission(acordPdfFile, name, email);
    }

    public class WorkCompDUREXTest
    {
        [Theory]
        [InlineData("DUREXproducts WC.pdf", "DUREX", EndToEndTest.NSI_QA)]
        public void WorkComp_DUREX_Submission_Test(string acordPdfFile, string name, string email) =>
            EndToEndTest.TestWorkCompSubmission(acordPdfFile, name, email);
    }

    public class WorkCompPillarTest
    {
        [Theory]
        [InlineData("Pillar Construction Corp WC.pdf", "Pillar", EndToEndTest.WBCL_QA)]
        public void WorkComp_Pillar_Submission_Test(string acordPdfFile, string name, string email) =>
            EndToEndTest.TestWorkCompSubmission(acordPdfFile, name, email);
    }

    #endregion

    #region PackageTest

    public class PackageOtterHouseDriverTest
    {
        [Theory]
        [InlineData("OtterHouseRecoveryLLC Package.pdf", "Otter House Recovery LLC", EndToEndTest.NSI_QA, RequestTypes.Package)]
        public void Drivers_OtterHouse_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    public class PackageOctopusGardenVehicleTest
    {
        [Theory]
        [InlineData("OctopusGarden Package.pdf", "Octopus's Garden", EndToEndTest.WBCL_QA, RequestTypes.Package)]
        public void Vehicle_OctopusGarden_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    public class PackageGeneralTreeTest
    {
        [Theory]
        [InlineData("GeneralTreeServicePKGforE2E.pdf", "General Tree Service", EndToEndTest.WBCL_QA, RequestTypes.Package)]
        public void Package_GeneralTree_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    public class PackageShesElectricInlandMarineTest
    {
        [Theory]
        [InlineData("She's Electric.pdf", "She's Electric", EndToEndTest.WBCL_QA, RequestTypes.Package)]
        public void ContractorsEquipment_ShesEletric_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    public class PackageParadigmLocationsTest
    {
        [Theory]
        [InlineData("ParadigmResidentialContracting.pdf", "Paradigm Residential Services,", EndToEndTest.WBCL_QA, RequestTypes.Package)]
        public void Locations_ParadigmResidentialContracting_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    #endregion

    #region AutoTest

    public class AutoStickShiftTest
    {
        [Theory]
        [InlineData("StickShift Auto.pdf", "Stickshift Driver Training", EndToEndTest.WBCL_QA, RequestTypes.Auto)]
        public void Auto_StickShift_Submission_Test(string acordPdfFile, string name, string email, RequestTypes type) =>
            EndToEndTest.TestSubmission(acordPdfFile, name, email, type);
    }

    #endregion

    public class EndToEndTest
    {
        public const string ARG_QA = "ARG_Acord_Submissions_QA@wbmi.com";
        public const string NSI_QA = "NSI_Acord_Submissions_QA@wbmi.com";
        public const string WBCL_QA = "WBCL_Acord_Submissions_QA@wbmi.com";

        public static void TestWorkCompSubmission(string acordPdfFile, string name, string email)
        {
            var policyData = EndToEndFunctions.SubmitWorkCompAcord(email, acordPdfFile, name);

            Assert.True(policyData.Tables[0].Rows.Count == 1, "Policy not found in database.");
            Assert.True(policyData.Tables[0].Rows[0]["TurnstileGenerated"].ToString() == "True", "Policy" + policyData.Tables[0].Rows[0]["PolicyNumber"] + " found, but TurnstileGenerated flag was not set.");

            Console.WriteLine("Policy Number: " + policyData.Tables[0].Rows[0]["PolicyNumber"].ToString());
        }

        public static void TestSubmission(string acordPdfFile, string name, string email, RequestTypes type)
        {
            var duckXmlTableData = EndToEndFunctions.SubmitAcord(email, acordPdfFile, name, type);

            Assert.NotNull(duckXmlTableData);

            Console.WriteLine("Policy Found: " + duckXmlTableData.BusinessName);
        }
    }
}
