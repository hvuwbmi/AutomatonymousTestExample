﻿using AcordSubmissions.Infrastructure.StorageService.TableEntities;
using AcordSubmissions.Test.UnitTest.EndToEnd;
using Microsoft.Azure.Cosmos.Table.Queryable;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using Xunit.Abstractions;

namespace AcordSubmissions.Test.UnitTest.AcordXmlToSubmitApi
{
    public class SubmitApiFunctions
    {
        private HttpClient _httpClient;
        private readonly string _apiRoute = "commercial/acord/submit";
        private readonly ITestOutputHelper output;

        public SubmitApiFunctions(ITestOutputHelper output)
        {
            this.output = output;
        }

        public async void submitToApi(XDocument xml)
        {
            //Set up HttpClient to make call to acord api with acordXml
            _httpClient = new HttpClient
            {
                //BaseAddress = new Uri("https://dev-api.wbmi.com/")
                BaseAddress = new Uri("https://qa-api.wbmi.com/"),
            };

            //_httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "70f322c158f14fc1a997aa9d6c8c2e71");//dev
            _httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");//qa
            var rq = new HttpRequestMessage(HttpMethod.Post, _apiRoute);
            rq.Content = new StringContent(xml.ToString(), Encoding.UTF8, "application/xml");
            _httpClient.Timeout = TimeSpan.FromMinutes(30);

            //make http call
            await _httpClient.SendAsync(rq);
        }

        public List<SubmissionLOBEventsTable> ValidateSubmitXml(string emailID, int typeCount)
        {
            // Create Tables
            var eventsTable = EndToEndFunctions.CreateTableAsync("SubmissionLOBEvents").Result;

            var eventsQuery = eventsTable
                .CreateQuery<SubmissionLOBEventsTable>()
                .Where(e =>
                e.PartitionKey == emailID
                && e.Events == "MAPPING_COMPLETE"
                ).AsTableQuery();

            bool found = false;
            int checkCount = 0;
            List<SubmissionLOBEventsTable> events = null;
            //5000 miliseconds X 120 iterations = 600000 miliseconds is 10 minutes
            while (!found && checkCount < 120)
            {
                Thread.Sleep(5000);
                events = eventsTable.ExecuteQuery(eventsQuery).ToList();
                found = events.Count() >= typeCount;
                checkCount++;
            }


            return events;
        }

        public void debugLOBEventItems(List<SubmissionLOBEventsTable> events, string name)
        {
            foreach (var e in events)
            {
                output.WriteLine($"{name}:\n-------\n" +
                    $"ParitionKey: {e.PartitionKey}\n" +
                    $"RowKey: {e.RowKey}\n" +
                    $"Events: {e.Events}\n" +
                    $"PolicyNumber: {e.PolicyNumber}\n" +
                    $"Status: {e.Status}\n" +
                    $"SubmissionLOBKey: {e.SubmissionLOBKey}\n" +
                    $"Target: {e.Target}\n" +
                    $"=====================\n");
            }
        }
    }
}
