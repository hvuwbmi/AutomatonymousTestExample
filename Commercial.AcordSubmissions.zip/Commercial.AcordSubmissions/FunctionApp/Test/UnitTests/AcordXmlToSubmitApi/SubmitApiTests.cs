﻿using AcordSubmissions.Test.UnitTest.EndToEnd;
using AcordSubmissions.Test.UnitTest.Enums;
using System.Linq;
using System.Xml.Linq;
using System.Xml.XPath;
using Xunit;
using Xunit.Abstractions;

namespace AcordSubmissions.Test.UnitTest.AcordXmlToSubmitApi
{
    public class WorkCompPkgStencilTest : SubmitApiTest
    {
        public WorkCompPkgStencilTest(ITestOutputHelper output) : base(output) { }

        [Theory]
        [InlineData("stencilAcordXml.xml", RequestTypes.PackageAndWorkComp)]
        public void WorkCompAndPackage_Submit_Test(string acordXmlFileName, RequestTypes types) =>
            SubmitTest(acordXmlFileName, types);
    }

    public class AutoMonoStickShiftTest : SubmitApiTest
    {
        public AutoMonoStickShiftTest(ITestOutputHelper output) : base(output) { }

        [Theory]
        [InlineData("StickShiftAutoMonoAcordXml.xml", RequestTypes.Auto)]
        public void Auto_Submit_Test(string acordXmlFileName, RequestTypes types) =>
            SubmitTest(acordXmlFileName, types);
    }

    public class SubmitApiTest
    {
        private readonly SubmitApiFunctions functionsClass;
        private readonly ITestOutputHelper output;
        public SubmitApiTest(ITestOutputHelper output)
        {
            this.output = output;
            functionsClass = new SubmitApiFunctions(output);
        }

        protected void SubmitTest(string acordXmlFileName, RequestTypes types)
        {
            // Arrange
            string emailID = EndToEndFunctions.CreateEmailId();
            output.WriteLine($"EmailID: {emailID}");
            // Load xml and create a new id
            XDocument xml = XDocument.Load($@"TestData\SubmitApiTestXml\{acordXmlFileName}");
            xml.XPathSelectElements("FormServerResponse/Status/Messages/Message/FileName")
                .Where(f => f.Value == "2_EmailID_WBCL_XXXXXXXXXXXXXXXXXXXX.pdf")
                .FirstOrDefault()
                .SetValue($"5_EmailID_WBCL_{emailID}.pdf");

            // Act
            functionsClass.submitToApi(xml);
            // Validate that the xml transformed
            var events = functionsClass.ValidateSubmitXml(emailID, types.GetRequestCount());

            // Filter on 200 status
            events = events.Where(e => e.Status == "200").ToList();

            Assert.NotNull(events);

            // Get "DCT" targets
            var completeDuck = events
                .Where(e => e.Target == "DCT")
                .ToList();

            // Get "Penguin" targets
            var completePenguin = events
                .Where(e =>
                e.Target == "Penguin"
                && !string.IsNullOrWhiteSpace(e.PolicyNumber))
                .ToList();

            // Log entries for debugging
            functionsClass.debugLOBEventItems(events, "Event");
            functionsClass.debugLOBEventItems(completeDuck, "CompleteDuck");
            functionsClass.debugLOBEventItems(completePenguin, "CompletePenguin");

            // Assert
            // Check that there is exactly one success for each
            Assert.True(completeDuck.Count == types.GetDuckRouteCount(), "No successful duck transform found");
            Assert.True(completePenguin.Count == types.GetPenguinRouteCount(), "No successful penguin transform found");
            if (types.GetDuckRouteCount() > 0)
            {
                Assert.True(EndToEndFunctions.CheckContainerForDctXml(emailID), "Blob in acordxmls does not exist");
            }
        }
    }
}
