using MassTransit;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading;
using System.Xml.Linq;
using Xunit;

namespace DuckXmlTableQuery.Test.UnitTest
{
    public class TransformTest
    {
        private static HttpClient _httpClient;
        private readonly string _apiRoute = "commercial/acord/submit";



        [Theory]
        [ClassData(typeof(SubmissionTestData))]
        public void Submit(string inputPath, int count, int sleepInterval, string division_Id)
        {

            for( var i = 0; i<count; i++)
            {
                PerformSubmit(inputPath, division_Id);
                Thread.Sleep(sleepInterval);

            }


            //Assert.NotNull(output);

        }

        private async void PerformSubmit(string inputPath, string division_Id)
        {
            var turnstileXml = XDocument.Load(inputPath);

            var message = turnstileXml
                 .Element("FormServerResponse")
                 .Element("Status")
                 .Element("Messages")
                 .Elements("Message")
                 .Where(e => e.Element("FileName").Value == division_Id)
                 .Single();

            message.Element("FileName").Value = "6_EmailID_WBCL_GEN" + CreateEmailId() + ".pdf";
            
                //turnstileXml.Save(inputPath);


            //Set up HttpClient to make call to acord api with acordXml
            _httpClient = new HttpClient
            {
                //BaseAddress = new Uri("https://dev-api.wbmi.com/")
                BaseAddress = new Uri("https://qa-api.wbmi.com/"),
            };
            //_httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "70f322c158f14fc1a997aa9d6c8c2e71");//dev
            _httpClient.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", "e8cb460cc6f642108f42241099ea3f88");//qa
            var rq = new HttpRequestMessage(HttpMethod.Post, _apiRoute);
            rq.Content = new StringContent(turnstileXml.ToString(), Encoding.UTF8, "application/xml");
            _httpClient.Timeout = TimeSpan.FromMinutes(30);
            //make http call
            var result = await _httpClient.SendAsync(rq);
            //grab json response
            var rsBody = await result.Content.ReadAsStringAsync();

        }

        private string CreateEmailId()
        {            
            var rnd = new Random();

            var inverseTimeKey = DateTime
              .MaxValue
              .Subtract(DateTime.UtcNow)
              .TotalMilliseconds
              .ToString(CultureInfo.InvariantCulture);
            var randomNumber = rnd.Next(999).ToString();
            return string.Format("{0}{1}", "00" + inverseTimeKey, randomNumber);
        }

    }

    public class SubmissionTestData : IEnumerable<object[]>
    {
        string _path = Path.Combine(Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location), "TestData\\");

        public IEnumerator<object[]> GetEnumerator()
        {
            //yield return new object[]
            //{ _path + "Karrels.xml", 10, 15000, "6_WBCL_08D7ED24-32BA-3DBC-0015-5DF8C4320011.pdf"};

            yield return new object[]
            { _path + "SandTLawn.xml", 1, 30000, "2_NSI_08D7EE0B-1DBB-B4B9-0015-5DF8C4320000.pdf"};
            yield return new object[]
            { _path + "ChildsGarden.xml", 1, 30000, "2_NSI_08D7EE10-C15B-AF0B-0015-5DF8C4320000.pdf"};
            yield return new object[]
            { _path + "ServiceToolAndDie.xml", 1, 30000, "3_WBCL_08D7EE11-2DC8-C92F-0015-5DF8C4320000.pdf"};
            yield return new object[]
            { _path + "Prochnow.xml", 1, 30000, "2_WBCL_08D7EE11-E284-5495-0015-5DF8C4320000.pdf"};
        }

        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
