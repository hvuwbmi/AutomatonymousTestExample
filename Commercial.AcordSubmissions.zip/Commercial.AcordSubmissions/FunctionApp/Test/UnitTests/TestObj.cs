﻿namespace PagedSearchTests
{
    public class TestObj
	{
		public string A { get; set; }
		public string B { get; set; }
		public string C { get; set; }
		public string D { get; set; }
	}


    public class TestObj2
    {
        public string ColA { get; set; }
        public string ColB { get; set; }
        public string ColC { get; set; }
        public string ColD { get; set; }
    }
}
