﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.DriverImportErrors;
using AcordSubmissions.Domain.Entities.Enums;
using AcordSubmissions.Domain.Entities.Storage;
using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using Microsoft.Extensions.Logging;
using System;
using System.IO;
using System.Text;
using System.Threading.Tasks;
using System.Xml;

namespace AcordSubmissions.Infrastructure.StorageService
{
    public class BlobStorageClient
    {
        private string _connectionString;        
        private CloudBlobClient _client;
        private ILogger<StorageClient> _logger;
        
        private readonly string DuckXmlContainerName = "dctxml-from-penguin";
        private readonly string AcordXmlContainerName = "acordxmls";
        private readonly string DriverValidationContainerName = "driver-validation-data";
        private readonly string VehicleValidationContainerName = "vehicle-validation-errors";
        private readonly string STORAGE_ACCOUNT_CONNECTION_STRING_KEY = "storage_account_connection_string";
        

        public BlobStorageClient(ILogger<StorageClient> logger)
        {
            _connectionString = Environment.GetEnvironmentVariable(STORAGE_ACCOUNT_CONNECTION_STRING_KEY);
            _logger = logger;
        }

        public async Task<XmlStorageResponse> StoreXmlToBlob(XmlStorageRequest request)
        {
            _logger.LogInformation($"StoreXmlToBlob: Begin Store to BLob with connection string = {_connectionString}");

            var response = new XmlStorageResponse();
            try
            {
                _client = GetClient();

                if (_client != null)
                {
                    var containerName = AcordXmlContainerName;
                    if (request.XmlType == Domain.Entities.Enums.XmlType.Duck)
                    {
                        containerName = DuckXmlContainerName;
                    }
                    var requestContainer = await CreateContainer(containerName);


                    _logger.LogInformation($"Got a client - created request container {requestContainer.Name}");
                    StoreBlob(request.RowKey, XmlToString(request.Xml), requestContainer, response);
                }
                else
                {
                    response.ResponseCode = ResponseCode.ServerError;
                    response.ResponseMessage = $"Blob Storage failed. Unable to create Client";
                }

            }
            catch(Exception ex)
            {
                var msg = $"Error storing to Blob Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }

            _logger.LogInformation($"StoreDuckXMlToBlob: Store to Blob competed with status {response.ResponseCode}");
            return response;
        }       

        public async Task<RetrieveImportErrorsResponse> GetValidationBlob(string rowKey, string type)
        {
            _logger.LogInformation($"GetValidationBlob: Begin Get from BLob with connection string = {_connectionString}");

            var response = new RetrieveImportErrorsResponse();
            try
            {
                _client = GetClient();

                if (_client != null)
                {
                    string containerName = GetContainerName(type);
                    var requestContainer = await CreateContainer(containerName);

                    _logger.LogInformation($"Got a client - created request container {requestContainer.Name}");
                    response.ErrorsHtml = await GetBlobByRowKey(rowKey, requestContainer);                   
                    response.ResponseCode = ResponseCode.Success;
                }
                else
                {
                    response.ResponseCode = ResponseCode.ServerError;
                    response.ResponseMessage = $"Blob Storage failed. Unable to create Client";
                }
            }
            catch (Exception ex)
            {
                var msg = $"Error retrieving from Blob Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }

            _logger.LogInformation($"GetValidationBlob: Retrieval from Blob storage completed with status {response.ResponseCode}");
            return response;
        }

        private string XmlToString(XmlDocument xml)
        {
            using (StringWriter sw = new StringWriter())
            {
                using (XmlTextWriter tx = new XmlTextWriter(sw))
                {
                    xml.WriteTo(tx);
                    string strXmlText = sw.ToString();
                    return strXmlText;
                }
            }
        }

        private void StoreBlob(string key, string xml, CloudBlobContainer container, BaseResponse response)
        {
            _logger.LogInformation($"StoreBlob: Key = {key} Xml = {xml}");            
            try
            {
                var blob = container.GetBlockBlobReference(key);
                blob.Properties.ContentType = "application/xml";
                blob.UploadText(xml);
                if (blob.Properties.Length < 0)
                {
                    var msg = $"Blob Storage Failed to store {xml} with Key = {key}";
                    _logger.LogError(msg);
                    response.ResponseCode = ResponseCode.ServerError;
                    response.ResponseMessage = msg;

                }
                else
                {
                    _logger.LogInformation("StoreBlob: Success");
                    response.ResponseCode = ResponseCode.Success;
                }
            }
            catch (Exception ex)
            {
                var msg = $"Blob Storage Failed to store {xml} with Key = {key} with exception {ex.Message}";
                _logger.LogError(msg);
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;          
            }           
        }

        private async Task<string> GetBlobByRowKey(string key, CloudBlobContainer container)
        {
            var result = string.Empty;

            var blob = container.GetBlockBlobReference(key);
            result = await GetBlobFromStorage(blob);

            return result;
        }

        public async Task<string> GetBlobFromStorage(CloudBlockBlob blob)
        {
            MemoryStream ms = new MemoryStream();
            //Retrieve to a memory stream, then to text
            blob.DownloadToStream(ms);
            var result = Encoding.ASCII.GetString(ms.ToArray());
            return result;
        }

        private CloudBlobClient GetClient()
        {
            _logger.LogInformation("Get Client: Begin");
            CloudStorageAccount storageAccount;
            if (CloudStorageAccount.TryParse(_connectionString, out storageAccount))
            {
                _logger.LogInformation("Get Client: Success");
                return storageAccount.CreateCloudBlobClient();
            }
            else
            {
                _logger.LogError("Could not Create Cloud Blob Client");
                return null;
            }


        }

        private async Task<CloudBlobContainer> CreateContainer(string containerName)
        {
            var container = _client.GetContainerReference(containerName);
            await container.CreateIfNotExistsAsync();
            var permissions = new BlobContainerPermissions
            {
                PublicAccess = BlobContainerPublicAccessType.Off
            };
            await container.SetPermissionsAsync(permissions);
            return container;
        }

        private string GetContainerName(string type)
        {
            string container = "";
            switch(type)
            {
                case ValidationDataType.DriverType:
                    {
                        container = DriverValidationContainerName;
                        break;
                    }
                case ValidationDataType.VehicleType:
                    {
                        container = VehicleValidationContainerName;
                        break;
                    }
            }
            return container;
        }
    }
}
