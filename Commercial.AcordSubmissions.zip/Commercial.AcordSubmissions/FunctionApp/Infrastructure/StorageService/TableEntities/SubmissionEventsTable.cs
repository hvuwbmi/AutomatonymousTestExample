﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Infrastructure.StorageService.TableEntities
{
    public class SubmissionEventsTable : TableEntity
    {
        public string Events { get; set; }
        public string Status { get; set; }

        public string ErrorDescription { get; set; }

        public string TotalCount    { get; set; }
        public string Count { get; set; }

    }
}
