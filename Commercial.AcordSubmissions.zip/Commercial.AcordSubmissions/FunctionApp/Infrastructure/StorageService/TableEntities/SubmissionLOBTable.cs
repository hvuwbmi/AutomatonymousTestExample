﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Infrastructure.StorageService.TableEntities
{
    public class SubmissionLOBTable : TableEntity
    {
        public string LOBType { get; set; }
    }
}
