﻿using Microsoft.Azure.Cosmos.Table;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissions.Infrastructure.StorageService.TableEntities
{
    public class SubmissionLOBEventsTable : TableEntity
    {
        public string SubmissionLOBKey { get; set; }
        public string Events { get; set; }
        public string Target { get; set; }
        public string Status { get; set; }
        public string ErrorDescription { get; set; }
        public string PolicyNumber { get; set; }
    }
}
