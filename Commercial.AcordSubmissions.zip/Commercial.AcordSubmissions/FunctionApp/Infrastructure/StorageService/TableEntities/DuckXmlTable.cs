﻿using Microsoft.Azure.Cosmos.Table;

namespace AcordSubmissions.Infrastructure.StorageService.TableEntities
{
    class DuckXmlTable : TableEntity
    {
        public string BusinessName { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }

        public string State { get; set; }

        public string Zipcode { get; set; }

        public string AgencyName { get; set; }

        public string DriversValidation { get; set; }

        public string VehicleValidation { get; set; }

        public string Timestamp_formatted
        {
            get
                {
                return Timestamp.ToString();
                }
        }
       
    }
}
