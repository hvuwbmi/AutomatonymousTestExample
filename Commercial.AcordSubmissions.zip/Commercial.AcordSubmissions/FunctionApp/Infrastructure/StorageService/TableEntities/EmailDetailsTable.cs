﻿using Microsoft.Azure.Cosmos.Table;

namespace AcordSubmissions.Infrastructure.StorageService.TableEntities
{
    public class EmailDetailsTable : TableEntity
    {
        public string Sender { get; set; }

        public string emailGUID { get; set; }

        public string Subject { get; set; }

        public string Division { get; set; }

        public string receivedTimestamp { get; set; }

        public string ConfidenceIndex { get; set; }
    }
}
