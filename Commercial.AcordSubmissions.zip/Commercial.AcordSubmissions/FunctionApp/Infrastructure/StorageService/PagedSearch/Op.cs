﻿namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public enum Op
	{
		Equals,
		GreaterThan,
		LessThan,
		GreaterThanOrEqual,
		LessThanOrEqual,
		Contains,
        ContainsCaseInsensitive,
        StartsWith,
		EndsWith,
		IsNullOrEmpty
	}
}
