﻿using System;
using System.Collections.Generic;

namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public abstract class PagedResultBase
	{
		public int PageSize { get; set; }
		public int Draw { get; set; }
		public int CurrentPage { get; set; }
		public int PageCount { get; set; }
		public int RecordsFiltered { get; set; }
		public int RecordsTotal { get; set; }

		public int IndexOfFirstItemOnPage
		{

			get { return ((CurrentPage - 1) * PageSize) + 1; }
		}

		public int IndexOfLastItemOnPage
		{
			get
			{
				return Math.Min((CurrentPage * PageSize), RecordsFiltered);
			}
		}
	}

	public class PagedResult<T> : PagedResultBase where T : class
	{
		public IList<T> Data { get; set; }

		public PagedResult()
		{
			Data = new List<T>();
		}
	}
}
