﻿using System;
using System.Linq;

namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public static class IQueryableExtensions
	{
		public static PagedResult<T> GetPaged<T>(this IQueryable<T> query, int page, int pageSize) where T : class
		{
			var result = new PagedResult<T>();
			result.CurrentPage = page;
			result.PageSize = pageSize;
			result.RecordsFiltered = query.Count();
			result.RecordsTotal = query.Count();


			var pageCount = (double)result.RecordsTotal / pageSize;
			result.PageCount = (int)Math.Ceiling(pageCount);

			var skip = (page - 1) * pageSize;
			result.Data = query.Skip(skip).Take(pageSize).ToList();

			return result;
		}

		
		public static PagedResult<T> GetPaged<T>(this IQueryable<T> query, PagedRequest rq) where T : class
		{
			var result = new PagedResult<T> { PageSize = rq.PageSize };
			if (rq.Start == 0)
			{
				result.CurrentPage = 1;
			}
			else
			{
				result.CurrentPage = rq.Start + 1;
			}
			
			// Determine total results b4 filter
			result.RecordsTotal = query.Count();

			var deleg = ExpressionBuilder.GetAnyExpression<T>(rq.Filters, rq.Columns).Compile();
			var filteredQuery = query.Where(deleg);
			// Determine total number of rows that match filter
			result.RecordsFiltered = filteredQuery.Count();

			// Determine number of filtered pages
			var pageCount = (double)result.RecordsFiltered / rq.PageSize;
			result.PageCount = (int)Math.Ceiling(pageCount);

			// Filter the actual results and get the subset
			var filteredResults = filteredQuery.Skip(rq.Start * rq.PageSize).Take(rq.PageSize).ToList();
			result.Data = filteredResults;
			return result;
		}
	}
}
