﻿using System;

namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public static class ExtensionMethods
    {
        public static bool ContainsCaseInsensitive(this string source, string toCheck)
        {
            return source?.IndexOf(toCheck, StringComparison.OrdinalIgnoreCase) >= 0;
        }
    }

}
