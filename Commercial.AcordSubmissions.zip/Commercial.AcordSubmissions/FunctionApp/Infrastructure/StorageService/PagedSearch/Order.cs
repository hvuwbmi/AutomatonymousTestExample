﻿namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public class Order
	{
		public int Column { get; set; }
		public string Dir { get; set; }
	}
}
