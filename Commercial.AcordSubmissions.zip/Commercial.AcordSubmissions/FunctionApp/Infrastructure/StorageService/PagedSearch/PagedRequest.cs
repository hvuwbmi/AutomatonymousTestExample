﻿using System.Collections.Generic;

namespace AcordSubmissions.Infrastructure.StorageService.PagedSearch
{
    public class PagedRequest
	{
		public PagedRequest()
		{
			Search = new Search { Value = string.Empty };
		}
		public int Draw { get; set; }
		public int Start { get; set; }
		public int PageSize { get; set; }
		public List<Order> Order { get; set; }
		public List<Column> Columns { get; set; }
		public Search Search { get; set; }

		public IList<Filter> Filters
		{
			get
			{
				var results = new List<Filter>();
				if (Search.Value == null)
				{
					Search.Value = string.Empty;
				}
				var searchTerms = Search.Value.Split(' ');
				foreach (var searchTerm in searchTerms)
				{
					results.Add(new Filter { Value = searchTerm, Operation = Op.ContainsCaseInsensitive });
				}
				return results;
			}
		}
	}
}
