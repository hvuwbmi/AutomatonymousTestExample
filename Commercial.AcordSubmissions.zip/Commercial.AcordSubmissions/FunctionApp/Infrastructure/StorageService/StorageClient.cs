﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.DriverImportErrors;
using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using AcordSubmissions.Domain.Entities.Storage;
using AcordSubmissions.Domain.Interfaces;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Text;
using System.Threading.Tasks;

namespace AcordSubmissions.Infrastructure.StorageService
{
    public class StorageClient : IRepository
    {
        private ILogger<StorageClient> _logger;
        private TableStorageClient _tableStorageClient;
        private BlobStorageClient _blobStorageClient;

        public StorageClient(ILogger<StorageClient> logger)
        {
            _logger = logger;
            _tableStorageClient = new TableStorageClient(logger);
            _blobStorageClient = new BlobStorageClient(logger);
        }
        public async Task<XmlStorageResponse> StoreXml(XmlStorageRequest request)
        {
            _logger.LogInformation($"Begin storage....");   
            if (request.XmlType == Domain.Entities.Enums.XmlType.Duck)
            {
                return await _tableStorageClient.StoreDuckXmlFromPenguin(request);
            }

            // it is ACORD
            return await _blobStorageClient.StoreXmlToBlob(request);                      
        }
      
        public async Task<DuckXmlTableQueryResponse> QueryDuckXml(DuckXmlTableQueryRequest request)
        {
            _logger.LogInformation($"Query table storage....");
            return await _tableStorageClient.QueryDuckXmlFromTable(request);
        }
            
        public async Task<RetrieveImportErrorsResponse> RetrieveDuckUploadValidationErrors(RetrieveImportErrorsRequest request)
        {         
            var rowKey = _tableStorageClient.GetValidationErrorsBlobKey(request.RowKey, request.Type);

            // now get the blob and turn it nto HTML
            var response = await _blobStorageClient.GetValidationBlob(rowKey, request.Type);

            var validationErrors = JsonConvert.DeserializeObject<ValidationErrorsJsonWrapper>(response.ErrorsHtml);

            // build html with string builder
            var html = new StringBuilder();
            html.Append("<html>");
            html.Append("<body>");
            html.Append("<div>");
            foreach (var entityError in validationErrors.Errors.EntityErrors)
            {
                html.Append($"<h4 style=\"color:red;\">{entityError.Description}");
                html.Append("</h4>");
                foreach (var propertyError in entityError.PropertyErrors)
                {                    
                    html.Append("<div style=\"color:blue;\">");
                    html.Append("<ul>");
                    switch (propertyError.ErrorType)
                    {
                        case "Required":
                            html.Append($"<li>{propertyError.LabelText} is {propertyError.ErrorType}</li>");
                            break;
                        case "FormatMaskRegExpression":
                            html.Append($"<li>{propertyError.Message}</li>");
                            break;
                        case "MaxLength":
                            html.Append($"<li> Field Label: {propertyError.LabelText} Invalid {propertyError.ErrorType}. AdditionalInfo: {propertyError.AdditionalInfo}</li>");
                            break;
                        case "InvalidListOption":
                            html.Append($"<li> Field Label: {propertyError.LabelText} {propertyError.ErrorType}. Value: {propertyError.Message} Valid Values: {propertyError.AdditionalInfo}</li>");
                            break;
                        case "FormatMask":
                            html.Append($"<li> Field Label: {propertyError.LabelText} Invalid {propertyError.ErrorType}. Message: {propertyError.Message} Additional Info: {propertyError.AdditionalInfo}</li>");
                            break;
                        case "ReadOnly":
                            html.Append($"<li>{propertyError.LabelText} is {propertyError.ErrorType}</li>");
                            break;
                        default:
                            break;
                    }
                                                              
                    html.Append("</ul>");
                    html.Append("</div>");
                }
            }
            html.Append("</div>");
            html.Append("</body>");
            html.Append("</html>");

            response.ErrorsHtml = html.ToString();         
            return response;

        }

        public async Task<RetrieveConfidenceIndexResponse> RetrieveConfidenceIndex(RetrieveConfidenceIndexRequest request)
        {
            return await _tableStorageClient.RetrieveEmailDetailsConfidenceIndex(request.RowKey);
        }

        public async Task<BaseResponse> UpdateConfidenceIndex(UpdateEmailTableRequest request)
        {
            return await _tableStorageClient.UpdateEmailDetailsWithConfidenceIndex(request.RowKey, request.ConfidenceIndex);
        }

        public async Task<BaseResponse> StoreSubmissionEvents(SubmissionEventsRequest request)
        {
            return await _tableStorageClient.StoreSubmissionEvent(request);
        }

        public async Task<SubmissionLOBResponse> StoreSubmissionLOB(SubmissionLOBRequest request)
        {
            return await _tableStorageClient.StoreSubmissionLOB(request);
        }

        public async Task<BaseResponse> StoreSubmissionLOBEvents(SubmissionLOBEventsRequest request)
        {
            return await _tableStorageClient.StoreSubmissionLOBEvent(request);
        }
    }
}
