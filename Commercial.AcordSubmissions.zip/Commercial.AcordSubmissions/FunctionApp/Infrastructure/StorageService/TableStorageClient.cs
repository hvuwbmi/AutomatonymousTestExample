﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using AcordSubmissions.Infrastructure.StorageService.TableEntities;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Extensions.Logging;
using AcordSubmissions.Infrastructure.StorageService.PagedSearch;
using SmallCommercial.Infrastructure.StorageService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AcordSubmissions.Domain.Entities.Storage;
using MassTransit;
using AcordSubmissions.Domain.Entities.Enums;
using System.Net.Http;

namespace AcordSubmissions.Infrastructure.StorageService
{
    public class TableStorageClient
    {
        private string _connectionString;
        private int _maximumRows;
        private CloudStorageAccount _storageAccount;
        private ILogger<StorageClient> _logger;

        private readonly BlobStorageClient _blobStorageService;
        private static readonly string DuckXmlTableName = "DuckXmlFromPenguin";
        private static readonly string DuckXmlPartitionKey = "DCTXML";
        private static readonly string EmailDetailsTableName = "EmailDetails";
        private static readonly string EmailDetailsPartitionKey = "AcordSubmission";
        private static readonly string SubmissionEventsTableName = "SubmissionEvents";
        private static readonly string SubmissionLOBTableName = "SubmissionLOB";
        private static readonly string SubmissionLOBEventsTableName = "SubmissionLOBEvents";
        private readonly string STORAGE_ACCOUNT_CONNECTION_STRING_KEY = "storage_account_connection_string";
        private readonly string MAXIMUM_ROWS_READ_FROM_TABLE = "maximum_rows_read_from_table";
        public TableStorageClient(ILogger<StorageClient> logger)
        {
            _logger = logger;
            _connectionString = Environment.GetEnvironmentVariable(STORAGE_ACCOUNT_CONNECTION_STRING_KEY);
            _maximumRows = int.TryParse(Environment.GetEnvironmentVariable(MAXIMUM_ROWS_READ_FROM_TABLE), out var max) ? max : 19;
            _blobStorageService = new BlobStorageClient(logger);

            _logger.LogInformation($"MAXIMUM_ROWS_READ_FROM_TABLE {MAXIMUM_ROWS_READ_FROM_TABLE}");
            _logger.LogInformation($"int.TryParse {int.TryParse(Environment.GetEnvironmentVariable(MAXIMUM_ROWS_READ_FROM_TABLE), out var m)}");
            _logger.LogInformation($"_maximumRows {_maximumRows}");
        }

        public async Task<XmlStorageResponse> StoreDuckXmlFromPenguin(XmlStorageRequest request)
        {
            _logger.LogInformation("StoreDctXML: Begin Table Storage");

            // store blob 1st
            var response = await _blobStorageService.StoreXmlToBlob(request);

            if (response.ResponseCode == ResponseCode.Success)
            {
                // begin table storage setup
                var businessName = string.Empty;
                var address = string.Empty;
                var city = string.Empty;
                var state = string.Empty;
                var zipcode = string.Empty;
                var agency = string.Empty;
                try
                {
                    _logger.LogInformation("TableStorageClient:StoreDuckXmlFromPenguin: Begin xpath parsing");
                    if (request.Xml.SelectSingleNode("//session/data/account/Name") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/account/Name/text()") != null)
                        {
                            businessName = request.Xml.SelectSingleNode("//session/data/account/Name/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for business name {businessName}");
                        }
                    }

                    if (request.Xml.SelectSingleNode("//session/data/account/address/Address1") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/account/address/Address1/text()") != null)
                        {
                            address = request.Xml.SelectSingleNode("//session/data/account/address/Address1/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for Address1 {address}");
                        }
                    }

                    if (request.Xml.SelectSingleNode("//session/data/account/address/City") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/account/address/City/text()") != null)
                        {
                            city = request.Xml.SelectSingleNode("//session/data/account/address/City/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for City {city}");
                        }
                    }


                    if (request.Xml.SelectSingleNode("//session/data/account/address/State") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/account/address/State/text()") != null)
                        {
                            state = request.Xml.SelectSingleNode("//session/data/account/address/State/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for State {state}");
                        }

                    }


                    if (request.Xml.SelectSingleNode("//session/data/account/address/ZipCode") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/account/address/ZipCode/text()") != null)
                        {
                            zipcode = request.Xml.SelectSingleNode("//session/data/account/address/ZipCode/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for Zipcode {zipcode}");
                        }
                    }

                    if (request.Xml.SelectSingleNode("//session/data/agencyDetails/agency/name") != null)
                    {
                        if (request.Xml.SelectSingleNode("//session/data/agencyDetails/agency/name/text()") != null)
                        {
                            agency = request.Xml.SelectSingleNode("//session/data/agencyDetails/agency/name/text()").Value;
                            _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Found Node and data for Agency Name {agency}");
                        }
                    }
                    // create Table Storage Tbale
                    var table = CreateTableAsync(DuckXmlTableName).Result;
                    _logger.LogInformation($"TableStorageClient:StoreDuckXmlFromPenguin: Created Table {table.Name}");
                    // build entity from XML 
                    var tableEntity = new DuckXmlTable
                    {
                        PartitionKey = DuckXmlPartitionKey,
                        RowKey = request.RowKey,
                        BusinessName = businessName,
                        Address1 = address,
                        City = city,
                        State = state,
                        Zipcode = zipcode,
                        AgencyName = agency
                    };


                    await StoreToTableStorage(table, tableEntity);

                    _logger.LogInformation("TableStorageClient:StoreDuckXmlFromPenguin: Table storage success");
                    response.ResponseCode = ResponseCode.Success;
                    response.Response = ResponseCode.Success.ToString();
                    response.ResponseMessage = "Duck Xml storage successful.";
                }
                catch (Exception ex)
                {
                    var msg = $"Error storing to Blob Storage: {ex.Message}";
                    _logger.LogError(msg);
                    response.ExceptionResult = ex;
                    response.ResponseCode = ResponseCode.ServerError;
                    response.ResponseMessage = msg;
                }
            }

            return response;


        }

        public async Task<DuckXmlTableQueryResponse> QueryDuckXmlFromTable(DuckXmlTableQueryRequest request)
        {
            _logger.LogInformation("Query DuckXmlFromPenguin: Get data from table");

            var response = new DuckXmlTableQueryResponse();
            response.Submissions = new List<DuckXmlSubmission>();

            try
            {
                // Fill the table with rows that match the PartitionKey
                _logger.LogInformation("Query DuckXmlFromPenguin: Get rows by PartitionKey");
                var table = CreateTableAsync(DuckXmlTableName).Result;
                string filter = TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, DuckXmlPartitionKey);
                var query = new TableQuery<DuckXmlTable>().Where(filter);
                _logger.LogInformation($"Query DuckXmlFromPenguin maximumRows: {_maximumRows}");
                var allRowsByPartition = table.ExecuteQuery(query).ToList().Take(_maximumRows);

                // Set up variables from the request
                var numberOfRowsPerPage = int.TryParse(request.NumberOfRows, out var n) ? n : 0;
                var page = int.TryParse(request.Page, out var p) ? p : 0;
                var numberOfRowsToSkip = (page - 1) * numberOfRowsPerPage;

                // Create the PagedRequest
                var rq = new PagedRequest
                {
                    Search = new Search { Value = request.SearchCriterion },
                    PageSize = numberOfRowsPerPage,
                    Columns = new List<Column>
                    {
                        new Column { Data = "BusinessName"},
                        new Column { Data = "Address1"},
                        new Column { Data = "City"},
                        new Column { Data = "State"},
                        new Column { Data = "Zipcode"},
                        new Column { Data = "AgencyName"},
                        new Column { Data = "Timestamp_formatted"}
                    }
                };

                // Use the PagedRequest to filter the rows
                _logger.LogInformation("Query DuckXmlFromPenguin: Filter rows by search criteria");
                var delegat = ExpressionBuilder.GetAnyExpression<DuckXmlTable>(rq.Filters, rq.Columns);
                var filteredRowCount = allRowsByPartition.AsQueryable().Where(delegat).ToList().Count();
                var pageRows = allRowsByPartition.AsQueryable().Where(delegat).Skip(numberOfRowsToSkip).Take(numberOfRowsPerPage).ToList();

                response.Total = filteredRowCount;
                response.Start = (numberOfRowsToSkip) + 1;
                response.End = numberOfRowsToSkip + pageRows.Count();

                for (int i = 0; i < pageRows.Count(); i++)
                {
                    var sub = new DuckXmlSubmission();
                    sub.RowKey = pageRows[i].RowKey;
                    sub.Address = pageRows[i].Address1;
                    sub.AgencyName = pageRows[i].AgencyName;
                    sub.City = pageRows[i].City;
                    sub.BusinessName = pageRows[i].BusinessName;
                    sub.State = pageRows[i].State;
                    sub.Zipcode = pageRows[i].Zipcode;
                    sub.DateTime = ConvertToCentralStandardTime(pageRows[i].Timestamp).ToString();
                    _logger.LogInformation($"Query DuckXmlFromPenguin: Timestamp {pageRows[i].Timestamp}");
                    _logger.LogInformation($"Query DuckXmlFromPenguin: converted {ConvertToCentralStandardTime(pageRows[i].Timestamp.DateTime).ToString()}");
                    response.Submissions.Add(sub);
                }
                _logger.LogInformation("Query DuckXmlFromPenguin: Query success");
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "Duck Xml query successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error querying Duck Xml Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }
            return response;
        }

        public async Task<RetrieveConfidenceIndexResponse> RetrieveEmailDetailsConfidenceIndex(string rowKey)
        {
            _logger.LogInformation("Query EmailDetails: Get row by PartitionKey and rowkey");
            var response = new RetrieveConfidenceIndexResponse();
            string confidenceIndex = "Confidence Index unavailable";

            try
            {
                var table = CreateTableAsync(EmailDetailsTableName).Result;

                var row = table.CreateQuery<EmailDetailsTable>()
                    .Where(d => d.PartitionKey == EmailDetailsPartitionKey
                            && d.RowKey == rowKey)
                            .Select(x => new EmailDetailsTable()
                            {
                                PartitionKey = x.PartitionKey,
                                RowKey = x.RowKey,
                                ConfidenceIndex = x.ConfidenceIndex
                            }).FirstOrDefault();

                if (row != null && !string.IsNullOrEmpty(row.ConfidenceIndex))
                {
                    confidenceIndex = row.ConfidenceIndex;
                }

                _logger.LogInformation("TableStorageClient: RetrieveEmailDetailsConfidenceIndex: success");
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "retrieval success";
            }
            catch (Exception ex)
            {
                var msg = $"Error retrieving from Table Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }
            finally
            {
                response.ConfidenceIndex = confidenceIndex;
            }

            return response;
        }

        public async Task<BaseResponse> UpdateEmailDetailsWithConfidenceIndex(string rowKey, string confidenceIndex)
        {
            _logger.LogInformation("Query EmailDetails: Get row by PartitionKey and rowkey");
            var response = new BaseResponse();

            try
            {
                var table = CreateTableAsync(EmailDetailsTableName).Result;

                var row = table.CreateQuery<EmailDetailsTable>()
                    .Where(d => d.PartitionKey == EmailDetailsPartitionKey
                            && d.RowKey == rowKey)
                            .Select(x => new EmailDetailsTable()
                            {
                                PartitionKey = x.PartitionKey,
                                RowKey = x.RowKey
                            }).FirstOrDefault();

                if (row != null)
                {
                    row.ConfidenceIndex = confidenceIndex;

                    // update it
                    await StoreToTableStorage(table, row);
                }
                _logger.LogInformation("TableStorageClient:UpdateEmailDetailsWithConfidenceIndex: Table storage success");
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "EmailDetails storage successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Table Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }
            return response;
        }


        public string GetValidationErrorsBlobKey(string rowKey, string type)
        {
            _logger.LogInformation("Query GetValidationErrorsBlobKey: Get row by PartitionKey and rowkey");
            var result = string.Empty;

            var table = CreateTableAsync(DuckXmlTableName).Result;

            var row = table.CreateQuery<DuckXmlTable>()
                .Where(d => d.PartitionKey == DuckXmlPartitionKey
                        && d.RowKey == rowKey)
                        .Select(x => new DuckXmlTable()
                        {
                           DriversValidation = x.DriversValidation,
                           VehicleValidation = x.VehicleValidation
                        }).FirstOrDefault();

            if (row != null)
            {
                result = ReturnBasedOnType(row, type);
            }

            return result;
            
        }

        private string ReturnBasedOnType(DuckXmlTable row, string type)
        {
            string result = "";

            switch (type)
            {
                case ValidationDataType.DriverType:
                    {
                        
                        result = row.DriversValidation ?? "";
                        break;
                    }
                case ValidationDataType.VehicleType:
                    {
                        result = row.VehicleValidation ?? "";
                        break;
                    }
            }

            return result;
        }     

        public async Task<BaseResponse> StoreSubmissionEvent(SubmissionEventsRequest request)
        {
            _logger.LogInformation("TableStorageClient:StoreSubmissionEvent: Begin Table Storage");

            var response = new BaseResponse();

            try { 
                // begin table storage setup
              
                // create Table Storage Tbale
                var table = CreateTableAsync(SubmissionEventsTableName).Result;
                _logger.LogInformation($"TableStorageClient:StoreSubmissionEvent: Created Table {table.Name}");
                // build entity from XML 
                var tableEntity = new SubmissionEventsTable
                {
                    PartitionKey = request.EmailId,
                    RowKey = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant(),
                    Events = request.Event                              
                };

                
                tableEntity.Status = !string.IsNullOrEmpty(request.Status) ? request.Status : string.Empty;
                tableEntity.ErrorDescription = !string.IsNullOrEmpty(request.ErrorDescription) ? request.ErrorDescription : string.Empty;
                tableEntity.TotalCount = request.TotalCount > 0 ? request.TotalCount.ToString() : string.Empty;
                tableEntity.Count = request.Count > 0 ? request.Count.ToString() : string.Empty;
                
                await StoreToTableStorage(table, tableEntity);

                _logger.LogInformation("TableStorageClient:StoreSubmissionEvent: Table storage success");
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "SubmissionEvents storage successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Table Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }


            return response;


        }

        public async Task<SubmissionLOBResponse> StoreSubmissionLOB(SubmissionLOBRequest request)
        {
            _logger.LogInformation("TableStorageClient:StoreSubmissionLOB: : Begin Table Storage");

            var response = new SubmissionLOBResponse();
            var newRowKey = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant();
            try
            {
                // begin table storage setup

                // create Table Storage Tbale
                var table = CreateTableAsync(SubmissionLOBTableName).Result;
                _logger.LogInformation($"TableStorageClient:StoreSubmissionLOB: Created Table {table.Name}");
                // build entity from XML 
                var tableEntity = new SubmissionLOBTable
                {
                    PartitionKey = request.EmailId,
                    RowKey = newRowKey,
                    LOBType = request.LOB                  
                };               

                await StoreToTableStorage(table, tableEntity);

                _logger.LogInformation("TableStorageClient:StoreSubmissionLOB: Table storage success");
                response.SubmissionLOBRowKey = newRowKey;
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "SubmissionLOBTable storage successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Table Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }


            return response;


        }

        public async Task<BaseResponse> StoreSubmissionLOBEvent(SubmissionLOBEventsRequest request)
        {
            _logger.LogInformation("TableStorageClient:StoreSubmissionLOBEvent: Begin Table Storage");

            var response = new BaseResponse();

            try
            {
                // begin table storage setup

                // create Table Storage Tbale
                var table = CreateTableAsync(SubmissionLOBEventsTableName).Result;
                _logger.LogInformation($"TableStorageClient:StoreSubmissionLOBEvent: Created Table {table.Name}");
                // build entity from XML 
                var tableEntity = new SubmissionLOBEventsTable
                {
                    PartitionKey = request.EmailId,
                    RowKey = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant(),
                    SubmissionLOBKey = request.LOBRowKey,
                    Events = request.Event,
                    Status = request.Status,
                    ErrorDescription = request.ErrorDescription,
                    PolicyNumber = request.PolicyNumber,
                    Target = request.Target
                };
           
                await StoreToTableStorage(table, tableEntity);

                _logger.LogInformation("TableStorageClient:StoreSubmissionLOBEvent: Table storage success");
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "SubmissionEvents storage successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Table Storage: {ex.Message}";
                _logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }


            return response;


        }

        private async Task StoreToTableStorage(CloudTable cloudTable, TableEntity tableEntity)
        {
            _logger.LogInformation("TableStorageClient:StoreToTableStorage: Begin");
            //// Create the InsertOrReplace table operation
            TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(tableEntity);

            try
            {
                var requestOptions = new TableRequestOptions();
                requestOptions.RetryPolicy = new TimeoutRetryPolicy(TimeSpan.FromMilliseconds(250), 3);

                var operationContext = new OperationContext();
                operationContext.Retrying += OperationContext_Retrying;
                operationContext.RequestCompleted += OperationContext_RequestCompleted;

                // Execute the operation.
                var result = await cloudTable.ExecuteAsync(insertOrMergeOperation, requestOptions, operationContext);
                _logger.LogInformation($"TableStorageClient:StoreToTableStorage: ExecuteAsync InsertOrMerge Http Result: {result.HttpStatusCode}");
            }
            catch (Exception ex)
            {
                _logger.LogError($"Request failed in {this.GetType().Name} due to exception {ex.Message}");
            }

            _logger.LogInformation("TableStorageClient:StoreToTableStorage: End");
        }

        private void OperationContext_RequestCompleted(object sender, RequestEventArgs e)
        {
            if (e.Response == null || (int)e.Response.StatusCode >= 400)
            {
                // This is occasionally executed - we want to retry in this case.
                _logger.LogError($"Request failed in {this.GetType().Name} due to HTTP code {e.RequestInformation.HttpStatusCode} with exception {e.RequestInformation.Exception.ToString()}");
            }
            else
            {
                _logger.LogInformation($"{this.GetType().Name} operation complete: Status code {e.Response.StatusCode}");
            }
        }

        private void OperationContext_Retrying(object sender, RequestEventArgs e)
        {
            _logger.LogInformation($"Retry policy activated in {this.GetType().Name} due to HTTP code {e.RequestInformation.HttpStatusCode} with exception {e.RequestInformation.Exception.ToString()}");
        }

        private async Task<CloudTable> CreateTableAsync(string tableName)
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);

            CloudTableClient tableClient = _storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            CloudTable table = tableClient.GetTableReference(tableName);

            await table.CreateIfNotExistsAsync();
            return table;
        }

        private void CreateStorageAccount()
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);
        }

        private DateTime ConvertToCentralStandardTime(DateTimeOffset offset)
        {
            TimeZoneInfo targetZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
            return TimeZoneInfo.ConvertTimeFromUtc(offset.DateTime, targetZone);
        }

    }
}
