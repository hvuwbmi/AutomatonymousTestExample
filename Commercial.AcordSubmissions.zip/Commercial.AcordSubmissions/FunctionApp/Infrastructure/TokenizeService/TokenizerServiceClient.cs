﻿using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using Newtonsoft.Json;

namespace AcordSubmissions.Infrastructure.Functions.Clients
{
    public class TokenizerServiceClient : ITokenizerService
    {
        private readonly HttpClient _httpClient;
        private readonly string _tokenizeApiRoute = "commercial/token/tokenize";
        private readonly string _detokenizeApiRoute = "commercial/token/detokenize";

        public TokenizerServiceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<TokenizeServiceRs> DeTokenize(TokenizeServiceRq rq)
        {
            var body = JsonConvert.SerializeObject(rq);
            var httpRq = new HttpRequestMessage(HttpMethod.Post, _detokenizeApiRoute);
            httpRq.Content = new StringContent(body, Encoding.UTF8, "application/json");
            var result = await _httpClient.SendAsync(httpRq);
            var rsBody = await result.Content.ReadAsStringAsync();
            var rs = JsonConvert.DeserializeObject<TokenizeServiceRs>(rsBody);
            return await Task.FromResult(rs);
        }

        public async Task<TokenizeServiceRs> Tokenize(TokenizeServiceRq rq)
        {
            var body = JsonConvert.SerializeObject(rq);
            var httpRq = new HttpRequestMessage(HttpMethod.Post, _tokenizeApiRoute);
            httpRq.Content = new StringContent(body, Encoding.UTF8, "application/json");
            var result = await _httpClient.SendAsync(httpRq);
            var rsBody = await result.Content.ReadAsStringAsync();
            var rs = JsonConvert.DeserializeObject<TokenizeServiceRs>(rsBody);
            if (result.IsSuccessStatusCode)
            {
                rs.ResponseCode = ResponseCode.Success;
            }
            else
            {                
                rs.ResponseCode = ResponseCode.ServerError;
            }

            return await Task.FromResult(rs);
        }
    }
}
