﻿using System;
using System.Net;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Entities.DuckXmlRetrieve;
using AcordSubmissions.Domain.Interfaces;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;

namespace AcordSubmissions.Infrastructure.DeliverDuckXml
{
    public class UploadDuckXmlClient : IUploadDuckXmlService
    {
        private readonly HttpClient _httpClient;
       
        private readonly ILogger<UploadDuckXmlClient> _logger;
        private IRepository _storageClient;
        private bool _debugMode;
        private string _debugUploadRoute;
        private string _penguinDebugUploadRoute;

        private readonly string _apiRoute = "commercial/duckxmlprocessing/submit";
        private readonly string _penguinApiRoute = "commercial/acord-private/duckxmlupload";
        private readonly string _penguinSecret = "JWT eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpYXQiOjE1NjIwMDgyMDQsImV4cCI6MTg3NjUwNDIwNCwic3ViIjozLCJ1bmFtZSI6ImM0MTg3OGFmLTc0OTctNGY0Ny1hMGJlLWUzNTViZmRhOTEzMyIsIm9yZ2lkIjoxLCJhZG1pbiI6ZmFsc2UsInN1cGVyIjpmYWxzZSwic3lzdXNyIjp0cnVlfQ.CO5pH21AdyK_wTIHgijGmjyvsSI9vYh3wJ5ottSj7_g";

        private const string UPLOAD_TIMEOUT_KEY = "UploadTimeout";

        public UploadDuckXmlClient(IRepository repository, HttpClient httpClient, ILogger<UploadDuckXmlClient> logger)
        {
            _httpClient = httpClient;
            _logger = logger;
            _storageClient = repository;
            _debugMode = false;
            if (Environment.GetEnvironmentVariable("DebugMode") != null)
            {                
                _debugMode = Environment.GetEnvironmentVariable("DebugMode") == "true";
                _debugUploadRoute = Environment.GetEnvironmentVariable("DebugUploadRoute");
                _penguinDebugUploadRoute = Environment.GetEnvironmentVariable("PenguinDebugUploadRoute");
            }
        }

        public async Task<DuckXmlUploadResponse> UploadDuckXml(DuckXmlUploadRequest request)
        {
            _logger.LogInformation("UploadDuckXml: Begin Upload");            
            var response = new DuckXmlUploadResponse();
            try
            {

                var fullRoute = string.Empty;
                // Get fullRoute 
                if (_debugMode)
                {
                    fullRoute = $"{_debugUploadRoute}/{request.Type}/{request.SessionId}";
                }
                else
                {
                    fullRoute = $"{_apiRoute}/{request.Type}/{request.SessionId}";
                }
                _logger.LogInformation($"UploadDuckXml: api route = {fullRoute}");             
                var httpRq = new HttpRequestMessage(HttpMethod.Post, fullRoute);
                httpRq.Content = new StringContent(request.DuckXml, Encoding.UTF8, "application/json");
                var httpResponse = await _httpClient.SendAsync(httpRq);
                var rsBody = await httpResponse.Content.ReadAsStringAsync();
                if (httpResponse.IsSuccessStatusCode)
                {
                    // store the error resutls in blob storage, if any occured
                    response.ValidationErrors = rsBody;
                    response.ResponseCode = ResponseCode.Success;
                    response.Response = ResponseCode.Success.ToString();
                    response.ResponseMessage = "Duck Xml upload successful.";
                    _logger.LogInformation($"UploadDuckXml: success");
                }
                else
                {
                    switch (httpResponse.StatusCode)
                    {
                        case System.Net.HttpStatusCode.NotFound:
                            response.ResponseCode = ResponseCode.ServerError;
                            response.ResponseMessage = httpResponse.StatusCode.ToString();
                            break;
                        default:
                            response.ResponseCode = ResponseCode.ServerError;
                            response.ResponseMessage = httpResponse.StatusCode.ToString();
                            break;
                    }
                    response.ReasonPhrase = httpResponse.ReasonPhrase;

                    _logger.LogInformation($"UploadDuckXml: failure = {response.ResponseMessage}");
                }
                response.StatusCode = (int)httpResponse.StatusCode;
            }
            catch (Exception ex)
            {
                var msg = $"Error delivering duck xml: {ex.Message}";
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
                _logger.LogInformation($"UploadDuckXml: failure = {response.ResponseMessage}");
            }
            return response;
        }

        public async Task<DuckXmlUploadResponse> UploadDuckXmlViaPenguin(DuckXmlUploadRequest request)
        {
            _logger.LogInformation("UploadDuckXmlViaPenguin: Begin Upload");
            _logger.LogInformation($"UploadDuckXmlViaPenguin: Duck Xml = {request.DuckXml}");

            var response = new DuckXmlUploadResponse();
            try
            {                
                HttpMethod method = HttpMethod.Post;

                // Get fullRoute 
                var fullRoute = string.Empty;
                var contentType = "application/json";
                // Get fullRoute 
                if (_debugMode)
                {
                    contentType = "application/xml";
                    method = HttpMethod.Put;
                    fullRoute = $"{_penguinDebugUploadRoute}/{request.Type}/{request.SessionId}";
                }
                else
                {
                    method = HttpMethod.Post;
                    fullRoute = $"{_penguinApiRoute}/{request.Type}/{request.SessionId}";                    
                }

                _logger.LogInformation($"UploadDuckXmlViaPenguin: api route = {fullRoute}");

                var httpRq = new HttpRequestMessage(method, fullRoute);

                if (_debugMode)
                {
                    // still need stuff runing local penguin code
                    httpRq.Headers.Add("Accept", contentType);
                    httpRq.Headers.Add("Authorization", $"{_penguinSecret}");
                    httpRq.Headers.Add("Env", "INT");                  
                }

                httpRq.Content = new StringContent(request.DuckXml, Encoding.UTF8, contentType);
                var httpResponse = await _httpClient.SendAsync(httpRq);

                if (httpResponse.IsSuccessStatusCode)
                {                                 
                    response.ResponseCode = ResponseCode.Success;
                    response.Response = ResponseCode.Success.ToString();
                    response.ResponseMessage = "Duck Xml upload successful.";
                    _logger.LogInformation($"UploadDuckXml: success");
                }
                else
                {
                    switch (httpResponse.StatusCode)
                    {
                        case System.Net.HttpStatusCode.NotFound:
                            response.ResponseCode = ResponseCode.ServerError;
                            response.ResponseMessage = httpResponse.StatusCode.ToString();
                            break;
                        default:
                            response.ResponseCode = ResponseCode.ServerError;
                            response.ResponseMessage = httpResponse.StatusCode.ToString();
                            break;
                    }
                    response.ReasonPhrase = httpResponse.ReasonPhrase;

                    _logger.LogInformation($"UploadDuckXml: failure = {response.ResponseMessage}");
                }
                response.StatusCode = (int)httpResponse.StatusCode;
            }
            catch (Exception ex)
            {
                var msg = $"Error delivering duck xml: {ex.Message}";
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
                _logger.LogInformation($"UploadDuckXml: failure = {response.ResponseMessage}");
            }
            return response;
        }
    }
}
