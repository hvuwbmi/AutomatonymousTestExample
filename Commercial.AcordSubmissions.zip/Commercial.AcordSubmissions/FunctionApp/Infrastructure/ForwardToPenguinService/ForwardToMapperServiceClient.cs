﻿using AcordSubmissions.Domain.Entities;
using AcordSubmissions.Domain.Interfaces;
using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;

namespace AcordSubmissions.Infrastructure.ForwardToPenguinService
{
    public class ForwardToMapperServiceClient : IForwardToMapperService
    {
        private readonly HttpClient _httpClient;
        private readonly string _penguinApiRoute = "/commercial/acord-private/api/v1/import/agencyport";
        private readonly string _wbmiApiRoute = "/commercial/acord-transformation-private/transform";
        private const string WC_LOB = "WorkCompPolicyQuoteInqRq";
       
        public ForwardToMapperServiceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;          
        }

        public async Task<ForwardToMapperRs> Submit(ForwardToMapperRq request)
        {
            var rs = new ForwardToMapperRs();
            try
            {
                var route = _penguinApiRoute;
                if (request.UseWbmiTransforms && !request.LOB.Equals(WC_LOB))
                {
                    route = _wbmiApiRoute;
                }
                var rq = new HttpRequestMessage(HttpMethod.Post, route);
                rq.Content = new StringContent(request.XmlToMap.OuterXml, Encoding.UTF8, "application/xml");
                var result = await _httpClient.SendAsync(rq);
                var rsBody = await result.Content.ReadAsStringAsync();
                
                rs.HttpStatusCode = result.StatusCode;
                if (result.IsSuccessStatusCode)
                {
                    rs.ResponseCode = ResponseCode.Success;
                    rs.ReturnValue = rsBody;
                    rs.ResponseMessage = "Success";
                }
                else
                {
                    rs.ResponseCode = ResponseCode.ServerError;
                    rs.ResponseMessage = rsBody;
                }

            }
            catch(Exception ex)
            {
                rs.ExceptionResult = ex;
                rs.ResponseCode = ResponseCode.ServerError;
                rs.ResponseMessage = ex.Message;
            }

            return await Task.FromResult(rs);
        }
    }
}

