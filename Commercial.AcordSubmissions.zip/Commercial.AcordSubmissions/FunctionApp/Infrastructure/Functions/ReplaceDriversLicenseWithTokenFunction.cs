using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using System.Xml;
using AcordSubmissions.Domain.Entities;
using MediatR;
using Microsoft.Extensions.Logging;
using System.Web.Http;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;

namespace AcordSubmissions.Infrastructure.Functions
{
    public class ReplaceDriversLicenseWithTokenFunction
    {
        private IMediator _mediator;

        public ReplaceDriversLicenseWithTokenFunction(IMediator mediator)
        {
            _mediator = mediator;
        }

        [FunctionName("ReplaceDriversLicenseWithToken")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            [DurableClient] IDurableOrchestrationClient orchestrationClient,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            var acordXml = new XmlDocument();
            acordXml.LoadXml(requestBody);
            var rq = new AcordXmlTokenizePIIRequest
            {
                AcordXml = acordXml
            };


            var rs = await _mediator.Send(rq);

            if (rs.ResponseCode == ResponseCode.Success && rs.SubmitToPenguin)
            {
                log.LogInformation("Calling Orchestration Client - SubmitXmlToPenguin....");
                var instanceId = await orchestrationClient.StartNewAsync("SubmitXmlToPenguin", rs);
                log.LogInformation("SunbmitToPenguin process started", instanceId);
                return new OkResult();
            }
            else
            {
                switch (rs.ResponseCode)
                {
                    case ResponseCode.Warning:
                        return new ObjectResult(rs.ResponseMessage);
                    case ResponseCode.BadRequest:
                        return new BadRequestObjectResult(rs.ResponseMessage);
                    case ResponseCode.ServerError:
                        if (rs.ExceptionResult != null)
                        {
                            return new ExceptionResult(rs.ExceptionResult, true);
                        }
                        else
                        {
                            return new NotFoundObjectResult(rs.ResponseMessage);
                        }

                    default:
                        return new OkResult();
                }
            }
        }
    }
}
