using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using System.Xml;
using MediatR;
using System.Web.Http;
using System.Xml.Serialization;
using AcordSubmissions.Domain.Entities.DuckXmlTableQuery;
using Newtonsoft.Json;

namespace AcordSubmissions.Infrastructure.Functions
{
    public class DuckXmlTableQueryFunction
    {
        private IMediator _mediator;

        public DuckXmlTableQueryFunction(IMediator mediator)
        {
            _mediator = mediator;
        }

        [FunctionName("DuckXmlTableQuery")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            try
            {
                string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
                var xmldoc = new XmlDocument();
                xmldoc.LoadXml(requestBody);

                var serializer = new XmlSerializer(typeof(DuckXmlTableQueryRequest));
                DuckXmlTableQueryRequest rq = null;

                using (XmlReader xmlReader = new XmlNodeReader(xmldoc))
                {
                    rq = (DuckXmlTableQueryRequest)serializer.Deserialize(xmlReader);
                }

                var rs = await _mediator.Send(rq);
                rs.Response = rs.ResponseCode.ToString();

                var wrapper = new JsonWrapper() { AcordSubmissions = rs };
                var json = JsonConvert.SerializeObject(wrapper);
                XmlDocument doc = JsonConvert.DeserializeXmlNode(json);
                return new ContentResult { Content = doc.InnerXml, ContentType = "application/xml" };

            }
            catch (Exception ex)
            {
                log.LogError($"DuckXmlTableStorage threw an exception: {ex.Message}");
                return new ExceptionResult(ex, true);
            }
        }
    }
}
