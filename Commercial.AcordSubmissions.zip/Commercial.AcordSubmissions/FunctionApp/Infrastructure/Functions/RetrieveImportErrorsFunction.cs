using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using AcordSubmissions.Domain.Entities.DriverImportErrors;
using MediatR;
using AcordSubmissions.Domain.Entities;
using System.Web.Http;

namespace AcordSubmissions.Infrastructure.Functions
{
    public class RetrieveImportErrorsFunction
    {
        private IMediator _mediator;

        public RetrieveImportErrorsFunction(IMediator mediator)
        {
            _mediator = mediator;
        }
        
        [FunctionName("RetrieveImportErrors")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = "RetrieveImportErrors/{type}/{rowkey}")] HttpRequest req,
            string type, string rowkey,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //var serializer = new XmlSerializer(typeof(RetrieveDriverImportErrorsRequest));
            RetrieveImportErrorsRequest rq = new RetrieveImportErrorsRequest()
            {
                RowKey = rowkey,
                Type = type
            };

            RetrieveImportErrorsResponse rs = null;
            try
            {
                rs = await _mediator.Send(rq);

                // Check for errors
                if (rs.ResponseCode != ResponseCode.Success && rs.ResponseCode != ResponseCode.Warning)
                {
                    switch (rs.ResponseCode)
                    {
                        case ResponseCode.ServerError:
                            if (rs.ExceptionResult != null)
                            {
                                return new ExceptionResult(rs.ExceptionResult, true);
                            }
                            else
                            {
                                return new NotFoundObjectResult(rs.ResponseMessage);
                            }

                        case ResponseCode.BadRequest:
                            return new BadRequestObjectResult(rs.ResponseMessage);
                        default:
                            return new ObjectResult(rs.ResponseMessage);
                    }
                }

                return new ContentResult { Content = rs.ErrorsHtml, ContentType = "text/html" };                
            }
            catch(Exception ex)
            {
                rs = new RetrieveImportErrorsResponse()
                {
                    ResponseCode = ResponseCode.ServerError,
                    ExceptionResult = ex
                };

                return new ExceptionResult(rs.ExceptionResult, true);
            }
           


            
        }
    }
}
