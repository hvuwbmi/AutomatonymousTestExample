using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using AcordSubmissions.Domain.Entities;
using MediatR;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.DurableTask;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;

namespace AcordSubmissions.Infrastructure.Functions
{
    public class SubmitXmlToPenguinFunction
    {                    
        private IMediator _mediator;
    
        public SubmitXmlToPenguinFunction(IMediator mediator)
        {
            _mediator = mediator;
        }

        [FunctionName("SubmitXmlToPenguin")]
        public async Task RunOrchestrator(
            [OrchestrationTrigger] IDurableOrchestrationContext context,
            ILogger logger)
        {          
             if (!context.IsReplaying)
            { 
                var rs = context.GetInput<AcordXmlTokenizePIResponse>();

                logger.Log(LogLevel.Information, $"RunOrchestrator started with {rs.Division},{rs.EmailRowKey}....");

                var forwardToMapperRq = new ForwardToMapperRq()
                {
                    AcordXml = rs.AcordXml,
                    Division = rs.Division,
                    EmailRowKey = rs.EmailRowKey,
                    ConfidenceIndex = rs.ConfidenceIndex,
                    BusinessName = rs.BusinessName
                };

                await _mediator.Send(forwardToMapperRq);

            }
        }

    }
}