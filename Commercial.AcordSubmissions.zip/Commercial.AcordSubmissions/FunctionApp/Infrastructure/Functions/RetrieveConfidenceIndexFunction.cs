using System;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using MediatR;
using AcordSubmissions.Domain.Entities;
using System.Web.Http;

namespace AcordSubmissions.Infrastructure.Functions
{
    public class RetrieveConfidenceIndexFunction
    {
        private IMediator _mediator;

        public RetrieveConfidenceIndexFunction(IMediator mediator)
        {
            _mediator = mediator;
        }

        [FunctionName("RetrieveConfidenceIndex")]
        public async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", Route = "RetrieveConfidenceIndex/{rowkey}")] HttpRequest req,
            string rowkey,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            RetrieveConfidenceIndexRequest rq = new RetrieveConfidenceIndexRequest()
            {
                RowKey = rowkey
            };

            RetrieveConfidenceIndexResponse rs = null;
            try
            {
                rs = await _mediator.Send(rq);

                // Check for errors
                if (rs.ResponseCode != ResponseCode.Success && rs.ResponseCode != ResponseCode.Warning)
                {
                    switch (rs.ResponseCode)
                    {
                        case ResponseCode.ServerError:
                            if (rs.ExceptionResult != null)
                            {
                                return new ExceptionResult(rs.ExceptionResult, true);
                            }
                            else
                            {
                                return new NotFoundObjectResult(rs.ResponseMessage);
                            }

                        case ResponseCode.BadRequest:
                            return new BadRequestObjectResult(rs.ResponseMessage);
                        default:
                            return new ObjectResult(rs.ResponseMessage);
                    }
                }

                return new ContentResult { Content = rs.ConfidenceIndex, ContentType = "text/xml" };                
            }
            catch(Exception ex)
            {
                rs = new RetrieveConfidenceIndexResponse()
                {
                    ResponseCode = ResponseCode.ServerError,
                    ExceptionResult = ex
                };

                return new ExceptionResult(rs.ExceptionResult, true);
            }
        }
    }
}
