﻿using AcordSubmissions.Application;
using AcordSubmissions.Domain.Interfaces;
using AcordSubmissions.Infrastructure.ForwardToPenguinService;
using AcordSubmissions.Infrastructure.Functions.Clients;
using AcordSubmissions.Infrastructure.StorageService;
using AcordSubmissions.Infrastructure.CommonLogService;
using MediatR;
using Microsoft.Azure.Functions.Extensions.DependencyInjection;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Reflection;

[assembly: FunctionsStartup(typeof(AcordSubmissions.Infrastructure.Functions.Startup))]

namespace AcordSubmissions.Infrastructure.Functions
{
    public class Startup : FunctionsStartup
    {
        public override void Configure(IFunctionsHostBuilder builder)
        {
            builder.Services.AddMediatR(typeof(AcordXmlTokenizePIIHandler).GetTypeInfo().Assembly);
            builder.Services.AddSingleton<IRepository, StorageClient>();
            
            builder.Services.AddHttpClient<IForwardToMapperService, ForwardToMapperServiceClient>(client =>
            {
                client.BaseAddress = new Uri(Environment.GetEnvironmentVariable("APIM"));
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", Environment.GetEnvironmentVariable("ApimSubscriptionKey"));
                client.Timeout = TimeSpan.FromMinutes(GetAPITimeout());
            });

            builder.Services.AddHttpClient<ITokenizerService, TokenizerServiceClient>(client =>
            {
                client.BaseAddress = new Uri(Environment.GetEnvironmentVariable("APIM"));
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", Environment.GetEnvironmentVariable("ApimSubscriptionKey"));               
            });

            builder.Services.AddHttpClient<ICommonLogService, CommonLogServiceClient>(client =>
            {
                client.BaseAddress = new Uri(Environment.GetEnvironmentVariable("APIM"));
                client.DefaultRequestHeaders.Add("Ocp-Apim-Subscription-Key", Environment.GetEnvironmentVariable("ApimSubscriptionKey"));
            });         
        }

        private int GetAPITimeout()
        {
            var httpTimeout = 10;
            if (Environment.GetEnvironmentVariable("HttpTimeout") != null)
            {
                if (!Int32.TryParse(Environment.GetEnvironmentVariable("HttpTimeout"), out httpTimeout))
                {
                    httpTimeout = 10;
                }
            }

            return httpTimeout;

        }
    }
}

