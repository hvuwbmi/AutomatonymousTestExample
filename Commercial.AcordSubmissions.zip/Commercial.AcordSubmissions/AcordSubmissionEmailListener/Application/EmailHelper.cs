﻿using System;
using System.Globalization;

namespace AcordSubmissionEmailListener.Application
{
    public static class EmailHelper
    {
        public static string CreateEmailId()
        {
            // https://alexandrebrisebois.wordpress.com/2013/03/01/storing-windows-azure-storage-table-entities-in-descending-order/#comments
            var rnd = new Random();

            var inverseTimeKey = DateTime
              .MaxValue
              .Subtract(DateTime.UtcNow)
              .TotalMilliseconds
              .ToString(CultureInfo.InvariantCulture);
            var randomNumber = rnd.Next(999).ToString();
            return string.Format("{0}{1}", "00" + inverseTimeKey, randomNumber);
        }
    }
}
