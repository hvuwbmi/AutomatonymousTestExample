﻿using AcordSubmissionEmailListener.Domain.Entities;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail.Enums;
using AcordSubmissionEmailListener.Domain.Interfaces;
using Microsoft.Exchange.WebServices.Data;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Text;

namespace AcordSubmissionEmailListener.Application
{
    public class UpdateEmailSubmissionClient //: IRequestHandler<GetEmailsRequest, GetEmailsResponse>
    {
        private IConfiguration _config;
        private IRepository _storageClient;
        private ICommonLogService _commonLogService;
        private readonly ILogger _logger;

        private const int MAX_EMAIL_SUBJECT_LENGTH = 128;
        private const int MAX_EMAIL_MESSAGE_SIZE = 20000000;

        private readonly string ACORD_SUBMISSION_MAILBOX;
        private readonly string ACORD_SUBMISSION_MAILBOX_KEY = "acord_submission_mailbox";
        private readonly string ACORD_SUBMISSION_MAILBOX_PASSWORD;
        private readonly string ACORD_SUBMISSION_MAILBOX_PASSWORD_KEY = "acord_submission_mailbox_password";
        private readonly string TARGET_ACORD_SUBMISSION_MAILBOX;
        private readonly string TARGET_ACORD_SUBMISSION_MAILBOX_KEY = "target_acord_submission_mailbox";
        private readonly string ARG_ACORD_SUBMISSION_MAILBOX_ALIAS;
        private readonly string ARG_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY = "ARG_acord_submission_mailbox_alias";
        private readonly string NSI_ACORD_SUBMISSION_MAILBOX_ALIAS;
        private readonly string NSI_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY = "NSI_acord_submission_mailbox_alias";
        private readonly string WBCL_ACORD_SUBMISSION_MAILBOX_ALIAS;
        private readonly string WBCL_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY = "WBCL_acord_submission_mailbox_alias";

        
        public UpdateEmailSubmissionClient(ILogger logger, IRepository storageClient, ICommonLogService commonLogService, IConfiguration config)
        {
            _config = config;
            _logger = logger;
            _logger.LogInformation("Update email submission");
            _storageClient = storageClient;
            _commonLogService = commonLogService;

            ACORD_SUBMISSION_MAILBOX = _config.GetSection("Mailboxes")[ACORD_SUBMISSION_MAILBOX_KEY];
            ACORD_SUBMISSION_MAILBOX_PASSWORD = _config.GetSection("Mailboxes")[ACORD_SUBMISSION_MAILBOX_PASSWORD_KEY];
            TARGET_ACORD_SUBMISSION_MAILBOX = _config.GetSection("Mailboxes")[TARGET_ACORD_SUBMISSION_MAILBOX_KEY];
            ARG_ACORD_SUBMISSION_MAILBOX_ALIAS = _config.GetSection("Mailboxes")[ARG_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY];
            NSI_ACORD_SUBMISSION_MAILBOX_ALIAS = _config.GetSection("Mailboxes")[NSI_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY];
            WBCL_ACORD_SUBMISSION_MAILBOX_ALIAS = _config.GetSection("Mailboxes")[WBCL_ACORD_SUBMISSION_MAILBOX_ALIAS_KEY];      
        }

        public async Task<GetEmailsResponse> Handle(GetEmailsRequest request, CancellationToken cancellationToken)
        {
            var response = new GetEmailsResponse();
            try
            {

                // do work          
                Console.WriteLine(request.ToString());
                _logger.LogInformation("handle email submission");


                response.EmailMessageEntities = new List<EmailMessageEntity>();
                ExchangeService service = new ExchangeService();
                // Create the exchange service
                service = new ExchangeService(ExchangeVersion.Exchange2015)
                {
                    Credentials = new WebCredentials(ACORD_SUBMISSION_MAILBOX, ACORD_SUBMISSION_MAILBOX_PASSWORD, "wbmi.onmicrosoft.com"),
                    Url = new Uri("https://outlook.office365.com/EWS/Exchange.asmx"),
                    TraceEnabled = false,
                    TraceFlags = TraceFlags.None
                };

                // Get the mailbox and folders
                var inboxFolderId = new FolderId(WellKnownFolderName.Inbox, new Mailbox(ACORD_SUBMISSION_MAILBOX));
                var inboxFolder = await GetFolder(service, inboxFolderId); 

                var inboxFolders = await inboxFolder.FindFolders(new FolderView(20));
                var subFolders = GetSubFolders(inboxFolders);

                //Get all the messages from the inbox and perform actions
                if (inboxFolder != null)
                {
                    FindItemsResults<Item> items = null;
                    do
                    {
                        items = await inboxFolder.FindItems("Kind:email", new ItemView(1));
                        List<EmailMessage> emailMessages = items.Select(s => (EmailMessage)s).ToList();

                        foreach (var emailMessage in emailMessages)
                        {
                            // truncate subject if necessary so Turnstile does not error
                            if (emailMessage.Subject.Length > MAX_EMAIL_SUBJECT_LENGTH)
                            {
                                emailMessage.Subject = emailMessage.Subject.Substring(0, MAX_EMAIL_SUBJECT_LENGTH);
                            }

                            _logger.LogInformation("email message: " + emailMessage.Subject);

                            // Define the division
                            var division = GetDivisionAsync(emailMessage);
                            if (division != Division.Unknown)
                            {
                                _logger.LogInformation("subject and division" + emailMessage.Subject + ":" + division);
                                //var GUID = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant();
                                var GUID = EmailHelper.CreateEmailId();

                                // Remove invalid email messages
                                if (await ValidEmailAsync(emailMessage, division, subFolders, GUID))
                                {
                                    // add attachment
                                    await this.AddAttachmentToEmailAsync(emailMessage, division, GUID);

                                    // Move message to another folder
                                    var subFolderId = subFolders[GetTargetFolderName(division)];
                                    if(subFolderId != null)
                                    {
                                        // Forward email to sub bot folder
                                        var targetEmailAddress = new EmailAddress(TARGET_ACORD_SUBMISSION_MAILBOX);
                                        var optionalBodyMessage = "this has been forwarded from " + division;
                                        await emailMessage.Forward(new MessageBody(optionalBodyMessage), targetEmailAddress);

                                        //If the subfolder exists, move the email to that folder
                                        await emailMessage.Move(subFolderId);

                                        //Add to collection of messages to be returned
                                        response.EmailMessageEntities.Add(MapEmailMessageToEntity(emailMessage, division, GUID));

                                        //Store the details of the emails
                                        var storeEmailRequest = MapEmailEntityToRequest(emailMessage, division, GUID);
                                        var storeEmailResponse = await _storageClient.StoreEmailDetails(storeEmailRequest);
                                        if (storeEmailResponse.ResponseCode != ResponseCode.Success
                                            && storeEmailResponse.ResponseCode != ResponseCode.Warning)
                                        {
                                            var LogRq = new CommonLogServiceRq();
                                            LogRq.severity = "Information";
                                            LogRq.message = $"Email Storage Failure - Code: {storeEmailResponse.ResponseCode} Reason: {storeEmailResponse.ResponseMessage}";
                                            LogRq.extendedProperties = new List<CommonLogExtendedProperty>();
                                            LogRq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
                                            var LogRs = _commonLogService.CommonLog(LogRq).Result;
                                        }

                                        var submissionEventsRq = new StoreSubmissionEventsRequest()
                                        {
                                            EmailId = GUID,
                                            Event = "SUBMITTED_TO_TURNSTILE"
                                        };

                                        var storeSubmissionEventsRs = await _storageClient.StoreSubmissionEvents(submissionEventsRq);
                                        if (storeEmailResponse.ResponseCode != ResponseCode.Success
                                            && storeEmailResponse.ResponseCode != ResponseCode.Warning)
                                        {
                                            var LogRq = new CommonLogServiceRq();
                                            LogRq.severity = "Information";
                                            LogRq.message = $"Submission Events Storage Failure - Code: {storeSubmissionEventsRs.ResponseCode} Reason: {storeSubmissionEventsRs.ResponseMessage}";
                                            LogRq.extendedProperties = new List<CommonLogExtendedProperty>();
                                            LogRq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
                                            var LogRs = _commonLogService.CommonLog(LogRq).Result;
                                        }
                                    }
                                    else
                                    {
                                        var message = $"Sub Folder not found";
                                        SendMessageToCommonLog(message, "Information", GUID, division);
                                    }
                                }
                                else
                                {
                                    var message = $"Email larger than 20MB";
                                    SendMessageToCommonLog(message, "Information", GUID, division);
                                }
                            }
                            else
                            {
                                if (IsACORDSubmissionEmail(emailMessage))
                                {
                                    // If this is a ACORD submission email, do nothing and leave in inbox
                                }
                                else
                                {
                                    // If it is not recognized as an ACORD submission email, ,ove message to the unknown folder
                                    var subFolderId = subFolders[GetTargetFolderName(division)];
                                    await emailMessage.Move(subFolderId);
                                    _logger.LogInformation("Division unknown");
                                }
                            }
                        }
                    }
                    while (items.Count() > 0);
                }
                else
                {
                    _logger.LogError($"Could not read the inbox.  Mailbox: {ACORD_SUBMISSION_MAILBOX}");
                    response.ResponseCode = ResponseCode.Failure;
                    response.ResponseMessage = "Could not read the inbox.";
                }

                return await System.Threading.Tasks.Task.FromResult(response);

            }
            catch(Exception ex)
            {
                _logger.LogError($"Error while processing emails.");
                response.ResponseCode = ResponseCode.Failure;
                response.ResponseMessage = $"Could not process emails. {ex.Message}";
                return await System.Threading.Tasks.Task.FromResult(response);
            };

        }

        private bool IsACORDSubmissionEmail (EmailMessage emailMessage)
        {
            bool result = false;
            if (emailMessage.DisplayTo.ToUpper().Contains("ACORD DEV") || 
                emailMessage.DisplayTo.ToUpper().Contains("ACORD QA") ||
                emailMessage.DisplayTo.ToUpper().Contains("CORD SUB PREPROD") ||
                emailMessage.DisplayTo.ToUpper().Contains("ACORD PROD"))
            {
                return true;
            }
            return result;
        }

        private StoreEmailDetailsRequest MapEmailEntityToRequest(EmailMessage email, string division, string GUID)
        {
            var detailsRequest = new StoreEmailDetailsRequest()
            {
                Division = division,
                emailGUID = GUID,
                receivedTimestamp = email.DateTimeReceived.ToString(),
                Sender = email.Sender.ToString(),
                Subject = email.Subject
            };

            return detailsRequest;
        }

        private EmailMessageEntity MapEmailMessageToEntity(EmailMessage msg, string division, string GUID)
        {
            var emailMessageEntity = new EmailMessageEntity()
            {
                Division = division,
                emailGUID = GUID,
                receivedTimestamp = msg.DateTimeReceived.ToString(),
                Sender = msg.Sender.ToString(),
                Subject = msg.Subject
            };
            return emailMessageEntity;
        }

        private string GetTargetFolderName(string division)
        {
            string result;
            switch(division)
            {
                case Division.Argent:
                    result = FolderName.Argent;
                    break;
                case Division.NSI:
                    result = FolderName.NSI;
                    break;
                case Division.WBCL:
                    result = FolderName.WBCL;
                    break;
                default:
                    result = FolderName.Unknown;
                    break;
            }
            _logger.LogInformation("folder name = " + result);
            return result;
        }

        private Dictionary<string, FolderId> GetSubFolders(FindFoldersResults inboxFolders)
        {
            var result = new Dictionary<string, FolderId>();

            result.Add(FolderName.Argent, GetFolderId(FolderName.Argent, inboxFolders));
            result.Add(FolderName.Argent + " Errors", GetFolderId(FolderName.Argent + " Errors", inboxFolders));
            result.Add(FolderName.NSI, GetFolderId(FolderName.NSI, inboxFolders));
            result.Add(FolderName.NSI + " Errors", GetFolderId(FolderName.NSI + " Errors", inboxFolders));
            result.Add(FolderName.WBCL, GetFolderId(FolderName.WBCL, inboxFolders));
            result.Add(FolderName.WBCL + " Errors", GetFolderId(FolderName.WBCL + " Errors", inboxFolders));
            result.Add(FolderName.Unknown, GetFolderId(FolderName.Unknown, inboxFolders));

            return result;
        }

        private FolderId GetFolderId(string division, FindFoldersResults inboxFolders)
        {
            FolderId result = null;
            foreach (var folder in inboxFolders)
            {
                if (folder.DisplayName == division)
                {
                    result = folder.Id;
                }
            }
            return result;
        }

        private string GetDivisionAsync(EmailMessage emailMessage)
        {
            _logger.LogInformation("begin GetDivisionAsync: " + emailMessage.Subject);

            var division = Division.Unknown;

                var recipients = emailMessage.DisplayTo;
                _logger.LogInformation("recipient = " + recipients);
                if (recipients.Contains(ARG_ACORD_SUBMISSION_MAILBOX_ALIAS))
                {
                    division = Division.Argent;
                }
                if (recipients.Contains(NSI_ACORD_SUBMISSION_MAILBOX_ALIAS))
                {
                    division = Division.NSI;
                }
                if (recipients.Contains(WBCL_ACORD_SUBMISSION_MAILBOX_ALIAS))
                {
                    division = Division.WBCL;
                }

            _logger.LogInformation("division = " + division);
            return division;
        }

        private async System.Threading.Tasks.Task AddAttachmentToEmailAsync (EmailMessage emailMessage, string division, string GUID)
        {
            var bytes = Properties.Resources.blank;
            emailMessage.Attachments.AddFileAttachment($"EmailID_{division}_{GUID}.pdf", bytes);
            await emailMessage.Update(ConflictResolutionMode.AlwaysOverwrite);
        }

        private async Task<Folder> GetFolder(ExchangeService service, FolderId folderId)
        {
            return await Folder.Bind(service, folderId);
        }

        private static bool RedirectionUrlValidationCallback(string redirectionUrl)
        {
            // The default for the validation callback is to reject the URL.
            bool result = false;
            Uri redirectionUri = new Uri(redirectionUrl);
            // Validate the contents of the redirection URL. In this simple validation
            // callback, the redirection URL is considered valid if it is using HTTPS
            // to encrypt the authentication credentials. 
            if (redirectionUri.Scheme == "https")
            {
                result = true;
            }
            return result;
        }

        private async Task<bool> ValidEmailAsync(EmailMessage emailMessage, string division, Dictionary<string, FolderId> subFolders, string GUID)
        {
            //Check size
            if (emailMessage.Size > MAX_EMAIL_MESSAGE_SIZE)
            {
                _logger.LogInformation("Email size > 20MB" + emailMessage.Subject + ":" + division);

                //store email
                var storeEmailResponse = await StoreEmailDetailsAsync(emailMessage, division, GUID);

                //move email
                var subFolderId = subFolders[GetTargetFolderName(division) + " Errors"];
                await emailMessage.Move(subFolderId);

                //Write Event
                //TODO: We need a way to update the status field
                var submissionEventsRq = new StoreSubmissionEventsRequest()
                {
                    EmailId = GUID,
                    Event = "UNSUBMITTED",
                    Status = ">20MB"
                };

                var storeSubmissionEventsRs = await _storageClient.StoreSubmissionEvents(submissionEventsRq);
                if (storeEmailResponse.ResponseCode != ResponseCode.Success
                    && storeEmailResponse.ResponseCode != ResponseCode.Warning)
                {
                    var message = $"Submission Events Storage Failure - Code: {storeSubmissionEventsRs.ResponseCode} Reason: {storeSubmissionEventsRs.ResponseMessage}";
                    SendMessageToCommonLog(message, "Information", GUID, division);
                }

                return false;
            }
            return true;
        }

        private async Task<StoreEmailDetailsResponse> StoreEmailDetailsAsync(EmailMessage emailMessage, string division, string GUID)
        {
            var storeEmailRequest = MapEmailEntityToRequest(emailMessage, division, GUID);
            var storeEmailResponse = await _storageClient.StoreEmailDetails(storeEmailRequest);
            if (storeEmailResponse.ResponseCode != ResponseCode.Success
                && storeEmailResponse.ResponseCode != ResponseCode.Warning)
            {
                var message = $"Email Storage Failure - Code: {storeEmailResponse.ResponseCode} Reason: {storeEmailResponse.ResponseMessage}";
                SendMessageToCommonLog(message, "Information", GUID, division);
            }
            return storeEmailResponse;

        }

        private void SendMessageToCommonLog(string message, string severity, string emailId, string division)
        {
            var errMessage = new StringBuilder();
            errMessage.AppendLine(message);
            errMessage.Append($"Divison: {division}");
            errMessage.Append($" EmailID: {emailId}");
            var LogRq = new CommonLogServiceRq();
            LogRq.severity = severity;
            LogRq.message = errMessage.ToString();
            LogRq.extendedProperties = new List<CommonLogExtendedProperty>();
            LogRq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
            var LogRs = _commonLogService.CommonLog(LogRq).Result;
        }
    }
}
