﻿using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using System.Threading.Tasks;

namespace AcordSubmissionEmailListener.Domain.Interfaces
{
    public interface IUpdateSubmissionEmail
    {
        Task<GetEmailsResponse> AddAttachmentAndForwardAsync(GetEmailsRequest rq);
    }
}
