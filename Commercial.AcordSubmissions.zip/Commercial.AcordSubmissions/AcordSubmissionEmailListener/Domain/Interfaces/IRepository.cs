﻿using AcordSubmissionEmailListener.Domain.Entities;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using System.Threading.Tasks;

namespace AcordSubmissionEmailListener.Domain.Interfaces
{
    public interface IRepository
    {        
        Task<StoreEmailDetailsResponse> StoreEmailDetails(StoreEmailDetailsRequest request);

        Task<BaseResponse> StoreSubmissionEvents(StoreSubmissionEventsRequest request);
    }
}
