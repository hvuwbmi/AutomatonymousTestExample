﻿using AcordSubmissionEmailListener.Domain.Entities;
using System.Threading.Tasks;

namespace AcordSubmissionEmailListener.Domain.Interfaces
{
    public interface ICommonLogService
    {
        Task<BaseResponse> CommonLog(CommonLogServiceRq rq);
    }
}
