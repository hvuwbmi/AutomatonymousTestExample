﻿using System.Collections.Generic;

namespace AcordSubmissionEmailListener.Domain.Entities
{
    public class CommonLogServiceRq
    {
        public string category
        {
            get
            {
                return "AcordUpload";
            }

        }

        public string severity { get; set; }

        public string message { get; set; }
        public List<CommonLogExtendedProperty> extendedProperties { get; set; }

    }
}
