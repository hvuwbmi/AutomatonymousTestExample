﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class Response
    {
        public string Result { get; set; }
    }
}
