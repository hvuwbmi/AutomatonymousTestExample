﻿using MediatR;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class StoreEmailDetailsRequest : IRequest<StoreEmailDetailsRequest>
    {
        public string Sender { get; set; }

        public string emailGUID { get; set; }

        public string Subject { get; set; }

        public string Division { get; set; }

        public string receivedTimestamp { get; set; }
    }
}
