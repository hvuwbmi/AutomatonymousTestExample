﻿namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class GetEmailsRequest
    {
    }
}
