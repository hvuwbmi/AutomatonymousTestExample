﻿namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail.Enums
{
    public static class FolderName
    {
        public const string Argent = "ARG";
        public const string NSI = "NSI";
        public const string WBCL = "WBCL";
        public const string Unknown = "Unknown";
    }
}
