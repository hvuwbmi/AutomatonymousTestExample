﻿namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail.Enums
{
    public static class Division
    {
        public const string Argent = "Argent";
        public const string NSI = "NSI";
        public const string WBCL = "WBCL";
        public const string Unknown = "Unknown";
    }
}
