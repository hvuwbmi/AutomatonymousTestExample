﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class StoreSubmissionEventsRequest
    {
        public string EmailId { get; set; }
        public string Event { get; set; }
        public string Status { get; set; }
    }
}
