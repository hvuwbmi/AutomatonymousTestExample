﻿using System.Collections.Generic;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class GetEmailsResponse : BaseResponse
    {
        public List<EmailMessageEntity> EmailMessageEntities { get; set; }
    }
}
