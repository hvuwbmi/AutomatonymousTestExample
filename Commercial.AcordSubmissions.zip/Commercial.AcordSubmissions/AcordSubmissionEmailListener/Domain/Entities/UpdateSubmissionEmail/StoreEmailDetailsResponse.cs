﻿namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class StoreEmailDetailsResponse : BaseResponse
    {
    }
}
