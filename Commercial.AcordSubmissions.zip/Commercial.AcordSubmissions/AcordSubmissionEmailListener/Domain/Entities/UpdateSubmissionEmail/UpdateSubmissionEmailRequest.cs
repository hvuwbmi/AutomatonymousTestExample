﻿using MediatR;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class UpdateSubmissionEmailRequest : IRequest<Unit>
    {

    }
}