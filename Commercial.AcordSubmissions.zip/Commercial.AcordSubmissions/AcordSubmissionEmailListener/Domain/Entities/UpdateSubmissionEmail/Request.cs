﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class Request : IRequest<Response>
    {
        public string Message { get; set; }
    }
}
