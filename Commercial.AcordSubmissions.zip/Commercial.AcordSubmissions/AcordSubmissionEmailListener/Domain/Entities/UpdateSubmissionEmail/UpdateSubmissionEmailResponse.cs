﻿namespace AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail
{
    public class UpdateSubmissionEmailResponse : BaseResponse
    {
    }
}
