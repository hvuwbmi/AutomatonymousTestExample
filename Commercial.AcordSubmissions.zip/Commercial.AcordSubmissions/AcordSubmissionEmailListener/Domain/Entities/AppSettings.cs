﻿using System;
using System.Collections.Generic;
using System.Text;

namespace AcordSubmissionEmailListener.Domain.Entities
{
    public class AppSettings
    {
        public string Environment { get; set; }
    }
}
