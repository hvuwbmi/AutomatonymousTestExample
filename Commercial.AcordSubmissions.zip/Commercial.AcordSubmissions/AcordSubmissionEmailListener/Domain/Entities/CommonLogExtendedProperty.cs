﻿namespace AcordSubmissionEmailListener.Domain.Entities
{
    public class CommonLogExtendedProperty
    {
        public string Key { get; set; }
        public string Value { get; set; }

    }
}
