﻿using Microsoft.Azure.Cosmos.Table;
using System;

namespace SmallCommercial.Infrastructure.StorageService
{
    public class TimeoutRetryPolicy : IRetryPolicy
    {
        int maxRetryAttempts = 3;

        TimeSpan defaultRetryInterval = TimeSpan.FromMilliseconds(250);

        public TimeoutRetryPolicy(TimeSpan deltaBackoff, int retryAttempts)
        {
            maxRetryAttempts = retryAttempts;
            defaultRetryInterval = deltaBackoff;
        }

        public IRetryPolicy CreateInstance()
        {
            return new TimeoutRetryPolicy(TimeSpan.FromMilliseconds(250), 3);
        }

        public bool ShouldRetry(int currentRetryCount, int statusCode, Exception lastException, out TimeSpan retryInterval, OperationContext operationContext)
        {
            retryInterval = defaultRetryInterval;
            if (currentRetryCount >= maxRetryAttempts)
            {
                return false;
            }

            // Non-retryable exceptions are all 400 ( >=400 and <500) class exceptions (Bad gateway, Not Found, etc.) as well as 501 and 505. 
            // This custom retry policy also retries on a 408 timeout.
            if ((statusCode >= 400 && statusCode <= 500 && statusCode != 408) || statusCode == 501 || statusCode == 505)
            {
                return false;
            }

            return true;
        }
    }
}
