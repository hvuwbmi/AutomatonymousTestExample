﻿using AcordSubmissionEmailListener.Domain.Entities;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using AcordSubmissionEmailListener.Domain.Interfaces;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;

namespace AcordSubmissionEmailListener.Infrastructure.StorageService
{
    public class StorageClient : IRepository
    {
        private ILogger<StorageClient> _logger;
        private TableStorageClient _tableStorageClient;
        

        public StorageClient(ILogger<StorageClient> logger, string connectionString)
        {
            //_logger = logger;
            _tableStorageClient = new TableStorageClient(logger, connectionString);
        }

        public async Task<StoreEmailDetailsResponse> StoreEmailDetails(StoreEmailDetailsRequest request)
        {
            //_logger.LogInformation($"Begin storage....");
            return await _tableStorageClient.StoreEmailDetails(request);
        }

        public async Task<BaseResponse> StoreSubmissionEvents(StoreSubmissionEventsRequest request)
        {
            return await _tableStorageClient.StoreSubmissionEvent(request);
        }
        
    }
}
