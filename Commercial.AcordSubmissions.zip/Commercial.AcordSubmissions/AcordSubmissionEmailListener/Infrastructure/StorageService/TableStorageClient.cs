﻿using AcordSubmissionEmailListener.Domain.Entities;
using AcordSubmissionEmailListener.Infrastructure.StorageService.TableEntities;
using Microsoft.Azure.Cosmos.Table;
using Microsoft.Extensions.Logging;
using System;
using System.Threading.Tasks;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using SmallCommercial.Infrastructure.StorageService;
using MassTransit;

namespace AcordSubmissionEmailListener.Infrastructure.StorageService
{
    public class TableStorageClient
    {
        private string _connectionString;
        private CloudStorageAccount _storageAccount;
        private ILogger<StorageClient> _logger;
       
        private static readonly string EmailDetailsTableName = "EmailDetails";
        private static readonly string SubmissionEventsTableName = "SubmissionEvents";
        private static readonly string EmailDetailsPartitionKey = "AcordSubmission";
              
        public TableStorageClient(ILogger<StorageClient> logger, string connectionString)
        {
            _logger = logger;           
            _connectionString = connectionString;

        }

        public async Task<StoreEmailDetailsResponse> StoreEmailDetails(StoreEmailDetailsRequest request)
        {
            var response = new StoreEmailDetailsResponse();

            try
            {
                // create Table Storage Table
                var table = CreateTableAsync(EmailDetailsTableName).Result;
                //_logger.LogInformation($"TableStorageClient:StoreEmailDetails: Created Table {table.Name}");
                // build entity from XML 
                var tableEntity = MapRequestToTableEntity(request, EmailDetailsPartitionKey);

                await StoreToTableStorage(table, tableEntity);
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Email Table Storage: {ex.Message} EmailId: {request.emailGUID}";
                //_logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
                return response;
            }


            //_logger.LogInformation("TableStorageClient:StoreEmailDetails: Table storage success");
            response.ResponseCode = ResponseCode.Success;
            response.Response = ResponseCode.Success.ToString();
            response.ResponseMessage = "Email details storage successful.";

            return response;
        }

        public async Task<BaseResponse> StoreSubmissionEvent(StoreSubmissionEventsRequest request)
        {           
            var response = new BaseResponse();

            try
            {
                // begin table storage setup

                // create Table Storage Tbale
                var table = CreateTableAsync(SubmissionEventsTableName).Result;
               
                // build entity from XML 
                var tableEntity = new SubmissionEventsTable
                {
                    PartitionKey = request.EmailId,
                    RowKey = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant(),
                    Events = request.Event,
                    Status = String.IsNullOrEmpty(request.Status) ? string.Empty : request.Status,
                    ErrorDescription = string.Empty,
                    TotalCount = string.Empty,
                    Count= string.Empty
                };

            
                await StoreToTableStorage(table, tableEntity);
              
                response.ResponseCode = ResponseCode.Success;
                response.Response = ResponseCode.Success.ToString();
                response.ResponseMessage = "SubmissionEvents storage successful.";
            }
            catch (Exception ex)
            {
                var msg = $"Error storing to Table Storage: {ex.Message}";
                //_logger.LogError(msg);
                response.ExceptionResult = ex;
                response.ResponseCode = ResponseCode.ServerError;
                response.ResponseMessage = msg;
            }


            return response;


        }

        private EmailDetailsTable MapRequestToTableEntity(StoreEmailDetailsRequest request, string partitionKey)
        {
            var response = new EmailDetailsTable()
            {
                PartitionKey = partitionKey,
                RowKey = request.emailGUID,
                Sender = request.Sender,
                Subject = request.Subject,
                Division = request.Division,
                receivedTimestamp = request.receivedTimestamp
            };

            return response;
        }

        private async Task StoreToTableStorage(CloudTable cloudTable, TableEntity tableEntity)
        {
            //_logger.LogInformation("TableStorageClient:StoreToTableStorage: Begin");
            //// Create the InsertOrReplace table operation
            TableOperation insertOrMergeOperation = TableOperation.InsertOrMerge(tableEntity);

            try
            {
                var requestOptions = new TableRequestOptions();
                requestOptions.RetryPolicy = new TimeoutRetryPolicy(TimeSpan.FromMilliseconds(250), 3);

                var operationContext = new OperationContext();
                operationContext.Retrying += OperationContext_Retrying;
                operationContext.RequestCompleted += OperationContext_RequestCompleted;

                // Execute the operation.
                var result = await cloudTable.ExecuteAsync(insertOrMergeOperation, requestOptions, operationContext);
                //_logger.LogInformation($"TableStorageClient:StoreToTableStorage: ExecuteAsync InsertOrMerge Http Result: {result.HttpStatusCode}");
            }
            catch (Exception ex)
            {
                //_logger.LogError($"Request failed in {this.GetType().Name} due to exception {ex.Message}");
            }

            //_logger.LogInformation("TableStorageClient:StoreToTableStorage: End");
        }

        private void OperationContext_RequestCompleted(object sender, RequestEventArgs e)
        {
            if (e.Response == null || (int)e.Response.StatusCode >= 400)
            {
                // This is occasionally executed - we want to retry in this case.
                //_logger.LogError($"Request failed in {this.GetType().Name} due to HTTP code {e.RequestInformation.HttpStatusCode} with exception {e.RequestInformation.Exception.ToString()}");
            }
            else
            {
                //_logger.LogInformation($"{this.GetType().Name} operation complete: Status code {e.Response.StatusCode}");
            }
        }

        private void OperationContext_Retrying(object sender, RequestEventArgs e)
        {
            //_logger.LogInformation($"Retry policy activated in {this.GetType().Name} due to HTTP code {e.RequestInformation.HttpStatusCode} with exception {e.RequestInformation.Exception.ToString()}");
        }

        private async Task<CloudTable> CreateTableAsync(string tableName)
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);

            CloudTableClient tableClient = _storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            CloudTable table = tableClient.GetTableReference(tableName);

            await table.CreateIfNotExistsAsync();
            return table;
        }
    }
}
