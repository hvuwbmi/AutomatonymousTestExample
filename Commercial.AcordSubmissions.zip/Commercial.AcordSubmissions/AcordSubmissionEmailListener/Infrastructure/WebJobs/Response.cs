﻿using System;
using System.Collections.Generic;
using System.Text;

namespace EmailWebJob.Infrastructure.ConsoleWebJob
{
    public class Response
    {
        public string Result { get; set; }
    }
}
