﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace EmailWebJob.Infrastructure.ConsoleWebJob
{
    public class Request : IRequest<Response>
    {
        public string Message { get; set; }
    }
}
