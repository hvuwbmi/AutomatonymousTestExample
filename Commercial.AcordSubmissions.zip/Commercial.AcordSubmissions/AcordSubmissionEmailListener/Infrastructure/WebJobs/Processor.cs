﻿using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using AcordSubmissionEmailListener.Infrastructure.StorageService;
using AcordSubmissionEmailListener.Infrastructure.CommonLogService;
using MediatR;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using System;
using System.Threading;
using AcordSubmissionEmailListener.Application;
using Microsoft.Extensions.Configuration;

namespace EmailWebJob.Infrastructure.ConsoleWebJob
{

    public class Processor
    {
        private IConfiguration _config;
      
        public Processor(IConfiguration config)
        {
            _config = config;
        }
        [NoAutomaticTrigger]
        public async void ProcessMethod(ILogger logger)
        {
            GetEmailsResponse rs = null;
            var rq = new GetEmailsRequest();
            //Because of a bug in .net core 3.0 DI, we are calling the handler directly
            var connectionString = _config.GetSection("ConnectionStrings")["AzureWebJobsStorage"];
            var storageClient = new StorageClient(null, connectionString);
            var httpClient = new System.Net.Http.HttpClient();
            httpClient.BaseAddress = new Uri(_config.GetSection("HttpCLient")["BaseAddress"]);
            httpClient.DefaultRequestHeaders.Add(_config.GetSection("HttpCLient")["SubscriptionKeyName"], _config.GetSection("HttpCLient")["SubscriptionKey"]);

            var commonLogService = new CommonLogServiceClient(httpClient);

            var client = new UpdateEmailSubmissionClient(logger, storageClient, commonLogService, _config);

            while (true)
            {

                rs = await client.Handle(rq, CancellationToken.None);

                logger.LogInformation(rs.ResponseMessage);
                Thread.Sleep(30000);
            }
        }
    }
}
