﻿using MediatR;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace EmailWebJob.Infrastructure.ConsoleWebJob
{
    public class Handler : IRequestHandler<Request, Response>
    {      
        public async Task<Response> Handle(Request request, CancellationToken cancellationToken)
        {
            // do work          
            Console.WriteLine(request.Message);

            var x = new Response()
            {
                Result = "Success"
            };
            return x;
        }
    }
}
