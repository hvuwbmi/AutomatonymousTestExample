﻿using System.Threading.Tasks;
using Xunit;
using AcordSubmissionEmailListener.Application;

namespace AcordSubmissionEmailListener.Test.UnitTest
{
    public class IDTest
    {

        [Fact]
        public async Task CreateEmailId_Test()
        {
            var firstId = EmailHelper.CreateEmailId();
            var secondId = EmailHelper.CreateEmailId();

            Assert.True(string.Compare(firstId, secondId) > 0);
        }


        // Tests I was using to write out results to a file for the NewId and the MaxValue methods
        //public void newID_Test()
        //{
        //    try
        //    {
        //        var csv = new StringBuilder();

        //        for (int x = 0; x < 100; x++)
        //        {
        //            var GUID = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant();
        //            var now = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff",
        //                                    CultureInfo.InvariantCulture);

        //            var newLine = string.Format("{0}, {1}", GUID, now.ToString());

        //            csv.Append(newLine);
        //            csv.Append("\n");
        //            Thread.Sleep(1);
        //        }

        //        //after your loop
        //        File.WriteAllText("C:\\temp\\file.csv", csv.ToString());

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }


        //}
        //public void newID_Test2()
        //{
        //    try
        //    {
        //        var csv = new StringBuilder();

        //        for (int x = 0; x < 100; x++)
        //        {
        //            var rnd = new Random();

        //            var inverseTimeKey = DateTime
        //              .MaxValue
        //              .Subtract(DateTime.UtcNow)
        //              .TotalMilliseconds
        //              .ToString(CultureInfo.InvariantCulture);
        //            var randomNumber = rnd.Next(999).ToString();
        //            //var GUID = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant();
        //            var now = DateTime.UtcNow.ToString("yyyy-MM-dd HH:mm:ss.fff",
        //                                    CultureInfo.InvariantCulture);

        //            var newLine = string.Format("{0}, {1}", "00" + inverseTimeKey + "_" + randomNumber, now.ToString());

        //            csv.Append(newLine);
        //            csv.Append("\n");
        //            Thread.Sleep(1);
        //        }

        //        //after your loop
        //        File.WriteAllText("C:\\temp\\file2.csv", csv.ToString());

        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }


        //}

    }
}
