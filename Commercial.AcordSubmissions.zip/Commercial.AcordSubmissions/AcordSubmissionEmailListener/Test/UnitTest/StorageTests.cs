﻿using AcordSubmissionEmailListener.Domain.Entities;
using AcordSubmissionEmailListener.Domain.Entities.UpdateSubmissionEmail;
using AcordSubmissionEmailListener.Infrastructure.StorageService;
using MassTransit;
using System;
using System.Net.Http;
using System.Threading.Tasks;
using Xunit;

namespace AcordSubmissionEmailListener.Test.UnitTest
{
    public class StorageTests
    {
        private StorageClient _storageClient;
        private readonly string _connectionString = "DefaultEndpointsProtocol=https;AccountName=clappdevsa;AccountKey=BDxzhDCMol1VIjzoLMQudT3+dm0jpPAke1El4N4BYxO0Di+O4QpAa2UOuzTUTQWN/z9V2DlGEIWc3rGnVNimPw==;EndpointSuffix=core.windows.net;";
        [Fact]
        public async Task StoreEmailDetailsTestDevApi()
        {            
            _storageClient = new StorageClient(null, _connectionString);
            var detailsRequest = new StoreEmailDetailsRequest()
            {
                Division = "WBCL",
                emailGUID = NewId.Next().ToSequentialGuid().ToString().ToUpperInvariant(),
                receivedTimestamp = DateTime.Now.ToString(),
                Sender = "testuser@wbmi.com",
                Subject = "Test Email Subject"
            };


            var rs = await _storageClient.StoreEmailDetails(detailsRequest);
            Assert.NotNull(rs);
        }

        [Fact]
        public async Task StoreSubmissionEventsTest()
        {
            _storageClient = new StorageClient(null, _connectionString);
            var submissionEventRequest = new StoreSubmissionEventsRequest()
            {
                EmailId = "08D7D035-5A39-B7F4-0003-FFF9D8C70000",
                Event = "SUBMITTED_TO_TURNSTILE"
            };

            var rs = await _storageClient.StoreSubmissionEvents(submissionEventRequest);
            Assert.NotNull(rs);
        }


    }
}
