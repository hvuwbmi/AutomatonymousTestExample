﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using Microsoft.Exchange.WebServices.Data;

namespace AcordSubmissionEmailListener.Test.LoadTest
{
    class Program
    {

        static void Main(string[] args)
        {
            try
            {
                SomeAsyncCode().GetAwaiter().GetResult();
            }
            catch (ArgumentException aex)
            {
                Console.WriteLine($"Caught ArgumentException: {aex.Message}");
            }

            Console.WriteLine("Hello World!");
        }

        private static async System.Threading.Tasks.Task SomeAsyncCode()
        {
            var ACORD_SUBMISSION_MAILBOX = "acordqa_dev@wbmi.com";
            var ACORD_SUBMISSION_MAILBOX_PASSWORD = "g4KER63JCPIoZ7FpmKU7";
            var iterations = 1;
            var sleepInterval = 0;

            ExchangeService service = new ExchangeService(ExchangeVersion.Exchange2016)
            {
                Credentials = new WebCredentials(ACORD_SUBMISSION_MAILBOX, ACORD_SUBMISSION_MAILBOX_PASSWORD, "wbmi.onmicrosoft.com"),
                Url = new Uri("https://outlook.office365.com/EWS/Exchange.asmx"),
                TraceEnabled = true,
                TraceFlags = TraceFlags.None
            };

            var sourceFolder = await FindFolders(service, "LoadTestDev");
            //var targetFolder = await FindFolders(service, "TargetFolder");
            var targetFolderId = new FolderId(WellKnownFolderName.Inbox);
            //var targetFolder = Folder.Bind(service, targetFolderId);

            var items = await sourceFolder.FindItems("Kind:email", new ItemView(100));
            List<EmailMessage> emailMessages = items.Select(s => (EmailMessage)s).ToList();

            for(int x = 0; x < iterations; x++)
            {
                foreach (var emailMessage in emailMessages)
                {
                    var subject = emailMessage.Subject;
                    await emailMessage.Copy(targetFolderId);
                    Thread.Sleep(sleepInterval);
                }
            }
        }

        private static async Task<Folder> FindFolders(ExchangeService service, string folderName)
        {
            // set View
            FolderView view = new FolderView(100);
            view.PropertySet = new PropertySet(BasePropertySet.IdOnly);
            view.PropertySet.Add(FolderSchema.DisplayName);
            view.Traversal = FolderTraversal.Deep;

            FindFoldersResults findFolderResults = await service.FindFolders(WellKnownFolderName.Inbox, view);

            // find specific folder
            foreach (Folder f in findFolderResults)
            {
                // show FolderId of the folder "Test"
                if (f.DisplayName == folderName)
                {
                    Console.WriteLine(f.Id);
                    return f;
                }
            }
            return null;
        }
    }
}
