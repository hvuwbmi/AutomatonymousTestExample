﻿using Microsoft.Azure.Cosmos.Table;
using Microsoft.Azure.Documents.Partitioning;
using PurgeStorage.Domain.Entities;
using PurgeStorage.Domain.Entities.TableEntities;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace PurgeStorage.Application
{
    public class TableStorageClient
    {
        private BlobStorageClient _blobStorageClient;
        private CloudStorageAccount _storageAccount;
        private string _connectionString;                
        private static readonly string EmailDetailsTableName = "EmailDetails";
        private static readonly string DuckXmlFromPenguinTableName = "DuckXmlFromPenguin";

        private readonly string DuckXmlContainerName = "dctxml-from-penguin";
        private readonly string AcordXmlContainerName = "acordxmls";
        private readonly string DriverValidationContainerName = "driver-validation-data";

        public List<string> LogMessages { get; set; }
        public List<string> LogErrorMessages { get; set; }
        public TableStorageClient(string connectionString)
        {
            _connectionString = connectionString;
            _blobStorageClient = new BlobStorageClient(connectionString);
        }

        public async Task<PurgeQueryResponse> QueryEmailDetails(PurgeQueryRequest request)
        {
            LogMessages.Add($"TableStorageClient:QueryEmailDetails: Begin Query...");

            var rs = new PurgeQueryResponse();
            
            var table = CreateTableAsync(EmailDetailsTableName).Result;

            var query = TableQuery.CombineFilters(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, "AcordSubmission"),
                                                  TableOperators.And,
                                                  TableQuery.GenerateFilterConditionForDate("Timestamp", QueryComparisons.LessThan, request.RetentionDate));

            TableQuery<EmailDetailsTable> rangeQuery = new TableQuery<EmailDetailsTable>().Where(query);
           
            EntityResolver<EmailDetailsTable> resolver = (pk, rk, ts, props, etag) =>
            {
                var resolvedEntity = new EmailDetailsTable
                {
                    PartitionKey = pk,
                    RowKey = rk,
                    Timestamp = ts,
                    ETag = etag
                };
                resolvedEntity.ReadEntity(props, null);

                return resolvedEntity;
            };

            TableContinuationToken continuationToken = null;
            rs.EmailIds = new List<string>();
            do
            {
                TableQuerySegment<EmailDetailsTable> tableQueryResult =
                        await table.ExecuteQuerySegmentedAsync(rangeQuery, resolver, continuationToken);

                continuationToken = tableQueryResult.ContinuationToken;
                //var tableQueryResult = table.ExecuteQuery(q).Select(ent => ent).ToList();

                foreach (EmailDetailsTable entity in tableQueryResult)
                {
                    rs.EmailIds.Add(entity.RowKey);                   
                }              
            } while (continuationToken != null);

            LogMessages.Add($"TableStorageClient:QueryEmailDetails: Found {rs.EmailIds.Count} records in the {EmailDetailsTableName}...");
            return rs;
        }
     

        public async Task QueryAndPurgeDuckXmlFromPenguin(List<string> emailIds)
        {
            LogMessages.Add($"TableStorageClient:QueryAndPurgeDuckXmlFromPenguin: Purging Acord XML Blob data, {DuckXmlFromPenguinTableName} and associated data...");
            var table = CreateTableAsync(DuckXmlFromPenguinTableName).Result;

            foreach (var emailId in emailIds)
            {
                // 1st do acordxmls blob removal                
                await _blobStorageClient.DeleteBlob(AcordXmlContainerName,emailId);

                var row = table.CreateQuery<DuckXmlTable>()
                   .Where(d => d.PartitionKey == "DCTXML"
                           && d.RowKey == emailId)
                           .Select(x => new DuckXmlTable()
                           {
                               PartitionKey = x.PartitionKey,
                               RowKey = x.RowKey
                           }).FirstOrDefault();

                if (row != null)
                {
                    // delete blob for acord
                    await _blobStorageClient.DeleteBlob(DuckXmlContainerName, row.RowKey);
                    
                    // driver valdation blob, if any
                    if (row.DriversValidation != null)
                    {
                        await _blobStorageClient.DeleteBlob(DriverValidationContainerName, row.DriversValidation);
                    }

                    // now delete the row
                    row.ETag = "*";
                    var deleteOperation = TableOperation.Delete(row);

                    table.Execute(deleteOperation);        
                }
                
            }

            LogMessages.Add($"TableStorageClient:QueryAndPurgeDuckXmlFromPenguin: Purging Acord XML Blob data, {DuckXmlFromPenguinTableName} and associated data Completed...");

        }

        public void QueryAndPurgeData<T>(string tableName, List<string> emailIds) where T : ITableEntity, new()
        {
            LogMessages.Add($"TableStorageClient:QueryAndPurgeData: Purging the {tableName} Table...");
            var table = CreateTableAsync(tableName).Result;

            foreach (var emailId in emailIds)
            {

                TableQuery<T> tableQuery = new TableQuery<T>().Where(TableQuery.GenerateFilterCondition("PartitionKey", QueryComparisons.Equal, emailId));

                var rows = table.ExecuteQuery(tableQuery);
                TableOperation deleteOperation;
                if (rows.Count() > 0)
                {
                    if (rows.Count() > 1)
                    {
                        foreach (var entity in rows)
                        {
                            entity.ETag = "*";
                            deleteOperation = TableOperation.Delete(entity);

                            table.Execute(deleteOperation);

                        }
                    }
                    else
                    {
                        var entity = rows.FirstOrDefault();
                        entity.ETag = "*";
                        deleteOperation = TableOperation.Delete(entity);

                        table.Execute(deleteOperation);
                    }
                }
            }

            LogMessages.Add($"TableStorageClient:QueryAndPurgeData: Purging the {tableName} Table is completed...");

        }

        public void PurgeEmailDetails(List<string> emailIds)
        {
            LogMessages.Add($"TableStorageClient:PurgeEmailDetails: Purging {EmailDetailsTableName}...");
            var table = CreateTableAsync(EmailDetailsTableName).Result;

            foreach (var emailId in emailIds)
            {

                var row = table.CreateQuery<DuckXmlTable>()
                   .Where(d => d.PartitionKey == "AcordSubmission"
                           && d.RowKey == emailId)
                           .Select(x => new DuckXmlTable()
                           {
                               PartitionKey = x.PartitionKey,
                               RowKey = x.RowKey
                           }).FirstOrDefault();

                if (row != null)
                {         
                    try
                    {
                        row.ETag = "*";
                        // now delete the row
                        var deleteOperation = TableOperation.Delete(row);

                        table.Execute(deleteOperation);
                    }
                    catch(Exception ex)
                    {
                        LogErrorMessages.Add($"TableStorageClient:PurgeEmailDetails:Purging {EmailDetailsTableName} failed with exception {ex.Message}...");
                    }                                      
                }
                   

            }

            LogMessages.Add($"TableStorageClient:PurgeEmailDetails: Purging {EmailDetailsTableName} Completed...");

        }


        private async Task<CloudTable> CreateTableAsync(string tableName)
        {
            _storageAccount = CloudStorageAccount.Parse(_connectionString);

            CloudTableClient tableClient = _storageAccount.CreateCloudTableClient(new TableClientConfiguration());
            CloudTable table = tableClient.GetTableReference(tableName);

            await table.CreateIfNotExistsAsync();
            return table;
        }


    }
}
