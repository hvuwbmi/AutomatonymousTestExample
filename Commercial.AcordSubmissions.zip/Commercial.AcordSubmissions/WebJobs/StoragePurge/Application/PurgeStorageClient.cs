﻿using Microsoft.Extensions.Configuration;
using Microsoft.Spatial;
using PurgeStorage.Domain.Entities;
using PurgeStorage.Domain.Entities.TableEntities;
using PurgeStorage.Domain.Interfaces;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace PurgeStorage.Application
{
    public class PurgeStorageClient
    {
        private TableStorageClient _tableStorageClient;        
        private IConfiguration _config;


        private ICommonLogService _commonLogService;
        private string _connectionString;
        private int _daysToRetain;

        private static readonly string SubmissionEventsTableName = "SubmissionEvents";
        private static readonly string SubmissionLOBTableName = "SubmissionLOB";
        private static readonly string SubmissionLOBEventsTableName = "SubmissionLOBEvents";
       

        public PurgeStorageClient(ICommonLogService commonLogService, IConfiguration config)
        {
            _commonLogService = commonLogService;
            _config = config;
            _connectionString = _config.GetSection("ConnectionStrings")["AzureWebJobsStorage"];
            _daysToRetain = Convert.ToInt32(_config.GetSection("PurgeSettings")["RetentionPeriod"]);

            _tableStorageClient = new TableStorageClient(_connectionString);
            _tableStorageClient.LogMessages = new List<string>();
            _tableStorageClient.LogErrorMessages = new List<string>();
        }

        /// <summary>
        /// Purge all Acord Submission re;ted table and blob storage based on a retnetion time period, i.e. 90 days
        /// STart with The EmailDetails Table
        ///     Find rows older than defined retention period
        ///     Next delete all child tables bottom up:
        ///         SubmissionLOBEvents
        ///         SubmissionLOB
        ///         SubmissionEvents
        ///         DuckXmlFromPEnguin
        ///             dctxml-from-penguin blobs
        ///             acordxmls blob
        ///      
        /// </summary>
        /// <returns></returns>
        public async Task Purge()
        {
            try
            {
                // read email details
                var rq = new PurgeQueryRequest
                {
                    RetentionDate = DateTime.Now.AddDays(_daysToRetain * -1)
                };

                _tableStorageClient.LogMessages.Add($"Purge Storage:Began at {DateTime.Now} and will remove all data older than {rq.RetentionDate}...");

                var rs = await _tableStorageClient.QueryEmailDetails(rq);
                if (rs.EmailIds.Count > 0)
                {
                    _tableStorageClient.QueryAndPurgeData<SubmissionLOBEventsTable>(SubmissionLOBEventsTableName, rs.EmailIds);
                    _tableStorageClient.QueryAndPurgeData<SubmissionLOBTable>(SubmissionLOBTableName, rs.EmailIds);
                    _tableStorageClient.QueryAndPurgeData<SubmissionEventsTable>(SubmissionEventsTableName, rs.EmailIds);

                    // now get all DuckXmlFromPEnguin qualifying rows. But before deleteing the table data, remove the blob stortage
                    // including the driver valdaition errors.
                    await _tableStorageClient.QueryAndPurgeDuckXmlFromPenguin(rs.EmailIds);

                    // and finally delete the email details
                    _tableStorageClient.PurgeEmailDetails(rs.EmailIds);
                }
                else
                {
                    _tableStorageClient.LogMessages.Add("Purge Storage: No records found to purge...");
                }
            }
            catch(Exception ex)
            {
                _tableStorageClient.LogErrorMessages.Add($"Error during Purge: {ex.Message}");
            }

            CommonLogServiceRq logRq;
            if (_tableStorageClient.LogErrorMessages.Count > 0)
            {
                var msg = new StringBuilder();
                foreach (var errorMessage in _tableStorageClient.LogErrorMessages)
                {
                    msg.AppendLine(errorMessage);
                }

                // report log messages and orr erro rmessages to teams
                logRq = new CommonLogServiceRq();
                logRq.severity = "Error";
                logRq.message = msg.ToString();
                logRq.extendedProperties = new List<CommonLogExtendedProperty>();
                logRq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
                await _commonLogService.CommonLog(logRq);
            }

            var log = new StringBuilder();
            foreach (var logMessage in _tableStorageClient.LogMessages)
            {
                log.AppendLine(logMessage);
            }

            logRq = new CommonLogServiceRq();
            logRq.severity = "Information";
            logRq.message = log.ToString();
            logRq.extendedProperties = new List<CommonLogExtendedProperty>();
            logRq.extendedProperties.Add(new CommonLogExtendedProperty { Key = "AcordUpload", Value = "Value" });
            await _commonLogService.CommonLog(logRq);
        }


    }
}
