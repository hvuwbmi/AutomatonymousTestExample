﻿using Microsoft.Azure.Storage;
using Microsoft.Azure.Storage.Blob;
using System;
using System.Collections.Generic;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace PurgeStorage.Application
{
    
    public class BlobStorageClient
    {
        private CloudBlobClient _client;
        private readonly string _connectionString;    

        public BlobStorageClient(string connectionString)
        {
            _connectionString = connectionString;
            _client = GetClient();
        }

        public async Task DeleteBlob(string containerName, string blobName)
        {
            try
            {
                if (_client != null)
                {
                    var container = await CreateContainer(containerName);
                    var blob = container.GetBlockBlobReference(blobName);
                    if (blob.Exists())
                    {
                        blob.Delete();
                    }                    
                }               

            }
            catch (Exception)
            {
                // eat it                  
            }
        }


        private CloudBlobClient GetClient()
        {         
            CloudStorageAccount storageAccount;
            if (CloudStorageAccount.TryParse(_connectionString, out storageAccount))
            {                
                return storageAccount.CreateCloudBlobClient();
            }
            else
            {                
                return null;
            }
        }

        private async Task<CloudBlobContainer> CreateContainer(string containerName)
        {
            var container = _client.GetContainerReference(containerName);
            await container.CreateIfNotExistsAsync();
            var permissions = new BlobContainerPermissions
            {
                PublicAccess = BlobContainerPublicAccessType.Off
            };
            await container.SetPermissionsAsync(permissions);
            return container;
        }
    }
}
