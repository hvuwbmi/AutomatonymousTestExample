﻿using PurgeStorage.Domain.Entities.TableEntities;
using System;
using System.Collections.Generic;
using System.Text;

namespace PurgeStorage.Domain.Entities
{
    public class PurgeQueryResponse : BaseResponse
    {
        public List<string> EmailIds;
    }
}
