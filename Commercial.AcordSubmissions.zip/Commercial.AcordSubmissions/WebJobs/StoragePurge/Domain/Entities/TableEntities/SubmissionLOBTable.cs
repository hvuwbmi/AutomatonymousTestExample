﻿using Microsoft.Azure.Cosmos.Table;

namespace PurgeStorage.Domain.Entities.TableEntities
{
    public class SubmissionLOBTable : TableEntity
    {
        public string LOBType { get; set; }
    }
}
