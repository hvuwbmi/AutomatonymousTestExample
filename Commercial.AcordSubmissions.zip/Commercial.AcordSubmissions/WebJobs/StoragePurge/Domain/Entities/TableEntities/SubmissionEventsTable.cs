﻿using Microsoft.Azure.Cosmos.Table;


namespace PurgeStorage.Domain.Entities.TableEntities
{
    public class SubmissionEventsTable : TableEntity
    {
        public string Events { get; set; }
        public string Status { get; set; }

        public string ErrorDescription { get; set; }

        public string TotalCount    { get; set; }
        public string Count { get; set; }

    }
}
