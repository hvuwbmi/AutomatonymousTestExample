﻿using Microsoft.Azure.Cosmos.Table;

namespace PurgeStorage.Domain.Entities.TableEntities
{
    public class DuckXmlTable : TableEntity
    {
        public string BusinessName { get; set; }
        public string Address1 { get; set; }
        public string City { get; set; }

        public string State { get; set; }

        public string Zipcode { get; set; }

        public string AgencyName { get; set; }

        public string DriversValidation { get; set; }

        public string Timestamp_formatted
        {
            get
                {
                return Timestamp.ToString();
                }
        }
       
    }
}
