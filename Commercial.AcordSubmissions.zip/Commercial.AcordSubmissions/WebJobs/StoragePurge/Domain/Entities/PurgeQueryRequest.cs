﻿using System;
using System.Collections.Generic;
using System.Text;

namespace PurgeStorage.Domain.Entities
{
    public class PurgeQueryRequest
    {
        public DateTime RetentionDate { get; set; }
    }
}
