﻿using PurgeStorage.Domain.Entities;
using System.Threading.Tasks;

namespace PurgeStorage.Domain.Interfaces
{
    public interface ICommonLogService
    {
        Task<BaseResponse> CommonLog(CommonLogServiceRq rq);
    }
}
