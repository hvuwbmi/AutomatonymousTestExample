﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Configuration;
using Newtonsoft.Json;
using System.IO;

namespace PurgeStorage.Infrastructure.WebJob.ConsoleWebJob
{
    class Program
    {
        static void Main(string[] args)
        {
            var builder = new HostBuilder();
            var appSettingsFileName = "appsettings.json";
            // get the env arg to set up proper environment           
            if (args.Length > 0)
            {
                for (int i = 0; i < args.Length; i++)
                {
                    if (args[i].ToUpper() == "-ENV")
                    {
                        if (args[i + 1].ToUpper() == "DEV")
                        {
                            appSettingsFileName = "appsettings.developer.json";
                        }
                    }
                }
            }
            
            builder.ConfigureWebJobs(b =>
            {
                b.AddAzureStorageCoreServices();
                b.AddTimers();
            })
            .ConfigureAppConfiguration((hostContext, configApp) =>
            {
                configApp.AddJsonFile($"{appSettingsFileName}", optional: false, reloadOnChange: true);
            })
            .ConfigureLogging((hostContext, configLogging) =>
            {
                configLogging.Services.AddLogging();
                configLogging.AddConfiguration(hostContext.Configuration.GetSection("Logging"));
            });

            var host = builder.Build();

            using (host)
            {
                var jobHost = host.Services.GetService(typeof(IJobHost)) as JobHost;
                host.StartAsync();
                jobHost.CallAsync("ProcessMethod");
                host.WaitForShutdown();
            }
        }
    }
}
