﻿using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.OData.Edm;
using PurgeStorage.Application;
using StoragePurge.Infrastructure.CommonLogService;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;

namespace PurgeStorage.Infrastructure.WebJob.ConsoleWebJob
{
    public class Processor
    {
        private IConfiguration _config;

        public Processor(IConfiguration config)
        {
            _config = config;
        }
              
        public async void ProcessMethod([TimerTrigger("%ScheduleConfiguration:CronExpression%")]TimerInfo timerInfo)
        {                      
            var httpClient = new System.Net.Http.HttpClient();           
            httpClient.BaseAddress = new Uri(_config.GetSection("HttpCLient")["BaseAddress"]);            
            httpClient.DefaultRequestHeaders.Add(_config.GetSection("HttpCLient")["SubscriptionKeyName"], _config.GetSection("HttpCLient")["SubscriptionKey"]);

            var commonLogService = new CommonLogServiceClient(httpClient);

            var client = new PurgeStorageClient(commonLogService, _config);

            await client.Purge();
        }

        
    }
}
