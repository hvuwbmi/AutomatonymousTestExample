﻿
using Newtonsoft.Json;
using PurgeStorage.Domain.Entities;
using PurgeStorage.Domain.Interfaces;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
	
namespace StoragePurge.Infrastructure.CommonLogService
{
    public class CommonLogServiceClient : ICommonLogService
    {
        private readonly HttpClient _httpClient;
        private readonly string _apiRoute = "commercial/commonlog/log";
        public CommonLogServiceClient(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        public async Task<BaseResponse> CommonLog(CommonLogServiceRq rq)
        {
            var response = new BaseResponse();
            response.ResponseCode = ResponseCode.Success;
            var body = JsonConvert.SerializeObject(rq);
            var httpRq = new HttpRequestMessage(HttpMethod.Post, _apiRoute);
            httpRq.Content = new StringContent(body, Encoding.UTF8, "application/json");
            var result = await _httpClient.SendAsync(httpRq);
            var rsBody = await result.Content.ReadAsStringAsync();

            if (!result.IsSuccessStatusCode)
            {
                var rsFailure = new BaseResponse();
                if ((int)result.StatusCode == 400)
                {
                    rsFailure.ResponseCode = ResponseCode.BadRequest;
                    rsFailure.ResponseMessage = rsBody;
                }
                else
                {
                    rsFailure.ResponseCode = ResponseCode.ServerError;
                    rsFailure.ResponseMessage = rsBody;
                }
                return rsFailure;
            }
            return response;
        }
    }
}
