﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CurrentCarrierControllerTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api.UnitTests.Controllers
{
    using System.Diagnostics;
    using System.Threading.Tasks;
    using System.Web.Http.Results;
    using Api.Controllers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class CurrentCarrierControllerTestFixture
    {
        [TestMethod]
        public async Task Test_CurrentCarrierController_PostCreatesFile()
        {
            // arrange
            var logger = MockRepository.GenerateStrictMock<ILogger>();
            var storageManager = MockRepository.GenerateStrictMock<IStorageManager>();
            var body = JObject.Parse("{ \"suppressSFTP\": true }");

            logger.Expect(l => l.Log("PL.CurrentCarrier", TraceEventType.Information, "Created CurrentCarrierController", null, null, string.Empty, true));
            logger.Expect(l => l.Log("PL.CurrentCarrier", TraceEventType.Information, "Calling trigger", null, null, string.Empty, true));
            storageManager.Expect(s => s.CreateFileAsync("pl-third-party-integration", "LexisNexis.CurrentCarrier", "trigger_currentCarrier.txt", body.ToString())).Return(Task.FromResult(string.Empty));

            // act
            var controller = new CurrentCarrierController(logger);
            var result = await controller.PostWorker(body, storageManager);

            // assert
            result.ShouldBeType<OkNegotiatedContentResult<string>>();
            var contentResult = result as OkNegotiatedContentResult<string>;
            contentResult.Content.ShouldEqual("The current carrier contribution file has been scheduled to be created.");
        }
    }
}