﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierMessageState.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageState
{
    using System;
    using Automatonymous;

    public class CurrentCarrierMessageState : SagaStateMachineInstance
    {
        public string CurrentState { get; set; }

        public string PolicyNumber { get; set; }

        public string PolicyVersion { get; set; }

        public int TransactionSequenceNumber { get; set; }

        public Guid CorrelationId { get; set; }
    }
}