﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimStatusChangedCLUEAutoMessageMachine.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Automatonymous;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using MessageService.Core.Helpers;
    using MessageService.Core.SharedMessageStates;
    using WestBend.Claims.ServiceContracts;
    using WestBend.Core;

    public class ClaimStatusChangedCLUEAutoMessageMachine : MassTransitStateMachine<StatusChangedMessageState>
    {
        private readonly ILogger logger;
        private readonly IClueAutoClaimEventProcessor clueAutoClaimEventProcessor;

        public ClaimStatusChangedCLUEAutoMessageMachine(ILogger logger, IClueAutoClaimEventProcessor clueAutoClaimEventProcessor) : this()
        {
            this.logger = logger;
            this.clueAutoClaimEventProcessor = clueAutoClaimEventProcessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Is this really unreadable? Seems nice and fluent to me.")]
        protected ClaimStatusChangedCLUEAutoMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);
            this.Event(() => this.ClaimStatusChanged, x => x.CorrelateBy(state => state.PolicyNumber, context => context.Message.PolicyNumber).SelectId(context => Guid.NewGuid()));
            this.Initially(
                When(this.ClaimStatusChanged, x => x.Data.PolicyOffering.Equals(Constants.Events.MARVINPOLICYOFFERING, StringComparison.InvariantCultureIgnoreCase))
                    .Then(context => this.AssignStateFromEvent(context.Instance, context.Data))
                    .ThenAsync(context => this.clueAutoClaimEventProcessor.ProcessClaimStatusChangedEvent(new StatusChangedDto().AssignStateFromEvent(context.Data)))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<IClaimStatusChanged> ClaimStatusChanged { get; private set; }

        private void AssignStateFromEvent(StatusChangedMessageState state, IClaimStatusChanged claimStatusChange)
        {
            state.AssignStateFromEvent(claimStatusChange);
            var additionalInformation = this.MakeAdditionalLogData(claimStatusChange);
            this.logger.Log(Constants.Logging.CATEGORY_CLUE_AUTO, TraceEventType.Information, "Claim Status Change CLUE Auto Message", additionalInformation);
        }

        private Dictionary<string, string> MakeAdditionalLogData(IClaimStatusChanged claimStatusChange)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", claimStatusChange.PolicyNumber },
                { "PolicyVersion", claimStatusChange.PolicyVersion },
                { "ClaimNumber", claimStatusChange.ClaimNumber },
                { "ClaimType", claimStatusChange.ClaimType },
                { "PolicyOffering", claimStatusChange.PolicyOffering },
                {
                    "DateOfLoss", claimStatusChange.DateOfLoss.HasValue
                        ? claimStatusChange.DateOfLoss.Value.ToShortDateString() + " " + claimStatusChange.DateOfLoss.Value.ToShortTimeString()
                        : string.Empty
                },
                { "Division", claimStatusChange.Division },
                { "SourceSystemId", claimStatusChange.SourceSystemId },
                { "PriorStatus", claimStatusChange.PriorStatus },
                { "CurrentStatus", claimStatusChange.CurrentStatus }
            };

            return additionalInformation;
        }
    }
}