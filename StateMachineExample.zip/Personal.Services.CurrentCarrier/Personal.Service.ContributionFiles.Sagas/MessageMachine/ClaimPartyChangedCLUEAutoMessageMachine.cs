﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimPartyChangedCLUEAutoMessageMachine.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Text;
    using Automatonymous;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using MessageService.Core.Helpers;
    using MessageService.Core.SharedMessageStates;
    using WestBend.Claims.ServiceContracts;
    using WestBend.Core;
    using WestBend.Core.Service;

    public class ClaimPartyChangedCLUEAutoMessageMachine : MassTransitStateMachine<ClaimPartyChangedMessageState>
    {
        private readonly ILogger logger;
        private readonly IClueAutoClaimEventProcessor clueAutoClaimEventProcessor;

        public ClaimPartyChangedCLUEAutoMessageMachine(ILogger logger, IClueAutoClaimEventProcessor clueAutoClaimEventProcessor) : this()
        {
            this.logger = logger;
            this.clueAutoClaimEventProcessor = clueAutoClaimEventProcessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Is this really unreadable? Seems nice and fluent to me.")]
        protected ClaimPartyChangedCLUEAutoMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);
            this.Event(() => this.ClaimPartyChanged, x => x.CorrelateBy(state => state.PolicyNumber, context => context.Message.PolicyNumber).SelectId(context => Guid.NewGuid()));
            this.Initially(
                When(this.ClaimPartyChanged, x => x.Data.PolicyOffering.Equals(Constants.Events.MARVINPOLICYOFFERING, StringComparison.InvariantCultureIgnoreCase))
                    .Then(context => this.AssignStateFromEvent(context.Instance, context.Data))
                    .ThenAsync(context => this.clueAutoClaimEventProcessor.ProcessClaimPartyChangedEvent(new ClaimPartyChangedDto().AssignStateFromEvent(context.Data)))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<IClaimPartyChanged> ClaimPartyChanged { get; private set; }

        private void AssignStateFromEvent(ClaimPartyChangedMessageState state, IClaimPartyChanged claimPartyChanged)
        {
            state.AssignStateFromEvent(claimPartyChanged);
            var additionalInformation = this.MakeAdditionalLogData(claimPartyChanged);
            this.logger.Log(Constants.Logging.CATEGORY_CLUE_AUTO, TraceEventType.Information, "Claim Party Changed CLUE Auto Message", additionalInformation);
        }

        private Dictionary<string, string> MakeAdditionalLogData(IClaimPartyChanged claimPartyChanged)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", claimPartyChanged.PolicyNumber },
                { "PolicyVersion", claimPartyChanged.PolicyVersion },
                { "ClaimNumber", claimPartyChanged.ClaimNumber },
                { "ClaimType", claimPartyChanged.ClaimType },
                { "PolicyOffering", claimPartyChanged.PolicyOffering },
                {
                    "DateOfLoss", claimPartyChanged.DateOfLoss.HasValue
                        ? claimPartyChanged.DateOfLoss.Value.ToShortDateString() + " " + claimPartyChanged.DateOfLoss.Value.ToShortTimeString()
                        : string.Empty
                },
                { "Division", claimPartyChanged.Division },
                { "SourceSystemId", claimPartyChanged.SourceSystemId },
                { "PartyId", claimPartyChanged.PartyId }
            };

            var partyRoles = this.GetPartyRoleString(claimPartyChanged);
            additionalInformation.Add("PartyRoleInClaim", partyRoles);

            return additionalInformation;
        }

        private string GetPartyRoleString(IClaimPartyChanged claimPartyChanged)
        {
            var partyRoles = new StringBuilder();
            var first = true;
            foreach (var partyRole in claimPartyChanged.PartyRoleInClaim)
            {
                if (!first)
                {
                    partyRoles.Append(", ");
                }

                partyRoles.Append(partyRole);
                first = false;
            }

            return partyRoles.ToString();
        }
    }
}