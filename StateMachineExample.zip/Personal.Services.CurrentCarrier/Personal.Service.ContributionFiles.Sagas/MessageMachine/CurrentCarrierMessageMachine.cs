﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierMessageMachine.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Automatonymous;
    using FileHelpers.ServiceInterfaces;
    using MessageState;
    using Personal.Services.MessageService.Core.Helpers;
    using WestBend.Core;
    using WestBend.Personal.ServiceContracts.EventMessages;

    public class CurrentCarrierMessageMachine : MassTransitStateMachine<CurrentCarrierMessageState>
    {
        private readonly IMapperService mapperService;
        private readonly ILogger logger;

        public CurrentCarrierMessageMachine(ILogger logger, IMapperService mapperService) : this()
        {
            this.logger = logger;
            this.mapperService = mapperService;
        }

        protected CurrentCarrierMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);

            this.Event(
                () => this.TransactionCommitted,
                x => x.CorrelateBy(state => $"{state.PolicyNumber}/{state.PolicyVersion}/{state.TransactionSequenceNumber}", context => $"{context.Message.PolicyNumber}/{context.Message.PolicyVersion}/{context.Message.TransactionSequenceNumber}")
                    .SelectId(context => Guid.NewGuid()));

            this.Initially(
                When(this.TransactionCommitted, x => x.Data.Product != "HH")
                    .Then(context =>
                    {
                        context.Instance.PolicyNumber = context.Data.PolicyNumber;
                        context.Instance.PolicyVersion = context.Data.PolicyVersion;
                        context.Instance.TransactionSequenceNumber = context.Data.TransactionSequenceNumber;

                        var additionalInformation = MakeAdditionalLogData(context.Instance);
                        this.logger.Log(Constants.Logging.CATEGORY_CURRENT_CARRIER, TraceEventType.Information, "Transaction Committed Current Carrier Message", additionalInformation);
                    })
                    .ThenAsync(context => this.mapperService.Map(context.Instance.PolicyNumber, context.Instance.PolicyVersion, context.Instance.TransactionSequenceNumber.ToString()))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<ITransactionCommitted> TransactionCommitted { get; private set; }

        private static Dictionary<string, string> MakeAdditionalLogData(CurrentCarrierMessageState messageState)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", messageState.PolicyNumber },
                { "PolicyVersion", messageState.PolicyVersion },
                { "TransactionSequenceNumber", messageState.TransactionSequenceNumber.ToString() }
            };

            return additionalInformation;
        }
    }
}