﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FinancialTransactionCommittedCLUEAutoMessageMachine.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Automatonymous;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using MessageService.Core.Helpers;
    using MessageService.Core.SharedMessageStates;
    using WestBend.Claims.ServiceContracts;
    using WestBend.Core;
    using WestBend.Core.Service;

    public class FinancialTransactionCommittedCLUEAutoMessageMachine : MassTransitStateMachine<FinancialTransactionCommittedMessageState>
    {
        private readonly ILogger logger;
        private readonly IClueAutoClaimEventProcessor clueAutoClaimEventProcessor;

        public FinancialTransactionCommittedCLUEAutoMessageMachine(ILogger logger, IClueAutoClaimEventProcessor clueAutoClaimEventProcessor) : this()
        {
            this.logger = logger;
            this.clueAutoClaimEventProcessor = clueAutoClaimEventProcessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Is this really unreadable? Seems nice and fluent to me.")]
        protected FinancialTransactionCommittedCLUEAutoMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);
            this.Event(() => this.FinancialTransactionCommitted, x => x.CorrelateBy(state => state.PolicyNumber, context => context.Message.PolicyNumber).SelectId(context => Guid.NewGuid()));
            this.Initially(
                When(this.FinancialTransactionCommitted, x => x.Data.PolicyOffering.Equals(Constants.Events.MARVINPOLICYOFFERING, StringComparison.InvariantCultureIgnoreCase))
                    .Then(context => this.AssignStateFromEvent(context.Instance, context.Data))
                    .ThenAsync(context => this.clueAutoClaimEventProcessor.ProcessFinancialTransactionCommittedEvent(new FinancialTransactionCommittedDto().AssignStateFromEvent(context.Data)))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<IFinancialTransactionCommitted> FinancialTransactionCommitted { get; private set; }

        private void AssignStateFromEvent(FinancialTransactionCommittedMessageState state, IFinancialTransactionCommitted financialTransactionCommitted)
        {
            state.AssignStateFromEvent(financialTransactionCommitted);
            var additionalInformation = this.MakeAdditionalLogData(financialTransactionCommitted);
            this.logger.Log(Constants.Logging.CATEGORY_CLUE_AUTO, TraceEventType.Information, "Financial transaction commited CLUE Auto Message", additionalInformation);
        }

        private Dictionary<string, string> MakeAdditionalLogData(IFinancialTransactionCommitted financialTransactionCommitted)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", financialTransactionCommitted.PolicyNumber },
                { "PolicyVersion", financialTransactionCommitted.PolicyVersion },
                { "ClaimNumber", financialTransactionCommitted.ClaimNumber },
                { "ClaimType", financialTransactionCommitted.ClaimType },
                { "PolicyOffering", financialTransactionCommitted.PolicyOffering },
                {
                    "DateOfLoss", financialTransactionCommitted.DateOfLoss.HasValue
                        ? financialTransactionCommitted.DateOfLoss.Value.ToShortDateString() + " " + financialTransactionCommitted.DateOfLoss.Value.ToShortTimeString()
                        : string.Empty
                },
                { "Division", financialTransactionCommitted.Division },
                { "SourceSystemId", financialTransactionCommitted.SourceSystemId },
                { "Amount", financialTransactionCommitted.Amount.ToString() },
                { "CauseOfLoss", financialTransactionCommitted.CauseOfLoss },
                { "ClaimantId", financialTransactionCommitted.ClaimantId },
                { "CoverageType", financialTransactionCommitted.CoverageType },
                { "ObjectSequenceNumber", financialTransactionCommitted.ObjectSequenceNumber },
                { "ObjectType", financialTransactionCommitted.ObjectType },
                { "ReserveCategory", financialTransactionCommitted.ReserveCategory },
                { "ReserveType", financialTransactionCommitted.ReserveType },
                { "TransactionType", financialTransactionCommitted.TransactionType }
            };

            return additionalInformation;
        }
    }
}