﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OffsetOnsetCLUEAutoMessageMachine.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Automatonymous;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using MessageService.Core.Helpers;
    using MessageService.Core.SharedMessageStates;
    using WestBend.Claims.ServiceContracts;
    using WestBend.Core;

    public class OffsetOnsetCLUEAutoMessageMachine : MassTransitStateMachine<OffsetOnsetMessageState>
    {
        private readonly ILogger logger;
        private readonly IClueAutoClaimEventProcessor clueAutoClaimEventProcessor;

        public OffsetOnsetCLUEAutoMessageMachine(ILogger logger, IClueAutoClaimEventProcessor clueAutoClaimEventProcessor) : this()
        {
            this.logger = logger;
            this.clueAutoClaimEventProcessor = clueAutoClaimEventProcessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Is this really unreadable? Seems nice and fluent to me.")]
        protected OffsetOnsetCLUEAutoMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);
            this.Event(() => this.OffsetOnset, x => x.CorrelateBy(state => state.PolicyNumber, context => context.Message.PolicyNumber).SelectId(context => Guid.NewGuid()));
            this.Initially(
                When(this.OffsetOnset, x => x.Data.PolicyOffering.Equals(Constants.Events.MARVINPOLICYOFFERING, StringComparison.InvariantCultureIgnoreCase))
                    .Then(context => this.AssignStateFromEvent(context.Instance, context.Data))
                    .ThenAsync(context => this.clueAutoClaimEventProcessor.ProcessOffsetOnsetEvent(new OffsetOnsetDto().AssignEventToState(context.Data)))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<IOffsetOnset> OffsetOnset { get; private set; }

        private void AssignStateFromEvent(OffsetOnsetMessageState state, IOffsetOnset offsetOnset)
        {
            state.AssignEventToState(offsetOnset);

            var additionalInformation = this.MakeAdditionalLogData(offsetOnset);
            this.logger.Log(Constants.Logging.CATEGORY_CLUE_AUTO, TraceEventType.Information, "Offset Onset CLUE Auto Message", additionalInformation);
        }

        private Dictionary<string, string> MakeAdditionalLogData(IOffsetOnset offsetOnset)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", offsetOnset.PolicyNumber },
                { "PolicyVersion", offsetOnset.PolicyVersion },
                { "ClaimNumber", offsetOnset.ClaimNumber },
                { "ClaimType", offsetOnset.ClaimType },
                { "PolicyOffering", offsetOnset.PolicyOffering },
                {
                    "DateOfLoss", offsetOnset.DateOfLoss.HasValue
                        ? offsetOnset.DateOfLoss.Value.ToShortDateString() + " " + offsetOnset.DateOfLoss.Value.ToShortTimeString()
                        : string.Empty
                },
                { "Division", offsetOnset.Division },
                { "SourceSystemId", offsetOnset.SourceSystemId },
                {
                    "DateOfLossChanged", offsetOnset.DateOfLossChanged.HasValue
                        ? offsetOnset.DateOfLossChanged.Value.ToString()
                        : string.Empty
                },
                { "PolicyVersionChanged", offsetOnset.PolicyVersionChanged.ToString() },
                { "UnitsChanged", offsetOnset.UnitsChanged.ToString() }
            };

            return additionalInformation;
        }
    }
}