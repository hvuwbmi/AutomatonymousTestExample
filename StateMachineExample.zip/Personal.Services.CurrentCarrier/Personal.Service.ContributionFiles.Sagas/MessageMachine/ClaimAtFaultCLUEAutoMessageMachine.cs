﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimAtFaultCLUEAutoMessageMachine.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Sagas.MessageMachine
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using Automatonymous;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using MessageService.Core.Helpers;
    using MessageService.Core.SharedMessageStates;
    using WestBend.Claims.ServiceContracts;
    using WestBend.Core;

    public class ClaimAtFaultCLUEAutoMessageMachine : MassTransitStateMachine<AtFaultMessageState>
    {
        private readonly ILogger logger;
        private readonly IClueAutoClaimEventProcessor clueAutoClaimEventProcessor;

        public ClaimAtFaultCLUEAutoMessageMachine(ILogger logger, IClueAutoClaimEventProcessor clueAutoClaimEventProcessor) : this()
        {
            this.logger = logger;
            this.clueAutoClaimEventProcessor = clueAutoClaimEventProcessor;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1118:ParameterMustNotSpanMultipleLines", Justification = "Is this really unreadable? Seems nice and fluent to me.")]
        protected ClaimAtFaultCLUEAutoMessageMachine()
        {
            this.InstanceState(x => x.CurrentState);
            this.Event(() => this.ClaimAtFault, x => x.CorrelateBy(state => state.PolicyNumber, context => context.Message.PolicyNumber).SelectId(context => Guid.NewGuid()));
            this.Initially(
                When(this.ClaimAtFault, x => x.Data.PolicyOffering.Equals(Constants.Events.MARVINPOLICYOFFERING, StringComparison.InvariantCultureIgnoreCase))
                    .Then(context => this.AssignStateFromEvent(context.Instance, context.Data))
                    .ThenAsync(context => this.clueAutoClaimEventProcessor.ProcessAtFaultEvent(new AtFaultDto().AssignStateFromEvent(context.Data)))
                    .Finalize());

            this.SetCompletedWhenFinalized();
        }

        public Event<IClaimAtFault> ClaimAtFault { get; private set; }

        private void AssignStateFromEvent(AtFaultMessageState state, IClaimAtFault claimAtFault)
        {
            state.AssignStateFromEvent(claimAtFault);
            var additionalInformation = this.MakeAdditionalLogData(claimAtFault);
            this.logger.Log(Constants.Logging.CATEGORY_CLUE_AUTO, TraceEventType.Information, "Claim At Fault CLUE Auto Message", additionalInformation);
        }

        private Dictionary<string, string> MakeAdditionalLogData(IClaimAtFault claimAtFault)
        {
            var additionalInformation = new Dictionary<string, string>
            {
                { "PolicyNumber", claimAtFault.PolicyNumber },
                { "PolicyVersion", claimAtFault.PolicyVersion },
                { "ClaimNumber", claimAtFault.ClaimNumber },
                { "ClaimType", claimAtFault.ClaimType },
                { "PolicyOffering", claimAtFault.PolicyOffering },
                {
                    "DateOfLoss", claimAtFault.DateOfLoss.HasValue
                        ? claimAtFault.DateOfLoss.Value.ToShortDateString() + " " + claimAtFault.DateOfLoss.Value.ToShortTimeString()
                        : string.Empty
                },
                { "Division", claimAtFault.Division },
                { "SourceSystemId", claimAtFault.SourceSystemId },
                { "DriverFirstName", claimAtFault.DriverFirstName },
                { "DriverLAstName", claimAtFault.DriverLastName },
                { "DriverId", claimAtFault.DriverId },
                { "DriverType", claimAtFault.DriverType },
                {
                    "IsAtFault",
                    claimAtFault.IsAtFault.HasValue ? claimAtFault.IsAtFault.Value.ToString() : string.Empty
                }
            };

            return additionalInformation;
        }
    }
}