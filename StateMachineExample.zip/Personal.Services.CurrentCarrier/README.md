# Introduction 
This service will listen to service bus for events and then append a line to the current carrier file.

# Getting Started
TODO: Guide users through getting your code up and running on their own system. In this section you can talk about:
1.	Install Slow Cheetah https://marketplace.visualstudio.com/items?itemName=vscps.SlowCheetah-XMLTransforms
2.	review https://nvie.com/posts/a-successful-git-branching-model/
3.  FileHelpers https://www.filehelpers.net/
4.  Specification https://github.com/giacomelli/KissSpecifications
5.  refit https://github.com/reactiveui/refit

# Build and Test
Online here
- https://wbmi.visualstudio.com/WB/_build/index?definitionId=259&_a=completed
- https://wbmi.visualstudio.com/WB/_release?view=all&definitionId=217

# Xsd and Generated Classes for Current Carrier
To update the generated classes:
1.  Make changes to MinimalPolicyForClassGeneration.xml
2.  Copy file to Acord.xml in the Personal.Services.ContributionFiles.FileHelpers/Models directory.
3.  From Visual Studio command line run the following commands:
	- `cd c:\VSTS\GIT\Personal.Services.CurrentCarrier\Personal.Services.ContributionFiles.FileHelpers\Models`
    - `xsd Acord.xml`
    - `xsd /c Acord.xsd /n:Personal.Services.ContributionFiles.FileHelpers.Models`

# XSD and Generated Classes for CLUE Auto
To update the generated classes:
1. Make changes to Personal.Services.ContributionFiles.FileHelpers/Models/Claims/claims.xml
2. From Visual Studio command line run the following commands:
   - `cd C:\VSTS\GIT\Personal.Services.CurrentCarrier\Personal.Services.ContributionFiles\FileHelpers\Models\Claims`
   - `generateSchemas.cmd`

# Nuget Packages
1. Set your package source to WBMI-packages

# VSTS
User Story 57103: Enabler: CurrentCarrier contribution file

# How all the Pieces Fit Together
The batch process (from `Personal.BatchJobs`) makes a call through the APIM to the
`/personal/lexisnexis/contrib` endpoint (or `.../autoClueContrib`). This calls
into the personal-*env*-services-currentcarrier service, into one of the controllers
in the API project. That controller simply drops a trigger file into blob storage.

The WebJob's main Program.cs has a timer trigger that fires every 5 minutes and looks
for that trigger file. If the file is found, the process to remove obsolete files and
assemble the output file is started.

In Azure, the personal-*env*-services-currentcarrier is the API service. This is the
part that is called from the batch job and assembles the smaller files.
personal-*env*-webjobs contains the listeners (`PersonalServicesCurrentCarrierWebJob`),
which wait for events to happen to policies and create the small intermediate files
based on that information.

More details could be added here.


# Debugging
- If a policy does not generate a subfile (in Azure Storage, LexisNexis.CurrentCarrier folder),
try modifying the `MapperServiceBigAcordTest()` function in CurrentCarrierIntegrationTests.cs to
use the policy number in question. This seems to work better (generates errors) than a unit test.

- If the API call in Azure generates a 500 Internal Service Error, try to modify the web.config
(using Visual Studio Cloud Explorer) to add the following bits within `system.web`:
```
    <customErrors mode="Off" />
    <compilation debug="true" targetFramework="4.6.1" />
```
and run the call again. One issue that was found recently was that there was an old DLL
in the installation directory, and the controller mapping couldn't handle that.

- The XSD.exe utility sets the `DebuggerStepThroughAttribute` on the classes that
it creates. This makes debugging into most code somewhat painful. There doesn't seem
to be a way to easily override this. I ended up loading the partial class from
`Acord.cs` and removing the attribute there. Be sure not to commit changes to this
file.

It might be easier to turn off the 'Just My Code' setting in the debugger also.

