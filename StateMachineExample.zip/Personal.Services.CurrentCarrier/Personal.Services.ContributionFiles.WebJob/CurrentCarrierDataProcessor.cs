﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CurrentCarrierDataProcessor.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Threading.Tasks;
    using MediatR;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Requests;

    public class CurrentCarrierDataProcessor : BaseDataProcessor
    {
        public CurrentCarrierDataProcessor()
        {
        }

        protected override string LogCategory => Constants.Logging.CATEGORY;

        protected override string ContainerName => Constants.Azure.BlobStorage.ContainerName;

        protected override string FolderName => Constants.Azure.BlobStorage.FolderName;

        protected override string OutputFolderName => Constants.Azure.BlobStorage.FolderName;

        protected override string FileNamePrefix => "Current";

        protected override string LastRunParitionKey => "CurrentCarrier";

        protected override string LastRunRowKey => "1LR2";

        protected override string BuildContributionFileName(string environment, string dateString)
        {
            return $"cc_history_westbnd2_{environment}{dateString}.txt";
        }

        protected override async Task<string> RetrieveContributionDataWorker(string apimSubscriptionKey, IMediator mediator)
        {
            var runForDate = await mediator.Send(new GetRunDateRequest { ApimKey = apimSubscriptionKey, PartitionKey = "CurrentCarrier", RowKey = "1LR2" });
            var result = await mediator.Send(new BuildCurrentCarrierOutput { ApimKey = apimSubscriptionKey, RunForDate = runForDate });
            return result;
        }
    }
}
