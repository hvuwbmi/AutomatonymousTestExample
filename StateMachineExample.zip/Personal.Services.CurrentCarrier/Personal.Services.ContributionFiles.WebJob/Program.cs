﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Program.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Configuration;
    using System.Threading.Tasks;
    using FileHelpers.ServiceInterfaces;
    using MassTransit;
    using MessageService.Core;
    using Microsoft.Azure.WebJobs;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Refit;
    using WestBend.Core.Service;

    public class Program
    {
        public static async Task ProcessContribution([TimerTrigger("0 */5 * * * *")] TimerInfo myTimer)
        {
            await ProcessTimerWorker<CurrentCarrierDataProcessor>(
                Constants.Azure.BlobStorage.ContainerName,
                Constants.Azure.BlobStorage.FolderName,
                Constants.Azure.BlobStorage.TriggerFileCurrentCarrier,
                Constants.Logging.CATEGORY);

            await ProcessTimerWorker<ClueAutoDataProcessor>(
                Constants.Azure.BlobStorage.ContainerName,
                Constants.Azure.BlobStorage.FolderNameClueAutoOutput,
                Constants.Azure.BlobStorage.TriggerFileClueAuto,
                Constants.Logging.CATEGORYCLUEAUTO);
        }

        private static async Task ProcessTimerWorker<T>(string container, string folder, string triggerName, string logCategory) where T : IDataProcessor, new()
        {
            var log = new CommonLogger();
            string trigger = null;
            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimSubKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            IStorageManager storageManager = new StorageManager(apiUrl, apimSubKey);

            try
            {
                trigger = await storageManager.ReadFileAsync(container, folder, triggerName);
            }
            catch (ApiException)
            {
            }

            if (!string.IsNullOrEmpty(trigger))
            {
                log.Log(logCategory, System.Diagnostics.TraceEventType.Information, "Hit the timer trigger");
                await storageManager.DeleteFileAsync(container, folder, triggerName);

                var mediator = new FileHelpersRegistry().BuildMediator();
                T processor = new T();
                await processor.Execute(trigger, log, mediator);
            }
        }

        private static void Main(string[] args)
        {
            var config = new JobHostConfiguration();

            if (config.IsDevelopment)
            {
                config.UseDevelopmentSettings();
            }

            config.UseTimers();

            var host = new JobHost(config);

            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            IPolicyStoreApi policyStoreApi = RestService.For<IPolicyStoreApi>(apiUrl);
            IStorageManager storageManager = new StorageManager(apiUrl, apimKey);
            IClaimsClaim claimsClaimApi = RestService.For<IClaimsClaim>(apiUrl);

            var initializer = new MessagingServiceBusInitializer(new CommonLogger(), new MessagingService(new CommonLogger(), Bus.Factory), policyStoreApi, storageManager, claimsClaimApi);
            initializer.StartTheBuses();

            // The following code ensures that the WebJob will be running continuously
            host.RunAndBlock();

            host.Stop();
        }
    }
}