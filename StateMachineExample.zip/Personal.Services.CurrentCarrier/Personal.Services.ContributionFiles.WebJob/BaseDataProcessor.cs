﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BaseDataProcessor.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using System.Xml.Linq;
    using MediatR;
    using Newtonsoft.Json;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Refit;
    using WestBend.Core;

    public abstract class BaseDataProcessor : IDataProcessor
    {
        protected abstract string LogCategory { get; }

        protected abstract string ContainerName { get; }

        protected abstract string FolderName { get; }

        protected abstract string OutputFolderName { get; }

        protected abstract string FileNamePrefix { get; }

        protected abstract string LastRunParitionKey { get; }

        protected abstract string LastRunRowKey { get; }

        public async Task Execute(string requestBody, ILogger logger, IMediator mediator)
        {
            await this.CleanupFiles(logger);
            var body = JsonConvert.DeserializeObject<ContributionRequestBody>(requestBody);
            await this.ProcessContribution(body, logger, mediator);
        }

        internal async Task CleanupFiles(ILogger logger)
        {
            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimSubKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            var fileRetentionDays = ConfigurationManager.AppSettings[Constants.AppSettingKeys.FileRetentionDays];
            var newestDate = DateTime.UtcNow.AddDays(-1 * int.Parse(fileRetentionDays));
            var storageManager = new StorageManager(apiUrl, apimSubKey);

            await this.CleanupFilesProcessor(logger, storageManager, apimSubKey, newestDate);
        }

        internal async Task CleanupFilesProcessor(ILogger log, IStorageManager storageManager, string subscriptionKey, DateTime newestDate)
        {
            try
            {
                log.Log(this.LogCategory, TraceEventType.Information, "Starting to remove obsolete files");
                var stringList = await storageManager.ListFileAsync(
                    this.ContainerName,
                    this.FolderName,
                    this.FileNamePrefix);
                XDocument blobList = XDocument.Parse(stringList);

                var blobs = blobList.Element("EnumerationResults").Element("Blobs").Elements("Blob");
                foreach (var blob in blobs)
                {
                    var stringDate = blob.Element("Properties").Element("Creation-Time").Value;
                    var fileDate = DateTime.Parse(stringDate);
                    if (DateTime.Compare(fileDate, newestDate) < 0)
                    {
                        // fileDate is earlier than newestDate, delete the file.
                        var fileName = blob.Element("Name").Value;
                        var fileNameSplit = fileName.Split('/');
                        await storageManager.DeleteFileAsync(this.ContainerName, fileNameSplit[0], fileNameSplit[1]);
                    }
                }

                log.Log(this.LogCategory, TraceEventType.Information, "Finished removing obsolete files");
            }
            catch (Exception ex)
            {
                log.Log(this.LogCategory, TraceEventType.Error, ex.Message, null, ex);
            }
        }

        internal async Task ProcessContribution(ContributionRequestBody requestBody, ILogger logger, IMediator mediator)
        {
            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimSubKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            var lexisNexisEnv = ConfigurationManager.AppSettings[Constants.AppSettingKeys.LexisNexisEnvironment];
            var storageManager = new StorageManager(apiUrl, apimSubKey);
            ILexisNexisApi lexisNexisApi = RestService.For<ILexisNexisApi>(apiUrl);

            var currentCarrierResponse = await this.RetrieveContributionData(apimSubKey, logger, mediator);

            await this.ProcessContributionProcessor(requestBody, currentCarrierResponse, apimSubKey, storageManager, lexisNexisApi, lexisNexisEnv, logger);
        }

        internal async Task<ContributionResponse> RetrieveContributionData(string apimSubscriptionKey, ILogger logger, IMediator mediator)
        {
            logger.Log(this.LogCategory, TraceEventType.Information, "Running RetrieveContributionData");
            var contributionResponse = new ContributionResponse();

            try
            {
                contributionResponse.Data = await this.RetrieveContributionDataWorker(apimSubscriptionKey, mediator);
            }
            catch (Exception ex)
            {
                logger.Log(this.LogCategory, TraceEventType.Error, ex.Message, null, ex);
                contributionResponse.Data = string.Empty;
            }

            return contributionResponse;
        }

        internal async Task ProcessContributionProcessor(
            ContributionRequestBody requestBody,
            ContributionResponse responseBody,
            string apimSubscriptionKey,
            IStorageManager storageManager,
            ILexisNexisApi lexisNexisApi,
            string lexisNexisEnvironment,
            ILogger logger)
        {
            var utcString = DateTime.UtcNow.ToString("yyyyMMddHHmmss");
            var fileName = this.BuildContributionFileName(lexisNexisEnvironment, utcString);

            if (!string.IsNullOrEmpty(responseBody.Data) && !requestBody.suppressSFTP)
            {
                // upload the file to LexisNexis
                logger.Log(this.LogCategory, TraceEventType.Information, "Starting to upload file to LexisNexis");
                await lexisNexisApi.SftpUpload(fileName, apimSubscriptionKey, responseBody.Data);
                logger.Log(this.LogCategory, TraceEventType.Information, "Completed file upload");
            }
            else
            {
                try
                {
                    // store the file in Azure blob storage
                    logger.Log(this.LogCategory, TraceEventType.Information, "Storing file to Azure storage");
                    await storageManager.CreateFileAsync(
                        this.ContainerName,
                        this.OutputFolderName,
                        fileName,
                        responseBody.Data);
                    logger.Log(this.LogCategory, TraceEventType.Information, "Completed file store");
                }
                catch (Exception ex)
                {
                    logger.Log(this.LogCategory, TraceEventType.Error, ex.Message, null, ex);
                    throw;
                }
            }
        }

        protected abstract string BuildContributionFileName(string environment, string dateString);

        protected abstract Task<string> RetrieveContributionDataWorker(string apimSubscriptionKey, IMediator mediator);
    }
}
