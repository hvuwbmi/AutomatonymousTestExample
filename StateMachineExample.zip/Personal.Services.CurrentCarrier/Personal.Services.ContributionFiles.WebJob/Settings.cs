﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Settings.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Configuration;
    using MessageService.Core;
    using WestBend.Core.Service.MessageContracts.LexisNexisFacadeService.InteractiveOrder.Request;

    public static class Settings
    {
        public static class Azure
        {
            public static class APIM
            {
                public static string GetAPIMUrl()
                {
                    return ConfigurationManager.AppSettings["ApimUrl"];
                }
            }

            public static class ServiceBus
            {
                public static ServiceBusSettings GetServiceBusSettings(string subscriberName, string topicName, bool isClaims = false)
                {
                    if (isClaims)
                    {
                        return new ServiceBusSettings
                        {
                            Key = ConfigurationManager.AppSettings["AzureSbSharedAccessKeyClaim"],
                            KeyName = ConfigurationManager.AppSettings["AzureSbKeyNameClaim"],
                            NameSpace = ConfigurationManager.AppSettings["AzureSbNamespace"],
                            Path = ConfigurationManager.AppSettings["AzureSbPath"],
                            Subscriber = subscriberName,
                            Topic = topicName
                        };
                    }

                    return new ServiceBusSettings
                    {
                        Key = ConfigurationManager.AppSettings["AzureSbSharedAccessKey"],
                        KeyName = ConfigurationManager.AppSettings["AzureSbKeyName"],
                        NameSpace = ConfigurationManager.AppSettings["AzureSbNamespace"],
                        Path = ConfigurationManager.AppSettings["AzureSbPath"],
                        Subscriber = subscriberName,
                        Topic = topicName
                    };
                }
            }
        }
    }
}