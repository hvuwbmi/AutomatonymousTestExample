﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContributionResponse.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.WebJob
{
    public class ContributionResponse
    {
        public string Data { get; set; }
    }
}
