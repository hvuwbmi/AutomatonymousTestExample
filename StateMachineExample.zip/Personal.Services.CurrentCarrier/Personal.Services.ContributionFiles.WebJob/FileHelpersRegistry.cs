﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FileHelpersRegistry.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Configuration;
    using MediatR;
    using MediatR.Pipeline;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;
    using Personal.Services.ContributionFiles.FileHelpers.Requests;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces.Impls;
    using Refit;
    using StructureMap;
    using StructureMap.Pipeline;
    using WestBend.Core;
    using WestBend.Core.Service;

    public class FileHelpersRegistry : Registry
    {
        public IMediator BuildMediator()
        {
            var apimUrl = ConfigurationManager.AppSettings["ApimUrl"];
            var apimSubscriptionKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];

            var container = new Container(cfg =>
            {
                cfg.Scan(scanner =>
                {
                    scanner.AssemblyContainingType<GetRunDateRequest>();
                    scanner.AssemblyContainingType<FileHelpersRegistry>();
                    scanner.ConnectImplementationsToTypesClosing(typeof(IRequestHandler<,>));
                    scanner.ConnectImplementationsToTypesClosing(typeof(INotificationHandler<>));
                });

                cfg.For(typeof(IPipelineBehavior<,>)).Add(typeof(RequestPreProcessorBehavior<,>));
                cfg.For(typeof(IPipelineBehavior<,>)).Add(typeof(RequestPostProcessorBehavior<,>));

                // This is the default but let's be explicit. At most we should be container scoped.
                cfg.For<IMediator>().LifecycleIs<TransientLifecycle>().Use<Mediator>();

                cfg.For<ServiceFactory>().Use<ServiceFactory>(ctx => ctx.GetInstance);

                cfg.For<ILogger>().Add<CommonLogger>();
                cfg.For<IStorageManager>().Add(ctx => new StorageManager(apimUrl, apimSubscriptionKey));
                cfg.For<IEarsMapper>().Add<EarsMapper>();
                cfg.For<IFileWriter>().Add(ctx => new BlobFileWriter(ConfigurationManager.AppSettings["ContainerReference"], ctx.GetInstance<IStorageManager>()));
                cfg.For<EngineFactory>().Add<EngineFactory>();
            });

            var mediator = container.GetInstance<IMediator>();

            return mediator;
        }
    }
}
