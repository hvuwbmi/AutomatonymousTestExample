﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContributionRequestBody.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "Backwards compatibility")]
    public class ContributionRequestBody
    {
        public bool suppressSFTP { get; set; }
    }
}