﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoDataProcessor.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Threading.Tasks;
    using MediatR;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Requests;

    public class ClueAutoDataProcessor : BaseDataProcessor
    {
        public ClueAutoDataProcessor()
        {
        }

        protected override string LogCategory => Constants.Logging.CATEGORYCLUEAUTO;

        protected override string ContainerName => Constants.Azure.BlobStorage.ContainerName;

        protected override string FolderName => Constants.Azure.BlobStorage.FolderNameClueAuto;

        protected override string OutputFolderName => Constants.Azure.BlobStorage.FolderNameClueAutoOutput;

        protected override string FileNamePrefix => "ClueAuto";

        protected override string LastRunParitionKey => "ClueAuto";

        protected override string LastRunRowKey => "1LR2";

        protected override string BuildContributionFileName(string environment, string dateString)
        {
            return $"cc_history_westbnd2_{environment}{dateString}.txt";
        }

        protected override async Task<string> RetrieveContributionDataWorker(string apimSubscriptionKey, IMediator mediator)
        {
            var runForDate = await mediator.Send(new GetRunDateRequest { ApimKey = apimSubscriptionKey, PartitionKey = this.LastRunParitionKey, RowKey = this.LastRunRowKey });
            var result = await mediator.Send(new BuildClueAutoOutput { ApimKey = apimSubscriptionKey, RunForDate = runForDate });
            return result;
        }
    }
}
