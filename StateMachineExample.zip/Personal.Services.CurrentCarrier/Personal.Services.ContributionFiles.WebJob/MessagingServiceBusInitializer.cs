﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="MessagingServiceBusInitializer.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Configuration;
    using FileHelpers.ServiceInterfaces;
    using FileHelpers.ServiceInterfaces.Impls;
    using MassTransit;
    using MessageService.Core;
    using MessageService.Core.Helpers;
    using Personal.Service.Api.Storage;
    using Sagas.MessageMachine;
    using WestBend.Core;

    public class MessagingServiceBusInitializer
    {
        private readonly IMessageService messageService;
        private readonly ILogger logger;
        private readonly IPolicyStoreApi policyStoreApi;
        private readonly IStorageManager storageManager;
        private readonly IClaimsClaim claimsClaim;

        public MessagingServiceBusInitializer(ILogger logger, IMessageService messageService, IPolicyStoreApi policyStoreApi, IStorageManager storageManager, IClaimsClaim claimsClaim)
        {
            this.logger = logger;
            this.messageService = messageService;
            this.policyStoreApi = policyStoreApi;
            this.storageManager = storageManager;
            this.claimsClaim = claimsClaim;
        }

        public IBusControl RegisterTransactionCommitCurrentCarrierBusInstance(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ContainerPath"];

            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);
            var bus = this.messageService.Initialize(new CurrentCarrierMessageMachine(this.logger, mapperService), FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME, Constants.Logging.CATEGORY_CURRENT_CARRIER, serviceBusSettings);

            return bus;
        }

        public IBusControl RegisterClaimAtFaultCLUEAutoBus(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ClueAutoContainerPath"];
            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);

            return this.messageService.Initialize(
                new ClaimAtFaultCLUEAutoMessageMachine(this.logger, new ClueAutoClaimEventProcessor(this.logger, mapperService, this.storageManager)),
                FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME,
                Constants.Logging.CATEGORY_CLUE_AUTO,
                serviceBusSettings,
                Constants.Filters.POLICYOFFERING + Constants.Filters.AND + Constants.Filters.CLAIMTYPEAUT);
        }

        public IBusControl RegisterClaimStatusChangedCLUEAutoBus(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ClueAutoContainerPath"];
            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);

            return this.messageService.Initialize(
                new ClaimStatusChangedCLUEAutoMessageMachine(this.logger, new ClueAutoClaimEventProcessor(this.logger, mapperService, this.storageManager)),
                FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME,
                Constants.Logging.CATEGORY_CLUE_AUTO,
                serviceBusSettings,
                Constants.Filters.POLICYOFFERING + Constants.Filters.AND + Constants.Filters.CLAIMTYPEAUT);
        }

        public IBusControl RegisterOffsetOnsetCLUEAutoBus(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ClueAutoContainerPath"];
            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);

            return this.messageService.Initialize(
                new OffsetOnsetCLUEAutoMessageMachine(this.logger, new ClueAutoClaimEventProcessor(this.logger, mapperService, this.storageManager)),
                FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME,
                Constants.Logging.CATEGORY_CLUE_AUTO,
                serviceBusSettings,
                Constants.Filters.POLICYOFFERING + Constants.Filters.AND + Constants.Filters.CLAIMTYPEAUT);
        }

        public IBusControl RegisterFinancialTransactionCommittedCLUEAutoBus(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ClueAutoContainerPath"];
            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);

            return this.messageService.Initialize(
                new FinancialTransactionCommittedCLUEAutoMessageMachine(this.logger, new ClueAutoClaimEventProcessor(this.logger, mapperService, this.storageManager)),
                FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME,
                Constants.Logging.CATEGORY_CLUE_AUTO,
                serviceBusSettings,
                Constants.Filters.POLICYOFFERING + Constants.Filters.AND + Constants.Filters.CLAIMTYPEAUT);
        }

        public IBusControl RegisterClaimPartyChangedCLUEAutoBus(ServiceBusSettings serviceBusSettings)
        {
            var folder = ConfigurationManager.AppSettings["ClueAutoContainerPath"];
            var mapperService = new MapperService(this.policyStoreApi, new BlobFileWriter(folder, this.storageManager), this.logger, this.claimsClaim);

            return this.messageService.Initialize(
                new ClaimPartyChangedCLUEAutoMessageMachine(this.logger, new ClueAutoClaimEventProcessor(this.logger, mapperService, this.storageManager)),
                FileHelpers.FileMappers.Constants.AppSettingKeys.SERVICENAME,
                Constants.Logging.CATEGORY_CLUE_AUTO,
                serviceBusSettings,
                Constants.Filters.POLICYOFFERING + Constants.Filters.AND + Constants.Filters.CLAIMTYPEAUT);
        }

        public void StartTheBuses()
        {
            this.RegisterTransactionCommitCurrentCarrierBusInstance(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.CURRENTCARRIER,
                    Constants.Events.TRANSACTIONCOMMITED))
                .Start();

            this.RegisterClaimAtFaultCLUEAutoBus(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.ATFAULTCLUEAUTO,
                    Constants.Events.CLAIMSCHANGED,
                    true))
                .Start();

            this.RegisterClaimStatusChangedCLUEAutoBus(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.CLAIMCHANGEDCLUEAUTO,
                    Constants.Events.CLAIMSCHANGED,
                    true))
                .Start();

            this.RegisterOffsetOnsetCLUEAutoBus(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.ONSETOFFSETCLUEAUTO,
                    Constants.Events.CLAIMSCHANGED,
                    true))
                .Start();

            this.RegisterFinancialTransactionCommittedCLUEAutoBus(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.FINANCIALTRANSACTIONCOMMITTEDCLUEAUTO,
                    Constants.Events.FINANCIALTRANSACTIONCOMMITTED,
                    true))
                .Start();

            this.RegisterClaimPartyChangedCLUEAutoBus(
                Settings.Azure.ServiceBus.GetServiceBusSettings(
                    Constants.Subscribers.CLAIMPARTYCHANGEDCLUEAUTO,
                    Constants.Events.CLAIMPARTYCHANGED,
                    true))
                .Start();
        }
    }
}