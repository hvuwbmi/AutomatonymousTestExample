﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IDataProcessor.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob
{
    using System.Threading.Tasks;
    using MediatR;
    using WestBend.Core;

    public interface IDataProcessor
    {
        Task Execute(string requestBody, ILogger logger, IMediator mediator);
    }
}
