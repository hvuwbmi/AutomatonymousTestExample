﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="GetRunDateRequest.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests
{
    using MediatR;

    public class GetRunDateRequest : IRequest<string>
    {
        public string ApimKey { get; set; }

        public string PartitionKey { get; set; }

        public string RowKey { get; set; }
    }
}