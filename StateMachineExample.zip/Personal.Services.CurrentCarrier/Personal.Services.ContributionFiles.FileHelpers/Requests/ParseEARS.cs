﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ParseEARS.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests
{
    using MediatR;

    public class ParseEARS : IRequest<string>
    {
        public string ApimKey { get; set; }

        public string Container { get; set; }
    }
}