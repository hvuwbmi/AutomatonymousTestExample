﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="BuildCurrentCarrierOutput.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests
{
    using MediatR;

    public class BuildCurrentCarrierOutput : IRequest<string>
    {
        public string ApimKey { get; set; }

        public string RunForDate { get; set; }
    }
}