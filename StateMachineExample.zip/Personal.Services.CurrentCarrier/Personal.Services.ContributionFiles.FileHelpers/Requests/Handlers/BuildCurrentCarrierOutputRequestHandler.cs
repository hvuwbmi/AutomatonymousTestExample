﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BuildCurrentCarrierOutputRequestHandler.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests.Handlers
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using global::FileHelpers;
    using FileMappers;
    using FileMappers.CurrentCarrier;
    using MediatR;
    using Models;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using WestBend.Core;

    public class BuildCurrentCarrierOutputRequestHandler : IRequestHandler<BuildCurrentCarrierOutput, string>
    {
        private readonly IStorageManager storageManager;
        private readonly EngineFactory engineFactory;
        private readonly ILogger logger;

        public BuildCurrentCarrierOutputRequestHandler(IStorageManager storageManager, EngineFactory engineFactory, ILogger logger)
        {
            this.storageManager = storageManager;
            this.engineFactory = engineFactory;
            this.logger = logger;
        }

        public async Task<string> Handle(BuildCurrentCarrierOutput request, CancellationToken cancellationToken)
        {
            var carrierMetaFiles = await this.storageManager.ReadRecordFilteredAsync(Constants.Azure.TableStorage.ThirdPartyContribution, $"PartitionKey eq '{Constants.Azure.TableStorage.CurrentCarrier}' and CreateDate gt '{request.RunForDate}'");
            this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, $"{carrierMetaFiles.Count} policies found to be added to current carrier file output - last run date is {request.RunForDate}");

            return await this.ProcessFiles(carrierMetaFiles, request.ApimKey, request.RunForDate);
        }

        internal string WriteFinalFile(List<object> fileData, string lastRunDate)
        {
            var now = DateTime.UtcNow;
            MultiRecordEngine finalEngine = this.engineFactory.CreateEngine(EngineFactory.EngineType.CurrentCarrier);

            finalEngine.HeaderText = new FileHelperEngine<CurrentCarrierHeader>().WriteString(new List<CurrentCarrierHeader>() { new CurrentCarrierHeader().Map(now, lastRunDate, this.logger) });
            finalEngine.FooterText = new FileHelperEngine<CurrentCarrierTrailer>().WriteString(new List<CurrentCarrierTrailer>() { new CurrentCarrierTrailer().Map(fileData.Count, now) });

            return finalEngine.WriteString(fileData);
        }

        private async Task<string> ProcessFiles(List<JObject> carrierMetaFiles, string apimKey, string runForDate)
        {
            string newLastrunDate = runForDate;
            List<object> fileData = new List<object>();
            MultiRecordEngine engine = this.engineFactory.CreateEngine(EngineFactory.EngineType.CurrentCarrier);

            // The last 10 characters of the rowkey are the policy number, the policy version, and the transaction sequence number.  With the OoS transactions being in number order now,
            // sorting on this will result in the proper order for OoS transactions.

            // Using LINQ OrderBy rather than List.Sort because OrderBy is known to be stable.  List.Sort might be, but I couldn't find any documentation asserting that.
            
            // Transaction mod
            var sortedFile = carrierMetaFiles.OrderBy(x => x["TransSeqNumber"]);

            // Policy Version
            sortedFile = sortedFile.OrderBy(x => x["PolicyVersion"] ?? "0");

            // Policy Number
            sortedFile = sortedFile.OrderBy(x => x["PolicyNumber"]);
            
            foreach (var jobj in sortedFile)
            {
                var currentCarrierData = jobj.ToObject<CurrentCarrierData>();

                var file = await this.storageManager.ReadFileAsync(currentCarrierData.Container, currentCarrierData.Folder, currentCarrierData.Name);
                fileData.AddRange(engine.ReadString(file));
                
                // We aren't using the default sort order that has things in timestamp order any more, so we actually need to check if the date is newer than the last one.
                if (currentCarrierData.CreateDate.CompareTo(newLastrunDate) > 0)
                {
                    newLastrunDate = currentCarrierData.CreateDate;
                }
            }

            if (newLastrunDate.Equals(runForDate))
            {
                newLastrunDate = DateTime.UtcNow.ToString(Constants.Formatters.LastRunDateFormat);
            }

            var result = this.WriteFinalFile(fileData, runForDate);

            JObject fileObject = JObject.FromObject(new LastRunDate { RunDate = newLastrunDate });
            string fileContents = fileObject.ToString();
            await this.storageManager.UpdateRecordAsync(Constants.Azure.TableStorage.ThirdPartyContribution, Constants.Azure.TableStorage.CurrentCarrier, Constants.Azure.TableStorage.RunDateRowKey, fileObject);

            this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, $"{fileData.Count} policies added to current carrier file output");

            return result;
        }
    }
}