﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ParseEARSHandler.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests.Handlers
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Threading;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using global::FileHelpers;
    using FileMappers;
    using FileMappers.EarsRiskAlert;
    using MediatR;
    using Requests;
    using ServiceInterfaces;
    using WestBend.Core;

    public class ParseEARSHandler : IRequestHandler<ParseEARS, string>
    {
        private readonly ILogger logger;
        private readonly IEarsMapper earsMapper;

        public ParseEARSHandler(ILogger logger, IEarsMapper earsMapper)
        {
            this.logger = logger;
            this.earsMapper = earsMapper;
        }

        public async Task<string> Handle(ParseEARS request, CancellationToken cancellationToken)
        {
            try
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, "Handling Parse EARS...");
                return await this.earsMapper.MapEars(request.Container, request.ApimKey);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, ex.Message, exception: ex);
                return string.Empty;
            }
        }
    }
}