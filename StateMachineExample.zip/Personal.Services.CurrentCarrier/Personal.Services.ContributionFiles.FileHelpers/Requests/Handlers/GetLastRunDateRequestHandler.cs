﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="GetLastRunDateRequestHandler.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests.Handlers
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using MediatR;
    using Models;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Utilities;

    public class GetLastRunDateRequestHandler : IRequestHandler<GetRunDateRequest, string> 
    {
        private readonly IStorageManager storageManager;

        public GetLastRunDateRequestHandler(IStorageManager storageManager)
        {
            this.storageManager = storageManager;
        }

        public async Task<string> Handle(GetRunDateRequest request, CancellationToken cancellationToken)
        {
            List<JObject> root = await this.storageManager.ReadRecordFilteredAsync("ThirdPartyContribution", $"PartitionKey eq '{request.PartitionKey}' and RowKey eq '{request.RowKey}'");
            LastRunDate lastRunDate = root.FirstOrDefault()?.ToObject<LastRunDate>();

            if (lastRunDate == null || lastRunDate.RunDate.IsEmpty())
            {
                return DateTime.MinValue.ToString("yyyyMMddhhmmssffff");
            }
            else
            {
                return lastRunDate.RunDate;
            }
        }
    }
}