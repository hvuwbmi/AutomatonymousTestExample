﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BuildClueAutoOutputRequestHandler.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Requests.Handlers
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using global::FileHelpers;
    using FileMappers;
    using FileMappers.CLUEAuto;
    using MediatR;
    using Models;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using WestBend.Core;

    public class BuildClueAutoOutputRequestHandler : IRequestHandler<BuildClueAutoOutput, string>
    {
        private readonly IStorageManager storageManager;
        private readonly EngineFactory engineFactory;
        private readonly ILogger logger;

        public BuildClueAutoOutputRequestHandler(IStorageManager storageManager, EngineFactory engineFactory, ILogger logger)
        {
            this.storageManager = storageManager;
            this.engineFactory = engineFactory;
            this.logger = logger;
        }

        public async Task<string> Handle(BuildClueAutoOutput request, CancellationToken cancellationToken)
        {
            var clueAutoData = await this.storageManager.ReadRecordFilteredAsync(Constants.Azure.TableStorage.ThirdPartyContribution, $"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and CreateDate gt '{request.RunForDate}'");
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Information, $"{clueAutoData.Count} claims found to be added to clue auto file output - last run date is {request.RunForDate}");

            return await this.ProcessFiles(clueAutoData, request.ApimKey, request.RunForDate);
        }

        internal string WriteFinalFile(List<object> fileData, string lastRunDate)
        {
            var now = DateTime.UtcNow;
            MultiRecordEngine finalEngine = this.engineFactory.CreateEngine(EngineFactory.EngineType.CLUEAuto);

            finalEngine.HeaderText = new FileHelperEngine<CLUEAutoHeader>().WriteString(new List<CLUEAutoHeader>() { new CLUEAutoHeader().Map(now, lastRunDate, this.logger) });
            finalEngine.FooterText = new FileHelperEngine<CLUEAutoTrailer>().WriteString(new List<CLUEAutoTrailer>() { new CLUEAutoTrailer().Map(fileData.Count, now) });

            return finalEngine.WriteString(fileData);
        }

        private async Task<string> ProcessFiles(List<JObject> clueAutoMetaFiles, string apimKey, string runForDate)
        {
            string newLastrunDate = runForDate;
            List<object> fileData = new List<object>();
            MultiRecordEngine engine = this.engineFactory.CreateEngine(EngineFactory.EngineType.CLUEAuto);
            int successfulProcessed = 0;

            foreach (var jobj in clueAutoMetaFiles.OrderBy(a => a["CreateDate"]))
            {
                var clueAutoMetaData = jobj.ToObject<ClueAutoData>();

                var additionalData = new Dictionary<string, string>
                {
                    { "Container", clueAutoMetaData.Container },
                    { "Folder", clueAutoMetaData.Folder },
                    { "Name", clueAutoMetaData.Name }
                };

                try
                {
                    var file = await this.storageManager.ReadFileAsync(clueAutoMetaData.Container, clueAutoMetaData.Folder, clueAutoMetaData.Name);
                    fileData.AddRange(engine.ReadString(file));
                    newLastrunDate = clueAutoMetaData.CreateDate;
                    successfulProcessed += 1;
                }
                catch (Exception exception)
                {
                    this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, "Failed to process ClueAuto file.", additionalData, exception);
                }
            }

            if (newLastrunDate.Equals(runForDate))
            {
                newLastrunDate = DateTime.UtcNow.ToString(Constants.Formatters.LastRunDateFormat);
            }

            var result = this.WriteFinalFile(fileData, runForDate);

            JObject record = JObject.FromObject(new LastRunDate { RunDate = newLastrunDate });
            await this.storageManager.UpdateRecordAsync(Constants.Azure.TableStorage.ThirdPartyContribution, Constants.Azure.TableStorage.ClueAutoPartitionKey, Constants.Azure.TableStorage.RunDateRowKey, record);

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Information, $"{successfulProcessed} claims added to CLUE Auto file output");

            return result;
        }
    }
}