﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="FinanceCompanyCodeRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class FinanceCompanyCodeRules
    {
        /// <summary>
        /// Retrieve the finance company code for the provided nature interest code.
        /// </summary>
        /// <param name="natureInterestCode">The code from the Acord document.</param>
        /// <returns>The finance company code to insert into the FR01 record.</returns>
        public static string GetFinanceCompanyCode(this string natureInterestCode)
        {
            switch (natureInterestCode)
            {
                case "ADDIN":
                case "AINT":
                case "AINL":
                    return "AD";
                case "LOSSP":
                case "LIEN":
                    return "FL";
                case "OT":
                    return "OT";
                default:
                    return null;
            }
        }

        public static bool IsValidInterestCode(this string natureInterestCode)
        {
            if (string.IsNullOrEmpty(natureInterestCode))
            {
                return false;
            }

            return string.Equals(natureInterestCode, "LOSSP", System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(natureInterestCode, "AINT", System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(natureInterestCode, "AINL", System.StringComparison.OrdinalIgnoreCase) ||
                    string.Equals(natureInterestCode, "ADDIN", System.StringComparison.OrdinalIgnoreCase);
        }
    }
}
