﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ShouldCreateContributionFile.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    public class ShouldCreateContributionFile : SpecificationBase<Models.PolicyRs, Models.PolicyRs>
    {
        public override bool IsSatisfiedBy(PolicyRs current, PolicyRs previous)
        {
            if (current?.Policy?[0] == null)
            {
                return false;
            }

            // A policy without an Auto LOB shouldn't be applied to current carrier.
            if (current?.Policy?[0].PersAutoLineBusiness == null || current?.Policy?[0].PersAutoLineBusiness.Length == 0)
            {
                return false;
            }

            // A policy with no vehicles should not be applied to current carrier.
            if (current?.Policy?[0].PersAutoLineBusiness?[0]?.Vehicle == null)
            {
                return false;
            }

            if (current.BusinessPurposeTypeCd == "NBQ")
            {
                return true;
            }
            else if (current.BusinessPurposeTypeCd == "PCH")
            {
                if (previous?.Policy?[0].PersAutoLineBusiness == null ||
                    current.Policy[0].PersAutoLineBusiness == null)
                {
                    return false;
                }

                // We need to always send the CC file for endorsements, no matter what was changed in the endorsement.
                return true;
            }
            else if ((current.BusinessPurposeTypeCd == "XLC" || current.BusinessPurposeTypeCd == "REI" || current.BusinessPurposeTypeCd == "REW" || current.BusinessPurposeTypeCd == "RIX" || current.BusinessPurposeTypeCd == "RWL"
                || current.BusinessPurposeTypeCd == "RWX") && previous?.Policy?[0].PersAutoLineBusiness != null && current.Policy[0].PersAutoLineBusiness != null)
            {
                 return true;
            }

            return false;
        }
    }
}
