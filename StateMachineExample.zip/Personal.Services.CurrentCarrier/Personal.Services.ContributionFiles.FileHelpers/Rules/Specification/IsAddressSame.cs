﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IsAddressSame.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    public class IsAddressSame : SpecificationBase<Addr, Addr>
    {
        public override bool IsSatisfiedBy(Addr address1, Addr address2)
        {
            if (address1 == null && address2 == null)
            {
                return true;
            }

            if (address1 == null && address2 != null)
            {
                return false;
            }
            else if (address1 != null && address2 == null)
            {
                return false;
            }

            bool isAddressStreetSame = false;

            var address2Standardized = Addr.IsAddressStandardized(address2.AddrExt);
            var address1Standardized = Addr.IsAddressStandardized(address1.AddrExt);

            if (address2Standardized && address1Standardized)
            {
                isAddressStreetSame =
                    address2.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber == address1.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber &&
                    Addr.BuildStreetName(address2.AddrExt[0]?.WBAddressStandardization[0]) == Addr.BuildStreetName(address1.AddrExt[0]?.WBAddressStandardization[0]) && 
                    address2.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber == address1.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber;
            }
            else if (!address2Standardized && !address1Standardized)
            {
                isAddressStreetSame =
                    address2.Addr1.Equals(address1.Addr1, System.StringComparison.OrdinalIgnoreCase);
            }
            else if (address2Standardized && !address1Standardized)
            {
                isAddressStreetSame =
                    address1.Addr1.Equals($"{address2.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeStreetNumber} {Addr.BuildStreetName(address2.AddrExt[0]?.WBAddressStandardization[0])}");
            }
            else if (!address2Standardized && address1Standardized)
            {
                isAddressStreetSame =
                    address2.Addr1.Equals($"{address1.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeStreetNumber} {Addr.BuildStreetName(address1.AddrExt[0]?.WBAddressStandardization[0])}");
            }

            var isCityStateZipSame = 
                    address2.City.Equals(address1.City, System.StringComparison.OrdinalIgnoreCase) &&
                    address2.StateProvCd.Equals(address1.StateProvCd, System.StringComparison.OrdinalIgnoreCase) &&
                    address2.PostalCode.GetZip5().Equals(address1.PostalCode.GetZip5(), System.StringComparison.OrdinalIgnoreCase);

            return isAddressStreetSame && isCityStateZipSame;
        }
    }
}
