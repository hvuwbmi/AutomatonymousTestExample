﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IsCoverageNotExpired.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using System;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    /// <summary>
    /// Determine whether the coverage has not been expired. Coverages might be expired
    /// for cancel or endorsement transactions, potentially others.
    /// </summary>
    public class IsCoverageNotExpired : SpecificationBase<PolicyRs, Coverage>
    {
        /// <summary>
        /// A coverage on a transaction has to be inspected for the
        /// expiration date of the coverage against the transaction effective
        /// date.
        /// </summary>
        /// <param name="policyRs">The policy to check against.</param>
        /// <param name="coverage">The coverage to determine validity of.</param>
        /// <returns>True if the coverage is valid, false otherwise.</returns>
        public override bool IsSatisfiedBy(PolicyRs policyRs, Coverage coverage)
        {
            DateTime coverageExpirationDate;
            if (DateTime.TryParse(coverage.ExpirationDt, out coverageExpirationDate))
            {
                if (coverageExpirationDate.Date < policyRs.TransactionEffectiveDate.Date)
                {
                    return false;
                }
            }

            return true;
        }
    }
}
