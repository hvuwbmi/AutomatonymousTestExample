﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="SpecificationBase.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    public abstract class SpecificationBase<T1, T2>
    {
        public abstract bool IsSatisfiedBy(T1 firstValue, T2 secondValue);
    }
}