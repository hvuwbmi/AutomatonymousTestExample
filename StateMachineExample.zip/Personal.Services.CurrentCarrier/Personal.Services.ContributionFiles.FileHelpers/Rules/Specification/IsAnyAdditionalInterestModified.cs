﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IsAnyAdditionalInterestModified.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using System.Linq;
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    public class IsAnyAdditionalInterestModified : SpecificationBase<Models.PolicyRs, Models.PolicyRs>
    {
        public override bool IsSatisfiedBy(PolicyRs currentTransaction, PolicyRs previousTransaction)
        {
            bool additionalInterestIsModified = false;

            if (previousTransaction == null)
            {
                return false;
            }

            if (currentTransaction.BusinessPurposeTypeCd == "PCH")
            {
                if (currentTransaction.Policy[0].PersAutoLineBusiness[0].Vehicle != null)
                {
                    foreach (var vehicle in currentTransaction.Policy[0]?.PersAutoLineBusiness[0]?.Vehicle)
                    {
                        var previousTransactionVehicle = previousTransaction.Policy[0].PersAutoLineBusiness[0].Vehicle?.FirstOrDefault(v => v.id == vehicle.id);

                        if (vehicle.AdditionalInterest != null)
                        {
                            foreach (var additionalInterest in vehicle.AdditionalInterest)
                            {
                                var additionalInterestActionCd = currentTransaction.ModInfo?.FirstOrDefault(m => m.IdRef == additionalInterest.id)?.ActionCd;
                                if (additionalInterestActionCd == "M")
                                {
                                    var previousTransactionAdditionalInterest = previousTransactionVehicle?.AdditionalInterest?.FirstOrDefault(ai => ai.id == additionalInterest.id);

                                    if (previousTransactionAdditionalInterest != null &&
                                        (!string.Equals(additionalInterest.GivenName, previousTransactionAdditionalInterest.GivenName, System.StringComparison.OrdinalIgnoreCase) ||
                                        !string.Equals(additionalInterest.Surname, previousTransactionAdditionalInterest.Surname, System.StringComparison.OrdinalIgnoreCase) ||
                                        !string.Equals(additionalInterest.AccountNumberId, previousTransactionAdditionalInterest.AccountNumberId, System.StringComparison.OrdinalIgnoreCase) ||
                                        !new IsAddressSame().IsSatisfiedBy(additionalInterest.Addr[0], previousTransactionAdditionalInterest.Addr[0])))
                                    {
                                        additionalInterest.ModInfoActionCd = additionalInterestActionCd;
                                        additionalInterestIsModified = true;
                                    }

                                    // If there was no additional interest on the previous transaction, should we consider this modified?
                                    if (previousTransactionAdditionalInterest == null)
                                    {
                                        additionalInterest.ModInfoActionCd = additionalInterestActionCd;
                                        additionalInterestIsModified = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }

            return additionalInterestIsModified;
        }
    }
}
