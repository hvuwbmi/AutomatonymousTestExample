﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ShouldCreateSJ01Record.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using KissSpecifications;

    public class ShouldCreateSJ01Record : SpecificationBase<string>
    {
        public override bool IsSatisfiedBy(string target)
        {
            switch (target)
            {
                case "D":   // Deleted
                    return false;
                default:
                    return true;
            }
        }
    }
}