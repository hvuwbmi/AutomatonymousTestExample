﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ShouldMapGaragingLocation.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    public class ShouldMapGaragingLocation : SpecificationBase<Addr, Addr>
    {
        public override bool IsSatisfiedBy(Addr garagingAddress, Addr mailingAddress)
        {
            if (mailingAddress == null && garagingAddress != null)
            {
                return true;
            }
            else if (garagingAddress == null)
            {
                return false;
            }

            return !new IsAddressSame().IsSatisfiedBy(garagingAddress, mailingAddress);
        }
    }
}
