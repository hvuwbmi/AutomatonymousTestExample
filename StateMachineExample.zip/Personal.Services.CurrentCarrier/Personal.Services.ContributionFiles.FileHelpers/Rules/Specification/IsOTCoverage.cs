﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IsOTCoverage.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using KissSpecifications;

    public class IsOTCoverage : SpecificationBase<string>
    {
        public override bool IsSatisfiedBy(string target)
        {
            switch (target)
            {
                case "AL":      // Auto Liability
                case "CUSTE":   // Customized Equipment
                case "LNCMP":   // Auto Loan - Comprehensive
                case "LNCOL":   // Auto Loan - Collision
                case "RRGAP":   // New Car Replacement and Gap Coverage
                    return true;
                default:
                    return false;
            }
        }
    }
}