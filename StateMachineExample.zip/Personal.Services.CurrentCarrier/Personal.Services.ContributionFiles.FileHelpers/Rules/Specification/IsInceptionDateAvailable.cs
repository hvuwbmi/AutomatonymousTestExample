﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IsInceptionDateAvailable.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using KissSpecifications;

    public class IsInceptionDateAvailable : SpecificationBase<string>
    {
        public override bool IsSatisfiedBy(string target)
        {
            return !string.IsNullOrEmpty(target);
        }
    }
}