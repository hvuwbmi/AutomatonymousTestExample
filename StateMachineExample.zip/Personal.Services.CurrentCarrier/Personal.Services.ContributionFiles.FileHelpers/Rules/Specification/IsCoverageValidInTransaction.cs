﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IsCoverageValidInTransaction.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using KissSpecifications;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;

    /// <summary>
    /// Determine whether the coverage is valid for this transaction (typically
    /// endorsement, but could be any) based on the ModInfo discovered for the
    /// coverage.
    /// </summary>
    public class IsCoverageValidInTransaction : SpecificationBase<string>
    {
        /// <summary>
        /// A coverage on a transaction may technically be deleted based on the
        /// ModInfo. Deleted coverages should not be mapped in the contribution
        /// file.
        /// </summary>
        /// <param name="target">The ModInfo of the coverage.</param>
        /// <returns>True if the coverage applies to the transaction, false
        /// otherwise.</returns>
        public override bool IsSatisfiedBy(string target)
        {
            if (string.Equals(target, Constants.ModInfo.Deleted, System.StringComparison.InvariantCultureIgnoreCase))
            {
                return false;
            }

            return true;
        }
    }
}
