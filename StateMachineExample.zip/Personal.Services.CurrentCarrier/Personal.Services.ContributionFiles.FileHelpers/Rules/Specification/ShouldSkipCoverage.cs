﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ShouldSkipCoverage.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Rules.Specification
{
    using KissSpecifications;

    public class ShouldSkipCoverage : SpecificationBase<string>
    {
        public override bool IsSatisfiedBy(string target)
        {
            switch (target)
            {
                case "FRESP":   // Financial Responsibility Filing
                case "MCCA":    // Michigan Catastrophic Claims Association
                case "RRGAP":   // Car Damage Replacement
                    return true;
                default:
                    return false;
            }
        }
    }
}