﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="AddressRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class AddressRules
    {
        public static string GetZip5(this string fullZip)
        {
            if (!string.IsNullOrEmpty(fullZip) && fullZip.Length > 5)
            {
                return fullZip.Substring(0, 5);
            }

            return fullZip;
        }

        public static string GetZip4(this string fullZip)
        {
            if (!string.IsNullOrEmpty(fullZip) && fullZip.Length == 10)
            {
                return fullZip.Substring(6);
            }

            return string.Empty;
        }
    }
}