﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BusinessPurposeTypeCdRules.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using System;
    using System.Configuration;
    using System.Xml.Linq;
    using System.Xml.XPath;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Refit;

    public static class BusinessPurposeTypeCdRules
    {
        /// <summary>
        /// Retrieve the Notification Action code based on the provided Policy Status Code.
        /// </summary>
        /// <param name="businessPurposeTypeCd">The Policy Status code to look up</param>
        /// <returns>The matching Notification Action code</returns>
        /// <exception cref="ArgumentException">Thrown if the policy status code provided is not recognized.</exception>
        public static string GetNotificationAction(this string businessPurposeTypeCd, string vehicleModInfoActionCd, Models.PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest, string requestorCd, string cancelReasonCd, string policyNumber, string policyVersion, string transSeqNumber, IPolicyStoreApi policyStore)
        {
            if (int.Parse(transSeqNumber) >= 3)
            {
                // for any non-nb transaction, we need to load from the transaction list to determine if it's out of sequence

                // lack of error handling for either the refit call or the xdocument parse is deliberate.
                // This will allow the Mass Transit retry logic to pick it up when that's added if either fails.
                if (policyStore != null)
                {
                    string transactionList = policyStore.GetTransactionList(policyNumber, ConfigurationManager.AppSettings["ApimSubscriptionKey"]).Result;

                    XDocument transactionDoc = XDocument.Parse(transactionList);

                    var originalId = transactionDoc.XPathSelectElement($"/transactions/transaction[.//TransactionCounter = {transSeqNumber}]/OriginalID");

                    if (originalId != null)
                    {
                        // if we have a non-null originalId from the transaction list, then the transaction is an OSEAdjustment.  In this case, return 999 rather than using the logic below.
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }
                }
            }

            switch (businessPurposeTypeCd)
            {
                case Constants.BusinessPurposeTypeCode.NewBusiness:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.NewBusiness;
                case Constants.BusinessPurposeTypeCode.Endorsement:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    if (!string.IsNullOrEmpty(vehicleModInfoActionCd))
                    {
                        switch (vehicleModInfoActionCd)
                        {
                            case Constants.ModInfo.Deleted:
                                return Constants.CurrentCarrier.NotificationActionCode.VehicleDeleted;
                            case Constants.ModInfo.Modified:
                                if (additionalInterest == null || string.IsNullOrEmpty(additionalInterest.ModInfoActionCd))
                                {
                                    return Constants.CurrentCarrier.NotificationActionCode.VehicleChanged;
                                }

                                break;
                        }
                    }

                    if (additionalInterest != null && !string.IsNullOrEmpty(additionalInterest.ModInfoActionCd))
                    {
                        switch (additionalInterest.ModInfoActionCd)
                        {
                            case Constants.ModInfo.Added:
                                return Constants.CurrentCarrier.NotificationActionCode.PolicyChange;
                            case Constants.ModInfo.Deleted:
                                return Constants.CurrentCarrier.NotificationActionCode.InterestRemoved;
                            case Constants.ModInfo.Modified:
                                return Constants.CurrentCarrier.NotificationActionCode.LienholderChanged;
                        }
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                case Constants.BusinessPurposeTypeCode.Cancel:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    if ("NP".Equals(cancelReasonCd))
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.CancellationNonPayment;
                    }
                    else if ("C".Equals(requestorCd))
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.CompanyCancelled;
                    }
                    else if ("I".Equals(requestorCd))
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.CancellationCustomerRequest;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                case Constants.BusinessPurposeTypeCode.Reinstate:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.Reinstatement;
                case Constants.BusinessPurposeTypeCode.Rewrite:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.Rewrite;
                case Constants.BusinessPurposeTypeCode.Reissue:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.Reissue;
                case Constants.BusinessPurposeTypeCode.Renewal:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.Renewal;

                case Constants.BusinessPurposeTypeCode.NonRenewal:
                    if (additionalInterest == null)
                    {
                        return Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice;
                    }

                    return Constants.CurrentCarrier.NotificationActionCode.NonRenewal;

                default:
                    throw new ArgumentException($"Business Purpose Type Cd provided {businessPurposeTypeCd} is not recognized");
            }
        }

        public static string GetVehicleStatus(this string businessPurposeTypeCd, string vehicleModInfoActionCd)
        {
            // will be mapped in different stories
            // N: No Vehicle Policy
            switch (businessPurposeTypeCd)
            {
                case Constants.BusinessPurposeTypeCode.NewBusiness:
                case Constants.BusinessPurposeTypeCode.Renewal:
                    return "A";
                case Constants.BusinessPurposeTypeCode.Rewrite:
                case Constants.BusinessPurposeTypeCode.Reissue:
                case Constants.BusinessPurposeTypeCode.Endorsement:
                    // If deleted during endorsement return C else A
                    return (!string.IsNullOrEmpty(vehicleModInfoActionCd) && vehicleModInfoActionCd == Constants.ModInfo.Deleted) ? "C" : "A";
                case Constants.BusinessPurposeTypeCode.Cancel:
                case Constants.BusinessPurposeTypeCode.NonRenewal:
                    return "C";
                case Constants.BusinessPurposeTypeCode.Reinstate:
                    return "R";
                default:
                    throw new ArgumentException($"Business Purpose Type Cd provided {businessPurposeTypeCd} is not recognized");
            }
        }

        public static string GetNotificationActionDate(this string businessPurposeTypeCd, string notificationActionCode, string contractEffectiveDate, string transactionEffectiveDate, string cancelEffectiveDate)
        {
            if (notificationActionCode == "999")
            {
                return string.Empty;
            }

            if (businessPurposeTypeCd == "PCH" || businessPurposeTypeCd == "REI" || businessPurposeTypeCd == "RWL" || businessPurposeTypeCd == "REW" || businessPurposeTypeCd == "RIX" || businessPurposeTypeCd.Equals("XLC")
                || businessPurposeTypeCd == Constants.BusinessPurposeTypeCode.NonRenewal)
            {
                return transactionEffectiveDate;
            }

            return contractEffectiveDate;
        }
    }
}