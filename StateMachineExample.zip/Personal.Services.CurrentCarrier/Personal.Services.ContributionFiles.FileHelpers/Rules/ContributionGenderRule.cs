﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ContributionGenderRule.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using System;

    public static class ContributionGenderRule
    {
        public static string GetContributionGenderMapping(this string gender)
        {
            if (gender.Equals("U", StringComparison.CurrentCultureIgnoreCase))
            {
                return string.Empty;
            }

            return gender;
        }
    }
}