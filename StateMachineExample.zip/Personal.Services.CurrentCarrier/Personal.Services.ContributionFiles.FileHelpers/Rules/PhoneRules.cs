﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PhoneRules.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class PhoneRules
    {
        public static string GetPhone(this string phone)
        {
            if (phone.Length == 7)
            {
                return phone;
            }

            if (phone.Length == 10)
            {
                return phone.Substring(3);
            }

            if (phone.Length == 12)
            {
                var replaced = phone.Replace("-", string.Empty);
                return replaced.Substring(3);
            }

            return string.Empty;
        }

        public static string GetAreaCode(this string phone)
        {
            if (phone.Length == 12 || phone.Length == 10)
            {
                return phone.Substring(0, 3);
            }

            return string.Empty;
        }
    }
}