﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueGenderRule.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class ClueGenderRule
    {
        public static string GetClueGenderMapping(this string gender)
        {
            if (gender.Equals("NB", System.StringComparison.InvariantCultureIgnoreCase))
            {
                return string.Empty;
            }

            return gender;
        }
    }
}
