﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AcordVROToClueAutoVRO.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class AcordVROToClueAutoVRO
    {
        public static string TransformAcordVROToClueAutoVRO(string acordVRO)
        {
            switch (acordVRO)
            {
                case "FNI":
                    return "P";
                case "CN":
                    return "H";
                case "SP":
                    return "S";
                case "CH":
                    return "C";
                case "PA":
                    return "F";
                case "GP":
                case "RE":
                    return "O";
                case "NR":
                    return "X";
                default:
                    return string.Empty;
            }
        }
    }
}