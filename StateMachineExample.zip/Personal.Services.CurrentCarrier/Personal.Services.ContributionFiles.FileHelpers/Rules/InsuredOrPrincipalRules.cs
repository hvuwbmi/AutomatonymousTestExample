﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="InsuredOrPrincipalRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using System;

    public static class InsuredOrPrincipalRules
    {
        /// <summary>
        /// Transform an Driver's relationship code value (from ACORD) to a relationship code for the SJ01 record.
        /// </summary>
        /// <param name="driverRelationshipCode">The ACORD relationship code from the Driver node.</param>
        /// <param name="firstNamedInsured">Specifies whether the insured is the FNI or not (from the InsuredOrPrincipal node).</param>
        /// <param name="licenseStatusCode">The license status code from the Driver node.</param>
        /// <param name="driverTypeCode">The driver type code from the Driver node.</param>
        /// <param name="coApplicant">Specifies whether the insured is the CN or not (from the InsuredOrPrincipal node).</param>
        /// <returns>The code to use in the SJ01 record.</returns>
        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1305:FieldNamesMustNotUseHungarianNotation", Justification = "coApplicant is ok")]
        public static string GetRelationshipType(this string driverRelationshipCode, bool firstNamedInsured, string licenseStatusCode, string driverTypeCode, bool coApplicant)
        {
            if (driverTypeCode != null && driverTypeCode.Equals("E", StringComparison.CurrentCultureIgnoreCase))
            {
                return "E1";        // Excluded Driver
            }

            if (firstNamedInsured && driverRelationshipCode.Equals("IN", StringComparison.CurrentCultureIgnoreCase))
            {
                return "A1";
            }

            if (driverTypeCode != null && driverTypeCode.Equals("N", StringComparison.CurrentCultureIgnoreCase))
            {
                return "N1";        // Non-Driver or Non-Rated Driver
            }

            if (licenseStatusCode != null && licenseStatusCode.Equals("NOLIC", StringComparison.CurrentCultureIgnoreCase))
            {
                return "N1";        // Non-Driver or Non-Rated Driver
            }

            if (coApplicant && driverRelationshipCode.Equals("IN", StringComparison.CurrentCultureIgnoreCase))
            {
                return "B1";
            }

            return "L1";
        }
    }
}
