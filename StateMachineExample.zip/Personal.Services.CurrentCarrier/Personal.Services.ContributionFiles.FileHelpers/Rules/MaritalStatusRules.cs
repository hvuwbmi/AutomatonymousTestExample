﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="MaritalStatusRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class MaritalStatusRules
    {
        /// <summary>
        /// Retrieve the contribution file's marital status code based on the ACORD marital status code
        /// </summary>
        /// <param name="acordMaritalStatus">The marital status code as sent in ACORD</param>
        /// <returns>The marital status code to send to contribution</returns>
        public static string GetMaritalStatus(this string acordMaritalStatus)
        {
            switch (acordMaritalStatus)
            {
                case "D":       // Divorced
                    return "3";
                case "M":       // Married
                case "P":
                    return "2";
                case "W":       // Widowed
                    return "4";
                case "S":       // Single
                    return "1";
                default:
                    return "1";     // Contribution doesn't have an option for 'other'
            }
        }
    }
}
