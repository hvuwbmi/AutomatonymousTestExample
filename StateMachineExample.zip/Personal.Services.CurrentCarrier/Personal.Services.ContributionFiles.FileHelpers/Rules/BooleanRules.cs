﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="BooleanRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using System;

    public static class BooleanRules
    {
        public static string GetBoolean(this string acordBoolean)
        {
            if (string.Compare(acordBoolean, "0", StringComparison.CurrentCultureIgnoreCase) == 0)
            {
                return "N";
            }

            if (string.Compare(acordBoolean, "1", StringComparison.CurrentCultureIgnoreCase) == 0)
            {
                return "Y";
            }

            return "U";
        }
    }
}