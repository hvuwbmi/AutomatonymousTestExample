﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueFaultIndicatorClaimClaimAtFaultRule.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class ClueFaultIndicatorClaimClaimAtFaultRule
    {
        public static string GetClueFaultIndicatorCode(bool claimAtFault)
        {
            switch (claimAtFault)
            {
                case true:
                    return "A";
                case false:
                    return "N";
                default:
                    return "U";
            }
        }
    }
}