﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueClaimTypeClaimTypeRule.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    public static class ClueClaimTypeClaimTypeRule
    {
        public static string GetClueClaimTypeCode(string claimTypeCode, string reserveCauseOfLoss)
        {
            switch (claimTypeCode.ToUpper())
            {
                case "CSL":
                case "CSLENO":
                case "CSLNNO":
                case "BI":
                case "BIENO":
                case "BINNO":
                case "BIMGP":
                    return "BI";
                case"COLL":
                case"COLLENO":
                case"COLLNNO":
                case"ALCCOLL":
                case"CDRCOLL":
                    return "CO";
                case "OTC":
                case "OTCENO":
                case "OTCNNO":
                    return reserveCauseOfLoss.Equals("03") ? "GL" : "CP";
                case"ALCOTC":
                case"CDROTC":
                    return "CP";
                case "MP":
                case "MPENO":
                case "MPNNO":
                    return "MP";
                case "PD":
                case "APD":
                case "PPI":
                case "PDENO":
                case "PDNNO":
                    return "PD";
                case "PIPMED":
                case "PIPMEDENO":
                case "PIPMEDNNO":
                case "PIPWKLOSS":
                case "PIPWKLOSSENO":
                case "PIPWKLOSSNNO":
                case "PIPALLOTHER":
                case "PIPALLOTHERENO":
                case "PIPALLOTHERNNO":
                    return "PI";
                case "TRNSEXP":
                    return "RR";
                case "TLN":
                    return "TL";
                case "UMCSL":
                case "UMCSLNNO":
                case "UMSP":
                case "UMSPNNO":
                case "UMPD":
                case "UMPDNNO":
                    return "UM";
                case "UNDMCSL":
                case "UNDMCSLNNO":
                case "UNDMSP":
                case "UNDMSPNNO":
                    return "UN";
                default: return "OT";
            }
        }
    }
}