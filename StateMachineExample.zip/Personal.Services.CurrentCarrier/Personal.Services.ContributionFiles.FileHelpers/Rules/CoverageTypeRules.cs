﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CoverageTypeRules.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using Models;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;

    public static class CoverageTypeRules
    {
        public enum CoverageLimitType
        {
            Individual,
            Occurrence,
            CSL
        }

        /// <summary>
        /// Retrieve the Coverage Type value for Current Carrier given the Coverage Code value from Acord.
        /// </summary>
        /// <param name="coverageCode">Defines the Acord coverage code</param>
        /// <param name="limitAppliesToCode">Defines what this particular limit applies to (used for BI/PD currently)</param>
        /// <returns>The CurrentCarrier coverage code based on the Acord coverage code</returns>
        public static string GetCoverageType(this string coverageCode, string limitAppliesToCode)
        {
            switch (coverageCode)
            {
                case Constants.Acord.CoverageCode.BodilyInjury:
                    if (limitAppliesToCode == "CSL")
                    {
                        return Constants.CurrentCarrier.CoverageCode.CombinedSingleLimit;
                    }

                    return Constants.CurrentCarrier.CoverageCode.BodilyInjury;
                case Constants.Acord.CoverageCode.BroadenedCollision:
                case Constants.Acord.CoverageCode.Collision:
                case "LCOLL":   // Limited Collision -- TODO: Needed?
                    return Constants.CurrentCarrier.CoverageCode.Collision;
                case Constants.Acord.CoverageCode.Comprehensive:
                    return Constants.CurrentCarrier.CoverageCode.Comprehensive;
                case Constants.Acord.CoverageCode.CombinedSingleLimit:
                    return Constants.CurrentCarrier.CoverageCode.CombinedSingleLimit;
                case Constants.Acord.CoverageCode.MedicalPayments:
                    return Constants.CurrentCarrier.CoverageCode.MedicalPayments;
                case Constants.Acord.CoverageCode.UninsuredMotorist:
                case "UMISG":   // Uninsured Motorist Bodily Injury Single Limit -- TODO: Needed?
                    return Constants.CurrentCarrier.CoverageCode.UninsuredMotoristBodilyInjury;
                case "UMPD":    // Uninsured Motorist Property Damage
                    return Constants.CurrentCarrier.CoverageCode.UninsuredMotoristPropertyDamage;
                case Constants.Acord.CoverageCode.AutoLiability:
                case Constants.Acord.CoverageCode.CustomizedEquipment:
                case Constants.Acord.CoverageCode.AutoLoanComprehensive:
                case Constants.Acord.CoverageCode.AutoLoanCollision:
                case Constants.Acord.CoverageCode.NewCarReplacementAndGapCoverage:
                    return Constants.CurrentCarrier.CoverageCode.Other;
                case Constants.Acord.CoverageCode.EmergencyRoadsideAssistance:
                case "TL":      // Towing and Labor -- TODO: Needed?
                    return Constants.CurrentCarrier.CoverageCode.TowingAndLabor;
                case Constants.Acord.CoverageCode.PropertyDamage:
                case Constants.Acord.CoverageCode.LimitedPropertyDamageLiability:
                case Constants.Acord.CoverageCode.PropertyProtectionInsurance:
                    return Constants.CurrentCarrier.CoverageCode.PropertyDamage;
                case Constants.Acord.CoverageCode.PersonalInjuryProtection:
                case Constants.Acord.CoverageCode.WageLossBenefit:
                    return Constants.CurrentCarrier.CoverageCode.PersonalInjuryProtection;
                case Constants.Acord.CoverageCode.TransportationExpense:
                case "RREIM":   // Rental Reimbursement -- TODO: Needed?
                    return Constants.CurrentCarrier.CoverageCode.RentalReimbursement;
                case "UNDSG":   // Underinsured Motorist Bodily Injury Single Limit -- TODO: Needed?
                case Constants.Acord.CoverageCode.UnderinsuredMotorist:
                    return Constants.CurrentCarrier.CoverageCode.UnderinsuredMotoristBodilyInjury;
                case Constants.Acord.CoverageCode.UninsuredMotoristCSL:
                    return Constants.CurrentCarrier.CoverageCode.UninsuredMotoristCSL;
                case Constants.Acord.CoverageCode.UnderinsuredMotoristCSL:
                    return Constants.CurrentCarrier.CoverageCode.UnderinsuredMotoristCSL;
                case "UNDPD":   // Underinsured Motorist Property Damage -- TODO: Needed?
                    return Constants.CurrentCarrier.CoverageCode.UnderinsuredMotoristPropertyDamage;
                case Constants.Acord.CoverageCode.FinancialResponsibilityFiling:
                case Constants.Acord.CoverageCode.MichiganCatastrophicClaimsAssociation:
                    return null;
                
                default:
                    // The coverage found was unexpected.
                    return null;

                    // TODO: ME = Medical Expenses
                    // TODO: SV = Stated Value
                    // TODO: UMBR = Umbrella
                    // TODO: UMUB = Uninsured and Underinsured Combined Motorists Bodily Injury
                    // TODO: UMUP = Uninsured and Underinsured Combined Motorists Property Damage
                    // TODO: US = Uninsured and Underinsured Combined Motorists CSL
            }
        }

        /// <summary>
        /// Retrieve the value of the coverage limit type provided the limit, the coverage type, and the limit type.
        /// </summary>
        /// <param name="coverage"></param>
        /// <param name="coverageType"></param>
        /// <param name="limitType"></param>
        /// <returns></returns>
        public static int GetCoverageLimit(this Coverage coverage, string coverageType, CoverageLimitType limitType)
        {
            switch (coverageType)
            {
                case "BI":
                    foreach (var limit in coverage.Limit)
                    {
                        if (limit.LimitAppliesToCd == "BIEachPers" && limitType == CoverageLimitType.Individual)
                        {
                            return limit.GetLimitAmount();
                        }

                        if (limit.LimitAppliesToCd == "PerAcc" && limitType == CoverageLimitType.Occurrence)
                        {
                            return limit.GetLimitAmount();
                        }
                    }

                    break;
                case "NB":
                case "UB":
                case "UMUB":
                case "UMUP":
                    foreach (var limit in coverage.Limit)
                    {
                        if (limit.LimitAppliesToCd == "PerPerson" && limitType == CoverageLimitType.Individual)
                        {
                            return limit.GetLimitAmount();
                        }

                        if (limit.LimitAppliesToCd == "PerAcc" && limitType == CoverageLimitType.Occurrence)
                        {
                            return limit.GetLimitAmount();
                        }
                    }

                    break;
                case "CO":
                case "CP":
                    // Collision wants nothing assigned
                    // Comprehensive wants nothing assigned.
                    break;
                case "CS":
                    foreach (var limit in coverage.Limit)
                    {
                        if (limit.LimitAppliesToCd == "CSL" && limitType == CoverageLimitType.CSL)
                        {
                            return limit.GetLimitAmount();
                        }

                        if (limit.LimitAppliesToCd == "PerAcc" && limitType == CoverageLimitType.CSL)
                        {
                            return limit.GetLimitAmount();
                        }
                    }

                    break;
                case "PD":
                    // This is working around bug #122352, PD coverages from the UI are always marked CSL. They
                    // should be marked PerAcc. We'll treat them both the same for now.
                    if (coverage.Limit != null)
                    {
                        foreach (var limit in coverage.Limit)
                        {
                            if (limit.LimitAppliesToCd == "PerAcc" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }

                            if (limit.LimitAppliesToCd == "EachClaim" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }

                            if (limit.LimitAppliesToCd == "CSL" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }
                        }
                    }

                    break;
                case "MP":
                    if (coverage.Limit != null)
                    {
                        foreach (var limit in coverage.Limit)
                        {
                            if (limit.LimitAppliesToCd == "PerPerson" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }
                        }
                    }

                    break;
                case "ME":
                case "NP":
                case "OT":
                case "PI":
                case "SV":
                case "UMBR":
                case "UP":
                    if (coverage.Limit != null)
                    {
                        foreach (var limit in coverage.Limit)
                        {
                            if (limit.LimitAppliesToCd == "PerAcc" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }

                            if (limit.LimitAppliesToCd == "EachClaim" && limitType == CoverageLimitType.Occurrence)
                            {
                                return limit.GetLimitAmount();
                            }

                            if (limit.LimitAppliesToCd == "CSL" && limitType == CoverageLimitType.CSL)
                            {
                                return limit.GetLimitAmount();
                            }
                        }
                    }

                    break;
                case "TL":
                    foreach (var limit in coverage.Limit)
                    {
                        if (limitType == CoverageLimitType.Occurrence)
                        {
                            return limit.GetLimitAmount();
                        }
                    }

                    break;
                case "RR":
                    foreach (var limit in coverage.Limit)
                    {
                        if (limit.LimitAppliesToCd == "PerDay" && limitType == CoverageLimitType.Individual)
                        {
                            return limit.GetLimitAmount();
                        }

                        if (limit.LimitAppliesToCd == "EachClaim" && limitType == CoverageLimitType.Occurrence)
                        {
                            return limit.GetLimitAmount();
                        }
                    }

                    break;
                case "UM":
                case "UN":
                case "US":
                    foreach (var limit in coverage.Limit)
                    {
                        if ((limit.LimitAppliesToCd == "PerAcc" || limit.LimitAppliesToCd == "CSL") && limitType == CoverageLimitType.CSL)
                        {
                            return limit.GetLimitAmount();
                        }
                        //// UM only wants CSL assigned.
                    }

                    break;
            }

            return 0;
        }

        public static int GetCoverageDeductible(this Coverage coverage, string coverageType)
        {
            switch (coverageType)
            {
                case "CO":
                case "CP":
                    int retval = 0;
                    if (coverage.Deductible != null && coverage.Deductible[0].FormatCurrencyAmt != null && coverage.Deductible[0].FormatCurrencyAmt[0].Amt != null)
                    {
                        if (int.TryParse(coverage.Deductible[0].FormatCurrencyAmt[0].Amt, out retval))
                        {
                            return retval;
                        }
                    }

                    return 0;
            }

            return 0;
        }

        internal static int GetLimitAmount(this CoverageLimit limit)
        {
            int retval = 0;

            if (limit.FormatCurrencyAmt != null && limit.FormatCurrencyAmt[0] != null && !string.IsNullOrEmpty(limit.FormatCurrencyAmt[0].Amt))
            {
                if (int.TryParse(limit.FormatCurrencyAmt[0].Amt, out retval))
                {
                    return retval;
                }

                return 0;
            }

            if (int.TryParse(limit.FormatInteger, out retval))
            {
                return retval;
            }

            return 0;
        }
    }
}