﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueClaimDispositionClaimStatusCodeRule.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Rules
{
    using System.ComponentModel;

    public static class ClueClaimDispositionClaimStatusCodeRule
    {
        public static string GetClueClaimDispositionCode(string claimStatusCode)
        {
            switch (claimStatusCode.ToUpper())
            {
                case "O":
                    return "O";
                case "C":
                    return "C";
                case "E":
                case "N":
                    return "W";
                case "S":
                    return "S";
                default:
                    throw new InvalidEnumArgumentException($"{claimStatusCode} is not Valid for lookup.");
            }
        }
    }
}