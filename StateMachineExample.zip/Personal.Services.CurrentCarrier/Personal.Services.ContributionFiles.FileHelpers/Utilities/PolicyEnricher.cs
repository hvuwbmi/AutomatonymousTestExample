﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyEnricher.cs" company="West Bend">
//    Copyright (c) 2020 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Utilities
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using static Personal.Services.ContributionFiles.FileHelpers.FileMappers.Constants;

    public class PolicyEnricher : IPolicyEnricher
    {
        private PolicyRs policyResponse;

        public PolicyEnricher(PolicyRs policyResponse)
        {
            if (policyResponse == null)
            {
                throw new ArgumentNullException(nameof(policyResponse));
            }

            this.PolicyResponse = policyResponse;
        }

        public PolicyRs PolicyResponse { get => this.policyResponse; set => this.policyResponse = value; }
        
        public virtual void Enrich()
        {
            this.EnrichPolicy();
            this.EnrichVehicles();
            this.EnrichDrivers();
        }

        private void EnrichPolicy()
        {
            // not sure why we wouldn't always use the transaction effective date, but retaining current logic moved from PolicyRs
            string effectiveDate = this.policyResponse.Policy[0].ContractTerm[0].EffectiveDt;
            if (this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Endorsement
                || this.policyResponse.BusinessPurposeTypeCd == "XLC"
                || this.policyResponse.BusinessPurposeTypeCd == "REI"
                || this.policyResponse.BusinessPurposeTypeCd == "REW"
                || this.policyResponse.BusinessPurposeTypeCd == "RIX"
                || this.policyResponse.BusinessPurposeTypeCd == "RWL")
            {
                effectiveDate = this.policyResponse.TransactionEffectiveDt;
            }

            this.policyResponse.TransactionEffectiveDate = DateTime.Parse(effectiveDate);
        }

        private void EnrichVehicles()
        {
            if (this.policyResponse.Policy?[0]?.PersAutoLineBusiness?[0]?.Vehicle == null)
            {
                // no vehicles
                return;
            }

            IList<PolicyRsPolicyPersAutoLineBusinessVehicle> risksToKeep = this.GetRisksToKeep(this.policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle);

            // remove deleted risks
            if (risksToKeep.Count != this.policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle.Length)
            {
                this.policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle = risksToKeep.ToArray();
            }

            // set modinfo on vehicles for endorsements etc
            if (this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Endorsement
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Rewrite
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Reissue
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Renewal)
            {
                if (this.policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle != null)
                {
                    foreach (var vehicle in this.policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle)
                    {
                        var vehicleActionCd = this.policyResponse.ModInfo?.FirstOrDefault(m => m.IdRef == vehicle.id)?.ActionCd;
                        vehicle.ModInfoActionCd = vehicleActionCd;

                        this.EnrichVehicleAdditionalInterest(vehicle);
                        this.EnrichVehicleCoverage(vehicle);
                    }
                }
            }
        }

        private void EnrichDrivers()
        {
            if (this.policyResponse.Policy?[0]?.PersAutoLineBusiness?[0]?.Driver == null)
            {
                // no drivers
                return;
            }

            IList<PolicyRsPolicyPersAutoLineBusinessDriver> risksToKeep = this.GetRisksToKeep(this.policyResponse.Policy[0].PersAutoLineBusiness[0].Driver);

            // remove deleted risks
            if (risksToKeep.Count != this.policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length)
            {
                this.policyResponse.Policy[0].PersAutoLineBusiness[0].Driver = risksToKeep.ToArray();
            }

            // set modinfo on drivers for endorsements, etc
            if (this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Endorsement
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Reissue
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Rewrite
                || this.policyResponse.BusinessPurposeTypeCd == BusinessPurposeTypeCode.Renewal)
            {
                if (this.policyResponse.Policy[0].PersAutoLineBusiness[0].Driver != null)
                {
                    foreach (var driver in this.policyResponse.Policy[0].PersAutoLineBusiness[0].Driver)
                    {
                        var driverActionCd = this.policyResponse.ModInfo?.FirstOrDefault(m => m.IdRef == driver.id)?.ActionCd;
                        driver.ModInfoActionCd = driverActionCd;
                    }
                }
            }
        }

        private void EnrichVehicleAdditionalInterest(PolicyRsPolicyPersAutoLineBusinessVehicle vehicle)
        {
            if (vehicle.AdditionalInterest != null)
            {
                foreach (var additionalInterest in vehicle.AdditionalInterest)
                {
                    var additionalInterestActionCd = this.policyResponse.ModInfo?.FirstOrDefault(m => m.IdRef == additionalInterest.id)?.ActionCd;
                    additionalInterest.ModInfoActionCd = additionalInterestActionCd;
                }
            }
        }

        private void EnrichVehicleCoverage(PolicyRsPolicyPersAutoLineBusinessVehicle vehicle)
        {
            if (vehicle.Coverage != null)
            {
                foreach (var coverage in vehicle.Coverage)
                {
                    var coverageActionCd = this.policyResponse.ModInfo?.FirstOrDefault(m => m.IdRef == coverage.id)?.ActionCd;
                    coverage.ModInfoActionCd = coverageActionCd;
                }
            }
        }

        private IList<T> GetRisksToKeep<T>(T[] risks) where T : IRisk
        {
            var risksToKeep = new List<T>();
            if (risks == null)
            {
                // no risks on the policy
                return risksToKeep;
            }

            // every risk that has a risk expiration date
            foreach (T risk in risks)
            {
                WBRiskTerm riskTerm = risk?.RiskExt?.WBRiskTerm;
                if (riskTerm == null || string.IsNullOrEmpty(riskTerm.WBRiskExpirationDt))
                {
                    // no risk experation date - keep it
                    risksToKeep.Add(risk);
                    continue;
                }

                // if risk is deleted, and it wasn't deleted this term, remove it from the model
                if (!this.IsDeleted(riskTerm) || this.IsDeletedThisTransaction(riskTerm, risk.Id))
                {
                    // risk is not deleted, or not deleted this term based on mod info
                    risksToKeep.Add(risk);
                }
            }

            return risksToKeep;
        }

        private bool IsDeleted(WBRiskTerm riskTerm)
        {
            DateTime riskExpirationDate = DateTime.Parse(riskTerm.WBRiskExpirationDt);
            return riskExpirationDate <= this.policyResponse.TransactionEffectiveDate;
        }

        private bool IsDeletedThisTransaction(WBRiskTerm riskTerm, string id)
        {
            // transactions such as cancel do not contain a modinfo for every risk
            if (this.policyResponse.BusinessPurposeTypeCd != BusinessPurposeTypeCode.Endorsement)
            {
                DateTime riskExpirationDate = DateTime.Parse(riskTerm.WBRiskExpirationDt);
                return riskExpirationDate == this.policyResponse.TransactionEffectiveDate;
            }

            // multiple endorsements allowed on the same day - make sure the risk was deleted on this transaction
            return this.policyResponse.ModInfo?.FirstOrDefault(
                m => 
                string.Equals(m.IdRef, id, StringComparison.InvariantCultureIgnoreCase)
                && string.Equals(m.ActionCd, ModInfo.Deleted, StringComparison.InvariantCultureIgnoreCase)) != null;
        }
    }
}