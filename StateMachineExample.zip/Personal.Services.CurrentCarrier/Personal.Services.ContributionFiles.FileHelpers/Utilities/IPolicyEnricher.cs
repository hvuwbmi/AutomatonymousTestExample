﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IPolicyEnricher.cs" company="West Bend">
//    Copyright (c) 2020 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Utilities
{
    public interface IPolicyEnricher
    {
        void Enrich();
    }
}