﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyEnricherForNonRenewal.cs" company="West Bend">
//    Copyright (c) 2020 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Utilities
{
    using System;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using WestBend.Core;

    public class PolicyEnricherForNonRenewal : PolicyEnricher
    {
        private ILogger logger;

        public PolicyEnricherForNonRenewal(PolicyRs policyResponse, ILogger logger) : base(policyResponse)
        {
            this.Logger = logger;
        }

        public ILogger Logger
        {
            get => this.logger ?? (new WestBend.Core.Service.CommonLogger());
            set => this.logger = value;
        }

        public override void Enrich()
        {
            base.Enrich();

            // Renewal reinforce
            this.EnrichPolicyForNonRenewal();
        }

        protected void EnrichPolicyForNonRenewal()
        {
            var previousEffectivedate = PolicyResponse.TransactionEffectiveDate;
            try
            {
                string effectiveDate = PolicyResponse.Policy?[0]?.ContractTerm?[0]?.ExpirationDt;
                PolicyResponse.TransactionEffectiveDate = DateTime.Parse(effectiveDate);
            }
            catch (Exception ex)
            {
                this.Logger.Log(Constants.Logging.CATEGORY, System.Diagnostics.TraceEventType.Critical, $"Non-Renewal set Effective Date failed, error message:  {ex.Data}");
                PolicyResponse.TransactionEffectiveDate = previousEffectivedate;
                return;
            }         
        }
    }
}
