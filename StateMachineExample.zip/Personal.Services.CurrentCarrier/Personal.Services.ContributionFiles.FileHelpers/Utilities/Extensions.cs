﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="Extensions.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Utilities
{
    using System;

    public static class Extensions
    {
        public static bool IsEmpty(this string str)
        {
            if (string.IsNullOrEmpty(str))
            {
                return true;
            }

            return false;
        }

        public static bool IsNotEmpty(this string str)
        {
            return !IsEmpty(str);
        }

        public static DateTime ToDateRequired(this string str)
        {
            return DateTime.Parse(str);
        }
    }
}