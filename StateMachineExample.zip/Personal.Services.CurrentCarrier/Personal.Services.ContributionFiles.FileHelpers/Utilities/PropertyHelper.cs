﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PropertyHelper.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Utilities
{
    using System;
    using System.Reflection;

    public static class PropertyHelper
    {
        /// <summary>
        ///     Allows the caller to set a property where the name of the property may not be known until run time.
        /// </summary>
        /// <param name="obj">The object that contains the property to be set.</param>
        /// <param name="propName">The name of the property to be assigned to.</param>
        /// <param name="propValue">The value to assign to the property.</param>
        public static void SetDynamicProperty(object obj, string propName, string propValue)
        {
            obj.GetType().InvokeMember(propName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.SetField, Type.DefaultBinder, obj, new object[] { propValue });
        }

        public static void SetDynamicProperty(object obj, string propName, int propValue)
        {
            obj.GetType().InvokeMember(propName, BindingFlags.Instance | BindingFlags.Public | BindingFlags.SetField, Type.DefaultBinder, obj, new object[] { propValue });
        }
    }
}