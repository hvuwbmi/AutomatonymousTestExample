﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="TokenRequest.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System.Diagnostics.CodeAnalysis;

    [SuppressMessage("StyleCop.CSharp.NamingRules", "SA1300:ElementMustBeginWithUpperCaseLetter", Justification = "JSON.")]
    public class TokenRequest
    {
        public string scheme { get; set; }

        public string data { get; set; }

        public string requestedBy { get; set; }

        public string application { get; set; }

        public string caller { get; set; }

        public string applicationContext { get; set; }
    }
}