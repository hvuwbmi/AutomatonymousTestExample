﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="LastRunDate.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;

    public class LastRunDate
    {
        public string PartitionKey { get; set; }

        public string RowKey { get; set; }

        public DateTime Timestamp { get; set; }

        public string RunDate { get; set; }
    }
}