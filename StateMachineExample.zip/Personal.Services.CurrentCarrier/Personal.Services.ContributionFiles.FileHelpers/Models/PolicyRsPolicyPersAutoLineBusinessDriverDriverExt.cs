﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessDriverDriverExt.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public partial class PolicyRsPolicyPersAutoLineBusinessDriverDriverExt : IRiskExt
    {
        WBRiskTerm IRiskExt.WBRiskTerm => this.WBRiskTerm?[0];
    }
}
