﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyProducer.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Linq;
    using FileMappers.CurrentCarrier;
    using Rules;

    public partial class PolicyRsPolicyProducer
    {
        public void Map(CurrentCarrierFIRStPolicyInfoFP01 file, bool setPhoneFromProducer)
        {
            // PMS file send agency name in First Name field for Auto and Last Name field for Property.
            file.AgentFirstName = this.Name;

            this.Addr?.FirstOrDefault(a => a.AddrTypeCd.Equals("MailingAddress", StringComparison.CurrentCultureIgnoreCase))
                ?.Map(file);

            if (setPhoneFromProducer)
            {
                var com = this.Communications?.FirstOrDefault(a => !string.IsNullOrEmpty(a.PhoneNumber));
                if (com != null)
                {
                    file.AgentPhoneNumber = com.PhoneNumber.GetPhone();
                    file.AgentAreaCode = com.PhoneNumber.GetAreaCode();
                }
            }
            else
            {
                file.AgentPhoneNumber = "9264244";
                file.AgentAreaCode = "888";
            }
        }
    }
}