﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="Coverage.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using FileMappers.CurrentCarrier;
    using Rules;
    using Utilities;

    public partial class Coverage
    {
        public string ModInfoActionCd { get; set; }

        internal void Map(CurrentCarrierPropertyInfoPR01 file, int index, bool skipLimit = false)
        {
            if (index < 1 || index > 15)
            {
                throw new ArgumentOutOfRangeException("index", $"index must be in the range 1..15 value {index}");
            }

            string coverageType = CoverageTypeRules.GetCoverageType(this.CoverageCd, this.GetLimitAppliesToCode());
            if (coverageType != null)
            {
                PropertyHelper.SetDynamicProperty(file, "CoverageType" + index, coverageType);

                if (this.Limit != null && !skipLimit)
                {
                    PropertyHelper.SetDynamicProperty(
                        file,
                        "IndividualLimit" + index,
                        this.GetCoverageLimit(coverageType, CoverageTypeRules.CoverageLimitType.Individual));

                    PropertyHelper.SetDynamicProperty(
                        file,
                        "OccurrenceLimit" + index,
                        this.GetCoverageLimit(coverageType, CoverageTypeRules.CoverageLimitType.Occurrence));

                    PropertyHelper.SetDynamicProperty(
                        file,
                        "CslLimit" + index,
                        this.GetCoverageLimit(coverageType, CoverageTypeRules.CoverageLimitType.CSL));
                }
            }
        }

        internal void Map(CurrentCarrierPropertyInfoPR01 file, int index, string coverageCode, int individualLimit, int occurrenceLimit, int cslLimit, int deductibleAmount, bool skipLimit = false)
        {
            if (index < 1 || index > 15)
            {
                throw new ArgumentOutOfRangeException("index", $"index must be in the range 1..15 value {index}");
            }

            PropertyHelper.SetDynamicProperty(file, "CoverageType" + index, coverageCode);
            PropertyHelper.SetDynamicProperty(file, "IndividualLimit" + index, individualLimit);
            PropertyHelper.SetDynamicProperty(file, "OccurrenceLimit" + index, occurrenceLimit);
            PropertyHelper.SetDynamicProperty(file, "CslLimit" + index, cslLimit);
            PropertyHelper.SetDynamicProperty(file, "DeductibleAmount" + index, deductibleAmount);
        }

        internal string GetLimitAppliesToCode()
        {
            if (this.Limit != null && this.Limit.Length > 0)
            {
                return this.Limit[0]?.LimitAppliesToCd;
            }

            return null;
        }
    }
}