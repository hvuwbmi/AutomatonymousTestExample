﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyLocation.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyLocation
    {
        internal void Map(CurrentCarrierPropertyInfoPR01 file)
        {
            file.LocationAddressState = this.Addr[0].StateProvCd;
        }
    }
}