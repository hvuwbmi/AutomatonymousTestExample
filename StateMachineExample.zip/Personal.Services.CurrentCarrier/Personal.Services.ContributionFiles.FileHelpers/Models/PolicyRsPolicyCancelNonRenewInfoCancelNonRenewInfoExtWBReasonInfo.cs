﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyCancelNonRenewInfoCancelNonRenewInfoExtWBReasonInfo.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyCancelNonRenewInfoCancelNonRenewInfoExtWBReasonInfo
    {
        public void Map(CurrentCarrierVehicleVR01 file, string requestorCd)
        {
            if ("NP".Equals(this.WBCancelReasonCd))
            {
                file.VehicleCancellationReason = "NONP";
            }
            else if ("C".Equals(requestorCd))
            {
                file.VehicleCancellationReason = "COMP";
            }
            else if ("I".Equals(requestorCd))
            {
                file.VehicleCancellationReason = "CUST";
            }
        }

        public void Map(CurrentCarrierMiscellaneousInfoMR01 file, string requestorCd)
        {
            if ("NP".Equals(this.WBCancelReasonCd))
            {
                file.CancellationReasonCode = "NONP";
            }
            else if ("C".Equals(requestorCd))
            {
                file.CancellationReasonCode = "COMP";
            }
            else if ("I".Equals(requestorCd))
            {
                file.CancellationReasonCode = "CUST";
            }
        }
    }
}