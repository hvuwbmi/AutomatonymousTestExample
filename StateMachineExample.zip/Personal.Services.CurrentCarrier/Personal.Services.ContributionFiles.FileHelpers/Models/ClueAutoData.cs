﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoData.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    public class ClueAutoData
    {
        public string Container { get; set; }

        public string Folder { get; set; }

        public string Name { get; set; }

        public string CreateDate { get; set; }

        public string ClaimNumber { get; set; }

        public string PolicyNumber { get; set; }

        public string ClaimType { get; set; }
    }
}