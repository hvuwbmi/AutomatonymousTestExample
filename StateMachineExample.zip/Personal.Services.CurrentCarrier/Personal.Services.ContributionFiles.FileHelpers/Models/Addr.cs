﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Addr.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto;
    using Rules;

    public partial class Addr
    {
        public void Map(CurrentCarrierPolicyInfoNP01 file)
        {
            // For working with addresses, we should prefer the AddrExt node. If that's not there (rarely), fall back to Addr1.
            if (IsAddressStandardized(this.AddrExt))
            {
                file.PolicyholderAddressNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber;
                file.PolicyholderAddressStreetName = BuildStreetName(this.AddrExt[0]?.WBAddressStandardization[0]);
                file.PolicyholderAddressAptNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber;
            }
            else
            {
                // When we fall back to Addr1, we're not splitting anything.
                file.PolicyholderAddressStreetName = this.Addr1;
            }

            file.PolicyholderAddressCity = this.City;
            file.PolicyholderAddressState = this.StateProvCd;
            file.PolicyholderAddressZip = this.PostalCode.GetZip5();
            file.PolicyholderAddressZip4 = string.Empty; // rules says to send nothing
        }

        public void Map(CurrentCarrierPropertyInfoPR01 file, PolicyRsPolicyInsuredOrPrincipal insured)
        {
            Addr mailingAddress = null;
            if (insured != null)
            {
                mailingAddress = insured.Addr?.FirstOrDefault(a => a.AddrTypeCd.Equals("MailingAddress", StringComparison.CurrentCultureIgnoreCase));
            }

            // Address used to be optional (if the garaging address was different than mailing address). ALIRtS now
            // requires the address to be mapped.

            // By default its set to Addr1, we're not splitting anything.
            file.LocationAddressStreetName = this.Addr1;
            file.LocationAddressCity = this.City;
            file.LocationAddressState = this.StateProvCd;
            file.LocationAddressZip = this.PostalCode.GetZip5();

            // For working with addresses, we should prefer the AddrExt node. If that's not there (rarely), fall back to Addr1.
            if (IsAddressStandardized(this.AddrExt))
            {
                file.LocationAddressNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber;
                file.LocationAddressStreetName = BuildStreetName(this.AddrExt[0]?.WBAddressStandardization[0]);
                file.LocationAddressAptNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber;
            }
        }

        public Task MapPolicyHolder1(CLUEAutoLossTransaction file)
        {
            // For working with addresses, we should prefer the AddrExt node. If that's not there (rarely), fall back to Addr1.
            if (IsAddressStandardized(this.AddrExt))
            {
                file.PolicyHolder1AddressHouseNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber?.ToUpper();
                file.PolicyHolder1AddressStreetName = BuildStreetName(this.AddrExt[0]?.WBAddressStandardization[0])?.ToUpper();
                file.PolicyHolder1AddressApartmentNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber?.ToUpper();
            }
            else
            {
                // When we fall back to Addr1, we're not splitting anything.
                file.PolicyHolder1AddressStreetName = this.Addr1?.ToUpper();
            }

            file.PolicyHolder1AddressCity = this.City?.ToUpper();
            file.PolicyHolder1AddressState = this.StateProvCd?.ToUpper();
            file.PolicyHolder1AddressZipCode = this.PostalCode.GetZip5()?.ToUpper();
            file.PolicyHolder1AddressZipCodePlus4 = this.PostalCode.GetZip4()?.ToUpper();

            return Task.CompletedTask;
        }

        public void Map(CurrentCarrierFIRStPolicyInfoFP01 file)
        {
            // For working with addresses, we should prefer the DetailAddr node. If that's not there (rarely), fall back to Addr1.
            if (IsAddressStandardized(this.AddrExt))
            {
                file.AgentAddressNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber;
                file.AgentAddressStreetName = BuildStreetName(this.AddrExt[0]?.WBAddressStandardization[0]);
                file.AgentAddressAptNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber;
            }
            else
            {
                // When we fall back to Addr1, we're not splitting anything.
                file.AgentAddressStreetName = this.Addr1;
            }

            file.AgentAddressCity = this.City;
            file.AgentAddressState = this.StateProvCd;
            file.AgentAddressZip = this.PostalCode.GetZip5();
            file.AgentAddressZip4 = this.PostalCode.GetZip4();

            // TODO: Steve questions - how do we figure out which phone number to use here? Agency # or Customer Care #?
        }

        public void Map(CurrentCarrierFIRSTPropertyInfoFR01 file)
        {
            if (IsAddressStandardized(this.AddrExt))
            {
                file.FinanceCompany1AddressNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeStreetNumber;
                file.FinanceCompany1AddressStreetName = BuildStreetName(this.AddrExt[0]?.WBAddressStandardization[0]);
                file.FinanceCompany1AddressAptNumber = this.AddrExt[0]?.WBAddressStandardization[0]?.WBAddrStandardizeUnitNumber;
            }
            else
            {
                file.FinanceCompany1AddressStreetName = this.Addr1;
            }

            file.FinanceCompany1AddressCity = this.City;
            file.FinanceCompany1AddressState = this.StateProvCd;
            file.FinanceCompany1AddressZipCode = this.PostalCode.GetZip5();
            file.FinanceCompany1AddressZipCode4 = this.PostalCode.GetZip4();
        }

        /// <summary>
        /// Combine address standardization street name parts into a string for use in the contribution
        /// file.
        /// </summary>
        /// <param name="addressStandardization">Contains the parts of the street to combine</param>
        /// <returns>the street name suitable for contribution</returns>
        internal static string BuildStreetName(AddrAddrExtWBAddressStandardization addressStandardization)
        {
            if (addressStandardization == null)
            {
                return string.Empty;
            }

            string streetName = addressStandardization.WBAddrStandardizeLeadingDirectional
                + " " + addressStandardization.WBAddrStandardizeStreetName
                + " " + addressStandardization.WBAddrStandardizeStreetTypeCd;
            return streetName.Trim();
        }

        /// <summary>
        /// Determine whether the address has been standardized and not overridden.
        /// </summary>
        /// <param name="addrExtArray">The AddrExt node from the address.</param>
        /// <returns>true if the address is standardized and not overridden; false otherwise</returns>
        internal static bool IsAddressStandardized(AddrAddrExt[] addrExtArray)
        {
            if (addrExtArray != null
                && addrExtArray.Length > 0
                && addrExtArray[0].WBAddressStandardization != null
                && addrExtArray[0].WBAddressStandardization[0].WBAddrStandardizeStatus != null
                && addrExtArray[0].WBAddressStandardization[0].WBAddrStandardizeStatus.Equals("Accepted", StringComparison.OrdinalIgnoreCase))
            {
                return true;
            }

            return false;
        }
    }
}