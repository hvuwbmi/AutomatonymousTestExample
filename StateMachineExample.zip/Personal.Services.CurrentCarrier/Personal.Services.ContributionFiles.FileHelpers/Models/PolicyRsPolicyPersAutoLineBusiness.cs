﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusiness.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Rules;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;

    public partial class PolicyRsPolicyPersAutoLineBusiness
    {
        public IEnumerable<ICurrentCarrierFile> GetCurrentCarrierPR01s(PolicyRs policyRs, PolicyRs previousTransactionPolicyRs, IPolicyStoreApi policyStore)
        {
            var currentCarriers = new List<ICurrentCarrierFile>();

            if (this.Vehicle != null)
            {
                foreach (var vehicle in this.Vehicle)
                {
                    if (vehicle.ModInfoActionCd == Constants.ModInfo.Deleted &&
                        (policyRs.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Reissue || policyRs.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Rewrite))
                    {
                        // Skip this vehicle
                        continue;
                    }

                    currentCarriers.Add(new CurrentCarrierPropertyInfoPR01().Map(policyRs, previousTransactionPolicyRs, vehicle));
                    currentCarriers.Add(new CurrentCarrierVehicleVR01().Map(policyRs, vehicle));

                    if (vehicle.AdditionalInterest != null)
                    {
                        var additionalInterests = vehicle.AdditionalInterest.Where(ai => ai.NatureInterestCd.IsValidInterestCode()).ToList();
                        if (additionalInterests.Any())
                        {
                            foreach (var additionalInterest in additionalInterests)
                            {
                                currentCarriers.Add(new CurrentCarrierFIRSTPropertyInfoFR01().Map(policyRs, vehicle, additionalInterest, policyStore));
                            }
                        }
                        else
                        {
                            currentCarriers.Add(new CurrentCarrierFIRSTPropertyInfoFR01().Map(policyRs, vehicle, policyStore));
                        }
                    }
                    else
                    {
                        currentCarriers.Add(new CurrentCarrierFIRSTPropertyInfoFR01().Map(policyRs, vehicle, policyStore));
                    }
                }
            }

            return currentCarriers;
        }

        public IEnumerable<ICurrentCarrierFile> GetCurrentCarrierPR01sForNonRenewal(PolicyRs policyRs, PolicyRs previousTransactionPolicyRs, IPolicyStoreApi policyStore)
        {
            var currentCarriers = new List<ICurrentCarrierFile>();

            if (this.Vehicle != null)
            {
                foreach (var vehicle in this.Vehicle)
                {
                    if (vehicle.ModInfoActionCd == Constants.ModInfo.Deleted &&
                        (policyRs.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Reissue || policyRs.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Rewrite))
                    {
                        // Skip this vehicle
                        continue;
                    }

                    currentCarriers.Add(new CurrentCarrierPropertyInfoPR01().Map(policyRs, previousTransactionPolicyRs, vehicle));
                    var currentCR01Carrier = new CurrentCarrierVehicleVR01().Map(policyRs, vehicle);
                    currentCR01Carrier.VehicleStatus = "C";
                    currentCR01Carrier.VehicleStatusDate = policyRs.TransactionEffectiveDate;
                    currentCR01Carrier.VehicleCancellationReason = "COMP";
                    currentCarriers.Add(currentCR01Carrier);

                    if (vehicle.AdditionalInterest != null)
                    {
                        var additionalInterests = vehicle.AdditionalInterest.Where(ai => ai.NatureInterestCd.IsValidInterestCode()).ToList();
                        if (additionalInterests.Any())
                        {
                            foreach (var additionalInterest in additionalInterests)
                            {
                                var newItem = new CurrentCarrierFIRSTPropertyInfoFR01();

                                // Only update to "RWO" if there is any extra party. Anomaly 183884 in VSTS.
                                newItem.NotificationActionCode = Constants.CurrentCarrier.NotificationActionCode.NonRenewal;
                                newItem.ChangeEffectiveDate = policyRs.TransactionEffectiveDate; 
                                newItem.NotificationActionDate = policyRs.TransactionEffectiveDate;
                                currentCarriers.Add(newItem.Map(policyRs, vehicle, additionalInterest, policyStore));
                            }
                        }
                        else
                        {
                            var newItem = new CurrentCarrierFIRSTPropertyInfoFR01();
                            if (newItem.NotificationActionCode == Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice)
                            {
                                newItem.NotificationActionDate = null;
                            }

                            currentCarriers.Add(newItem.Map(policyRs, vehicle, policyStore));
                        }
                    }
                    else
                    {
                        var newItem = new CurrentCarrierFIRSTPropertyInfoFR01();
                        if (newItem.NotificationActionCode == Constants.CurrentCarrier.NotificationActionCode.DoNotSendNotice)
                        {
                            newItem.NotificationActionDate = null;
                        }

                        currentCarriers.Add(newItem.Map(policyRs, vehicle, policyStore));
                    }
                }
            }

            return currentCarriers;
        }

         internal void Map(CurrentCarrierSubjectInfoSJ01 file, PolicyRsPolicyInsuredOrPrincipal principal, PolicyRsPolicyPersAutoLineBusinessDriver driver, Relationship relationship)
        {
            driver.Map(file, principal, relationship);
        }

        internal void Map(CurrentCarrierFIRSTPropertyInfoFR01 file, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle)
        {
            vehicle.Map(file);
        }

        internal void Map(CurrentCarrierFIRSTPropertyInfoFR01 file, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest)
        {
            vehicle.Map(file, additionalInterest);
        }
    }
}