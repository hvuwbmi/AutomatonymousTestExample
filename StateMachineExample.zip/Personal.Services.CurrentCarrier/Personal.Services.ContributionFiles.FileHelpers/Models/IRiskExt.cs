﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IRiskExt.cs" company="West Bend">
//    Copyright (c) 2020 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    public interface IRiskExt
    {
        WBRiskTerm WBRiskTerm { get; }
    }
}