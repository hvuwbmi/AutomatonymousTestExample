﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessDriverLicense.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using FileMappers.CLUEAuto;
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyPersAutoLineBusinessDriverLicense
    {
        public void Map(CurrentCarrierSubjectInfoSJ01 file)
        {
            file.DriversLicenseNumber = this.LicensePermitNumber;
            file.DriversLicenseState = this.StateProvCd;
        }

        public void MapPolicyHolder1(CLUEAutoLossTransaction clueAutoLossTransaction)
        {
            clueAutoLossTransaction.PolicyHolder1DLNumber = this.LicensePermitNumber;
            clueAutoLossTransaction.PolicyHolder1DLState = this.StateProvCd;
        }

        public void MapPolicyHolder2(CLUEAutoLossTransaction clueAutoLossTransaction)
        {
            clueAutoLossTransaction.PolicyHolder2DLNumber = this.LicensePermitNumber;
            clueAutoLossTransaction.PolicyHolder2DLState = this.StateProvCd;
        }
    }
}