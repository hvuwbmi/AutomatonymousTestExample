﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CombinedClueAutoAndPolicyData.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using Claims;

    public class CombinedClueAutoAndPolicyData
    {
        public GetFullClaimResponse GetFullClaimResponse { get; set; }

        public PolicyRs Policy { get; set; }
    }
}