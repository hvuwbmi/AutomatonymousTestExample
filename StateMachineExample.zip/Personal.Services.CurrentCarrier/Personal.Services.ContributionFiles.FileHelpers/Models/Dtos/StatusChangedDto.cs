﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StatusChangedDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using WestBend.Claims.ServiceContracts;

    public class StatusChangedDto : ClaimsDto, IClaimStatusChanged
    {
        public string CurrentStatus { get; set; }

        public string PriorStatus { get; set; }

        public StatusChangedDto AssignStateFromEvent(IClaimStatusChanged claimStatusChange)
        {
            base.AssignStateFromEvent(claimStatusChange);
            this.CurrentStatus = claimStatusChange.CurrentStatus;
            this.PriorStatus = claimStatusChange.PriorStatus;

            return this;
        }
    }
}