﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AtFaultDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using WestBend.Claims.ServiceContracts;

    public class AtFaultDto : ClaimsDto, IClaimAtFault
    {
        public string DriverFirstName { get; set; }

        public string DriverLastName { get; set; }

        public string DriverType { get; set; }

        public string DriverId { get; set; }

        public bool? IsAtFault { get; set; }

        public AtFaultDto AssignStateFromEvent(IClaimAtFault claimAtFault)
        {
            base.AssignStateFromEvent(claimAtFault);
            this.DriverFirstName = claimAtFault.DriverFirstName;
            this.DriverId = claimAtFault.DriverId;
            this.DriverLastName = claimAtFault.DriverLastName;
            this.DriverType = claimAtFault.DriverType;
            this.IsAtFault = claimAtFault.IsAtFault;

            return this;
        }
    }
}