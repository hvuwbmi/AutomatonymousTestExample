﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="OffsetOnsetDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using WestBend.Claims.ServiceContracts;

    public class OffsetOnsetDto : ClaimsDto, IOffsetOnset
    {
        public bool? DateOfLossChanged { get; set; }

        public bool? UnitsChanged { get; set; }

        public bool? PolicyVersionChanged { get; set; }

        public OffsetOnsetDto AssignEventToState(IOffsetOnset offsetOnset)
        {
            this.AssignStateFromEvent(offsetOnset);
            this.DateOfLossChanged = offsetOnset.DateOfLossChanged;
            this.PolicyVersionChanged = offsetOnset.PolicyVersionChanged;
            this.UnitsChanged = offsetOnset.UnitsChanged;

            return this;
        }
    }
}