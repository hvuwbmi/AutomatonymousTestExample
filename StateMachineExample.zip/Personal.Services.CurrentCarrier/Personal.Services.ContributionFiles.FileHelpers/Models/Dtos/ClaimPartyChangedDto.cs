﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimPartyChangedDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using System.Collections.Generic;
    using WestBend.Claims.ServiceContracts;

    public class ClaimPartyChangedDto : ClaimsDto, IClaimPartyChanged
    {
        public string PartyId { get; set; }

        public IList<string> PartyRoleInClaim { get; set; }

        public ClaimPartyChangedDto AssignStateFromEvent(IClaimPartyChanged claimPartyChanged)
        {
            base.AssignStateFromEvent(claimPartyChanged);
            this.PartyId = claimPartyChanged.PartyId;
            this.PartyRoleInClaim = claimPartyChanged.PartyRoleInClaim;

            return this;
        }
    }
}