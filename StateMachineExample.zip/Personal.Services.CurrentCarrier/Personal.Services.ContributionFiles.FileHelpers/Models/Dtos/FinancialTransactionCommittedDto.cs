﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FinancialTransactionCommittedDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using WestBend.Claims.ServiceContracts;

    public class FinancialTransactionCommittedDto : ClaimsDto, IFinancialTransactionCommitted
    {
        public string ObjectType { get; set; }

        public string ObjectSequenceNumber { get; set; }

        public string CoverageType { get; set; }

        public string CauseOfLoss { get; set; }

        public string ReserveCategory { get; set; }

        public decimal? Amount { get; set; }

        public decimal? OutstandingReserveAmount { get; set; }

        public string ReserveType { get; set; }

        public string TransactionType { get; set; }

        public string ClaimantId { get; set; }

        public FinancialTransactionCommittedDto AssignStateFromEvent(IFinancialTransactionCommitted financialTransactionCommitted)
        {
            base.AssignStateFromEvent(financialTransactionCommitted);
            this.Amount = financialTransactionCommitted.Amount;
            this.CauseOfLoss = financialTransactionCommitted.CauseOfLoss;
            this.ClaimantId = financialTransactionCommitted.ClaimantId;
            this.CoverageType = financialTransactionCommitted.CoverageType;
            this.ObjectSequenceNumber = financialTransactionCommitted.ObjectSequenceNumber;
            this.OutstandingReserveAmount = financialTransactionCommitted.OutstandingReserveAmount;
            this.ObjectType = financialTransactionCommitted.ObjectType;
            this.ReserveCategory = financialTransactionCommitted.ReserveCategory;
            this.ReserveType = financialTransactionCommitted.ReserveType;
            this.TransactionType = financialTransactionCommitted.TransactionType;

            return this;
        }
    }
}