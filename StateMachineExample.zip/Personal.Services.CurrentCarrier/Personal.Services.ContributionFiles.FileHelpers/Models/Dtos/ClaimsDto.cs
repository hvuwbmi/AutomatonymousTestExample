﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimsDto.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Dtos
{
    using System;
    using WestBend.Claims.ServiceContracts;

    public class ClaimsDto : IClaimEventBase
    {
        public string PolicyNumber { get; set; }

        public string PolicyVersion { get; set; }

        public string PolicyOffering { get; set; }

        public string Division { get; set; }

        public string ClaimNumber { get; set; }

        public string ClaimType { get; set; }

        public DateTime? DateOfLoss { get; set; }

        public string SourceSystemId { get; set; }

        public string AdditionalData { get; set; }

        public void AssignStateFromEvent(IClaimEventBase claimBase)
        {
            this.PolicyNumber = claimBase.PolicyNumber;
            this.PolicyVersion = claimBase.PolicyVersion;
            this.ClaimNumber = claimBase.ClaimNumber;
            this.ClaimType = claimBase.ClaimType;
            this.PolicyOffering = claimBase.PolicyOffering;
            this.DateOfLoss = claimBase.DateOfLoss;
            this.Division = claimBase.Division;
            this.SourceSystemId = claimBase.SourceSystemId;
            this.AdditionalData = DateTime.Now.ToString("yyyyMMddhhmmss");
        }
    }
}