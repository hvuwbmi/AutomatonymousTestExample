﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessVehicle.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System.Collections.Generic;
    using System.Linq;
    using FileMappers.CLUEAuto;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Rules;
    using Rules.Specification;

    public partial class PolicyRsPolicyPersAutoLineBusinessVehicle : IRisk
    {
        public string ModInfoActionCd { get; set; }

        public IRiskExt RiskExt => this.VehicleExt?[0];

        public string Id => this.id;

        public void Map(CurrentCarrierPropertyInfoPR01 file, Coverage[] lineOfBusinessCoverages, PolicyRs currentTransactionPolicyRs)
        {
            file.Vin = this.VehIdentificationNumber;
            file.VehicleModelYear = this.ModelYear;
            file.VehicleMake = this.Manufacturer;
            file.VehicleModel = this.Model;

            var isOTCoverage = new IsOTCoverage();
            var shouldSkip = new ShouldSkipCoverage();
            var isValidLOBCoverage = new IsValidLineOfBusinessCoverage();
            var isValidTransactionCoverage = new IsCoverageValidInTransaction();
            var isCoverageInEffect = new IsCoverageNotExpired();

            var coverages = new List<Coverage>();

            var lobCoverages = new List<Coverage>();

            if (lineOfBusinessCoverages != null)
            {
                lobCoverages = lineOfBusinessCoverages?.Where(c => c.CoverageCd != null && isValidLOBCoverage.IsSatisfiedBy(c.CoverageCd)).ToList();
            }

            if (lobCoverages != null)
            {
                coverages.AddRange(lobCoverages);
            }

            if (this.Coverage != null)
            {
                coverages.AddRange(this.Coverage.Where(a => a.CoverageCd != null &&
                    isValidTransactionCoverage.IsSatisfiedBy(a.ModInfoActionCd) &&
                    isCoverageInEffect.IsSatisfiedBy(currentTransactionPolicyRs, a) &&
                    !isOTCoverage.IsSatisfiedBy(a.CoverageCd) &&
                    !shouldSkip.IsSatisfiedBy(a.CoverageCd))?.ToList());
            }

            var coverageDict = this.CombineCoverageTypes(coverages);
            var reportedSoFar = 0;

            foreach (var val in coverageDict)
            {
                reportedSoFar++;
                coverages.First().Map(file, reportedSoFar, val.Key, val.Value.Individual, val.Value.Occurrence, val.Value.CSL, val.Value.DeductibleAmount);

                if (reportedSoFar == 15)
                {
                    break;
                }
            }

            if (reportedSoFar < 15)
            {
                coverages.Clear();

                if (this.Coverage != null)
                {
                    coverages = this.Coverage.Where(a => a.CoverageCd != null &&
                        isValidTransactionCoverage.IsSatisfiedBy(a.ModInfoActionCd) &&
                        isCoverageInEffect.IsSatisfiedBy(currentTransactionPolicyRs, a) &&
                        isOTCoverage.IsSatisfiedBy(a.CoverageCd) &&
                        !shouldSkip.IsSatisfiedBy(a.CoverageCd))?.ToList();
                }

                var otherCoverageDict = this.CombineCoverageTypes(coverages);

                var firstOT = otherCoverageDict.FirstOrDefault();

                coverages.FirstOrDefault()?.Map(file, reportedSoFar + 1, firstOT.Key, firstOT.Value.Individual, firstOT.Value.Occurrence, firstOT.Value.CSL, firstOT.Value.DeductibleAmount, coverages.Count > 1);
            }

            var hasFinComp = this.AdditionalInterest?.Any(a => a.NatureInterestCd.IsValidInterestCode());

            if (hasFinComp.HasValue && hasFinComp.Value == true)
            {
                var firstOne = this.AdditionalInterest.First(a => a.NatureInterestCd.IsValidInterestCode());

                file.FinanceCompanyType = firstOne.NatureInterestCd.GetFinanceCompanyCode();
            }

            file.LeasedVehicle = this.LeasedVehInd.GetBoolean();
        }

        internal void Map(CurrentCarrierFIRSTPropertyInfoFR01 file)
        {
            file.Vin = this.VehIdentificationNumber;

            var autoLiabilityCoverageCodes = new List<string>
            {
                Constants.Acord.CoverageCode.BodilyInjury,
                Constants.Acord.CoverageCode.CombinedSingleLimit,
                Constants.Acord.CoverageCode.PropertyDamage,
                Constants.Acord.CoverageCode.MedicalPayments,
                Constants.Acord.CoverageCode.UninsuredMotorist,
                Constants.Acord.CoverageCode.UninsuredMotoristCSL,
                Constants.Acord.CoverageCode.UnderinsuredMotorist,
                Constants.Acord.CoverageCode.UnderinsuredMotoristCSL,
            };

            // Coverages that we should ignore in the check -- fees that look like coverages.
            var ignoredCoverageCodes = new List<string>
            {
                Constants.Acord.CoverageCode.TheftPreventionAuthorityCharge,
            };

            var coverages = new List<Coverage>();

            if (this.Coverage != null)
            {
                coverages = this.Coverage.Where(a => a.CoverageCd != null && !ignoredCoverageCodes.Contains(a.CoverageCd))?.ToList();
            }

            file.AutoLiabilityOnlyCoverage = "Y";       // default to 'Y' for now, reset to 'N' if needed below.
            foreach (var cv in coverages)
            {
                if (!autoLiabilityCoverageCodes.Contains(cv.CoverageCd))
                {
                    file.AutoLiabilityOnlyCoverage = "N";
                }
            }
        }

        internal void Map(CurrentCarrierFIRSTPropertyInfoFR01 file, PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest)
        {
            this.Map(file);
            additionalInterest.Map(file);
        }

        internal void Map(CurrentCarrierVehicleVR01 file, string businessPurposeTypeCd, PolicyRsPolicyPersAutoLineBusiness persAutoLineBusiness)
        {
            this.Map(file, persAutoLineBusiness);
            if ((businessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Rewrite || businessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Reissue) && file.VehicleStatusDate == null)
            {
                file.VehicleStatusDate = file.ChangeEffectiveDate;
            }

            if (file.VehicleStatus == "C" || file.VehicleStatus == "R")
            {
                file.VehicleStatusDate = file.ChangeEffectiveDate;
            }

            if (file.VehicleStatus == "C" && string.IsNullOrEmpty(file.VehicleCancellationReason))
            {
                // TODO: Cancellation Reason must be mapped to the values in appendix 5 (page 142 of the specs PDF),
                file.VehicleCancellationReason = "OTHR";
            }
        }

        internal void Map(CurrentCarrierVehicleVR01 file, PolicyRsPolicyPersAutoLineBusiness persAutoLineBusiness)
        {
            file.VIN = this.VehIdentificationNumber;

            if (this.Registration != null)
            {
                this.Registration[0].Map(file);
            }

            if (this.VehicleExt != null)
            {
                this.VehicleExt[0].Map(file);
            }

            // look up the driver of this vehicle
            if (persAutoLineBusiness != null)
            {
                var driver = persAutoLineBusiness.Driver.FirstOrDefault(d => d.Id == this.RatedDriverRef);
                if (driver != null)
                {
                    file.InsuredSequenceNumber = driver.ItemIdInfo?[0]?.InsurerId;
                }
            }
        }

        internal void Map(CLUEAutoLossTransaction file)
        {
            file.InsuredVehicleModelYear = this.ModelYear;
            file.InsuredVehicleMakeAndModel = $"{this.Manufacturer?.ToUpper()} {this.Model?.ToUpper()}";
        }

        internal Dictionary<string, CoverageLimits> CombineCoverageTypes(List<Coverage> originalCoverages)
        {
            Dictionary<string, CoverageLimits> coverageDictionary = new Dictionary<string, CoverageLimits>();

            foreach (var cov in originalCoverages)
            {
                string coverageCode = CoverageTypeRules.GetCoverageType(cov.CoverageCd, cov.GetLimitAppliesToCode());
                if (coverageCode != null)
                {
                    if (!coverageDictionary.ContainsKey(coverageCode))
                    {
                        coverageDictionary.Add(coverageCode, new CoverageLimits());
                    }

                    var limits = coverageDictionary[coverageCode];

                    limits.Individual += cov.GetCoverageLimit(coverageCode, CoverageTypeRules.CoverageLimitType.Individual);
                    limits.Occurrence += cov.GetCoverageLimit(coverageCode, CoverageTypeRules.CoverageLimitType.Occurrence);
                    limits.CSL += cov.GetCoverageLimit(coverageCode, CoverageTypeRules.CoverageLimitType.CSL);
                    limits.DeductibleAmount += cov.GetCoverageDeductible(coverageCode);

                    coverageDictionary[coverageCode] = limits;
                }
            }

            return coverageDictionary;
        }

        internal struct CoverageLimits
        {
            public int Individual;
            public int Occurrence;
            public int CSL;
            public int DeductibleAmount;

            public override string ToString()
            {
                return $"I: {Individual} / O: {Occurrence} / C: {CSL} / DA: {DeductibleAmount}";
            }
        }
    }
}