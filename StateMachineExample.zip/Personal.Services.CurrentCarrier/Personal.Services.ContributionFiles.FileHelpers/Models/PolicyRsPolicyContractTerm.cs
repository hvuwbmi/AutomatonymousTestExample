﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyContractTerm.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyContractTerm
    {
        public void Map(CurrentCarrierPolicyInfoNP01 file)
        {
            file.PolicyPeriodEndDate = DateTime.Parse(this.ExpirationDt);
            file.PolicyPeriodBeginDate = DateTime.Parse(this.EffectiveDt);
        }
    }
}