﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NewDataSet.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System.Collections.Generic;
    using System.Configuration;
    using System.IO;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using WestBend.Core;

    public partial class NewDataSet
    {
        private readonly IPolicyStoreApi policyStoreApi;
        private readonly ILogger logger;
        private readonly string apimSubscriptionKey;

        public NewDataSet(IPolicyStoreApi policyStoreApi, ILogger logger)
        {
            this.policyStoreApi = policyStoreApi;
            this.logger = logger;
            this.apimSubscriptionKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];
        }

        public async Task<IReadOnlyCollection<ICurrentCarrierFile>> Map(string policyNumber, string policyVersion, string transactionSequenceNumber)
        {
            PolicyRs currentTransactionData = await this.GetTheAcord(policyNumber, policyVersion, transactionSequenceNumber);
            PolicyRs previousTransactionData = null;

            if (currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Endorsement
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Cancel
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Reinstate
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Rewrite
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Reissue
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Renewal
                || currentTransactionData.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.NonRenewal)
            {
                previousTransactionData = await this.GetPolicyPriorVersion(currentTransactionData.Policy[0].PolicyNumber, currentTransactionData.Policy[0].PolicyVersion, currentTransactionData.TransactionSeqNumber);
            }

            return currentTransactionData.Map(this.policyStoreApi, previousTransactionData);
        }

        /// <summary>
        /// Retrieve the prior version of the policy relative to the version provided.
        /// </summary>
        /// <param name="policyNumber">The policy number to retrieve.</param>
        /// <param name="policyVersion">The policy version to retrieve.</param>
        /// <param name="transactionSequenceNumber">The transaction sequence number to retrieve.</param>
        /// <returns></returns>
        private async Task<PolicyRs> GetPolicyPriorVersion(string policyNumber, string policyVersion, string transactionSequenceNumber)
        {
            // I'm not sure what statusInForced is, but the API has '0' as the default, so...
            var xml = await this.policyStoreApi.GetPriorVersion(policyNumber, policyVersion, transactionSequenceNumber, "0", this.apimSubscriptionKey);
            return this.GetPolicy(xml);
        }

        private async Task<PolicyRs> GetTheAcord(string policyNumber, string policyVersion, string transactionSequenceNumber)
        {
            var xml = await this.policyStoreApi.GetPolicyRequest(policyNumber, policyVersion, transactionSequenceNumber, this.apimSubscriptionKey);
            return this.GetPolicy(xml);
        }

        private PolicyRs GetPolicy(string xml)
        {
            var serializer = new XmlSerializer(typeof(PolicyRs));
            using (var reader = new StringReader(xml.Replace("xmlns=\"http://www.acord.org/schema/PC/xml/2\"", string.Empty)))
            {
                return (PolicyRs)serializer.Deserialize(reader);
            }
        }
    }
}