﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PartiesPeoplePerson_Type.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System;
    using FileMappers.CLUEAuto;

    public partial class PartiesPeoplePerson_Type
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            if (!string.IsNullOrEmpty(this.BirthDate))
            {
                file.VehicleOperatorDOB = DateTime.Parse(this.BirthDate);
            }

            file.VehicleOperatorSex = this.GenderCode == "U" ? string.Empty : this.GenderCode;

            this.PersonNames[0].Map(file);
            this.DriverLicense[0]?.Map(file);
        }
    }
}