﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimAtFault.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System;
    using FileMappers.CLUEAuto;
    using Rules;

    public partial class ClaimAtFault
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            if (this.DriverType != null)
            {
                if (this.DriverType.Equals("PARKEDVEHICLE", StringComparison.CurrentCultureIgnoreCase))
                {
                    file.VehicleOperatorLastName = "PARKEDVEHICLE";
                }
            }

            if (bool.TryParse(this.IsAtFault, out var fault))
            {
                file.FaultIndicator = ClueFaultIndicatorClaimClaimAtFaultRule.GetClueFaultIndicatorCode(fault);
            }
            else
            {
                file.FaultIndicator = "U";
            }
        }
    }
}