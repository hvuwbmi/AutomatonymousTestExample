﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimReservesClaimReserve_Type.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using FileMappers;
    using FileMappers.CLUEAuto;
    using Rules;

    public partial class ClaimReservesClaimReserve_Type
    {
        public void Map(CLUEAutoLossTransaction file, string claimStatusCode)
        {
            // We are to use the claim's status rather than the reserve's status if the status isn't a subrogation
            file.ClaimDisposition =
                this.ClaimReserveType[0].ReserveTypeCode == Constants.ClaimReserveTypeCode.SUBROGATION
                    ? Constants.ClaimStatusValue.SUBROGATED
                    : ClueClaimDispositionClaimStatusCodeRule.GetClueClaimDispositionCode(claimStatusCode);

            file.ClaimAmount = decimal.ToInt32(decimal.Parse(this.TotalPaidAmount) * 100);
            file.ClaimType = ClueClaimTypeClaimTypeRule.GetClueClaimTypeCode(this.CoverageType, this.ReserveCauseOfLoss);
        }
    }
}