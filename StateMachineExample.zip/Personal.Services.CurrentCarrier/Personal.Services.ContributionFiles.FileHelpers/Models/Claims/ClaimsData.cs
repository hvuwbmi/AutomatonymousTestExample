﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimsData.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    public class ClaimsData
    {
        public string DriverNumber { get; set; }

        public string VehicleNumber { get; set; }

        public string DriverType { get; set; }
    }
}