﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LossOccurrence.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System;
    using FileMappers.CLUEAuto;

    public partial class LossOccurrence
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            file.ClaimDate = DateTime.Parse(this.LossOccurrenceDate);
        }
    }
}