﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PartiesPeoplePerson_TypePersonNames.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using FileMappers.CLUEAuto;

    public partial class PartiesPeoplePerson_TypePersonNames
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            this.PersonName_Type[0].Map(file);
        }
    }
}