﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PartiesPeoplePerson_TypeDriverLicense.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using FileMappers.CLUEAuto;

    public partial class PartiesPeoplePerson_TypeDriverLicense
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            file.VehicleOperatorDLNumber = this.RegistrationNumber;
            file.VehicleOperatorDLState = this.LicensedStateCode;
        }
    }
}