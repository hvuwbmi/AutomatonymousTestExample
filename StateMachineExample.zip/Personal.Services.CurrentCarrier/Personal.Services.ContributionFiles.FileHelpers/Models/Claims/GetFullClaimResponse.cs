﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="GetFullClaimResponse.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System.Threading.Tasks;
    using FileMappers.CLUEAuto;

    public partial class GetFullClaimResponse
    {
        public async Task<ClaimsData> Map(CLUEAutoLossTransaction file, ClaimReservesClaimReserve_Type claimReserve, PolicyRs policy)
        {
            return await this.Claimk__BackingField[0].Map(file, claimReserve, policy);
        }

        public async Task<ClaimReservesClaimReserve_Type[]> GetClaimReserves()
        {
            return await this.Claimk__BackingField[0].GetClaimReserves();
        }
    }
}