﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PartiesPeoplePerson_TypePersonNamesPersonName_Type.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using FileMappers.CLUEAuto;

    public partial class PartiesPeoplePerson_TypePersonNamesPersonName_Type
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            file.VehicleOperatorLastName = this.Surname;
            file.VehicleOperatorFirstName = this.GivenName;
            file.VehicleOperatorMiddleName = this.MiddleName;
            file.VehicleOperatorSuffix = this.Suffix;
        }
    }
}