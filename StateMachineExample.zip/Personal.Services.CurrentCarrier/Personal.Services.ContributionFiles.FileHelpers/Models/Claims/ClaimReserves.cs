﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimReserves.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System.Linq;
    using FileMappers.CLUEAuto;

    public partial class ClaimReserves
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            file.ClaimAmount = decimal.ToInt32(this.ClaimReserve_Type.Sum(a => decimal.Parse(a.TotalPaidAmount) * 100));
        }
    }
}