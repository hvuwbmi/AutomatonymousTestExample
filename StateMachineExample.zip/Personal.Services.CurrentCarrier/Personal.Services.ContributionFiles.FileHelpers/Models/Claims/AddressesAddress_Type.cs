﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="AddressesAddress_Type.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System.Linq;
    using FileMappers.CLUEAuto;

    public partial class AddressesAddress_Type
    {
        public void Map(CLUEAutoLossTransaction file, PartiesPeoplePerson_Type driver, PolicyRs policy)
        {
            // Look for this driver on the policy. If it's found, check the driver's address. If the address matches
            // between the policy and the claim, use the policy's standardized address.
            // If none of that works, just fall back to using the claim's address.56
            var policyDriver = policy?.Policy?[0]?.PersAutoLineBusiness?[0]?.Driver?.FirstOrDefault(d =>
                string.Equals(d.GivenName, driver.PersonNames[0].PersonName_Type[0].GivenName, System.StringComparison.InvariantCultureIgnoreCase) &&
                string.Equals(d.Surname, driver.PersonNames[0].PersonName_Type[0].Surname, System.StringComparison.InvariantCultureIgnoreCase));

            if (policyDriver != null)
            {
                var policyAddress = policyDriver?.Addr?.FirstOrDefault(a => a.AddrTypeCd == "InsuredsAddress");

                if (policyAddress != null &&
                    string.Equals(policyAddress.Addr1, this.AddressLine1, System.StringComparison.InvariantCultureIgnoreCase) &&
                    string.Equals(policyAddress.City, this.CityName, System.StringComparison.InvariantCultureIgnoreCase) &&
                    string.Equals(policyAddress.StateProvCd, this.StateAbbreviationCode, System.StringComparison.InvariantCultureIgnoreCase) &&
                    string.Equals(policyAddress.PostalCode, this.PostalCode, System.StringComparison.InvariantCultureIgnoreCase))
                {
                    file.VehicleOperatorAddressCity = policyAddress.City;
                    file.VehicleOperatorAddressState = policyAddress.StateProvCd;
                    var zipParts = policyAddress.PostalCode.Split('-');
                    if (zipParts.Length == 2)
                    {
                        file.VehicleOperatorAddressZipCode = zipParts[0];
                        file.VehicleOperatorAddressZipCodePlus4 = zipParts[1];
                    }

                    file.VehicleOperatorAddressHouseNumber = policyAddress?.AddrExt?[0]?.WBAddressStandardization?[0]?.WBAddrStandardizeStreetNumber;
                    file.VehicleOperatorAddressStreetName = this.BuildStreetName(policyAddress?.AddrExt?[0]?.WBAddressStandardization?[0]);
                    file.VehicleOperatorAddressApartmentNumber = policyAddress?.AddrExt?[0]?.WBAddressStandardization?[0]?.WBAddrStandardizeUnitNumber;

                    return;
                }
            }

            file.VehicleOperatorAddressCity = this.CityName;
            file.VehicleOperatorAddressState = this.StateAbbreviationCode;
            var zipSplit = this.PostalCode.Split('-');
            if (zipSplit.Length == 2)
            {
                file.VehicleOperatorAddressZipCode = zipSplit[0];
                file.VehicleOperatorAddressZipCodePlus4 = zipSplit[1];
            }

            var startIndex = this.AddressLine1.IndexOf(' ');
            file.VehicleOperatorAddressHouseNumber = this.AddressLine1.Substring(0, startIndex);
            file.VehicleOperatorAddressStreetName = this.AddressLine1.Substring(startIndex + 1);
            file.VehicleOperatorAddressApartmentNumber = this.AddressLine2;
        }

        internal string BuildStreetName(AddrAddrExtWBAddressStandardization addressStandardization)
        {
            if (addressStandardization == null)
            {
                return string.Empty;
            }

            string streetName = addressStandardization.WBAddrStandardizeLeadingDirectional
                + " " + addressStandardization.WBAddrStandardizeStreetName
                + " " + addressStandardization.WBAddrStandardizeStreetTypeCd;
            return streetName.Trim();
        }
    }
}