﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClaimPolicyAgreement.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    public partial class ClaimPolicyAgreement
    {
    }
}