﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="Claim.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using System.Linq;
    using System.Threading.Tasks;
    using FileMappers;
    using FileMappers.CLUEAuto;
    using Rules;
    
    public partial class Claim
    {
        // We are only allowed one vehicle per claim.  To make sure we are consistant, when we get the "first" vehicle, we will store it here.
        // Any other time we would load a vehicle, if we've already used one, we'll use this number instead even if it doesn't match what's in the Claim.
        private string usedVehicleNumber = string.Empty;

        public Task<ClaimsData> Map(CLUEAutoLossTransaction file, ClaimReservesClaimReserve_Type claimReserve, PolicyRs policy)
        {
            file.ClaimNumber = this.ClaimNumber;

            if (this.ClaimAtFault != null)
            {
                this.ClaimAtFault.Map(file);
            }
            else
            {
                file.FaultIndicator = "U";
            }

            claimReserve.Map(file, this.ClaimStatusCode);
            this.LossOccurrence.Map(file);

            if (this.PhysicalObjects?.LandVehicles != null)
            {
                this.PhysicalObjects.LandVehicles.FirstOrDefault()?.Map(file);
            }

            var driverKey = this.PartyRoleInClaim?[0]?.InsuredVehicleDriver_Type?[0]?.References?[0]?.PartyReferences?[0]?.@string;
            this.Parties[0].Person_Type.FirstOrDefault(a => a.key == driverKey)?.Map(file);

            var driver = this.Parties[0].Person_Type.FirstOrDefault(a => a.key == driverKey);

            var contactKey = this.Parties[0].Person_Type.FirstOrDefault(a => a.key == driverKey)?.References?[0]?.ContactPointReferences?[0]?.@string;
            var addressKey = this.ContactPoints?.PostalContacts?[0]?.PostalContact_Type?.FirstOrDefault(a => a.key == contactKey)?.References?[0]?.AddressReferences?[0]?.@string;
            this.Addresses?.FirstOrDefault(a => a.key == addressKey)?.Map(file, driver, policy);

            var driverNumber = this.ClaimAtFault?.DriverNumber;
            var driverType = this.ClaimAtFault?.DriverType;
            var vehicleNumber = string.Empty;
            if (this.usedVehicleNumber.Equals(string.Empty))
            {
                if (this.PhysicalObjects.LandVehicles != null)
                {
                    vehicleNumber = this.PhysicalObjects.LandVehicles.FirstOrDefault()?.LandVehicle_Type.FirstOrDefault(a => a.key == claimReserve.PhysicalObjectRole[0]?.PhysicalObjectReference)?.Number;
                }

                this.usedVehicleNumber = vehicleNumber;
            }
            else
            {
                vehicleNumber = this.usedVehicleNumber;
            }

            return Task.FromResult(new ClaimsData() { DriverNumber = driverNumber, VehicleNumber = vehicleNumber, DriverType = driverType });
        }

        public Task<ClaimReservesClaimReserve_Type[]> GetClaimReserves()
        {
            var results = this.ClaimReserves?.ClaimReserve_Type?.Where(a => a.ClaimReserveType[0].ReserveTypeCode == "B" || a.ClaimReserveType[0].ReserveTypeCode == "D");
            return Task.FromResult(results?.ToArray());
        }
    }
}