﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PhysicalObjectsLandVehiclesLandVehicle_Type.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models.Claims
{
    using FileMappers.CLUEAuto;

    public partial class PhysicalObjectsLandVehiclesLandVehicle_Type
    {
        public void Map(CLUEAutoLossTransaction file)
        {
            file.InsuredVehicleVIN = this.VehicleIdentificationNumber;
        }
    }
}