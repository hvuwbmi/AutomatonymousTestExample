﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyInsuredOrPrincipal.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Linq;
    using System.Threading.Tasks;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto;
    using Rules;
    using Utilities;

    public partial class PolicyRsPolicyInsuredOrPrincipal
    {
        private string[] codes = new[] { "FNI", "CN", "SP", "CH", "PA", "GP", "RE", "NR" };
        
        public void Map(CurrentCarrierPolicyInfoNP01 file)
        {
            Enumerable.FirstOrDefault<Addr>(this.Addr, a => a.AddrTypeCd.Equals("MailingAddress", StringComparison.CurrentCultureIgnoreCase))
                ?.Map(file);
        }

        public Task MapPolicyHolder1(CLUEAutoLossTransaction file)
        {
            file.PolicyHolder1LastName = this.Surname?.ToUpper();
            file.PolicyHolder1FirstName = this.GivenName?.ToUpper();
            file.PolicyHolder1MiddleName = this.OtherGivenName?.ToUpper();
            file.PolicyHolder1Suffix = this.NameSuffix?.ToUpper();
            file.PolicyHolder1DOB = this.BirthDt.ToDateRequired();

            Enumerable.FirstOrDefault<Addr>(this.Addr, a => a.AddrTypeCd.Equals("InsuredsAddress", StringComparison.CurrentCultureIgnoreCase))?.MapPolicyHolder1(file);

            return Task.CompletedTask;
        }

        public Task MapPolicyHolder2(CLUEAutoLossTransaction file)
        {
            file.PolicyHolder2LastName = this.Surname?.ToUpper();
            file.PolicyHolder2FirstName = this.GivenName?.ToUpper();
            file.PolicyHolder2MiddleName = this.OtherGivenName?.ToUpper();
            file.PolicyHolder2Suffix = this.NameSuffix?.ToUpper();
            file.PolicyHolder2DOB = this.BirthDt.ToDateRequired();

            return Task.CompletedTask;
        }

        internal void Map(CLUEAutoLossTransaction clueAutoLossTransaction)
        {
            var relationshipToCd = this.Relationship.FirstOrDefault(a => this.codes.Any(b => b.Equals(a.RelationshipToCd, StringComparison.CurrentCultureIgnoreCase)))?.RelationshipToCd;
            clueAutoLossTransaction.VehicleOperatorRelationship = AcordVROToClueAutoVRO.TransformAcordVROToClueAutoVRO(relationshipToCd);
        }
    }
}