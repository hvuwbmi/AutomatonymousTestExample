﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyCancelNonRenewInfo.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyCancelNonRenewInfo
    {
        public void Map(CurrentCarrierVehicleVR01 file)
        {
            this.cancelNonRenewInfoExtField[0].Map(file, this.RequestorCd);
        }

        public void Map(CurrentCarrierMiscellaneousInfoMR01 file)
        {
            this.cancelNonRenewInfoExtField[0].Map(file, this.RequestorCd);
        }
    }
}