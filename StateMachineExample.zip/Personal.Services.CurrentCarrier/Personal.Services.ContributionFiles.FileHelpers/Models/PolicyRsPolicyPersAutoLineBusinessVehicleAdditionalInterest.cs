﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using FileMappers.CurrentCarrier;
    using Rules;
    using Utilities;

    public partial class PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest
    {
        public string ModInfoActionCd { get; set; }

        internal void Map(CurrentCarrierFIRSTPropertyInfoFR01 file)
        {
            ////PropertyHelper.SetDynamicProperty(file, $"FinanceCompany{index}Name", this.Name);
            ////PropertyHelper.SetDynamicProperty(file, $"FinanceCompany{index}Type", this.NatureInterestCd.GetFinanceCompanyCode());
            ////PropertyHelper.SetDynamicProperty(file, $"FinanceCompany{index}LoanNumber", this.AccountNumberId);

            file.FinanceCompany1Name = this.GivenName;
            file.FinanceCompany1Type = this.NatureInterestCd.GetFinanceCompanyCode();
            file.FinanceCompany1LoanNumber = this.AccountNumberId;

            if (this.Addr != null)
            {
                this.Addr[0].Map(file);
            }
        }
    }
}