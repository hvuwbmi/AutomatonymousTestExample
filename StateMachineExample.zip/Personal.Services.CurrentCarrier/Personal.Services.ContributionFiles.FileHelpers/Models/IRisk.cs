﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IRisk.cs" company="West Bend">
//    Copyright (c) 2020 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    public interface IRisk
    {
        IRiskExt RiskExt { get; }

        string Id { get; }
    }
}