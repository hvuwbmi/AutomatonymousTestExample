﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRs.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using Claims;
    using FileMappers.CLUEAuto;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Personal.Services.ContributionFiles.FileHelpers.Utilities;
    using WestBend.Core;
    using WestBend.Core.Service;
    using static Personal.Services.ContributionFiles.FileHelpers.FileMappers.Constants;

    public partial class PolicyRs
    {
        public DateTime TransactionEffectiveDate { get; set; }

        public static IReadOnlyCollection<ICurrentCarrierFile> Map(string xml, IPolicyStoreApi policyStore)
        {
            var serializer = new XmlSerializer(typeof(PolicyRs));
            using (var reader = new StringReader(xml))
            {
                var data = (PolicyRs)serializer.Deserialize(reader);
                return data.Map(policyStore);
            }
        }

        public IReadOnlyCollection<ICurrentCarrierFile> Map(IPolicyStoreApi policyStore)
        {
            return this.Map(policyStore, previousTransactionPolicyRs: null);
        }

        public IReadOnlyCollection<ICurrentCarrierFile> Map(IPolicyStoreApi policyStore, PolicyRs previousTransactionPolicyRs)
        {
            // enrich the policy prior to processing
            IPolicyEnricher enricher = null;
            var records = new List<ICurrentCarrierFile>();
            if (this.BusinessPurposeTypeCd == BusinessPurposeTypeCode.NonRenewal)
            {
                // all changes are based on this https://wbmi.visualstudio.com/WB/_workitems/edit/80245
                enricher = new PolicyEnricherForNonRenewal(this, new CommonLogger());
                enricher.Enrich();

                // check if we even need to create the record for this policy
                if (new ShouldCreateContributionFile().IsSatisfiedBy(this, previousTransactionPolicyRs))
                {
                    var policcyInfoNP01 = new CurrentCarrierPolicyInfoNP01();
                    policcyInfoNP01.ChangeEffectiveDate = this.TransactionEffectiveDate;
                    policcyInfoNP01.PolicyCancellationDate = this.TransactionEffectiveDate;
                    records.Add(new CurrentCarrierPolicyInfoNP01().Map(this));
                    var fp01 = this.Policy[0].CreateFP01IfShouldBeCreated(this);
                    if (fp01 != null)
                    {
                        fp01.ChangeEffectiveDate = this.TransactionEffectiveDate;
                        records.Add(fp01);
                    }

                    records.AddRange(this.Policy[0].GetCarrierSubjectInfoSj01s(this));

                    // Note: PR01 mapping contains VR01 and FR01.
                    records.AddRange(this.Policy[0].PersAutoLineBusiness[0].GetCurrentCarrierPR01sForNonRenewal(this, previousTransactionPolicyRs, policyStore));
                    var miscellaneousInfoMR01 = this.Policy[0].GetCarrierMiscellaneousInfoMR01(this);
                    miscellaneousInfoMR01.ChangeEffectiveDate = this.TransactionEffectiveDate;
                    miscellaneousInfoMR01.CancellationReasonCode = "COMP";
                    records.Add(miscellaneousInfoMR01);
                }
            }
            else
            {
                enricher = new PolicyEnricher(this);
                enricher.Enrich();
  
                // check if we even need to create the record for this policy
                if (new ShouldCreateContributionFile().IsSatisfiedBy(this, previousTransactionPolicyRs))
                {
                    records.Add(new CurrentCarrierPolicyInfoNP01().Map(this));
                    var fp01 = this.Policy[0].CreateFP01IfShouldBeCreated(this);
                    if (fp01 != null)
                    {
                        records.Add(fp01);
                    }

                    records.AddRange(this.Policy[0].GetCarrierSubjectInfoSj01s(this));
   
                    // Note: PR01 mapping contains VR01 and FR01.
                    records.AddRange(this.Policy[0].PersAutoLineBusiness[0].GetCurrentCarrierPR01s(this, previousTransactionPolicyRs, policyStore));
                    if (!string.IsNullOrWhiteSpace(this.Policy[0].CancellationDt) || this.BusinessPurposeTypeCd.Equals(Constants.BusinessPurposeTypeCode.Reinstate))
                    {
                        records.Add(this.Policy[0].GetCarrierMiscellaneousInfoMR01(this));
                    }
                }
            }

            return records.AsReadOnly();
        }

        public void Map(ICurrentCarrierFile file)
        {
            file.ChangeEffectiveDateP = this.TransactionEffectiveDate;
            file.PolicyNumberP = this.Policy[0].PolicyNumber;
        }

        public async Task<CLUEAutoLossTransaction> MapCLUEAutoLossTransaction(CLUEAutoLossTransaction file, ClaimsData claimData)
        {
            return await file.Map(this, claimData.DriverNumber, claimData.DriverType, claimData.VehicleNumber);
        }
    }
}