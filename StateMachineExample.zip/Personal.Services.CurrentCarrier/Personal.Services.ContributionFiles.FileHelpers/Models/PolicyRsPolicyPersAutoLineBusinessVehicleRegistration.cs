﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessVehicleRegistration.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyPersAutoLineBusinessVehicleRegistration
    {
        internal void Map(CurrentCarrierVehicleVR01 file)
        {
            file.VehicleRegisteredState = this.StateProvCd;
        }
    }
}