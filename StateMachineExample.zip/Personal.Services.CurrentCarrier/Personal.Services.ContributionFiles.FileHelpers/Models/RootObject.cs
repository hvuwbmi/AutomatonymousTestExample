﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="RootObject.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System.Collections.Generic;
    using Newtonsoft.Json;

    public class RootObject<T>
    {
        [JsonProperty("Value")]
        public List<T> Values { get; set; }
    }
}