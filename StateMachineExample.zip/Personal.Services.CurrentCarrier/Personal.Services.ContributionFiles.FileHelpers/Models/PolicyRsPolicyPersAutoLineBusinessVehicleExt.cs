﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyPersAutoLineBusinessVehicleExt.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyPersAutoLineBusinessVehicleVehicleExt : IRiskExt
    {
        WBRiskTerm IRiskExt.WBRiskTerm => this.WBRiskTerm?[0];

        internal void Map(CurrentCarrierVehicleVR01 file)
        {
            if (this.WBVehicleOriginationDt != null)
            {
                file.AddDate = DateTime.Parse(this.WBVehicleOriginationDt);
            }
            else
            {
                if (this.WBRiskTerm != null && this.WBRiskTerm[0].WBRiskEffectiveDt != null)
                {
                    file.AddDate = DateTime.Parse(this.WBRiskTerm[0].WBRiskEffectiveDt);
                }
            }
        }
    }
}