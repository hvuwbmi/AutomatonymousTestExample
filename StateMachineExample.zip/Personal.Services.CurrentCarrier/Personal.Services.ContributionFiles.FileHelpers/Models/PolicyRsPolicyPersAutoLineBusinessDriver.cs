﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PolicyRsPolicyPersAutoLineBusinessDriver.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Linq;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto;
    using Rules;

    public partial class PolicyRsPolicyPersAutoLineBusinessDriver : IRisk
    {
        public string ModInfoActionCd { get; set; }

        public IRiskExt RiskExt => this.DriverExt?[0];

        public string Id => this.id;

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1305:FieldNamesMustNotUseHungarianNotation", Justification = "coApplicant is ok")]
        public void Map(CurrentCarrierSubjectInfoSJ01 file, PolicyRsPolicyInsuredOrPrincipal principal, Relationship relationship)
        {
            this.License?[0]?.Map(file);

            file.LastName = this.Surname;
            file.FirstName = this.GivenName;
            file.MiddleName = this.OtherGivenName;
            file.NameSuffix = this.NameSuffix;
            file.SequenceNumber = this.ItemIdInfo?[0]?.InsurerId;

            bool firstNamedInsured = principal.Relationship != null && principal.Relationship.Any(r => r.RelationshipToCd.Equals("FNI", StringComparison.CurrentCultureIgnoreCase));
            bool coApplicant = principal.Relationship != null && principal.Relationship.Any(r => r.RelationshipToCd.Equals("CN", StringComparison.CurrentCultureIgnoreCase));

            if (relationship != null)
            {
                file.Relationship = relationship.RelationshipToCd?.GetRelationshipType(firstNamedInsured, this.License?[0]?.LicenseStatusCd, this.DriverTypeCd, coApplicant);
            }

            file.EmailAddress = principal.Communications?.FirstOrDefault()?.EmailAddr;

            file.BirthDate = DateTime.Parse(this.BirthDt);
            file.Gender = this.GenderCd?.GetContributionGenderMapping();
            file.MaritalStatus = this.MaritalStatusCd.GetMaritalStatus();
        }

        internal void MapPolicyHolder1(CLUEAutoLossTransaction clueAutoLossTransaction)
        {
            this.License[0]?.MapPolicyHolder1(clueAutoLossTransaction);
            clueAutoLossTransaction.PolicyHolder1Sex = this.GenderCd?.GetClueGenderMapping();
        }

        internal void MapPolicyHolder2(CLUEAutoLossTransaction clueAutoLossTransaction)
        {
            this.License[0]?.MapPolicyHolder2(clueAutoLossTransaction);
            clueAutoLossTransaction.PolicyHolder2Sex = this.GenderCd?.GetClueGenderMapping();
        }
    }
}