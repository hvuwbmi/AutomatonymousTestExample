﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicyCancelNonRenewInfoCancelNonRenewInfoExt.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using FileMappers.CurrentCarrier;

    public partial class PolicyRsPolicyCancelNonRenewInfoCancelNonRenewInfoExt
    {
        public void Map(CurrentCarrierVehicleVR01 file, string requestorCd)
        {
            if (this.WBReasonInfo != null && this.WBReasonInfo.Length > 0 && this.WBReasonInfo[0] != null)
            {
                this.WBReasonInfo[0].Map(file, requestorCd);
            }
        }

        public void Map(CurrentCarrierMiscellaneousInfoMR01 file, string requestorCd)
        {
            if (this.WBReasonInfo != null && this.WBReasonInfo.Length > 0 && this.WBReasonInfo[0] != null)
            {
                this.WBReasonInfo[0].Map(file, requestorCd);
            }
        }
    }
}