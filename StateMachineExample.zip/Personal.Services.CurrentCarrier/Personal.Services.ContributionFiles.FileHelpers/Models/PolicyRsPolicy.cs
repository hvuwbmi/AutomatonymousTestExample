﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PolicyRsPolicy.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using FileMappers.CurrentCarrier;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Rules;
    using Utilities;

    public partial class PolicyRsPolicy
    {
        public void Map(CurrentCarrierPolicyInfoNP01 file, string businessPurposeTypeCd)
        {
            file.PolicyType = this.GetPolicyType();

            // if this date is missing what should happen?
            file.PolicyInceptionDate = string.IsNullOrEmpty(this.OriginalPolicyInceptionDt) ? DateTime.Parse(this.ContractTerm[0].EffectiveDt) : DateTime.Parse(this.OriginalPolicyInceptionDt);
            file.PolicyCancellationDate = string.IsNullOrEmpty(this.CancellationDt)
                ? (DateTime?)null
                : DateTime.Parse(this.CancellationDt);
            file.PolicyState = this.ControllingStateProvCd;

            this.ContractTerm[0].Map(file);

            // Find the first InsuredOrPrincipal that has a Relationship node with a RelationshipToCd set to FNI.
            var insured = this.InsuredOrPrincipal?.FirstOrDefault(
                a => a.Relationship != null && a.Relationship.Any(r => r.RelationshipToCd.Equals("FNI", StringComparison.CurrentCultureIgnoreCase)));
            if (insured != null)
            {
                insured.Map(file);
            }
        }

        public void Map(CurrentCarrierFIRSTPropertyInfoFR01 file, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, string businessPurposeTypeCd, string transSeqNum, IPolicyStoreApi policyStore)
        {
            // TODO : find a better way to do this. Has impact on existing test cases
            this.SetPolicyRs(file, businessPurposeTypeCd, vehicle.ModInfoActionCd, null, this.PolicyVersion, transSeqNum, policyStore);

            this.PersAutoLineBusiness[0].Map(file, vehicle);
        }

        public void Map(CurrentCarrierFIRSTPropertyInfoFR01 file, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest, string businessPurposeTypeCd, string transSeqNum, IPolicyStoreApi policyStore)
        {
            this.SetPolicyRs(file, businessPurposeTypeCd, vehicle.ModInfoActionCd, additionalInterest, this.PolicyVersion, transSeqNum, policyStore);

            this.PersAutoLineBusiness[0].Map(file, vehicle, additionalInterest);
        }

        public void Map(CurrentCarrierFIRStPolicyInfoFP01 file, string businessPurposeTypeCd)
        {
            bool? setFromProducer = !this.CustomerServicingCd?.Equals("CompSvc", StringComparison.CurrentCultureIgnoreCase);

            // Find the first Producer that has a Relationship node with a RelationshipToCd set to 'Agency'.
            var producer = this.Producer?.FirstOrDefault(
                p => p.Relationship != null && p.Relationship.Any(r => r.RelationshipToCd.Equals("Agency", StringComparison.CurrentCultureIgnoreCase)));

            producer?.Map(file, setFromProducer ?? true);
        }

        public CurrentCarrierFIRStPolicyInfoFP01 CreateFP01IfShouldBeCreated(PolicyRs policy)
        {
            return CurrentCarrierFIRStPolicyInfoFP01.ShouldRecordGetCreated(this)?.Map(policy);
        }

        public CurrentCarrierMiscellaneousInfoMR01 GetCarrierMiscellaneousInfoMR01(PolicyRs policy)
        {
            return (CurrentCarrierMiscellaneousInfoMR01)new CurrentCarrierMiscellaneousInfoMR01().Map(policy);
        }

        public IEnumerable<ICurrentCarrierFile> GetCarrierSubjectInfoSj01s(PolicyRs policyRs)
        {
            List<ICurrentCarrierFile> files = new List<ICurrentCarrierFile>();

            if (this.InsuredOrPrincipal != null && this.PersAutoLineBusiness?[0]?.Driver != null)
            {
                foreach (var insured in this.InsuredOrPrincipal)
                {
                    foreach (var driver in this.PersAutoLineBusiness[0].Driver)
                    {
                        if (new ShouldCreateSJ01Record().IsSatisfiedBy(driver.ModInfoActionCd) && driver.Relationship != null)
                        {
                            foreach (var relationship in driver.Relationship)
                            {
                                if (string.Equals(relationship.RelationshipToRef, insured.id, StringComparison.CurrentCultureIgnoreCase))
                                {
                                    files.Add(new CurrentCarrierSubjectInfoSJ01().Map(policyRs, insured, driver, relationship));
                                }
                            }
                        }
                    }
                }
            }

            return files;
        }

        public void Map(CurrentCarrierVehicleVR01 file, string businessPurposeTypeCd, string modInfoActionCd)
        {
            if (businessPurposeTypeCd.Equals("XLC") && this.CancelNonRenewInfo[0] != null)
            {
                this.CancelNonRenewInfo[0].Map(file);
            }

            file.VehicleStatus = businessPurposeTypeCd.GetVehicleStatus(modInfoActionCd);
        }

        public void Map(CurrentCarrierMiscellaneousInfoMR01 file, string businessPurposeTypeCd)
        {
            if (businessPurposeTypeCd.Equals("XLC") && this.CancelNonRenewInfo[0] != null)
            {
                this.CancelNonRenewInfo[0].Map(file);
                file.ReinstatementDate = (DateTime?)null;
            }
            else if (businessPurposeTypeCd.Equals("REI"))
            {
                file.ReinstatementDate = file.ChangeEffectiveDate;
            }
        }

        internal void Map(CurrentCarrierSubjectInfoSJ01 file, PolicyRsPolicyInsuredOrPrincipal principal, PolicyRsPolicyPersAutoLineBusinessDriver driver, Relationship relationship, string businessPurposeTypeCd)
        {
            this.PersAutoLineBusiness[0].Map(file, principal, driver, relationship);
        }

        internal void Map(CurrentCarrierPropertyInfoPR01 file, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, PolicyRs previousTransactionPolicyRs, Coverage[] lobCoverages, PolicyRs currentTransactionPolicyRs)
        {
            if (currentTransactionPolicyRs.BusinessPurposeTypeCd == Constants.BusinessPurposeTypeCode.Endorsement
                && Constants.ModInfo.Deleted == vehicle.ModInfoActionCd)
            {
                var priorVehicle = previousTransactionPolicyRs?.Policy[0]?.PersAutoLineBusiness[0]?.Vehicle?.FirstOrDefault(v => v.Id == vehicle.Id);
                if (priorVehicle != null)
                {
                    priorVehicle.Map(file, lobCoverages, currentTransactionPolicyRs);
                }
                else
                {
                    // This really shouldn't happen - the policy says we deleted a vehicle that didn't exist on the prior transaction.
                    // We need to map something here so we don't get random VR01/FR01 records without a PR01.
                    vehicle.Map(file, lobCoverages, currentTransactionPolicyRs);
                }
            }
            else
            {
                vehicle.Map(file, lobCoverages, currentTransactionPolicyRs);
            }

            if (vehicle.Addr != null)
            {
                var garagingAddress = vehicle.Addr.FirstOrDefault(a => a.AddrTypeCd != null && a.AddrTypeCd.Equals("GaragingAddress", StringComparison.CurrentCultureIgnoreCase));
                if (garagingAddress != null)
                {
                    garagingAddress.Map(file, this.GetFirstNamedInsured());
                }
            }
        }

        internal PolicyRsPolicyInsuredOrPrincipal GetFirstNamedInsured()
        {
            return this.InsuredOrPrincipal?.FirstOrDefault(
                a => a.Relationship != null && a.Relationship.Any(r => r.RelationshipToCd.Equals("FNI", StringComparison.CurrentCultureIgnoreCase)));
        }

        /// <summary>
        /// Retrieve the policy type based on elements within the policy.
        /// </summary>
        /// <returns>The Contribution formatted policy type, for use in the NP01 record.</returns>
        internal string GetPolicyType()
        {
            if (this.PersAutoLineBusiness != null && this.PersAutoLineBusiness.Count() > 0)
            {
                return "AU";
            }

            // At some point there will be checks for Home, Umbrella, etc.
            return "XO";
        }

        internal async Task Map(CLUEAutoLossTransaction clueAutoLossTransaction, string driverNumber, string driverType, string vehicleNumber)
        {
            clueAutoLossTransaction.PolicyNumber = this.PolicyNumber;

            // Policy Holder 1
            this.InsuredOrPrincipal.Where(a => a.Relationship.Any(b => b.RelationshipToCd.Equals("FNI", StringComparison.CurrentCultureIgnoreCase)))?.FirstOrDefault()?.MapPolicyHolder1(clueAutoLossTransaction);
            string insRef = null;
            if (this.InsuredOrPrincipal != null)
            {
                insRef = this.InsuredOrPrincipal.FirstOrDefault(a => a.Relationship.Any(b => b.RelationshipToCd.Equals("FNI", StringComparison.CurrentCultureIgnoreCase)))?.id;
            }

            PolicyRsPolicyPersAutoLineBusinessDriver driver = null;
            if (this.PersAutoLineBusiness[0] != null && this.PersAutoLineBusiness[0].Driver != null)
            {
                driver = this.PersAutoLineBusiness[0].Driver.FirstOrDefault(a => a.Relationship != null && a.Relationship.Any(b => b.RelationshipToRef.Equals(insRef, StringComparison.CurrentCultureIgnoreCase)));
            }

            if (driver != null)
            {
                driver.MapPolicyHolder1(clueAutoLossTransaction);
            }

            // Policy Holder 2
            this.InsuredOrPrincipal.Where(a => a.Relationship.Any(b => b.RelationshipToCd.Equals("CN", StringComparison.CurrentCultureIgnoreCase)))?.FirstOrDefault()?.MapPolicyHolder2(clueAutoLossTransaction);
            insRef = null;
            if (this.InsuredOrPrincipal != null)
            {
                insRef = this.InsuredOrPrincipal.FirstOrDefault(a => a.Relationship.Any(b => b.RelationshipToCd.Equals("CN", StringComparison.CurrentCultureIgnoreCase)))?.id;
            }

            driver = null;
            if (this.PersAutoLineBusiness[0] != null && this.PersAutoLineBusiness[0].Driver != null)
            {
                driver = this.PersAutoLineBusiness[0].Driver.FirstOrDefault(a => a.Relationship != null && a.Relationship.Any(b => b.RelationshipToRef.Equals(insRef, StringComparison.CurrentCultureIgnoreCase)));
            }

            if (driver != null)
            {
                driver.MapPolicyHolder2(clueAutoLossTransaction);
            }

            this.PersAutoLineBusiness?[0]?.Vehicle?.FirstOrDefault(a => a.ItemIdInfo[0].InsurerId == vehicleNumber)?.Map(clueAutoLossTransaction);

            await this.MapVehicleOperator(clueAutoLossTransaction, driverNumber, driverType);
        }

        internal Task MapVehicleOperator(CLUEAutoLossTransaction clueAutoLossTransaction, string driverNumber, string driverType)
        {
            if ("listed".Equals(driverType, StringComparison.CurrentCultureIgnoreCase))
            {
                var relationship = this.PersAutoLineBusiness?[0]?.Driver?.FirstOrDefault(a => a.ItemIdInfo[0].InsurerId == driverNumber)?.Relationship?.FirstOrDefault(a => a.RelationshipToRef.StartsWith("I", StringComparison.CurrentCultureIgnoreCase));
                var relationshipCode = relationship?.RelationshipToCd;
                if ("in".Equals(relationshipCode, StringComparison.CurrentCultureIgnoreCase))
                {
                    var insId = relationship?.RelationshipToRef;
                    this.InsuredOrPrincipal?.FirstOrDefault(a => a.id == insId)?.Map(clueAutoLossTransaction);
                }
                else
                {
                    clueAutoLossTransaction.VehicleOperatorRelationship = AcordVROToClueAutoVRO.TransformAcordVROToClueAutoVRO(relationshipCode);
                }
            }

            return Task.CompletedTask;
        }

        private void SetPolicyRs(CurrentCarrierFIRSTPropertyInfoFR01 file, string businessPurposeTypeCd, string vehicleModInfoActionCd, PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest, string policyVersion, string transSeqNumber, IPolicyStoreApi policyStore)
        {
            var requestorCd = (string)null; 
            var cancelReasonCd = (string)null;
            if (this.CancelNonRenewInfo != null && this.CancelNonRenewInfo[0].CancelNonRenewInfoExt[0] != null && this.CancelNonRenewInfo[0].CancelNonRenewInfoExt[0].WBReasonInfo != null)
            {
                requestorCd = this.CancelNonRenewInfo[0]?.RequestorCd;
                cancelReasonCd = this.CancelNonRenewInfo[0]?.CancelNonRenewInfoExt[0]?.WBReasonInfo[0]?.WBCancelReasonCd;
            }

            file.NotificationActionCode = businessPurposeTypeCd.GetNotificationAction(vehicleModInfoActionCd, additionalInterest, requestorCd, cancelReasonCd, file.PolicyNumber, policyVersion, transSeqNumber, policyStore);

            var notificationActionDate = businessPurposeTypeCd.GetNotificationActionDate(file.NotificationActionCode, this.ContractTerm.First().EffectiveDt, file.ChangeEffectiveDate.ToString(), this.CancellationDt);
            if (!string.IsNullOrEmpty(notificationActionDate))
            {
                file.NotificationActionDate = notificationActionDate.ToDateRequired();
            }
        }

        private void MapChangeEffectiveDate(ICurrentCarrierFile file, string businessPurposeTypeCd)
        {
            if (businessPurposeTypeCd.Equals("XLC"))
            {
                file.ChangeEffectiveDateP = DateTime.Parse(this.CancellationDt);
            }
        }
    }
}