﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierData.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    public class CurrentCarrierData
    {
        public string Container { get; set; }

        public string Folder { get; set; }

        public string Name { get; set; }

        public string CreateDate { get; set; }

        public string PolicyNumber { get; set; }

        public string PolicyVersion { get; set; }

        public string TransSeqNumber { get; set; }
    }
}