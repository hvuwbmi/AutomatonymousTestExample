﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoPolicyClaimData.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.Models
{
    using System;
    using System.Configuration;
    using System.IO;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using Claims;
    using ServiceInterfaces;
    using WestBend.Core;

    public class ClueAutoPolicyClaimData
    {
        private readonly IClaimsClaim claimApi;
        private readonly IPolicyStoreApi policyStoreApi;
        private readonly ILogger logger;
        private readonly string apimSubscriptionKey;

        public ClueAutoPolicyClaimData(IClaimsClaim claimApi, IPolicyStoreApi policyStoreApi, ILogger logger)
        {
            this.claimApi = claimApi;
            this.policyStoreApi = policyStoreApi;
            this.logger = logger;
            this.apimSubscriptionKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];
        }

        public async Task<CombinedClueAutoAndPolicyData> GetTheData(string policyNumber, string claimNumber, DateTime? effectiveDate)
        {
            var response = new CombinedClueAutoAndPolicyData
            {
                GetFullClaimResponse = await this.GetTheClaim(claimNumber),
                Policy = await this.GetTheAcord(policyNumber, effectiveDate)
            };

            return response;
        }

        private async Task<PolicyRs> GetTheAcord(string policyNumber, DateTime? effectiveDate)
        {
            if (effectiveDate.HasValue == false)
            {
                return new PolicyRs();
            }

            var xml = await this.policyStoreApi.GetPolicyRequest(policyNumber, effectiveDate.Value.ToString("yyyy-MM-dd"), this.apimSubscriptionKey);
            var serializer = new XmlSerializer(typeof(PolicyRs));
            using (var reader = new StringReader(xml.Replace("xmlns=\"http://www.acord.org/schema/PC/xml/2\"", string.Empty)))
            {
                return (PolicyRs)serializer.Deserialize(reader);
            }
        }

        private async Task<GetFullClaimResponse> GetTheClaim(string claimNumber)
        {
            GetFullClaimResponse response = null;
            var claimXml = await this.claimApi.ClaimOrchestratorLogicApp(claimNumber, this.apimSubscriptionKey);
            XmlSerializer serializer = new XmlSerializer(typeof(GetFullClaimResponse));

            using (StringReader sr = new StringReader(claimXml))
            {
                response = (GetFullClaimResponse)serializer.Deserialize(sr);
            }

            return response;
        }
    }
}