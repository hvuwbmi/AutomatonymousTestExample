﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LicenseConverter.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using System.Configuration;
    using global::FileHelpers;
    using Models;
    using Personal.Services.ContributionFiles.FileHelpers.FileMappers;
    using Polly;
    using Refit;
    using ServiceInterfaces;
    using WestBend.Core;
    using WestBend.Core.Service;

    public class LicenseConverter : ConverterBase
    {
        private static ITokenApi tokenApi;

        private static ILogger logger;

        public static ILogger Logger
        {
            get
            {
                if (logger == null)
                {
                    logger = new CommonLogger();
                }

                return logger;
            }

            set
            {
                logger = value;
            }
        }

        /// <summary>
        /// The tokenization API object to use to detokenize the drivers license. Typically this does not need to
        /// be assigned prior to use, but unit tests should assign a mock object to this.
        /// </summary>
        public static ITokenApi TokenApi
        {
            get
            {
                if (tokenApi == null)
                {
                    tokenApi = RestService.For<ITokenApi>(ConfigurationManager.AppSettings["ApimUrl"]);
                }

                return tokenApi;
            }

            set
            {
                tokenApi = value;
            }
        }

        /// <summary>
        /// Convert the license token in the policy-level file to the true drivers license to be sent in the daily file.
        /// </summary>
        /// <param name="from">The tokenized drivers license</param>
        /// <returns>The true drivers license</returns>
        public override object StringToField(string @from)
        {
            // Try five times, backing off by seconds: 2, 4, 8, 16, 32.
            // Generally the AggregateException contains an ApiException with a 500 error. We could use the predicate to ensure
            // this condition, or just retry on any exception.
            var retryPolicy = Policy
                .Handle<Exception>()
                .WaitAndRetryAsync(
                    5,
                    retryAttempt => TimeSpan.FromSeconds(Math.Pow(2, retryAttempt)),
                    (exception, timeSpan, retryCount, context) =>
                    {
                        Logger.Log(Constants.Logging.CATEGORY, System.Diagnostics.TraceEventType.Warning, $"Retrying detokenizer, attempt {retryCount}", null, exception);
                    });

            var request = new TokenRequest
            {
                application = "PL.CurrentCarrierContribution",
                applicationContext = "sample",
                caller = "sample",
                data = from.Trim(),
                requestedBy = "sample",
                scheme = "DriversLicense"
            };

            var response = retryPolicy.ExecuteAsync(async () => await TokenApi.Detokenize(request, ConfigurationManager.AppSettings["ApimSubscriptionKey"]));

            if (response == null)
            {
                throw new Exception("Failed to Detokenize Drivers License");
            }

            return response.Result.data;
        }

        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return string.Empty;
            }

            return (string)from;
        }
    }
}