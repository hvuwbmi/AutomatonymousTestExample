﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EarsRiskAlertEngineFactory.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  ---------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;
    using FileMappers.EarsRiskAlert;

    public class EarsRiskAlertEngineFactory
    {
        public MultiRecordEngine CreateEngine()
        {
            var engine = this.BuildEngine();
            return engine;
        }

        private MultiRecordEngine BuildEngine()
        {
            var engine = new MultiRecordEngine(
                typeof(EarsRiskAlertDetailRequest),
                typeof(EarsRiskAlertHeader),
                typeof(EarsRiskAlertTrailer));

            engine.RecordSelector = new RecordTypeSelector(this.EarsRiskAlertCustomSelector);
            return engine;
        }

        private Type EarsRiskAlertCustomSelector(MultiRecordEngine engine, string recordLine)
        {
            // This will be used when we start reading EARS/RiskAlert output records. This isn't happening just yet.
            return null;
        }
    }
}
