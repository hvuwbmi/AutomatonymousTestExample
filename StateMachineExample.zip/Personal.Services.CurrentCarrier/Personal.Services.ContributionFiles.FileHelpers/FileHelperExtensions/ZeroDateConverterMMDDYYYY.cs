﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ZeroDateConverterMMDDYYYY.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using global::FileHelpers;

    public class ZeroDateConverterMMDDYYYY : ConverterBase
    {
        [SuppressMessage("StyleCop.CSharp.ReadabilityRules", "SA1126:PrefixCallsCorrectly", Justification = "Reviewed.")]
        public override object StringToField(string @from)
        {
            if (from == null)
            {
                return null;
            }

            if (from == "00000000")
            {
                return null;
            }

            DateTime val;
            if (!DateTime.TryParseExact(from.Trim(), "MMddyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out val))
            {
                return null;
            }

            return val;
        }

        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return "00000000";
            }

            return Convert.ToDateTime(from).ToString("MMddyyyy");
        }
    }
}
