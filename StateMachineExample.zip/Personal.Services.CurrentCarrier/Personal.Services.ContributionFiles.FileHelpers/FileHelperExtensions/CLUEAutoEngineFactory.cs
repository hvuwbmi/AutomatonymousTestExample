﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CLUEAutoEngineFactory.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  ---------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;
    using FileMappers.CLUEAuto;
    
    public class CLUEAutoEngineFactory
    {
        public MultiRecordEngine CreateEngine()
        {
            var engine = this.BuildEngine();
            return engine;
        }

        private MultiRecordEngine BuildEngine()
        {
            var engine = new MultiRecordEngine(
                typeof(CLUEAutoHeader),
                typeof(CLUEAutoLossTransaction),
                typeof(CLUEAutoTrailer));

            engine.RecordSelector = new RecordTypeSelector(this.CLUEAutoCustomSelector);
            return engine;
        }

        private Type CLUEAutoCustomSelector(MultiRecordEngine engine, string recordLine)
        {
            if (recordLine.StartsWith("##!!SAT#"))
            {
                return typeof(CLUEAutoHeader);
            }

            if (recordLine.StartsWith("##!!SAC#"))
            {
                return typeof(CLUEAutoTrailer);
            }

            if (recordLine.Length > 256)
            {
                return typeof(CLUEAutoLossTransaction);
            }

            return null;
        }
    }
}
