﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EngineFactory.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;
    using FileMappers.CurrentCarrier;
    
    public class EngineFactory 
    {
        public enum EngineType
        {
            CLUEAuto,
            CurrentCarrier,
            EARS,
            EarsInbound
        }

        public MultiRecordEngine CreateEngine(EngineType type)
        {
            switch (type)
            {
                case EngineType.CLUEAuto:
                    return new CLUEAutoEngineFactory().CreateEngine();
                case EngineType.CurrentCarrier:
                    return new CurrentCarrierEngineFactory().CreateEngine();
                case EngineType.EARS:
                    return new EarsRiskAlertEngineFactory().CreateEngine();
                case EngineType.EarsInbound:
                    return new EarsRiskAlertInboundEngineFactory().CreateEngine();
                default:
                    throw new NotSupportedException("Engine Type Not Supported.");
            }
        }
    }
}