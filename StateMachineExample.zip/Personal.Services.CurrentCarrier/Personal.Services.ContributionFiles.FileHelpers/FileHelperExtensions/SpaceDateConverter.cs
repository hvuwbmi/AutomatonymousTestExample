﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SpaceDateConverter.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using System.Globalization;
    using global::FileHelpers;

    public class SpaceDateConverter : ConverterBase
    {
        public override object StringToField(string @from)
        {
            if (from == null)
            {
                return null;
            }

            if (from == "        ")
            {
                return null;
            }

            DateTime val;
            if (!DateTime.TryParseExact(from.Trim(), "MMddyyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out val))
            {
                return null;
            }

            return val;
        }

        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return "        ";
            }

            return Convert.ToDateTime(from).ToString("MMddyyyy");
        }
    }
}