﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="StringUppercaseConverter.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using global::FileHelpers;

    public class StringUppercaseConverter : ConverterBase
    {
        public override object StringToField(string from)
        {
            return from.ToUpper();
        }

        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return string.Empty;
            }

            return from.ToString().ToUpper();
        }
    }
}
