﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInboundEngineFactory.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;
    using FileMappers.EarsRiskInbound;

    public class EarsRiskAlertInboundEngineFactory
    {
        public MultiRecordEngine CreateEngine()
        {
            var engine = this.BuildEngine();
            return engine;
        }

        private MultiRecordEngine BuildEngine()
        {
            var engine = new MultiRecordEngine(
                typeof(EarsRiskAlertInboundHeader),
                typeof(EarsRiskAlertInbound01),
                typeof(EarsRiskAlertInbound02),
                typeof(EarsRiskAlertInbound03),
                typeof(EarsRiskAlertInbound04),
                typeof(EarsRiskAlertInbound05),
                typeof(EarsRiskAlertInbound06),
                typeof(EarsRiskAlertInbound07),
                typeof(EarsRiskAlertInboundTrailer));

            engine.RecordSelector = new RecordTypeSelector(this.EarsRiskAlertCustomSelector);
            return engine;
        }

        private Type EarsRiskAlertCustomSelector(MultiRecordEngine engine, string recordLine)
        {
            if (recordLine.Length == 0)
            {
                return null;
            }

            if (recordLine.StartsWith("FH"))
            {
                return typeof(EarsRiskAlertInboundHeader);
            }

            if (recordLine.StartsWith("FT"))
            {
                return typeof(EarsRiskAlertInboundTrailer);
            }

            if (recordLine.StartsWith("01"))
            {
                return typeof(EarsRiskAlertInbound01);
            }

            if (recordLine.StartsWith("02"))
            {
                return typeof(EarsRiskAlertInbound02);
            }

            if (recordLine.StartsWith("03"))
            {
                return typeof(EarsRiskAlertInbound03);
            }

            if (recordLine.StartsWith("04"))
            {
                return typeof(EarsRiskAlertInbound04);
            }

            if (recordLine.StartsWith("05"))
            {
                return typeof(EarsRiskAlertInbound05);
            }

            if (recordLine.StartsWith("06"))
            {
                return typeof(EarsRiskAlertInbound06);
            }

            if (recordLine.StartsWith("07"))
            {
                return typeof(EarsRiskAlertInbound07);
            }

            return null;
        }
    }
}