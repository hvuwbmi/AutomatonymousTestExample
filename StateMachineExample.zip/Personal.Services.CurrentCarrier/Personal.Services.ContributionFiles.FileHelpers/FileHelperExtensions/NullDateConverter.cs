﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NullDateConverter.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;

    public class NullDateConverter : ConverterBase
    {
        public override object StringToField(string @from)
        {
            if (from == null)
            {
                return null;
            }

            DateTime val;
            if (!DateTime.TryParseExact(from.Trim(), "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out val))
            {
                return null;
            }

            return val;
        }
        
        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return string.Empty;
            }

            return Convert.ToDateTime(from).ToString("yyyyMMdd");
        }
    }
}