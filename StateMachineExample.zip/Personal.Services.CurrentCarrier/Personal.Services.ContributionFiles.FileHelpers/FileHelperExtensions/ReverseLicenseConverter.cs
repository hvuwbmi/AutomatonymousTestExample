﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ReverseLicenseConverter.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System.Configuration;
    using global::FileHelpers;
    using Models;
    using Refit;
    using ServiceInterfaces;
    using Utilities;

    public class ReverseLicenseConverter : ConverterBase
    {
        private static ITokenApi tokenApi;

        /// <summary>
        /// The tokenization API object to use to detokenize the drivers license. Typically this does not need to
        /// be assigned prior to use, but unit tests should assign a mock object to this.
        /// </summary>
        public static ITokenApi TokenApi
        {
            get
            {
                if (tokenApi == null)
                {
                    tokenApi = RestService.For<ITokenApi>(ConfigurationManager.AppSettings["ApimUrl"]);
                }

                return tokenApi;
            }

            set
            {
                tokenApi = value;
            }
        }

        public override object StringToField(string @from)
        {
            var response = AsyncHelper.RunSync<TokenResponse>(() => TokenApi.Tokenize(
                new TokenRequest()
                {
                    application = "sample",
                    applicationContext = "sample",
                    caller = "sample",
                    data = @from.Trim(),
                    requestedBy = "sample",
                    scheme = "DriversLicense"
                }, 
                ConfigurationManager.AppSettings["ApimSubscriptionKey"]));

            return response.data;
        }

        public override string FieldToString(object from)
        {
            if (from == null)
            {
                return string.Empty;
            }

            return (string)from;
        }
    }
}