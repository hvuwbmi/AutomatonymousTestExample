﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PadLeftDecimalConverter.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;

    public class PadLeftDecimalConverter : ConverterBase
    {
        private readonly int size;

        public PadLeftDecimalConverter(int size)
        {
            this.size = size;
        }

        public override object StringToField(string from)
        {
            return Convert.ToDecimal(decimal.Parse(from) / 100);
        }

        public override string FieldToString(object from)
        {
            return ((decimal)from).ToString("0.00").Replace(".", string.Empty).PadLeft(this.size, '0');
        }
    }
}