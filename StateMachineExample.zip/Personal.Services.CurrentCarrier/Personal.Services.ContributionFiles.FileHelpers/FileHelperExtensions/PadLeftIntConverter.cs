﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="PadLeftIntConverter.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using global::FileHelpers;

    public class PadLeftIntConverter : ConverterBase
    {
        private readonly int size;

        public PadLeftIntConverter(int size)
        {
            this.size = size;
        }

        public override object StringToField(string from)
        {
            return int.Parse(from);
        }

        public override string FieldToString(object from)
        {
            return from.ToString().PadLeft(this.size, '0');
        }
    }
}