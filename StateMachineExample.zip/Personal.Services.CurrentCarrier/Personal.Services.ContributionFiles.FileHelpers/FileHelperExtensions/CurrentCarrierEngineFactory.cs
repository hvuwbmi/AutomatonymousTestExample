﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CurrentCarrierEngineFactory.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions
{
    using System;
    using global::FileHelpers;
    using FileMappers.CurrentCarrier;

    public class CurrentCarrierEngineFactory
    {
        public MultiRecordEngine CreateEngine()
        {
            var engine = this.BuildCCEngine();
            return engine;
        }

        private MultiRecordEngine BuildCCEngine()
        {
            var engine = new MultiRecordEngine(
                typeof(CurrentCarrierFIRSTPropertyInfoFR01),
                typeof(CurrentCarrierFIRStPolicyInfoFP01),
                typeof(CurrentCarrierPolicyInfoNP01),
                typeof(CurrentCarrierPolicyInformationRemovalDP01),
                typeof(CurrentCarrierPropertyInfoPR01),
                typeof(CurrentCarrierSubjectInfoSJ01),
                typeof(CurrentCarrierVehicleVR01),
                typeof(CurrentCarrierMiscellaneousInfoMR01),
                typeof(CurrentCarrierHeader),
                typeof(CurrentCarrierTrailer));

            engine.RecordSelector = new RecordTypeSelector(this.CurrentCarrierCustomSelector);
            return engine;
        }

        private Type CurrentCarrierCustomSelector(MultiRecordEngine engine, string recordLine)
        {
            if (recordLine.Length == 0)
            {
                return null;
            }

            if (recordLine.StartsWith("##!!SAT#"))
            {
                return typeof(CurrentCarrierTrailer);
            }

            if (recordLine.StartsWith("##!!SAC#"))
            {
                return typeof(CurrentCarrierHeader);
            }

            if (recordLine.StartsWith("NP01"))
            {
                return typeof(CurrentCarrierPolicyInfoNP01);
            }

            if (recordLine.StartsWith("FP01"))
            {
                return typeof(CurrentCarrierFIRStPolicyInfoFP01);
            }

            if (recordLine.StartsWith("SJ01"))
            {
                return typeof(CurrentCarrierSubjectInfoSJ01);
            }

            if (recordLine.StartsWith("PR01"))
            {
                return typeof(CurrentCarrierPropertyInfoPR01);
            }

            if (recordLine.StartsWith("FR01"))
            {
                return typeof(CurrentCarrierFIRSTPropertyInfoFR01);
            }

            if (recordLine.StartsWith("VR01"))
            {
                return typeof(CurrentCarrierVehicleVR01);
            }

            if (recordLine.StartsWith("DP01"))
            {
                return typeof(CurrentCarrierPolicyInformationRemovalDP01);
            }

            if (recordLine.StartsWith("MR01"))
            {
                return typeof(CurrentCarrierMiscellaneousInfoMR01);
            }

            return null;
        }
    }
}