﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CLUEAutoHeader.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Globalization;
    using FileHelperExtensions;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CLUEAutoHeader
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string Constant = "##!!";

        [FieldFixedLength(4)]
        [FieldOrder(2)]
        public string RecordIdentifier = "SAC#";

        [FieldFixedLength(2)]
        [FieldConverter(ConverterKind.Date, "yy")]
        [FieldOrder(3)]
        public DateTime TransmissionYear;

        [FieldFixedLength(3)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldOrder(4)]
        public int TransmissionDayOfYear;

        [FieldFixedLength(4)]
        [FieldConverter(ConverterKind.Date, "HHmm")]
        [FieldOrder(5)]
        public DateTime TransmissionTime;

        [FieldFixedLength(4)]
        [FieldOrder(6)]
        public string ApplicationId = Constants.LexisData.APPLICATION_ID_CLUE;

        [FieldFixedLength(10)]
        [FieldOrder(7)]
        public string Filler1;

        [FieldFixedLength(9)]
        [FieldOrder(8)]
        public string SourceId = Constants.LexisData.SOURCE_ID;

        [FieldFixedLength(9)]
        [FieldOrder(9)]
        public string DestinationId = "E11967000";

        [FieldFixedLength(20)]
        [FieldOrder(10)]
        public string CustomerName = "WEST BEND MUTUAL INS";

        [FieldFixedLength(37)]
        [FieldOrder(11)]
        public string Filler2;

        [FieldFixedLength(30)]
        [FieldOrder(12)]
        public string DestinationFileName = "CLUE_HISTORY";

        [FieldFixedLength(8)]
        [FieldOrder(13)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ReportingBeginDate;

        [FieldFixedLength(8)]
        [FieldOrder(14)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ReportingEndDate;

        [FieldFixedLength(104)]
        [FieldOrder(17)]
        public string Filler3;

        public CLUEAutoHeader Map(DateTime nowUtc, string lastRunDate, WestBend.Core.ILogger logger)
        {
            var lastRunDateTime = DateTime.ParseExact(lastRunDate, Constants.Formatters.LastRunDateFormat, CultureInfo.InvariantCulture);

            DateTime localTime = nowUtc;
            DateTime localLastRun = lastRunDateTime;
            try
            {
                TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
                localTime = TimeZoneInfo.ConvertTimeFromUtc(nowUtc, cstZone);
                localLastRun = TimeZoneInfo.ConvertTimeFromUtc(lastRunDateTime, cstZone);
            }
            catch (Exception ex)
            {
                logger.Log(Constants.Logging.CATEGORYCLUEAUTO, System.Diagnostics.TraceEventType.Error, "Failed to convert UTC time to CST", null, ex);
            }

            logger.Log(Constants.Logging.CATEGORYCLUEAUTO, System.Diagnostics.TraceEventType.Information, $"Converted UTC time from '{nowUtc.ToString()}' to CST time '{localTime.ToString()}'");

            this.TransmissionTime = nowUtc;
            this.TransmissionYear = nowUtc;
            this.TransmissionDayOfYear = nowUtc.DayOfYear;
            this.ReportingBeginDate = localLastRun.AddDays(1); // Reporting date is the business day, not the last run date.
            this.ReportingEndDate = localTime;

            return this;
        }
    }
}