﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CLUEAutoLossTransaction.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CLUEAuto
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using global::FileHelpers;
    using FileMappers;
    using Models;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CLUEAutoLossTransaction
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1Prefix;

        [FieldFixedLength(20)]
        [FieldOrder(2)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1LastName;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1FirstName;

        [FieldFixedLength(15)]
        [FieldOrder(4)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1MiddleName;

        [FieldFixedLength(3)]
        [FieldOrder(5)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1Suffix;

        [FieldFixedLength(9)]
        [FieldOrder(6)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1AddressHouseNumber;

        [FieldFixedLength(20)]
        [FieldOrder(7)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1AddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(8)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1AddressApartmentNumber;

        [FieldFixedLength(20)]
        [FieldOrder(9)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1AddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(10)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1AddressState;

        [FieldFixedLength(5)]
        [FieldAlign(AlignMode.Left, '0')]
        [FieldOrder(11)]
        public string PolicyHolder1AddressZipCode;

        [FieldFixedLength(4)]
        [FieldAlign(AlignMode.Left, '0')]
        [FieldOrder(12)]
        public string PolicyHolder1AddressZipCodePlus4;

        [FieldFixedLength(10)]
        [FieldOrder(13)]
        public string Filler1;

        [FieldFixedLength(9)]
        [FieldOrder(14)]
        public string PolicyHolder1SocialSecurityNumber = "000000000";

        [FieldFixedLength(8)]
        [FieldOrder(15)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.MMDDYYYY)]
        public DateTime PolicyHolder1DOB;

        [FieldFixedLength(25)]
        [FieldOrder(16)]
        [FieldConverter(typeof(LicenseConverter))]
        public string PolicyHolder1DLNumber;

        [FieldFixedLength(2)]
        [FieldOrder(17)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1DLState;

        [FieldFixedLength(1)]
        [FieldOrder(18)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder1Sex;

        [FieldFixedLength(28)]
        [FieldOrder(19)]
        public string Filler2;

        [FieldFixedLength(4)]
        [FieldOrder(20)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2Prefix;

        [FieldFixedLength(20)]
        [FieldOrder(21)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2LastName;

        [FieldFixedLength(20)]
        [FieldOrder(22)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2FirstName;

        [FieldFixedLength(15)]
        [FieldOrder(23)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2MiddleName;

        [FieldFixedLength(3)]
        [FieldOrder(24)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2Suffix;

        [FieldFixedLength(9)]
        [FieldOrder(25)]
        public string PolicyHolder2SocialSecurityNumber = "000000000";

        [FieldFixedLength(8)]
        [FieldOrder(26)]
        [FieldConverter(typeof(ZeroDateConverterMMDDYYYY))]
        public DateTime? PolicyHolder2DOB;

        [FieldFixedLength(25)]
        [FieldOrder(27)]
        [FieldConverter(typeof(LicenseConverter))]
        public string PolicyHolder2DLNumber;

        [FieldFixedLength(2)]
        [FieldOrder(28)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2DLState;

        [FieldFixedLength(1)]
        [FieldOrder(29)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string PolicyHolder2Sex;

        [FieldFixedLength(18)]
        [FieldOrder(30)]
        public string Filler3;

        [FieldFixedLength(4)]
        [FieldOrder(31)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorPrefix;

        [FieldFixedLength(20)]
        [FieldOrder(32)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorLastName;

        [FieldFixedLength(20)]
        [FieldOrder(33)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorFirstName;

        [FieldFixedLength(15)]
        [FieldOrder(34)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorMiddleName;

        [FieldFixedLength(3)]
        [FieldOrder(35)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorSuffix;

        [FieldFixedLength(9)]
        [FieldOrder(36)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorAddressHouseNumber;

        [FieldFixedLength(20)]
        [FieldOrder(37)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorAddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(38)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorAddressApartmentNumber;

        [FieldFixedLength(20)]
        [FieldOrder(39)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(40)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorAddressState;

        [FieldFixedLength(5)]
        [FieldAlign(AlignMode.Left, '0')]
        [FieldOrder(41)]
        public string VehicleOperatorAddressZipCode;

        [FieldFixedLength(4)]
        [FieldAlign(AlignMode.Left, '0')]
        [FieldOrder(42)]
        public string VehicleOperatorAddressZipCodePlus4;

        [FieldFixedLength(10)]
        [FieldOrder(43)]
        public string Filler4;

        [FieldFixedLength(9)]
        [FieldOrder(44)]
        public string VehicleOperatorSocialSecurityNumber = "000000000";

        [FieldFixedLength(8)]
        [FieldOrder(45)]
        [FieldConverter(typeof(ZeroDateConverterMMDDYYYY))]
        public DateTime? VehicleOperatorDOB;

        [FieldFixedLength(25)]
        [FieldOrder(46)]
        [FieldConverter(typeof(LicenseConverter))]
        public string VehicleOperatorDLNumber;

        [FieldFixedLength(2)]
        [FieldOrder(47)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorDLState;

        [FieldFixedLength(1)]
        [FieldOrder(48)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorSex;

        [FieldFixedLength(1)]
        [FieldOrder(49)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string VehicleOperatorRelationship;

        [FieldFixedLength(28)]
        [FieldOrder(50)]
        public string Filler5;

        [FieldFixedLength(5)]
        [FieldOrder(51)]
        public string ContribuitingCompanyIdentificationNumber = "00964";

        [FieldFixedLength(20)]
        [FieldOrder(52)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(53)]
        public string PolicyType = "PA";

        [FieldFixedLength(18)]
        [FieldOrder(54)]
        public string Filler6;

        [FieldFixedLength(20)]
        [FieldOrder(55)]
        public string ClaimNumber;

        [FieldFixedLength(2)]
        [FieldOrder(56)]
        public string ClaimType;

        [FieldFixedLength(8)]
        [FieldOrder(57)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.MMDDYYYY)]
        public DateTime ClaimDate;

        [FieldFixedLength(9)]
        [FieldOrder(58)]
        [FieldConverter(typeof(PadLeftIntConverter), 9)]
        public int ClaimAmount;

        [FieldFixedLength(1)]
        [FieldOrder(59)]
        public string ClaimReportingStatus = "A";

        [FieldFixedLength(25)]
        [FieldOrder(60)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string InsuredVehicleVIN;

        [FieldFixedLength(4)]
        [FieldOrder(61)]
        public string InsuredVehicleModelYear = "0000";

        [FieldFixedLength(40)]
        [FieldOrder(62)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string InsuredVehicleMakeAndModel;

        [FieldFixedLength(1)]
        [FieldOrder(63)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string InsuredVehicleDisposition;

        [FieldFixedLength(1)]
        [FieldOrder(64)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string ClaimDisposition;

        [FieldFixedLength(1)]
        [FieldOrder(65)]
        [FieldConverter(typeof(StringUppercaseConverter))]
        public string FaultIndicator;

        [FieldFixedLength(8)]
        [FieldOrder(66)]
        [FieldConverter(typeof(ZeroDateConverterMMDDYYYY))]
        public DateTime? DateOfFirstPayment;

        [FieldFixedLength(1)]
        [FieldOrder(67)]
        public string CAIndicator1;

        [FieldFixedLength(1)]
        [FieldOrder(68)]
        public string CAIndicator2;

        [FieldFixedLength(1)]
        [FieldOrder(69)]
        public string CAIndicator3;

        [FieldFixedLength(1)]
        [FieldOrder(70)]
        public string CAIndicator4;

        [FieldFixedLength(24)]
        [FieldOrder(71)]
        public string Filler7;

        [FieldFixedLength(1)]
        [FieldOrder(72)]
        public string RecordVersionNumber = "2";

        public async Task<CLUEAutoLossTransaction> Map(PolicyRs policyRs, string driverNumber, string driverType, string vehicleNumber)
        {
            await policyRs.Policy[0].Map(this, driverNumber, driverType, vehicleNumber);

            return this;
        }
    }
}
