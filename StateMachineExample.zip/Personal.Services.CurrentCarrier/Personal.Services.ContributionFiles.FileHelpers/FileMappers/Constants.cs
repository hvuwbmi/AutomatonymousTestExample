﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="Constants.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers
{
    using System.Diagnostics.CodeAnalysis;

    [SuppressMessage("StyleCop.CSharp.NamingRules", "SA1310:FieldNamesMustNotContainUnderscore", Justification = "Reviewed.")]
    public static class Constants
    {
        public static class Logging
        {
            public const string CATEGORYCLUEAUTO = "PL.Services.Claims.ClueAuto";

            public const string CATEGORY = "PL.CurrentCarrier";
        }

        public static class Formatters
        {
            public const string YYYYMMDD = "yyyyMMdd";

            public const string JULLIAN_DATE = "yydddHHmm";

            public const string MMDDYYYY = "MMddyyyy";
            public const string MMDDYYYYSlash = "MM/dd/yyyy";

            public const string LastRunDateFormat = "yyyyMMddHHmmssffff";
        }

        public static class LexisData
        {
            public const string CONTRIBUTING_COMPANY = "00964";
            public const string INSURANCE_TYPE = "PA";
            public const string SOURCE_ID = "B50289FTP";
            public const string APPLICATION_ID = "CARR";
            public const string APPLICATION_ID_CLUE = "CLUE";
        }

        public static class Azure
        {
            public static class TableStorage
            {
                public const string CurrentCarrier = "CurrentCarrier";
                public const string ThirdPartyContribution = "ThirdPartyContribution";
                public const string RunDateRowKey = "1LR2";
                public const string ClueAutoPartitionKey = "ClueAuto";
            }

            public static class BlobStorage
            {
                public const string TextContentType = "text/plain";
                public const string BlobType = "BlockBlob";
                public const string ContainerName = "pl-third-party-integration";
                public const string FolderName = "LexisNexis.CurrentCarrier";
                public const string FolderNameClueAuto = "LexisNexis.ClueAuto.Out";
                public const string FolderNameClueAutoOutput = "LexisNexis.Contribution";

                public const string TriggerFileClueAuto = "trigger_ClueAuto.txt";
                public const string TriggerFileCurrentCarrier = "trigger_currentCarrier.txt";

                public static class EARSRisk
                {
                    public const string Folder = "EARS";
                    public const string FileName = "611852.EAR";
                }
            }
        }

        public static class AppSettingKeys
        {
            public const string ApimUrl = "ApimUrl";
            public const string ApimSubscriptionKey = "ApimSubscriptionKey";
            public const string FileRetentionDays = "FileRetentionDays";
            public const string LexisNexisEnvironment = "LexisNexisEnvironment";
            public const string SERVICENAME = "PL.CurrentCarrier";
        }

        public static class ClaimStatusValue
        {
            public const string SUBROGATED = "S";
        }

        public static class ClaimReserveTypeCode
        {
            public const string SUBROGATION = "B";
        }

        public static class BusinessPurposeTypeCode
        {
            public const string NewBusiness = "NBQ";
            public const string Endorsement = "PCH";
            public const string Cancel = "XLC";
            public const string Reinstate = "REI";
            public const string Rewrite = "REW";
            public const string Reissue = "RIX";
            public const string Renewal = "RWL";
            public const string NonRenewal = "RWX";
        }

        public static class ModInfo
        {
            public const string Added = "A";
            public const string Deleted = "D";
            public const string Modified = "M";
        }

        public static class Acord
        {
            public static class CoverageCode
            {
                public const string AutoLiability = "AL";
                public const string AutoLoanCollision = "LNCOL";
                public const string AutoLoanComprehensive = "LNCMP";
                public const string BodilyInjury = "BI";
                public const string BroadenedCollision = "BCOLL";
                public const string Collision = "COLL";
                public const string CombinedSingleLimit = "CSL";
                public const string Comprehensive = "COMP";
                public const string CustomizedEquipment = "CUSTE";
                public const string EmergencyRoadsideAssistance = "ROAD";
                public const string FinancialResponsibilityFiling = "FRESP";
                public const string LimitedPropertyDamageLiability = "LPD";
                public const string MedicalPayments = "MEDPM";
                public const string MichiganCatastrophicClaimsAssociation = "MCCA";
                public const string NewCarReplacementAndGapCoverage = "RRGAP";
                public const string PersonalInjuryProtection = "PIP";
                public const string PropertyDamage = "PD";
                public const string PropertyProtectionInsurance = "PPI";
                public const string TheftPreventionAuthorityCharge = "TPAC";
                public const string TransportationExpense = "TRNEX";
                public const string UninsuredMotorist = "UM";
                public const string UninsuredMotoristCSL = "UMCSL";
                public const string UnderinsuredMotorist = "UNDUM";
                public const string UnderinsuredMotoristCSL = "UNCSL";
                public const string WageLossBenefit = "WLB";
            }
        }

        public static class CurrentCarrier
        {
            public static class CoverageCode
            {
                public const string BodilyInjury = "BI";
                public const string Collision = "CO";
                public const string Comprehensive = "CP";
                public const string CombinedSingleLimit = "CS";
                public const string MedicalExpenses = "ME";
                public const string MedicalPayments = "MP";
                public const string UninsuredMotoristBodilyInjury = "NB";
                public const string UninsuredMotoristPropertyDamage = "NP";
                public const string Other = "OT";
                public const string PropertyDamage = "PD";
                public const string PersonalInjuryProtection = "PI";
                public const string RentalReimbursement = "RR";
                public const string StatedValue = "SV";
                public const string TowingAndLabor = "TL";
                public const string UnderinsuredMotoristBodilyInjury = "UB";
                public const string UninsuredMotoristCSL = "UM";
                public const string Umbrella = "UMBR";
                public const string UninsuredUnderinsuredCombinedMotoristsBodilyInjury = "UMUB";
                public const string UninsuredUnderinsuredCombinedMotoristsPropertyDamage = "UMUP";
                public const string UnderinsuredMotoristCSL = "UN";
                public const string UnderinsuredMotoristPropertyDamage = "UP";
                public const string UninsuredUnderinsuredCombinedMotoristsCSL = "US";
            }

            public static class NotificationActionCode
            {
                public const string DoNotSendNotice = "999";
                public const string InterestRemoved = "IRM";
                public const string LienholderChanged = "LNC";
                public const string NewBusiness = "NBS";
                public const string PolicyChange = "PCH";
                public const string Reinstatement = "REI";
                public const string Rewrite = "REW";
                public const string Reissue = "RIX";
                public const string Renewal = "RWL";
                public const string NonRenewal = "RWO";
                public const string VehicleDeleted = "VDL";
                public const string VehicleChanged = "VHC";
                public const string CancellationNonPayment = "XLN";
                public const string CompanyCancelled = "XLO";
                public const string CancellationCustomerRequest = "XLQ";
            }
        }
    }
}