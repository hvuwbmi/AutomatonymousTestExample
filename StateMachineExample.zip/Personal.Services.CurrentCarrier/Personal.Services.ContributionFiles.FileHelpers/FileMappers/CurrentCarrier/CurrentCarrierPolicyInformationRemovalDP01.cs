﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierPolicyInformationRemovalDP01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;
    using FileMappers;
    
    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierPolicyInformationRemovalDP01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "DP01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingComapny = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(5)]
        [FieldOrder(5)]
        public string NAICCode = "15350";

        public DateTime ChangeEffectiveDateP
        {
            get { return DateTime.MinValue; }
            set { }
        }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }
    }
}