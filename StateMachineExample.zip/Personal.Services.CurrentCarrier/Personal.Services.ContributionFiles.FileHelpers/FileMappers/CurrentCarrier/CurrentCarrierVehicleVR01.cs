﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierVehicleVR01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using System.Linq;
    using FileHelperExtensions;
    using global::FileHelpers;
    using Models;
    using PolicyRsPolicyPersAutoLineBusinessVehicle = Models.PolicyRsPolicyPersAutoLineBusinessVehicle;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierVehicleVR01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "VR01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date,  Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(25)]
        [FieldOrder(6)]
        public string VIN;

        [FieldFixedLength(2)]
        [FieldOrder(7)]
        public string VehicleRegisteredState;

        [FieldFixedLength(2)]
        [FieldOrder(8)]
        public string VehicleType = "02";

        [FieldFixedLength(1)]
        [FieldOrder(9)]
        public string VehicleStatus;

        [FieldFixedLength(8)]
        [FieldOrder(10)]
        [FieldConverter(typeof(ZeroDateConverter))]
        public DateTime? VehicleStatusDate;

        [FieldFixedLength(4)]
        [FieldOrder(11)]
        public string VehicleCancellationReason;

        [FieldFixedLength(3)]
        [FieldOrder(12)]
        public string NonCoverageReasonCode;

        [FieldFixedLength(10)]
        [FieldOrder(13)]
        public string LicensePlateNumber;

        [FieldFixedLength(30)]
        [FieldOrder(14)]
        public string StateTrackingNumber;

        [FieldFixedLength(10)]
        [FieldOrder(15)]
        public string InternalQuoteBack;

        [FieldFixedLength(8)]
        [FieldOrder(16)]
        [FieldConverter(ConverterKind.Date,  Constants.Formatters.YYYYMMDD)]
        public DateTime AddDate;

        /// <summary>
        /// Insured Sequence Number is the InsurerId from the driver listed as the Rated Driver Ref for this vehicle.
        /// The format of this field must match the format of <see cref="CurrentCarrierSubjectInfoSJ01.SequenceNumber"/>.
        /// </summary>
        [FieldFixedLength(3)]
        [FieldOrder(17)]
        [FieldAlign(AlignMode.Right, '0')]
        public string InsuredSequenceNumber;

        [FieldFixedLength(6)]
        [FieldOrder(18)]
        [FieldAlign(AlignMode.Left, '0')]
        public string Mileage;

        [FieldFixedLength(3)]
        [FieldOrder(19)]
        public string ALIRtsActivityCode;

        [FieldFixedLength(1)]
        [FieldOrder(20)]
        public string TelematicsInd;

        [FieldFixedLength(3)]
        [FieldOrder(21)]
        public string TownshipCode;

        [FieldFixedLength(3)]
        [FieldOrder(22)]
        public string RegistrationPlateType;

        [FieldFixedLength(1)]
        [FieldOrder(23)]
        public string RegistrationPlateColor;

        [FieldFixedLength(1)]
        [FieldOrder(24)]
        public string RideShareIndicator = " ";

        [FieldFixedLength(99)]
        [FieldOrder(25)]
        public string Filler;

        [FieldFixedLength(3)]
        [FieldOrder(26)]
        [FieldAlign(AlignMode.Left, '0')]
        public string CellPhoneCountryCode;

        [FieldFixedLength(3)]
        [FieldOrder(27)]
        [FieldAlign(AlignMode.Left, '0')]
        public string CellPhoneAreaCode;

        [FieldFixedLength(7)]
        [FieldOrder(28)]
        [FieldAlign(AlignMode.Left, '0')]
        public string CellPhoneNumber;

        [FieldFixedLength(724)]
        [FieldOrder(29)]
        public string Filler2;
        
        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        public CurrentCarrierVehicleVR01 Map(PolicyRs policyRs, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, policyRs.BusinessPurposeTypeCd, vehicle.ModInfoActionCd);
            vehicle.Map(this, policyRs.BusinessPurposeTypeCd, policyRs.Policy[0]?.PersAutoLineBusiness[0]);

            return this;
        }
    }
}