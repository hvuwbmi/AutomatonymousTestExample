﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierPropertyInfoPR01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;
    using Models;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierPropertyInfoPR01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "PR01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(25)]
        [FieldOrder(6)]
        public string Vin;

        [FieldFixedLength(4)]
        [FieldOrder(7)]
        public string VehicleModelYear;

        [FieldFixedLength(20)]
        [FieldOrder(8)]
        public string VehicleMake;

        [FieldFixedLength(20)]
        [FieldOrder(9)]
        public string VehicleModel;

        [FieldFixedLength(9)]
        [FieldOrder(10)]
        public string LocationAddressNumber;

        [FieldFixedLength(20)]
        [FieldOrder(11)]
        public string LocationAddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(12)]
        public string LocationAddressAptNumber;

        [FieldFixedLength(20)]
        [FieldOrder(13)]
        public string LocationAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(14)]
        public string LocationAddressState;

        [FieldFixedLength(5)]
        [FieldOrder(15)]
        public string LocationAddressZip = "00000";

        [FieldFixedLength(4)]
        [FieldOrder(16)]
        public string LocationAddressZip4 = "0000";

        [FieldFixedLength(100)]
        [FieldOrder(17)]
        public string LexisNexisInternalUse1;

        [FieldFixedLength(1)]
        [FieldOrder(18)]
        public string BusinessUseIndicator;

        [FieldFixedLength(10)]
        [FieldOrder(19)]
        public string LexisNexisInternalUse2 = "0000000000";

        [FieldFixedLength(4)]
        [FieldOrder(20)]
        public string CoverageType1;

        [FieldFixedLength(8)]
        [FieldOrder(21)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit1;

        [FieldFixedLength(8)]
        [FieldOrder(22)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit1;

        [FieldFixedLength(8)]
        [FieldOrder(23)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit1;

        [FieldFixedLength(4)]
        [FieldOrder(24)]
        public string CoverageType2;

        [FieldFixedLength(8)]
        [FieldOrder(25)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit2;

        [FieldFixedLength(8)]
        [FieldOrder(26)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit2;

        [FieldFixedLength(8)]
        [FieldOrder(27)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit2;

        [FieldFixedLength(4)]
        [FieldOrder(28)]
        public string CoverageType3;

        [FieldFixedLength(8)]
        [FieldOrder(29)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit3;

        [FieldFixedLength(8)]
        [FieldOrder(30)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit3;

        [FieldFixedLength(8)]
        [FieldOrder(31)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit3;

        [FieldFixedLength(4)]
        [FieldOrder(32)]
        public string CoverageType4;

        [FieldFixedLength(8)]
        [FieldOrder(33)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit4;

        [FieldFixedLength(8)]
        [FieldOrder(34)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit4;

        [FieldFixedLength(8)]
        [FieldOrder(35)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit4;

        [FieldFixedLength(4)]
        [FieldOrder(36)]
        public string CoverageType5;

        [FieldFixedLength(8)]
        [FieldOrder(37)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit5;

        [FieldFixedLength(8)]
        [FieldOrder(38)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit5;

        [FieldFixedLength(8)]
        [FieldOrder(39)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit5;

        [FieldFixedLength(4)]
        [FieldOrder(40)]
        public string CoverageType6;

        [FieldFixedLength(8)]
        [FieldOrder(41)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit6;

        [FieldFixedLength(8)]
        [FieldOrder(42)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit6;

        [FieldFixedLength(8)]
        [FieldOrder(43)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit6;

        [FieldFixedLength(4)]
        [FieldOrder(44)]
        public string CoverageType7;

        [FieldFixedLength(8)]
        [FieldOrder(45)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit7;

        [FieldFixedLength(8)]
        [FieldOrder(46)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit7;

        [FieldFixedLength(8)]
        [FieldOrder(47)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit7;

        [FieldFixedLength(4)]
        [FieldOrder(48)]
        public string CoverageType8;

        [FieldFixedLength(8)]
        [FieldOrder(49)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit8;

        [FieldFixedLength(8)]
        [FieldOrder(50)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit8;

        [FieldFixedLength(8)]
        [FieldOrder(51)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit8;

        [FieldFixedLength(4)]
        [FieldOrder(52)]
        public string CoverageType9;

        [FieldFixedLength(8)]
        [FieldOrder(53)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit9;

        [FieldFixedLength(8)]
        [FieldOrder(54)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit9;

        [FieldFixedLength(8)]
        [FieldOrder(55)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit9;

        [FieldFixedLength(4)]
        [FieldOrder(56)]
        public string CoverageType10;

        [FieldFixedLength(8)]
        [FieldOrder(57)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit10;

        [FieldFixedLength(8)]
        [FieldOrder(58)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit10;

        [FieldFixedLength(8)]
        [FieldOrder(59)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit10;

        [FieldFixedLength(4)]
        [FieldOrder(60)]
        public string CoverageType11;

        [FieldFixedLength(8)]
        [FieldOrder(61)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit11;

        [FieldFixedLength(8)]
        [FieldOrder(62)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit11;

        [FieldFixedLength(8)]
        [FieldOrder(63)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit11;

        [FieldFixedLength(4)]
        [FieldOrder(64)]
        public string CoverageType12;

        [FieldFixedLength(8)]
        [FieldOrder(65)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit12;

        [FieldFixedLength(8)]
        [FieldOrder(66)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit12;

        [FieldFixedLength(8)]
        [FieldOrder(67)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit12;

        [FieldFixedLength(4)]
        [FieldOrder(68)]
        public string CoverageType13;

        [FieldFixedLength(8)]
        [FieldOrder(69)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit13;

        [FieldFixedLength(8)]
        [FieldOrder(70)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit13;

        [FieldFixedLength(8)]
        [FieldOrder(71)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit13;

        [FieldFixedLength(4)]
        [FieldOrder(72)]
        public string CoverageType14;

        [FieldFixedLength(8)]
        [FieldOrder(73)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit14;

        [FieldFixedLength(8)]
        [FieldOrder(74)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit14;

        [FieldFixedLength(8)]
        [FieldOrder(75)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit14;

        [FieldFixedLength(4)]
        [FieldOrder(76)]
        public string CoverageType15;

        [FieldFixedLength(8)]
        [FieldOrder(77)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int IndividualLimit15;

        [FieldFixedLength(8)]
        [FieldOrder(78)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int OccurrenceLimit15;

        [FieldFixedLength(8)]
        [FieldOrder(79)]
        [FieldConverter(typeof(PadLeftIntConverter), 8)]
        public int CslLimit15;

        [FieldFixedLength(10)]
        [FieldOrder(80)]
        public string InternalQuoteback;

        [FieldFixedLength(2)]
        [FieldOrder(81)]
        public string PropeetyIdentifier;

        [FieldFixedLength(2)]
        [FieldOrder(82)]
        public string FinanceCompanyType;

        [FieldFixedLength(1)]
        [FieldOrder(83)]
        public string LeasedVehicle;

        [FieldFixedLength(1)]
        [FieldOrder(84)]
        public string PropertyCancellationIndicator;

        [FieldFixedLength(8)]
        [FieldOrder(85)]
        public string PropertyCancellationDate;

        [FieldFixedLength(1)]
        [FieldOrder(86)]
        public string Filler1;

        [FieldFixedLength(1)]
        [FieldOrder(87)]
        public string PropertyType;

        [FieldFixedLength(3)]
        [FieldOrder(88)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage1;

        [FieldFixedLength(5)]
        [FieldOrder(89)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount1;

        [FieldFixedLength(3)]
        [FieldOrder(90)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage2;

        [FieldFixedLength(5)]
        [FieldOrder(91)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount2;

        [FieldFixedLength(3)]
        [FieldOrder(92)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage3;

        [FieldFixedLength(5)]
        [FieldOrder(93)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount3;

        [FieldFixedLength(3)]
        [FieldOrder(94)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage4;

        [FieldFixedLength(5)]
        [FieldOrder(95)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount4;

        [FieldFixedLength(3)]
        [FieldOrder(96)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage5;

        [FieldFixedLength(5)]
        [FieldOrder(97)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount5;

        [FieldFixedLength(3)]
        [FieldOrder(98)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage6;

        [FieldFixedLength(5)]
        [FieldOrder(99)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount6;

        [FieldFixedLength(3)]
        [FieldOrder(100)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage7;

        [FieldFixedLength(5)]
        [FieldOrder(101)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount7;

        [FieldFixedLength(3)]
        [FieldOrder(102)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage8;

        [FieldFixedLength(5)]
        [FieldOrder(103)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount8;

        [FieldFixedLength(3)]
        [FieldOrder(104)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage9;

        [FieldFixedLength(5)]
        [FieldOrder(105)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount9;

        [FieldFixedLength(3)]
        [FieldOrder(106)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage10;

        [FieldFixedLength(5)]
        [FieldOrder(107)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount10;

        [FieldFixedLength(3)]
        [FieldOrder(108)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage11;

        [FieldFixedLength(5)]
        [FieldOrder(109)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount11;

        [FieldFixedLength(3)]
        [FieldOrder(110)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage12;

        [FieldFixedLength(5)]
        [FieldOrder(111)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount12;

        [FieldFixedLength(3)]
        [FieldOrder(112)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage13;

        [FieldFixedLength(5)]
        [FieldOrder(113)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount13;

        [FieldFixedLength(3)]
        [FieldOrder(114)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage14;

        [FieldFixedLength(5)]
        [FieldOrder(115)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount14;

        [FieldFixedLength(3)]
        [FieldOrder(116)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldNullValue(0)]
        public int DeductiblePercentage15;

        [FieldFixedLength(5)]
        [FieldOrder(117)]
        [FieldConverter(typeof(PadLeftIntConverter), 5)]
        [FieldNullValue(0)]
        public int DeductibleAmount15;

        [FieldFixedLength(4)]
        [FieldOrder(118)]
        public string FormNumber;

        [FieldFixedLength(25)]
        [FieldOrder(119)]
        public string OtherSerialNumber;

        [FieldFixedLength(20)]
        [FieldOrder(120)]
        public string OtherMake;

        [FieldFixedLength(20)]
        [FieldOrder(121)]
        public string OtherModel;

        [FieldFixedLength(4)]
        [FieldOrder(122)]
        public string OtherYear = "0000";

        [FieldFixedLength(76)]
        [FieldOrder(123)]
        public string Filler2;

        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        public CurrentCarrierPropertyInfoPR01 Map(PolicyRs policyRs, PolicyRs previousTransactionPolicyRs, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, vehicle, previousTransactionPolicyRs, policyRs.Policy[0].PersAutoLineBusiness[0].Coverage, policyRs);

            return this;
        }
    }
}