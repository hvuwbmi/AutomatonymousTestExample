﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierMiscellaneousInfoMR01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;
    using Models;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierMiscellaneousInfoMR01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "MR01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(4)]
        [FieldOrder(6)]
        public string CancellationReasonCode;

        [FieldFixedLength(8)]
        [FieldOrder(7)]
        [FieldConverter(typeof(NullDateConverter))]
        [FieldAlign(AlignMode.Left, '0')]
        public DateTime? ReinstatementDate;

        [FieldFixedLength(20)]
        [FieldOrder(8)]
        public string HouseholdNumber;

        [FieldFixedLength(10)]
        [FieldOrder(9)]
        public string LexisNexisInternalUse;

        [FieldFixedLength(3)]
        [FieldOrder(10)]
        public string ALIRtSActivityCode;

        [FieldFixedLength(5)]
        [FieldOrder(11)]
        public string UnpaidPremium;

        [FieldFixedLength(910)]
        [FieldOrder(12)]
        public string Filler;

        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        internal ICurrentCarrierFile Map(PolicyRs policyRs)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, policyRs.BusinessPurposeTypeCd);

            return this;
        }
    }
}