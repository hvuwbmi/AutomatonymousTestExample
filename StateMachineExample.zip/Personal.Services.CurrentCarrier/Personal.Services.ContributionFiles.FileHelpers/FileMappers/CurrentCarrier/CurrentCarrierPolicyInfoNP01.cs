﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierPolicyInfoNP01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;
    using Models;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierPolicyInfoNP01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "NP01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(20)]
        [FieldOrder(6)]
        public string ContributingCompanyName = "WEST BEND MUTUAL INS";

        [FieldFixedLength(1)]
        [FieldOrder(7)]
        public string RiskType = "M";

        [FieldFixedLength(2)]
        [FieldOrder(8)]
        public string PolicyType;

        [FieldFixedLength(5)]
        [FieldOrder(9)]
        public string NAICCode = "15350";
        
        [FieldFixedLength(8)]
        [FieldOrder(10)]
        [FieldConverter(ConverterKind.Date,  Constants.Formatters.YYYYMMDD)]
        public DateTime PolicyInceptionDate;

        [FieldFixedLength(8)]
        [FieldOrder(11)]
        [FieldConverter(ConverterKind.Date,  Constants.Formatters.YYYYMMDD)]
        public DateTime PolicyPeriodEndDate;

        [FieldFixedLength(8)]
        [FieldOrder(12)]
        [FieldConverter(ConverterKind.Date,  Constants.Formatters.YYYYMMDD)]
        public DateTime PolicyPeriodBeginDate;

        [FieldFixedLength(8)]
        [FieldOrder(13)]
        [FieldConverter(typeof(NullDateConverter))]
        [FieldAlign(AlignMode.Left, '0')]
        public DateTime? PolicyCancellationDate;

        [FieldFixedLength(7)]
        [FieldOrder(14)]
        [FieldAlign(AlignMode.Left, '0')]
        public string PolicyPremium;

        [FieldFixedLength(1)]
        [FieldOrder(15)]
        public string PremiumPaymentPlan;

        [FieldFixedLength(3)]
        [FieldOrder(16)]
        public string PremiumMethodOfPayment;

        [FieldFixedLength(1)]
        [FieldOrder(17)]
        public string LexisNexisInternalUse;

        [FieldFixedLength(9)]
        [FieldOrder(18)]
        public string PolicyholderAddressNumber;

        [FieldFixedLength(20)]
        [FieldOrder(19)]
        public string PolicyholderAddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(20)]
        public string PolicyholderAddressAptNumber;

        [FieldFixedLength(20)]
        [FieldOrder(21)]
        public string PolicyholderAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(22)]
        public string PolicyholderAddressState;

        [FieldFixedLength(5)]
        [FieldOrder(23)]
        public string PolicyholderAddressZip;

        [FieldFixedLength(4)]
        [FieldOrder(24)]
        [FieldAlign(AlignMode.Left, '0')]
        public string PolicyholderAddressZip4;

        [FieldFixedLength(3)]
        [FieldOrder(25)]
        [FieldAlign(AlignMode.Left, '0')]
        public string PolicyholderAreaCode;

        [FieldFixedLength(7)]
        [FieldOrder(26)]
        [FieldAlign(AlignMode.Left, '0')]
        public string PolicyholderPhoneNumber;

        [FieldFixedLength(4)]
        [FieldOrder(27)]
        public string PolicyholderPhoneExt = "0000";

        [FieldFixedLength(10)]
        [FieldOrder(28)]
        public string InternalQuoteBack;

        [FieldFixedLength(3)]
        [FieldOrder(29)]
        public string LexisNexisCDCode;

        [FieldFixedLength(10)]
        [FieldOrder(30)]
        public string AgentIdentifier = "WB - PL";

        [FieldFixedLength(2)]
        [FieldOrder(31)]
        public string PolicyState;

        [FieldFixedLength(784)]
        [FieldOrder(32)]
        public string Filler;

        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        internal ICurrentCarrierFile Map(PolicyRs policyRs)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, policyRs.BusinessPurposeTypeCd);

            return this;
        }
    }
}