﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ICurrentCarrierFile.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;

    public interface ICurrentCarrierFile
    {
        DateTime ChangeEffectiveDateP { get; set; }

        string PolicyNumberP { get; set; }
    }
}