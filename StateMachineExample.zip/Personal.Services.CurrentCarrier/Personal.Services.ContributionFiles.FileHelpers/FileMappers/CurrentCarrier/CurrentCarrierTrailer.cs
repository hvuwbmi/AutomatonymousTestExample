﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierTrailer.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierTrailer
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string Constant = "##!!";

        [FieldFixedLength(4)]
        [FieldOrder(2)]
        public string RecordIdentifier = "SAT#"; 

        [FieldFixedLength(2)]
        [FieldConverter(ConverterKind.Date, "yy")]
        [FieldOrder(3)]
        public DateTime TransmissionYear;

        [FieldFixedLength(3)]
        [FieldConverter(typeof(PadLeftIntConverter), 3)]
        [FieldOrder(4)]
        public int TransmissionDayOfYear;
        
        [FieldFixedLength(4)]
        [FieldConverter(ConverterKind.Date, "HHMM")]
        [FieldOrder(5)]
        public DateTime TransmissionTime;

        [FieldFixedLength(4)]
        [FieldOrder(6)]
        public string ApplicationId = Constants.LexisData.APPLICATION_ID;

        [FieldFixedLength(10)] 
        [FieldOrder(7)]
        public string Filler;
        
        [FieldFixedLength(9)]
        [FieldOrder(8)]
        public string SourceId = Constants.LexisData.SOURCE_ID;

        [FieldFixedLength(6)]
        [FieldOrder(9)]
        [FieldConverter(typeof(PadLeftIntConverter), 6)]
        public int RecordCount;

        [FieldFixedLength(8)]
        [FieldOrder(10)]
        public string TotalNumberOfBlocks;

        [FieldFixedLength(202)] 
        [FieldOrder(11)]
        public string Filler2;

        public CurrentCarrierTrailer Map(int numOfRecords, DateTime now)
        {
            if (numOfRecords <= 999999)
            {
                this.RecordCount = numOfRecords;
                this.TotalNumberOfBlocks = "        ";      // 8 spaces
            }
            else
            {
                this.RecordCount = 999999;
                this.TotalNumberOfBlocks = numOfRecords.ToString("D8");
            }

            this.TransmissionTime = now;
            this.TransmissionYear = now;
            this.TransmissionDayOfYear = now.DayOfYear;

            return this;
        }
    }
}