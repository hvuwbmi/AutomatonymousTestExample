﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierSubjectInfoSJ01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;
    using Models;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierSubjectInfoSJ01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "SJ01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = "00964";

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = "PA";

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, "yyyyMMdd")]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(2)]
        [FieldOrder(6)]
        public string Relationship;

        [FieldFixedLength(28)]
        [FieldOrder(7)]
        public string LastName;

        [FieldFixedLength(20)]
        [FieldOrder(8)]
        public string FirstName;

        [FieldFixedLength(15)]
        [FieldOrder(9)]
        public string MiddleName;

        [FieldFixedLength(3)]
        [FieldOrder(10)]
        public string NameSuffix;

        [FieldFixedLength(8)]
        [FieldOrder(11)]
        [FieldConverter(ConverterKind.Date, "yyyyMMdd")]
        public DateTime BirthDate;

        [FieldFixedLength(9)]
        [FieldOrder(12)]
        public string SocialSecurityNumber = "000000000";

        [FieldFixedLength(1)]
        [FieldOrder(13)]
        public string Gender;

        [FieldFixedLength(25)]
        [FieldOrder(14)]
        [FieldConverter(typeof(LicenseConverter))]
        public string DriversLicenseNumber;

        [FieldFixedLength(2)]
        [FieldOrder(15)]
        public string DriversLicenseState;

        [FieldFixedLength(10)]
        [FieldOrder(16)]
        public string InternalUse1 = "          ";

        [FieldFixedLength(1)]
        [FieldOrder(17)]
        public string InternalUse2 = " ";

        [FieldFixedLength(3)]
        [FieldOrder(18)]
        public string SpecialProjectsIdentifier = "   ";

        /// <summary>
        /// Sequence Number is the InsurerId of the Driver. This value will also be used as the Vehicle's Insured Sequence Number.
        /// The format of this field must match <see cref="CurrentCarrierVehicleVR01.InsuredSequenceNumber"/>.
        /// </summary>
        [FieldFixedLength(3)]
        [FieldOrder(19)]
        [FieldAlign(AlignMode.Right, '0')]
        public string SequenceNumber;

        [FieldFixedLength(8)]
        [FieldOrder(20)]
        public string ClientIdentifier = "        ";

        [FieldFixedLength(60)]
        [FieldOrder(21)]
        public string EmailAddress;

        [FieldFixedLength(1)]
        [FieldOrder(22)]
        public string IndividualOrBusinessType = "I";

        [FieldFixedLength(60)]
        [FieldOrder(23)]
        public string BusinessOrTrustName;

        [FieldFixedLength(9)]
        [FieldOrder(24)]
        public string FeinOrTaxId = "000000000";

        [FieldFixedLength(2)]
        [FieldOrder(25)]
        public string BusinessTrustAddressType = "  ";

        [FieldFixedLength(9)]
        [FieldOrder(26)]
        public string BusinessTrustAddressStreetNumber = "         ";

        [FieldFixedLength(20)]
        [FieldOrder(27)]
        public string BusinessTrustAddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(28)]
        public string BusinessTrustAddressSuiteNumber = "     ";

        [FieldFixedLength(20)]
        [FieldOrder(29)]
        public string BusinessTrustAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(30)]
        public string BusinessTrustAddressState = "  ";

        [FieldFixedLength(5)]
        [FieldOrder(31)]
        public string BusinessTrustAddressZipCode = "00000";

        [FieldFixedLength(4)]
        [FieldOrder(32)]
        public string BusinessTrustAddressZipPlus4 = "0000";

        [FieldFixedLength(3)]
        [FieldOrder(33)]
        public string BusinessTrustPhoneAreaCode = "000";

        [FieldFixedLength(7)]
        [FieldOrder(34)]
        public string BusinessTrustPhoneNumber = "0000000";

        [FieldFixedLength(4)]
        [FieldOrder(35)]
        public string BusinessTrustPhoneExtension = "0000";

        [FieldFixedLength(1)]
        [FieldOrder(36)]
        public string MaritalStatus;

        [FieldFixedLength(610)]
        [FieldOrder(37)]
        public string Filler;
      
        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        internal ICurrentCarrierFile Map(PolicyRs policyRs, PolicyRsPolicyInsuredOrPrincipal policyRsPolicyInsuredOrPrincipal, PolicyRsPolicyPersAutoLineBusinessDriver driver, Relationship relationship)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, policyRsPolicyInsuredOrPrincipal, driver, relationship, policyRs.BusinessPurposeTypeCd);
            
            return this;
        }
    }
}