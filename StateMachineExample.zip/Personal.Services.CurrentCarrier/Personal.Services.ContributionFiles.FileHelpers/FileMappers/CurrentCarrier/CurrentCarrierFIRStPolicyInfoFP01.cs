﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierFIRStPolicyInfoFP01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;
    using Models;
    using Rules.Specification;
    using PolicyRsPolicy = Models.PolicyRsPolicy;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierFIRStPolicyInfoFP01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "FP01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingComapny = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(28)]
        [FieldOrder(6)]
        public string AgentLastName;

        [FieldFixedLength(20)]
        [FieldOrder(7)]
        public string AgentFirstName;

        [FieldFixedLength(9)]
        [FieldOrder(8)]
        public string AgentAddressNumber;

        [FieldFixedLength(20)]
        [FieldOrder(9)]
        public string AgentAddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(10)]
        public string AgentAddressAptNumber;

        [FieldFixedLength(20)]
        [FieldOrder(11)]
        public string AgentAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(12)]
        public string AgentAddressState;

        [FieldFixedLength(5)]
        [FieldOrder(13)]
        public string AgentAddressZip;

        [FieldFixedLength(4)]
        [FieldOrder(14)]
        public string AgentAddressZip4;

        [FieldFixedLength(3)]
        [FieldOrder(15)]
        public string AgentAreaCode;

        [FieldFixedLength(7)]
        [FieldOrder(16)]
        public string AgentPhoneNumber;

        [FieldFixedLength(4)]
        [FieldOrder(17)]
        public string AgentPhoneExt = "0000";
        
        [FieldFixedLength(50)]
        [FieldOrder(18)]
        public string PayableTo;

        [FieldFixedLength(9)]
        [FieldOrder(19)]
        public string RemittanceAddressNumber;

        [FieldFixedLength(20)]
        [FieldOrder(20)]
        public string RemittanceAddressStreeName;

        [FieldFixedLength(5)]
        [FieldOrder(21)]
        public string RemittanceAddressAptNumber;

        [FieldFixedLength(20)]
        [FieldOrder(22)]
        public string RemittanceAddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(23)]
        public string RemittanceAddressState;

        [FieldFixedLength(5)]
        [FieldOrder(24)]
        public string RemittanceAddressZip  = "00000";

        [FieldFixedLength(4)]
        [FieldOrder(25)]
        public string RemittanceAddressZip4 = "0000";

        [FieldFixedLength(3)]
        [FieldOrder(26)]
        public string RemittanceAreaCode  = "000";

        [FieldFixedLength(7)]
        [FieldOrder(27)]
        public string RemittancePhoneNumber = "0000000";

        [FieldFixedLength(4)]
        [FieldOrder(28)]
        public string RemittancePhoneExt  = "0000";

        [FieldFixedLength(7)]
        [FieldOrder(29)]
        public string PremiumInstallmentAmount = "0000000";

        [FieldFixedLength(7)]
        [FieldOrder(30)]
        public string PremiumIncreasedAmount = "0000000";

        [FieldFixedLength(5)]
        [FieldOrder(31)]
        public string NotificationPolicyType;

        [FieldFixedLength(10)]
        [FieldOrder(32)]
        public string InternalQuoteBack;

        [FieldFixedLength(166)]
        [FieldOrder(33)]
        public string UserData;

        [FieldFixedLength(509)]
        [FieldOrder(34)]
        public string Filler;
        
        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        public static CurrentCarrierFIRStPolicyInfoFP01 ShouldRecordGetCreated(PolicyRsPolicy policy)
        {
            string inceptionDt = string.IsNullOrEmpty(policy.OriginalPolicyInceptionDt) ? policy.ContractTerm[0].EffectiveDt : policy.OriginalPolicyInceptionDt;

            if (new IsInceptionDateAvailable().IsSatisfiedBy(inceptionDt))
            {
                return new CurrentCarrierFIRStPolicyInfoFP01();
            }

            return null;
        }

        internal CurrentCarrierFIRStPolicyInfoFP01 Map(PolicyRs policyRs)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, policyRs.BusinessPurposeTypeCd);

            return this;
        }
    }
}