﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierFIRSTPropertyInfoFR01.cs" company="West Bend">
//    Copyright (c) 2018 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.CurrentCarrier
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;
    using Models;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class CurrentCarrierFIRSTPropertyInfoFR01 : ICurrentCarrierFile
    {
        [FieldFixedLength(4)]
        [FieldOrder(1)]
        public string RecordCode = "FR01";

        [FieldFixedLength(5)]
        [FieldOrder(2)]
        public string ContributingCompany = Constants.LexisData.CONTRIBUTING_COMPANY;

        [FieldFixedLength(20)]
        [FieldOrder(3)]
        public string PolicyNumber;

        [FieldFixedLength(2)]
        [FieldOrder(4)]
        public string InsuranceType = Constants.LexisData.INSURANCE_TYPE;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime ChangeEffectiveDate;

        [FieldFixedLength(25)]
        [FieldOrder(6)]
        public string Vin;

        [FieldFixedLength(2)]
        [FieldOrder(7)]
        public string PropertyIdentifier;

        [FieldFixedLength(10)]
        [FieldOrder(8)]
        public string TransactionId;

        [FieldFixedLength(3)]
        [FieldOrder(9)]
        public string NotificationActionCode;

        [FieldFixedLength(8)]
        [FieldOrder(10)]
        [FieldConverter(typeof(SpaceDateConverterYYYYMMDD))]
        public DateTime? NotificationActionDate;

        [FieldFixedLength(2)]
        [FieldOrder(11)]
        public string EndorsementState;

        [FieldFixedLength(10)]
        [FieldOrder(12)]
        public string Endorsement1;

        [FieldFixedLength(10)]
        [FieldOrder(13)]
        public string Endorsement2;

        [FieldFixedLength(10)]
        [FieldOrder(14)]
        public string Endorsement3;

        [FieldFixedLength(10)]
        [FieldOrder(15)]
        public string Endorsement4;

        [FieldFixedLength(10)]
        [FieldOrder(16)]
        public string Endorsement5;

        [FieldFixedLength(10)]
        [FieldOrder(17)]
        public string Endorsement6;

        [FieldFixedLength(10)]
        [FieldOrder(18)]
        public string Endorsement7;

        [FieldFixedLength(10)]
        [FieldOrder(19)]
        public string Endorsement8;

        [FieldFixedLength(50)]
        [FieldOrder(20)]
        public string FinanceCompany1Name;

        [FieldFixedLength(2)]
        [FieldOrder(21)]
        public string FinanceCompany1Type;

        [FieldFixedLength(9)]
        [FieldOrder(22)]
        public string FinanceCompany1AddressNumber;

        [FieldFixedLength(50)]
        [FieldOrder(23)]
        public string FinanceCompany1AddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(24)]
        public string FinanceCompany1AddressAptNumber;

        [FieldFixedLength(30)]
        [FieldOrder(25)]
        public string FinanceCompany1AddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(26)]
        public string FinanceCompany1AddressState;

        [FieldFixedLength(5)]
        [FieldOrder(27)]
        public string FinanceCompany1AddressZipCode;

        [FieldFixedLength(4)]
        [FieldOrder(28)]
        public string FinanceCompany1AddressZipCode4;

        [FieldFixedLength(15)]
        [FieldOrder(29)]
        public string FinanceCompany1LoanNumber;

        [FieldFixedLength(7)]
        [FieldOrder(30)]
        public string FinanceCompany1PremiumAmountDue = "0000000";

        [FieldFixedLength(50)]
        [FieldOrder(31)]
        public string FinanceCompany2Name;

        [FieldFixedLength(2)]
        [FieldOrder(32)]
        public string FinanceCompany2Type;

        [FieldFixedLength(9)]
        [FieldOrder(33)]
        public string FinanceCompany2AddressNumber;

        [FieldFixedLength(50)]
        [FieldOrder(34)]
        public string FinanceCompany2AddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(35)]
        public string FinanceCompany2AddressAptNumber;

        [FieldFixedLength(30)]
        [FieldOrder(36)]
        public string FinanceCompany2AddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(37)]
        public string FinanceCompany2AddressState;

        [FieldFixedLength(5)]
        [FieldOrder(38)]
        public string FinanceCompany2AddressZipCode;

        [FieldFixedLength(4)]
        [FieldOrder(39)]
        public string FinanceCompany2AddressZipCode4;

        [FieldFixedLength(15)]
        [FieldOrder(40)]
        public string FinanceCompany2LoanNumber;

        [FieldFixedLength(7)]
        [FieldOrder(41)]
        public string FinanceCompany2PremiumAmountDue = "0000000";

        [FieldFixedLength(50)]
        [FieldOrder(42)]
        public string FinanceCompany3Name;

        [FieldFixedLength(2)]
        [FieldOrder(43)]
        public string FinanceCompany3Type;

        [FieldFixedLength(9)]
        [FieldOrder(44)]
        public string FinanceCompany3AddressNumber;

        [FieldFixedLength(50)]
        [FieldOrder(45)]
        public string FinanceCompany3AddressStreetName;

        [FieldFixedLength(5)]
        [FieldOrder(46)]
        public string FinanceCompany3AddressAptNumber;

        [FieldFixedLength(30)]
        [FieldOrder(47)]
        public string FinanceCompany3AddressCity;

        [FieldFixedLength(2)]
        [FieldOrder(48)]
        public string FinanceCompany3AddressState;

        [FieldFixedLength(5)]
        [FieldOrder(49)]
        public string FinanceCompany3AddressZipCode;

        [FieldFixedLength(4)]
        [FieldOrder(50)]
        public string FinanceCompany3AddressZipCode4;

        [FieldFixedLength(15)]
        [FieldOrder(51)]
        public string FinanceCompany3LoanNumber;

        [FieldFixedLength(7)]
        [FieldOrder(52)]
        public string FinanceCompany3PremiumAmountDue = "0000000";

        [FieldFixedLength(50)]
        [FieldOrder(53)]
        public string PropertyLegalDescription;

        [FieldFixedLength(3)]
        [FieldOrder(54)]
        public string PropertyFloodZone;

        [FieldFixedLength(1)]
        [FieldOrder(55)]
        public string AutoLiabilityOnlyCoverage;

        [FieldFixedLength(10)]
        [FieldOrder(56)]
        public string ReservedForLexisNexisUse;

        [FieldFixedLength(190)]
        [FieldOrder(57)]
        public string Notes;

        [FieldFixedLength(1)]
        [FieldOrder(58)]
        public string FinancialNotificationInd;

        [FieldFixedLength(27)]
        [FieldOrder(59)]
        public string LexisNexisInternalUse;

        [FieldFixedLength(11)]
        [FieldOrder(60)]
        public string Filler;

        DateTime ICurrentCarrierFile.ChangeEffectiveDateP { get => this.ChangeEffectiveDate; set => this.ChangeEffectiveDate = value; }

        string ICurrentCarrierFile.PolicyNumberP { get => this.PolicyNumber; set => this.PolicyNumber = value; }

        public ICurrentCarrierFile Map(PolicyRs policyRs, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest additionalInterest, IPolicyStoreApi policyStore)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, vehicle, additionalInterest, policyRs.BusinessPurposeTypeCd, policyRs.TransactionSeqNumber, policyStore);

            return this;
        }

        public ICurrentCarrierFile Map(PolicyRs policyRs, PolicyRsPolicyPersAutoLineBusinessVehicle vehicle, IPolicyStoreApi policyStore)
        {
            policyRs.Map(this);
            policyRs.Policy[0].Map(this, vehicle, policyRs.BusinessPurposeTypeCd, policyRs.TransactionSeqNumber, policyStore);

            return this;
        }
    }
}