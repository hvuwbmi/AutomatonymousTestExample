﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound03.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound03
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "03";

        [FieldFixedLength(8)]
        [FieldOrder(2)]
        public string BirthDate;

        [FieldFixedLength(3)]
        [FieldOrder(3)]
        public int Weight;

        [FieldFixedLength(3)]
        [FieldOrder(4)]
        public int Height;

        [FieldFixedLength(4)]
        [FieldOrder(5)]
        public string EyeColor;

        [FieldFixedLength(19)]
        [FieldOrder(6)]
        public string Alias;

        [FieldFixedLength(30)]
        [FieldOrder(7)]
        public string PolicyNumber;

        [FieldFixedLength(10)]
        [FieldOrder(8)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.MMDDYYYYSlash)]
        public DateTime PolicyExpirationDate;

        [FieldFixedLength(22)]
        [FieldOrder(9)]
        [FieldConverter(typeof(ReverseLicenseConverter))]
        public string PreviousLicense;

        [FieldFixedLength(1)]
        [FieldOrder(10)]
        public string Gender;

        [FieldFixedLength(7)]
        [FieldOrder(11)]
        public string AccountNumber;

        [FieldFixedLength(41)]
        [FieldOrder(12)]
        public string Reserved1;
    }
}