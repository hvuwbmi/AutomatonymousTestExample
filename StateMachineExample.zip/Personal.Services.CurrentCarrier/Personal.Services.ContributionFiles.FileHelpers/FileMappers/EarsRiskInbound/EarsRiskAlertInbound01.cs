﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound01.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound01
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "01";

        [FieldFixedLength(2)]
        [FieldOrder(2)]
        public string LicenseState;

        [FieldFixedLength(22)]
        [FieldOrder(3)]
        public string LicenseNumber; // need to get token done here??

        [FieldFixedLength(8)]
        [FieldOrder(4)]
        public string Reserved1;

        [FieldFixedLength(80)]
        [FieldOrder(5)]
        public string QuoteBack;

        [FieldFixedLength(8)]
        [FieldOrder(6)]
        public string Reserved2;

        [FieldFixedLength(1)]
        [FieldOrder(7)]
        public string ReportType;

        [FieldFixedLength(2)]
        [FieldOrder(8)]
        public string Reserved3;

        [FieldFixedLength(25)]
        [FieldOrder(9)]
        public string Reserved4;
    }
}