﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound07.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound07
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "07";

        [FieldFixedLength(123)]
        [FieldOrder(2)]
        public string MiscText;

        [FieldFixedLength(25)]
        [FieldOrder(3)]
        public string Extra;
    }
}