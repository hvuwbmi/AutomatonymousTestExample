﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInboundHeader.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInboundHeader
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "FH";

        [FieldFixedLength(8)]
        [FieldOrder(2)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime FileDate;

        [FieldFixedLength(2)]
        [FieldOrder(3)]
        public string FileIdCode;

        [FieldFixedLength(7)]
        [FieldOrder(4)]
        public string SenderName;

        [FieldFixedLength(59)]
        [FieldOrder(5)]
        public string Reserved1;

        [FieldFixedLength(2)]
        [FieldOrder(6)]
        public string Version;

        [FieldFixedLength(70)]
        [FieldOrder(7)]
        public string Reserved2;
    }
}