﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound05.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound05
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "05";

        [FieldFixedLength(20)]
        [FieldOrder(2)]
        public string LicenseClass;

        [FieldFixedLength(2)]
        [FieldOrder(3)]
        public string EndorseRestType1;

        [FieldFixedLength(20)]
        [FieldOrder(4)]
        public string EndorseRestrict1;

        [FieldFixedLength(2)]
        [FieldOrder(5)]
        public string EndorseRestType2;

        [FieldFixedLength(20)]
        [FieldOrder(6)]
        public string EndorseRestrict2;

        [FieldFixedLength(2)]
        [FieldOrder(7)]
        public string EndorseRestType3;

        [FieldFixedLength(20)]
        [FieldOrder(8)]
        public string EndorseRestrict3;

        [FieldFixedLength(2)]
        [FieldOrder(9)]
        public string EndorseRestType4;

        [FieldFixedLength(20)]
        [FieldOrder(10)]
        public string EndorseRestrict4;

        [FieldFixedLength(40)]
        [FieldOrder(11)]
        public string Reserved1;
    }
}