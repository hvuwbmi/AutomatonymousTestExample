﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound06.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound06
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "06";

        [FieldFixedLength(10)]
        [FieldOrder(2)]
        public string IncidentResult;

        [FieldFixedLength(10)]
        [FieldOrder(3)]
        public string CustomerCode;

        [FieldFixedLength(8)]
        [FieldOrder(4)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime IncidentStartDate;

        [FieldFixedLength(80)]
        [FieldOrder(5)]
        public string IncidentDescription;

        [FieldFixedLength(8)]
        [FieldOrder(6)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime IncidentEndDate;

        [FieldFixedLength(3)]
        [FieldOrder(7)]
        public int IncidentPoints;

        [FieldFixedLength(1)]
        [FieldOrder(8)]
        public string Reserved1;

        [FieldFixedLength(10)]
        [FieldOrder(9)]
        public string StateCode;

        [FieldFixedLength(6)]
        [FieldOrder(10)]
        public string NationalCode;

        [FieldFixedLength(9)]
        [FieldOrder(11)]
        public string Reserved2;

        [FieldFixedLength(3)]
        [FieldOrder(12)]
        public string Extra;
    }
}