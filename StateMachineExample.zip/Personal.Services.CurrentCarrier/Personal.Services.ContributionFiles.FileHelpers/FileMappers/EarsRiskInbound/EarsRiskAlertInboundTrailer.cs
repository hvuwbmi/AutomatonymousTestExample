﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInboundTrailer.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInboundTrailer
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "FT";

        [FieldFixedLength(6)]
        [FieldOrder(2)]
        public int TotalDrivers;

        [FieldFixedLength(10)]
        [FieldOrder(3)]
        public int TotalRecords;

        [FieldFixedLength(30)]
        [FieldOrder(4)]
        public string ReceivingName;

        [FieldFixedLength(9)]
        [FieldOrder(5)]
        public string ReceivingNumber;

        [FieldFixedLength(2)]
        [FieldOrder(6)]
        public string FileIdCode;

        [FieldFixedLength(91)]
        [FieldOrder(7)]
        public string Reserved1;
    }
}