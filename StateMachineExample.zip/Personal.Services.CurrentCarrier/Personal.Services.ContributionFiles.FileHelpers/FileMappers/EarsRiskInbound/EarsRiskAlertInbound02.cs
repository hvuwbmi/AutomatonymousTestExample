﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound02.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound02
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "02";

        [FieldFixedLength(15)]
        [FieldOrder(2)]
        public string LastName;

        [FieldFixedLength(10)]
        [FieldOrder(3)]
        public string Reserved1; 

        [FieldFixedLength(14)]
        [FieldOrder(4)]
        public string FirstName;

        [FieldFixedLength(6)]
        [FieldOrder(5)]
        public string Reserved2;

        [FieldFixedLength(15)]
        [FieldOrder(6)]
        public string MiddleName;

        [FieldFixedLength(5)]
        [FieldOrder(7)]
        public string Reserved3;

        [FieldFixedLength(25)]
        [FieldOrder(8)]
        public string StreetAddress;

        [FieldFixedLength(20)]
        [FieldOrder(9)]
        public string City;

        [FieldFixedLength(2)]
        [FieldOrder(10)]
        public string State;

        [FieldFixedLength(5)]
        [FieldOrder(11)]
        public string ZipCode;

        [FieldFixedLength(31)]
        [FieldOrder(12)]
        public string Reserved4;
    }
}