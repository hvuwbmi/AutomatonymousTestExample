﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskAlertInbound04.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskInbound
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using FileHelperExtensions;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertInbound04
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "04";

        [FieldFixedLength(20)]
        [FieldOrder(2)]
        public string LicenseClass;

        [FieldFixedLength(1)]
        [FieldOrder(3)]
        public string Reserved1;

        [FieldFixedLength(8)]
        [FieldOrder(4)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime LicenseIssueDate;

        [FieldFixedLength(8)]
        [FieldOrder(5)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime LicenseExpDate;

        [FieldFixedLength(15)]
        [FieldOrder(6)]
        public string PersonalLicenseStatus;

        [FieldFixedLength(15)]
        [FieldOrder(7)]
        public string CdlLicenseStatus;

        [FieldFixedLength(20)]
        [FieldOrder(8)]
        public string LicenseType;

        [FieldFixedLength(61)]
        [FieldOrder(12)]
        public string Reserved2;
    }
}