﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EarsRiskAlertHeader.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskAlert
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertHeader
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "FH";

        [FieldFixedLength(8)]
        [FieldOrder(2)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime FileDate;

        [FieldFixedLength(2)]
        [FieldOrder(3)]
        public string FileIdCode = "DR";

        [FieldFixedLength(30)]
        [FieldOrder(4)]
        public string SenderName = "PL NEW PLAT";

        [FieldFixedLength(9)]
        [FieldOrder(5)]
        public string SenderNumber = "611852";

        [FieldFixedLength(4)]
        [FieldOrder(6)]
        public string Version = "0800";

        [FieldFixedLength(250)]
        [FieldOrder(7)]
        public string Reserved1;
    }
}
