﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EarsRiskAlertDetailRequest.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskAlert
{
    using System;
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;
    using FileHelpers.FileHelperExtensions;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertDetailRequest
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string LicenseState;

        [FieldFixedLength(22)]
        [FieldOrder(2)]
        [FieldConverter(typeof(LicenseConverter))]
        public string LicenseNumber;

        [FieldFixedLength(25)]
        [FieldOrder(3)]
        public string LastName;

        [FieldFixedLength(20)]
        [FieldOrder(4)]
        public string FirstName;

        [FieldFixedLength(20)]
        [FieldOrder(5)]
        public string MiddleName;

        [FieldFixedLength(8)]
        [FieldOrder(6)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime BirthDate;

        [FieldFixedLength(9)]
        [FieldOrder(7)]
        public string ZipCode;

        [FieldFixedLength(25)]
        [FieldOrder(8)]
        public string StreetAddress;

        [FieldFixedLength(1)]
        [FieldOrder(9)]
        public string Gender;

        [FieldFixedLength(1)]
        [FieldOrder(10)]
        public string Reserved1;

        [FieldFixedLength(32)]
        [FieldOrder(11)]
        public string PolicyNumber;

        [FieldFixedLength(8)]
        [FieldOrder(12)]
        [FieldConverter(ConverterKind.Date, Constants.Formatters.YYYYMMDD)]
        public DateTime PolicyExpirationDate;

        [FieldFixedLength(2)]
        [FieldOrder(13)]
        public string Reserved2;

        [FieldFixedLength(80)]
        [FieldOrder(14)]
        public string Quoteback;

        [FieldFixedLength(1)]
        [FieldOrder(15)]
        public string InsuranceIndicator = "R";

        [FieldFixedLength(8)]
        [FieldOrder(16)]
        public string Reserved3;

        /// <summary>
        /// A value of 'true' means that Exclude From EARS was set to 'No'.
        /// </summary>
        [FieldFixedLength(1)]
        [FieldOrder(17)]
        [FieldConverter(ConverterKind.Boolean, "1", "0")]
        public bool IncludeInEars;

        /// <summary>
        /// A value of 'true' means that Exclude from Risk Alert was set to 'No'.
        /// </summary>
        [FieldFixedLength(1)]
        [FieldOrder(18)]
        [FieldConverter(ConverterKind.Boolean, "1", "0")]
        public bool IncludeInRiskAlert;

        [FieldFixedLength(7)]
        [FieldOrder(19)]
        public string ProductFlags = "0000000";

        [FieldFixedLength(9)]
        [FieldOrder(20)]
        public string AccountNumber = "611852";

        [FieldFixedLength(23)]
        [FieldOrder(21)]
        public string Reserved4;
    }
}
