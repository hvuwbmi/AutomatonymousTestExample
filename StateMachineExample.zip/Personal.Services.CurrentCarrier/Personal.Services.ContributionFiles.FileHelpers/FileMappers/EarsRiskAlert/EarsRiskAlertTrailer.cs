﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EarsRiskAlertTrailer.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.FileMappers.EarsRiskAlert
{
    using System.Diagnostics.CodeAnalysis;
    using global::FileHelpers;

    [SuppressMessage("StyleCop.CSharp.MaintainabilityRules", "SA1401:FieldsMustBePrivate", Justification = "FileHelpers requires this.")]
    [FixedLengthRecord]
    public class EarsRiskAlertTrailer
    {
        [FieldFixedLength(2)]
        [FieldOrder(1)]
        public string RecordId = "FT";

        [FieldFixedLength(6)]
        [FieldOrder(2)]
        public string Reserved1;

        [FieldFixedLength(10)]
        [FieldOrder(3)]
        public int TotalRecords;

        [FieldFixedLength(30)]
        [FieldOrder(4)]
        public string ReceivingName = "EXPLORE";

        [FieldFixedLength(9)]
        [FieldOrder(5)]
        public string Reserved2;        // This is defined as "Receiving Number" in the docs.

        [FieldFixedLength(2)]
        [FieldOrder(6)]
        public string FileIdCode = "DR";

        [FieldFixedLength(246)]
        [FieldOrder(7)]
        public string Reserved3;
    }
}
