﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ILexisNexisApi.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Refit;

    public interface ILexisNexisApi
    {
        [Post("/personal/lexisnexis/sftp-upload/function/{filename}")]
        Task SftpUpload(string filename, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey, [Body] string fileContents);
    }
}
