﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClaimsClaim.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Refit;

    public interface IClaimsClaim
    {
        [Get("/Claims/Claim/claimsummary?claimNumber={claimNumber}")]
        Task<string> ClaimSummary(string claimNumber, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);

        [Get("/Claims/Claim/{id}")]
        [Headers("Accept: application/xml")]
        Task<string> ClaimOrchestratorLogicApp(string id, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);
    }
}