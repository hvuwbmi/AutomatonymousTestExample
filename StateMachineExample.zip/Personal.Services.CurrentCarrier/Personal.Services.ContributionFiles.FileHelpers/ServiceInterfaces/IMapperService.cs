﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IMapperService.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Models;
    using Models.Dtos;

    public interface IMapperService
    {
        Task<CurrentCarrierData> Map(string policyNumber, string policyVersion, string transactionSequenceNumber);

        Task<ClueAutoData> Map(ClaimsDto claimsDto);
    }
}