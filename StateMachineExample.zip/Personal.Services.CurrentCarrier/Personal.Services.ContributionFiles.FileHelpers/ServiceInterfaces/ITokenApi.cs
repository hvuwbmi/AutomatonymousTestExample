﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ITokenApi.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Refit;

    public interface ITokenApi
    {
        [Post("/personal/token/detokenize")]
        Task<TokenResponse> Detokenize([Body] TokenRequest token, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);
        [Post("/personal/token/tokenize")]
        Task<TokenResponse> Tokenize([Body] TokenRequest token, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);
    }
}