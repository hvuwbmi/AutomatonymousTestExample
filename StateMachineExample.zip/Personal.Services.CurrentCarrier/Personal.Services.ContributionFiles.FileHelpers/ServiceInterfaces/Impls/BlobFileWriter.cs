﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="BlobFileWriter.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces.Impls
{
    using System;
    using System.Configuration;
    using System.Threading.Tasks;
    using FileMappers;
    using Models;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using ServiceInterfaces;

    public class BlobFileWriter : IFileWriter
    {
        private readonly string containerPath;
        private readonly IStorageManager storageManager;

        public BlobFileWriter(string containerPath, IStorageManager storageManager)
        {
            this.containerPath = containerPath;
            this.storageManager = storageManager;
        }

        public async Task<CurrentCarrierData> WriteCurrentCarrier(string file, string policyNumber, string version, string mod)
        {
            var dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            var fileName = "CurrentCarrier" + dateTimeString + ".txt";
            var container = ConfigurationManager.AppSettings["ContainerReference"];
            var apimKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];

            await this.storageManager.CreateFileAsync(container, this.containerPath, fileName, file);

            var rowKey = dateTimeString + policyNumber + version + mod;
            
            var currentCarrierData = new CurrentCarrierData()
            {
                CreateDate = dateTimeString, 
                PolicyNumber = policyNumber, 
                Container = container, 
                Folder = this.containerPath, 
                Name = fileName,
                PolicyVersion = version,
                TransSeqNumber = mod
            };

            JObject record = JObject.FromObject(currentCarrierData);
            await this.storageManager.InsertRecordAsync("ThirdPartyContribution", "CurrentCarrier", rowKey, record);

            return currentCarrierData;
        }

        public async Task WriteEarsOutbound(string file, string container, string apimKey)
        {
            await this.storageManager.CreateFileAsync(container, Constants.Azure.BlobStorage.EARSRisk.Folder, Constants.Azure.BlobStorage.EARSRisk.FileName, file);
        }

        public async Task<ClueAutoData> WriteClueAuto(string file, string claimNumber, string policyNumber, string claimType)
        {
            var dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            var fileName = "ClueAuto" + dateTimeString + ".txt";
            var container = ConfigurationManager.AppSettings["ContainerReference"];
            var apimKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];

            await this.storageManager.CreateFileAsync(container, this.containerPath, fileName, file);

            var rowKey = $"{claimNumber}.{policyNumber}.{dateTimeString}";

            var clueAutoData = new ClueAutoData()
            {
                CreateDate = dateTimeString,
                PolicyNumber = policyNumber,
                Container = container,
                Folder = this.containerPath,
                Name = fileName,
                ClaimNumber = claimNumber
            };

            JObject record = JObject.FromObject(clueAutoData);
            await this.storageManager.InsertRecordAsync("ThirdPartyContribution", "ClueAuto", rowKey, record);

            return clueAutoData;
        }
    }
}