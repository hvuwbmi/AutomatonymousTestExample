﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="MapperService.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces.Impls
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using FileMappers;
    using FileMappers.CLUEAuto;
    using Models;
    using Models.Dtos;
    using Personal.Services.ContributionFiles.FileHelpers.Models.Claims;
    using Personal.Services.ContributionFiles.FileHelpers.Rules;
    using ServiceInterfaces;
    using WestBend.Core;
    using NewDataSet = Models.NewDataSet;

    public class MapperService : IMapperService
    {
        private readonly IFileWriter fileWriter;
        private readonly ILogger logger;
        private readonly IClaimsClaim claimsClaim;

        public MapperService(IPolicyStoreApi policyStoreApi, IFileWriter fileWriter, ILogger logger, IClaimsClaim claimsClaim)
        {
            this.PolicyStoreApi = policyStoreApi;
            this.fileWriter = fileWriter;
            this.logger = logger;
            this.claimsClaim = claimsClaim;
        }

         public IPolicyStoreApi PolicyStoreApi { get; private set; }

        public async Task<CurrentCarrierData> Map(string policyNumber, string policyVersion, string transactionSequenceNumber)
        {
            var additionalData = new Dictionary<string, string> { { "PolicyNumber", policyNumber }, { "PolicyVersion", policyVersion }, { "TransactionSequenceNumber", transactionSequenceNumber } };

            // Get The Policy
            try
            {
                // create the engine
                var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.CurrentCarrier);

                // Do the work here
                var records = await new NewDataSet(this.PolicyStoreApi, this.logger).Map(policyNumber, policyVersion, transactionSequenceNumber);

                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, $"{records.Count} records found for policy {policyNumber}", additionalData);

                CurrentCarrierData uri = null;
                if (records.Any())
                {
                    // store the file
                    var file = engine.WriteString(records.AsEnumerable());
                    uri = await this.fileWriter.WriteCurrentCarrier(file, policyNumber, policyVersion, transactionSequenceNumber);

                    this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, $"policy {policyNumber} was mapped for current carrier output", additionalData);
                }
                else
                {
                    this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, $"No records mapped for policy {policyNumber}", additionalData);
                }

                return uri;
            }
            catch (Exception e)
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, e.Message, additionalData, e);
                throw;
            }
        }

        public async Task<ClueAutoData> Map(ClaimsDto claimsDto)
        {
            var additionalData = new Dictionary<string, string>
                {
                    { "PolicyNumber", claimsDto.PolicyNumber },
                    { "ClaimNumber", claimsDto.ClaimNumber }
                };

            try
            {
                ClueAutoData clueAutoData = null;
                var claimPolicyData = new ClueAutoPolicyClaimData(this.claimsClaim, this.PolicyStoreApi, this.logger);
                var data = await claimPolicyData.GetTheData(claimsDto.PolicyNumber, claimsDto.ClaimNumber, claimsDto.DateOfLoss);
                var storableFile = string.Empty;
                var clueAutoLossTransactions = new List<CLUEAutoLossTransaction>();
                var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.CLUEAuto);

                var dataGetFullClaimResponse = data.GetFullClaimResponse;
                foreach (var claimReserve in this.MergeClaimReserves(await dataGetFullClaimResponse.GetClaimReserves()).Where(x => decimal.Parse(x.TotalPaidAmount) >= 0))
                {
                    var file = new CLUEAutoLossTransaction();
                    var claimData = await dataGetFullClaimResponse.Map(file, claimReserve, data.Policy);
                    file = await data.Policy.MapCLUEAutoLossTransaction(file, claimData);
                    clueAutoLossTransactions.Add(file);
                }

                if (clueAutoLossTransactions.Count > 0)
                {
                    storableFile = engine.WriteString(clueAutoLossTransactions);
                    clueAutoData = await this.fileWriter.WriteClueAuto(storableFile, claimsDto.ClaimNumber, claimsDto.PolicyNumber, string.Empty);
                }
                else
                {
                    this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, "There were no valid ClaimReserves for this policy/claim", additionalData);
                }

                return clueAutoData;
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, ex.Message, additionalData, ex);
                throw;
            }
        }
        
        private IEnumerable<ClaimReservesClaimReserve_Type> MergeClaimReserves(ClaimReservesClaimReserve_Type[] claimReservesClaimReserve_Type)
        {
            List<ClaimReservesClaimReserve_Type> outList = new List<ClaimReservesClaimReserve_Type>();

            if (claimReservesClaimReserve_Type != null && claimReservesClaimReserve_Type.Count() > 0)
            {
                foreach (var claimRow in claimReservesClaimReserve_Type)
                {
                    // If a claim row with that reserve type is already in the list, merge them.  Otherwise, add it to the list.
                    // using somewhat unsatisfying syntax to save on redoing the linq query if it finds something
                    ClaimReservesClaimReserve_Type reserve = outList.Where(
                            x => ClueClaimTypeClaimTypeRule.GetClueClaimTypeCode(x.CoverageType, x.ReserveCauseOfLoss) ==
                            ClueClaimTypeClaimTypeRule.GetClueClaimTypeCode(claimRow.CoverageType, claimRow.ReserveCauseOfLoss))
                            .FirstOrDefault();

                    if (reserve != null)
                    {
                        if (claimRow.ClaimReserveType[0].ReserveTypeCode == Constants.ClaimReserveTypeCode.SUBROGATION)
                        {
                            reserve.TotalPaidAmount = (decimal.Parse(reserve.TotalPaidAmount) - decimal.Parse(claimRow.TotalPaidAmount)).ToString();
                            reserve.ClaimReserveType[0].ReserveTypeCode = Constants.ClaimReserveTypeCode.SUBROGATION;
                        }
                        else
                        {
                            reserve.TotalPaidAmount = (decimal.Parse(reserve.TotalPaidAmount) + decimal.Parse(claimRow.TotalPaidAmount)).ToString();
                        }
                    }
                    else
                    {
                        ClaimReservesClaimReserve_Type newRow = new ClaimReservesClaimReserve_Type()
                        {
                            key = claimRow.key,
                            CauseOfLossDescription = claimRow.CauseOfLossDescription,
                            ClaimReserveType = claimRow.ClaimReserveType,
                            CoverageType = claimRow.CoverageType,
                            CoverageTypeCode = claimRow.CoverageTypeCode,
                            PhysicalObjectRole = claimRow.PhysicalObjectRole,
                            ReserveCategory = claimRow.ReserveCategory,
                            ReserveCauseOfLoss = claimRow.ReserveCauseOfLoss,
                            Status = claimRow.Status,
                            TotalPaidAmount = claimRow.TotalPaidAmount
                        };

                        if (newRow.ClaimReserveType[0].ReserveTypeCode == Constants.ClaimReserveTypeCode.SUBROGATION)
                        {
                            newRow.TotalPaidAmount = (decimal.Parse(newRow.TotalPaidAmount) * -1).ToString();
                        }

                        outList.Add(newRow);
                    }
                }
            }

            return outList.ToArray();
        }
    }
}