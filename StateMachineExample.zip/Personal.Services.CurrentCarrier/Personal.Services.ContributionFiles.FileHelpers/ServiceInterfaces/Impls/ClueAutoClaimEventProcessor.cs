﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoClaimEventProcessor.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces.Impls
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Diagnostics;
    using System.Linq;
    using System.Threading.Tasks;
    using FileMappers;
    using Models;
    using Models.Dtos;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using WestBend.Core;

    public class ClueAutoClaimEventProcessor : IClueAutoClaimEventProcessor
    {
        private readonly ILogger logger;
        private readonly IMapperService mapperService;
        private readonly IStorageManager storageManager;
        private readonly string key;

        public ClueAutoClaimEventProcessor(ILogger logger, IMapperService mapperService, IStorageManager storageManager)
        {
            this.logger = logger;
            this.mapperService = mapperService;
            this.storageManager = storageManager;
            this.key = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
        }

        public async Task<bool> ProcessClaimStatusChangedEvent(StatusChangedDto statusChangedMessage)
        {
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessClaimStatusChangedEvent started");

            try
            {
                var runDate = await this.GetLastRunDate();
                await this.mapperService.Map(statusChangedMessage);
                await this.RemoveOldData(statusChangedMessage, runDate);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Error, "ClueAutoClaimEventProcessor:ProcessClaimStatusChangedEvent", null, ex);
                return false;
            }

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessClaimStatusChangedEvent ended");

            return true;
        }

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1305:FieldNamesMustNotUseHungarianNotation", Justification = "atFaultMessage is a valid name.")]
        public async Task<bool> ProcessAtFaultEvent(AtFaultDto atFaultMessage)
        {
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessAtFaultEvent started");

            try
            {
                var runDate = await this.GetLastRunDate();
                await this.mapperService.Map(atFaultMessage);
                await this.RemoveOldData(atFaultMessage, runDate);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Error, "ClueAutoClaimEventProcessor:ProcessAtFaultEvent", null, ex);
                return false;
            }

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessAtFaultEvent ended");

            return true;
        }

        public async Task<bool> ProcessFinancialTransactionCommittedEvent(FinancialTransactionCommittedDto financialTransactionCommittedMessage)
        {
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessFinancialTransactionCommittedEvent started");

            try
            {
                var runDate = await this.GetLastRunDate();
                await this.mapperService.Map(financialTransactionCommittedMessage);
                await this.RemoveOldData(financialTransactionCommittedMessage, runDate);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Error, "ClueAutoClaimEventProcessor:ProcessFinancialTransactionCommittedEvent", null, ex);
                return false;
            }

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessFinancialTransactionCommittedEvent ended");

            return true;
        }

        public async Task<bool> ProcessOffsetOnsetEvent(OffsetOnsetDto offsetOnsetMessage)
        {
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessOffsetOnsetEvent started");

            try
            {
                var runDate = await this.GetLastRunDate();
                await this.mapperService.Map(offsetOnsetMessage);
                await this.RemoveOldData(offsetOnsetMessage, runDate);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Error, "ClueAutoClaimEventProcessor:ProcessOffsetOnsetEvent", null, ex);
                return false;
            }

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessOffsetOnsetEvent ended");

            return true;
        }

        public async Task<bool> ProcessClaimPartyChangedEvent(ClaimPartyChangedDto claimPartyChangedMessage)
        {
            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessClaimPartyChangedEvent started");

            try
            {
                var runDate = await this.GetLastRunDate();
                await this.mapperService.Map(claimPartyChangedMessage);
                await this.RemoveOldData(claimPartyChangedMessage, runDate);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Error, "ClueAutoClaimEventProcessor:ProcessClaimPartyChangedEvent", null, ex);
                return false;
            }

            this.logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Verbose, "ProcessClaimPartyChangedEvent ended");

            return true;
        }

        private async Task RemoveOldData(ClaimsDto claimsDto, LastRunDate runDate)
        {
            var foundData = await this.DoesRecordExist(claimsDto.ClaimNumber, runDate);
            if (foundData == null)
            {
                return;
            }

            var orderedData = foundData.OrderBy(a => a["CreateDate"]).ToList();
            for (int indx = 0; indx < orderedData.Count - 1; indx++)
            {
                await this.RemoveClaimData(orderedData[indx].ToObject<ClueAutoData>());
            }
        }

        private async Task<List<JObject>> DoesRecordExist(string claimNumber, LastRunDate runDate)
        {
            if (runDate == null)
            {
                runDate = new LastRunDate();
            }

            if (string.IsNullOrEmpty(runDate.RunDate))
            {
                runDate.RunDate = DateTime.MinValue.ToString("yyyyMMddhhmmssffff");
            }

            var oldData = await this.storageManager.ReadRecordFilteredAsync(
                Constants.Azure.TableStorage.ThirdPartyContribution,
                $"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and ClaimNumber eq '{claimNumber}' and CreateDate ge '{runDate.RunDate}'");

            return oldData;
        }

        private async Task<LastRunDate> GetLastRunDate()
        {
            var root = await this.storageManager.ReadRecordFilteredAsync(
                Constants.Azure.TableStorage.ThirdPartyContribution,
                $"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and RowKey eq '{Constants.Azure.TableStorage.RunDateRowKey}'");

            LastRunDate runDate = root.FirstOrDefault()?.ToObject<LastRunDate>();
            return runDate;
        }

        private async Task RemoveClaimData(ClueAutoData clueAutoData)
        {
            await this.storageManager.DeleteFileAsync(clueAutoData.Container, clueAutoData.Folder, clueAutoData.Name);
            var rowKey = $"{clueAutoData.ClaimNumber}.{clueAutoData.PolicyNumber}.{clueAutoData.CreateDate}";
            await this.storageManager.DeleteRecordAsync(Constants.Azure.TableStorage.ThirdPartyContribution, Constants.Azure.TableStorage.ClueAutoPartitionKey, rowKey);
        }
    }
}