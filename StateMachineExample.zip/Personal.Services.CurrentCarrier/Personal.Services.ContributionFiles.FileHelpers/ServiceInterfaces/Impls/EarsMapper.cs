﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsMapper.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces.Impls
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using FileHelperExtensions;
    using global::FileHelpers;
    using FileMappers;
    using FileMappers.EarsRiskAlert;
    using WestBend.Core;

    public class EarsMapper : IEarsMapper
    {
        private readonly EngineFactory engineFactory;
        private readonly IFileWriter fileWriter;
        private readonly ILogger logger;

        public EarsMapper(EngineFactory engineFactory, IFileWriter fileWriter, ILogger logger)
        {
            this.engineFactory = engineFactory;
            this.fileWriter = fileWriter;
            this.logger = logger;
        }

        public async Task<string> MapEars(string container, string apimKey)
        {
            try
            {
                var records = new List<EarsRiskAlertDetailRequest>();

                //// some sort of way to find the list of data to use.

                records.Add(new EarsRiskAlertDetailRequest()
                {
                    BirthDate = new DateTime(1976, 1, 1),
                    FirstName = "Bob",
                    Gender = "M",
                    IncludeInEars = true,
                    IncludeInRiskAlert = false,
                    LastName = "Martin",
                    LicenseNumber = "77773333666",
                    LicenseState = "WI",
                    MiddleName = "K",
                    PolicyExpirationDate = new DateTime(2020, 1, 1),
                    PolicyNumber = "A123456",
                    StreetAddress = "1111 W Main",
                    Quoteback = "A123456",
                    ZipCode = "53223"
                });

                return await this.WriteFile(records, container, apimKey);
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, ex.Message, exception: ex);
                return string.Empty;
            }
        }

        private async Task<string> WriteFile(IReadOnlyCollection<EarsRiskAlertDetailRequest> records, string container, string apimKey)
        {
            var engine = this.engineFactory.CreateEngine(EngineFactory.EngineType.EARS);
            var earsRiskAlertHeader = new EarsRiskAlertHeader()
            {
                FileDate = DateTime.Now,
            };
            var earsRiskAlertTrailer = new EarsRiskAlertTrailer()
            {
                TotalRecords = records.Count
            };

            engine.HeaderText = new FileHelperEngine<EarsRiskAlertHeader>().WriteString(new List<EarsRiskAlertHeader>() { { earsRiskAlertHeader } });
            engine.FooterText = new FileHelperEngine<EarsRiskAlertTrailer>().WriteString(new List<EarsRiskAlertTrailer>() { { earsRiskAlertTrailer } });

            await this.fileWriter.WriteEarsOutbound(engine.WriteString(records), container, apimKey);
            return engine.WriteString(records);
        }
    }
}