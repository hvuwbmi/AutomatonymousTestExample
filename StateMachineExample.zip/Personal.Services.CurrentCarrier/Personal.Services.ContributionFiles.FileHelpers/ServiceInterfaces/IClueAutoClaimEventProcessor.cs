﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IClueAutoClaimEventProcessor.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Models.Dtos;

    public interface IClueAutoClaimEventProcessor
    {
        Task<bool> ProcessClaimStatusChangedEvent(StatusChangedDto statusChangedMessage);

        [System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.StyleCop.CSharp.NamingRules", "SA1305:FieldNamesMustNotUseHungarianNotation", Justification = "atFaultMessage is a valid name.")]
        Task<bool> ProcessAtFaultEvent(AtFaultDto atFaultMessage);

        Task<bool> ProcessFinancialTransactionCommittedEvent(
            FinancialTransactionCommittedDto financialTransactionCommittedMessage);

        Task<bool> ProcessOffsetOnsetEvent(OffsetOnsetDto offsetOnsetMessage);

        Task<bool> ProcessClaimPartyChangedEvent(ClaimPartyChangedDto claimPartyChangedMessage);
    }
}