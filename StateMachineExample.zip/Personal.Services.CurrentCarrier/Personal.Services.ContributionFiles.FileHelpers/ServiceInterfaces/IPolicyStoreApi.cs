﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IPolicyStoreApi.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Refit;

    public interface IPolicyStoreApi
    {
        [Get("/personal/policy/store/load/{policyNumber}/{policyVersion}/{transactionSequenceNumber}/")]
        Task<string> GetPolicyRequest(string policyNumber, string policyVersion, string transactionSequenceNumber, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);

        [Get("/personal/policy/store/load/{policyNumber}/date/{date}/")]
        [Headers("Accept: application/xml")]
        Task<string> GetPolicyRequest(string policyNumber, string date, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);

        [Get("/personal/policy/store/transact/{policyNumber}")]
        [Headers("Accept: application/xml")]
        Task<string> GetTransactionList(string policyNumber, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);

        /// <summary>
        /// Retrieve the policy version that was in effect prior to the specified policy number/version/sequence.
        /// </summary>
        /// <param name="policyNumber">The policy number to retrieve.</param>
        /// <param name="policyVersion">The policy version to retrieve.</param>
        /// <param name="transactionSequenceNumber">THe transaction sequence number to retrieve.</param>
        /// <param name="statusInForced"></param>
        /// <param name="subscriptionKey">The subscription key used to communicate to the APIM.</param>
        /// <returns>The policy in effect prior to the specified policy.</returns>
        [Get("/personal/policy/store/GetPriorVersion/policy/{policyNumber}/term/{policyVersion}/mod/{transactionSequenceNumber}/previousHistory?statusInForced={statusInForced}")]
        [Headers("Accept: application/xml")]
        Task<string> GetPriorVersion(string policyNumber, string policyVersion, string transactionSequenceNumber, string statusInForced, [Header("Ocp-Apim-Subscription-Key")] string subscriptionKey);
    }
}