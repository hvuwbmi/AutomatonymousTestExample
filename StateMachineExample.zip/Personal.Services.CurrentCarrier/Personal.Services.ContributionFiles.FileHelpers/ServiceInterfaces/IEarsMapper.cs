﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IEarsMapper.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Requests;

    public interface IEarsMapper
    {
        Task<string> MapEars(string container, string apimKey);
    }
}