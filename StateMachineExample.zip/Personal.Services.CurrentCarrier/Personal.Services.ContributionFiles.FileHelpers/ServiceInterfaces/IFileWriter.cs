﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="IFileWriter.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces
{
    using System.Threading.Tasks;
    using Models;

    public interface IFileWriter
    {
        Task<CurrentCarrierData> WriteCurrentCarrier(string file, string policyNumber, string version, string mod);

        Task WriteEarsOutbound(string file, string container, string apimKey);

        Task<ClueAutoData> WriteClueAuto(string file, string claimNumber, string policyNumber, string claimType);
    }
}