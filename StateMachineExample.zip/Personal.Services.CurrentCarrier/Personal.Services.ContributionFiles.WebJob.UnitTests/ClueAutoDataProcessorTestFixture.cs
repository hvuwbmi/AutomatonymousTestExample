﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoDataProcessorTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.WebJob.UnitTests
{
    using System;
    using System.IO;
    using System.Threading.Tasks;
    using MediatR;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Personal.Services.ContributionFiles.WebJob;
    using Rhino.Mocks;
    using WestBend.Core;

    [TestClass]
    public class ClueAutoDataProcessorTestFixture
    {
        [TestMethod]
        public void Test_ClueAutoDataProcessor_CleanupFilesProcessor_Success()
        {
            // arrange
            var logger = MockRepository.GenerateStrictMock<ILogger>();
            var mediator = MockRepository.GenerateStub<IMediator>();
            var storageManager = MockRepository.GenerateStrictMock<IStorageManager>();
            var blobList = this.RetrieveFileContents("SomeFilesToDeleteClueAuto.xml");

            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Starting to remove obsolete files", null, null, string.Empty, true));
            storageManager.Expect(s => s.ListFileAsync("pl-third-party-integration", "LexisNexis.ClueAuto.Out", "ClueAuto")).Return(Task.FromResult(blobList));
            storageManager.Expect(s => s.DeleteFileAsync("pl-third-party-integration", "LexisNexis.ClueAuto.Out", "ClueAuto201910140629401529.txt")).Return(Task.FromResult(string.Empty));
            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Finished removing obsolete files", null, null, string.Empty, true));

            // act
            var processor = new ClueAutoDataProcessor();
            var result = processor.CleanupFilesProcessor(logger, storageManager, "abc123", DateTime.UtcNow);

            // assert
            logger.VerifyAllExpectations();
            storageManager.VerifyAllExpectations();
        }

        [TestMethod]
        public async Task Test_ClueAutoDataProcessor_ProcessCurrentCarrier_StoreFile()
        {
            // arrange
            var logger = MockRepository.GenerateStrictMock<ILogger>();
            var mediator = MockRepository.GenerateStub<IMediator>();
            var storageManager = MockRepository.GenerateStrictMock<IStorageManager>();
            var lexisNexisApi = MockRepository.GenerateStrictMock<ILexisNexisApi>();
            var requestBody = new ContributionRequestBody { suppressSFTP = true };
            var responseBody = new ContributionResponse { Data = "some data to store" };

            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Storing file to Azure storage", null, null, string.Empty, true));
            storageManager.Expect(s => s.CreateFileAsync(
                Arg.Is("pl-third-party-integration"),
                Arg.Is("LexisNexis.Contribution"),
                Arg<string>.Matches(m => m.StartsWith("cc_history_westbnd2_dev_")),
                Arg.Is("some data to store"),
                Arg.Is("text/plain"),
                Arg.Is("BlockBlob"))).Return(Task.FromResult(string.Empty));
            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Completed file store", null, null, string.Empty, true));

            // act
            var processor = new ClueAutoDataProcessor();
            await processor.ProcessContributionProcessor(requestBody, responseBody, "abc123", storageManager, lexisNexisApi, "dev_", logger);

            // assert
            logger.VerifyAllExpectations();
            storageManager.VerifyAllExpectations();
            lexisNexisApi.VerifyAllExpectations();
        }

        [TestMethod]
        public async Task Test_ClueAutoDataProcessor_ProcessCurrentCarrier_UploadFile()
        {
            // arrange
            var logger = MockRepository.GenerateStrictMock<ILogger>();
            var mediator = MockRepository.GenerateStub<IMediator>();
            var storageManager = MockRepository.GenerateStrictMock<IStorageManager>();
            var lexisNexisApi = MockRepository.GenerateStrictMock<ILexisNexisApi>();
            var requestBody = new ContributionRequestBody { suppressSFTP = false };
            var responseBody = new ContributionResponse { Data = "some data to store" };

            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Starting to upload file to LexisNexis", null, null, string.Empty, true));
            lexisNexisApi.Expect(a => a.SftpUpload(Arg<string>.Matches(m => m.StartsWith("cc_history_westbnd2_dev_")), Arg.Is("abc123"), Arg.Is("some data to store"))).Return(Task.CompletedTask);
            logger.Expect(l => l.Log("PL.Services.Claims.ClueAuto", System.Diagnostics.TraceEventType.Information, "Completed file upload", null, null, string.Empty, true));

            // act
            var processor = new ClueAutoDataProcessor();
            await processor.ProcessContributionProcessor(requestBody, responseBody, "abc123", storageManager, lexisNexisApi, "dev_", logger);

            // assert
            logger.VerifyAllExpectations();
            storageManager.VerifyAllExpectations();
            lexisNexisApi.VerifyAllExpectations();
        }

        private string RetrieveFileContents(string fileName)
        {
            using (var sr = new StreamReader($"data/{fileName}"))
            {
                var line = sr.ReadToEnd();
                return line;
            }
        }
    }
}
