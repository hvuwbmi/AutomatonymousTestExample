﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoController.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api.Controllers
{
    using System.Configuration;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using System.Web.Http;
    using FileHelpers.FileMappers;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using WestBend.Core;

    public class ClueAutoController : ApiController
    {
        public ClueAutoController(ILogger logger)
        {
            this.Logger = logger;
            this.Logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Information, "Created ClueAutoController");
        }

        public ILogger Logger { get; internal set; }

        [HttpPost]
        public async Task<IHttpActionResult> Post([FromBody] JObject requestBody)
        {
            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimSubKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            var storageManager = new StorageManager(apiUrl, apimSubKey);

            return await this.PostWorker(requestBody, storageManager);
        }

        internal async Task<IHttpActionResult> PostWorker(JObject requestBody, IStorageManager storageManager)
        {
            this.Logger.Log(Constants.Logging.CATEGORYCLUEAUTO, TraceEventType.Information, "Calling CLUEAuto trigger");

            await storageManager.CreateFileAsync(
                Constants.Azure.BlobStorage.ContainerName,
                Constants.Azure.BlobStorage.FolderNameClueAutoOutput,
                Constants.Azure.BlobStorage.TriggerFileClueAuto,
                requestBody.ToString());

            return this.Ok("The CLUE Auto contribution file has been scheduled to be created.");
        }
    }
}