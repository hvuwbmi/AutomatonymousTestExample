﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EARSController.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api.Controllers
{
    using System;
    using System.Configuration;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using System.Web.Http;
    using FileHelpers.FileMappers;
    using FileHelpers.Requests;
    using MediatR;
    using Models;
    using WestBend.Core;

    public class EARSController : ApiController
    {
        private readonly ILogger logger;
        private readonly IMediator mediator;

        public EARSController(ILogger logger, IMediator mediator)
        {
            this.logger = logger;
            this.mediator = mediator;
        }

        [HttpGet]
        public async Task<EARSResponse> Get()
        {
            var earsResponse = new EARSResponse();
            try
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, "Running Parse EARS");
                var apimKey = ConfigurationManager.AppSettings["ApimSubscriptionKey"];
                var container = ConfigurationManager.AppSettings["ContainerReference"];

                earsResponse.Data = await this.mediator.Send(new ParseEARS { ApimKey = apimKey, Container = container });

                return earsResponse;
            }
            catch (Exception ex)
            {
                this.logger.Log(Constants.Logging.CATEGORY, TraceEventType.Error, ex.Message, null, ex);
                earsResponse.Data = string.Empty;
                return earsResponse;
            }
        }
    }
}