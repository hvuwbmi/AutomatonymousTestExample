﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="CurrentCarrierController.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api.Controllers
{
    using System.Configuration;
    using System.Diagnostics;
    using System.Threading.Tasks;
    using System.Web.Http;
    using FileHelpers.FileMappers;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using WestBend.Core;

    /// <summary>
    /// This is the web API controller for Current Carrier.
    /// The user or batch job will call "POST /api/CurrentCarrier" with a JSON body,
    /// { "suppressSFTP": true/false }. The POST handler will write a trigger file to
    /// blob storage. The WebJob on a timer will poll the blob storage (BlobTrigger
    /// didn't work, maybe that's an enhancement) for that file, read the contents,
    /// delete the file, and start processing the current carrier data files.
    /// </summary>
    /// <remarks>
    /// Originally there was a GET handler. This has been reworked, and is now in the
    /// WebJob project, within the CurrentCarrierDataProcessor.
    /// </remarks>
    public class CurrentCarrierController : ApiController
    {
        public CurrentCarrierController(ILogger logger)
        {
            this.Logger = logger;
            this.Logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, "Created CurrentCarrierController");
        }

        public ILogger Logger { get; internal set; }

        [HttpPost]
        public async Task<IHttpActionResult> Post([FromBody] JObject requestBody)
        {
            var apiUrl = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimUrl];
            var apimSubKey = ConfigurationManager.AppSettings[Constants.AppSettingKeys.ApimSubscriptionKey];
            var storageManager = new StorageManager(apiUrl, apimSubKey);

            return await this.PostWorker(requestBody, storageManager);
        }

        internal async Task<IHttpActionResult> PostWorker(JObject requestBody, IStorageManager storageManager)
        {
            this.Logger.Log(Constants.Logging.CATEGORY, TraceEventType.Information, "Calling trigger");

            await storageManager.CreateFileAsync(
                Constants.Azure.BlobStorage.ContainerName,
                Constants.Azure.BlobStorage.FolderName,
                Constants.Azure.BlobStorage.TriggerFileCurrentCarrier,
                requestBody.ToString());

            return this.Ok("The current carrier contribution file has been scheduled to be created.");
        }
    }
}