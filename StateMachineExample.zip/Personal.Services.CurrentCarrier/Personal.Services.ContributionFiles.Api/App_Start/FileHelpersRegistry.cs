﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="FileHelpersRegistry.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api
{
    using StructureMap;
    using WestBend.Core;
    using WestBend.Core.Service;

    public class FileHelpersRegistry : Registry
    {
        public FileHelpersRegistry()
        {
            this.For<ILogger>().Add<CommonLogger>();
        }
    }
}