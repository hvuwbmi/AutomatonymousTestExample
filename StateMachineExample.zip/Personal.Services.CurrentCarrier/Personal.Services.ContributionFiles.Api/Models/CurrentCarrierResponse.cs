﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierResponse.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.Api.Models
{
    public class CurrentCarrierResponse
    {
        public string Data { get; set; }
    }
}