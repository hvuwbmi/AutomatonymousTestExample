﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoResponse.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.Api.Models
{
    public class ClueAutoResponse
    {
        public string Data { get; set; }
    }
}