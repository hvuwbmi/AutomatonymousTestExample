﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CLUEAutoTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using global::FileHelpers;
    using FileHelpers.FileHelperExtensions;
    using FileHelpers.FileMappers.CLUEAuto;
    using FileHelpers.Models;
    using FileHelpers.ServiceInterfaces;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Models.Claims;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class CLUEAutoTestFixture
    {
        #region Private variables
        private static readonly string DriverLicenseToken1 = "9RZ3L9GIZ30001";
        private static readonly string DriverLicenseToken2 = "9RZ3L9GIZ30002";
        private static readonly string DriverLicenseToken3 = "9RZ3L9GIZ30003";
        private static readonly string DriverLicenseNumber1 = "HOLDER1000000000";
        private static readonly string DriverLicenseNumber2 = "HOLDER2000000000";
        private static readonly string DriverLicenseNumber3 = "DRIVER1000000000";
        private static string policyHolder1Prefix = string.Empty;
        private static string policyHolder1LastName = "ADAMS";
        private static string policyHolder1FirstName = "BRYAN";
        private static string policyHolder1MiddleName = "A";
        private static string policyHolder1Suffix = string.Empty;
        private static string policyHolder1AddressHouseNumber = "102";
        private static string policyHolder1AddressStreetName = "MAIN ST";
        private static string policyHolder1AddressApartmentNumber = string.Empty;
        private static string policyHolder1AddressCity = "WEST BEND";
        private static string policyHolder1AddressState = "WI";
        private static string policyHolder1AddressZipCode = "53095";
        private static string policyHolder1AddressZipCodePlus4 = "8510";
        private static string filler1 = string.Empty.PadRight(10);
        private static string policyHolder1SocialSecurityNumber = string.Empty;
        private static string policyHolder1DOB = "05041969";
        private static string policyHolder1DLNumber = string.Empty;
        private static string policyHolder1DLState = "WI";
        private static string policyHolder1Sex = "M";
        private static string filler2 = string.Empty;
        private static string policyHolder2Prefix = string.Empty;
        private static string policyHolder2LastName = "PETTY";
        private static string policyHolder2FirstName = "TOM";
        private static string policyHolder2MiddleName = string.Empty;
        private static string policyHolder2Suffix = string.Empty;
        private static string policyHolder2SocialSecurityNumber = string.Empty;
        private static string policyHolder2DOB = "08071945";
        private static string policyHolder2DLNumber = string.Empty;
        private static string policyHolder2DLState = "WI";
        private static string policyHolder2Sex = "M";
        private static string filler3 = string.Empty;
        private static string vehicleOperatorPrefix = string.Empty;
        private static string vehicleOperatorLastName = "ADAMS";
        private static string vehicleOperatorFirstName = "BRYAN";
        private static string vehicleOperatorMiddleName = "A";
        private static string vehicleOperatorSuffix = string.Empty;
        private static string vehicleOperatorAddressHouseNumber = "102";
        private static string vehicleOperatorAddressStreetName = "MAIN ST";
        private static string vehicleOperatorAddressApartmentNumber = string.Empty;
        private static string vehicleOperatorAddressCity = "WEST BEND";
        private static string vehicleOperatorAddressState = "WI";
        private static string vehicleOperatorAddressZipCode = "53095";
        private static string vehicleOperatorAddressZipCodePlus4 = "8510";
        private static string filler4 = string.Empty;
        private static string vehicleOperatorSocialSecurityNumber = string.Empty;
        private static string vehicleOperatorDOB = "00000000";
        private static string vehicleOperatorDLNumber = string.Empty;
        private static string vehicleOperatorDLState = "WI";
        private static string vehicleOperatorSex = "M";
        private static string vehicleOperatorRelationship = "M";
        private static string filler5 = string.Empty;
        private static string contribuitingCompanyIdentificationNumber = "12345";
        private static string policyNumber = "AS123456789";
        private static string policyType = "HH";
        private static string filler6 = string.Empty;
        private static string claimNumber = "123456789";
        private static string claimType = "AB";
        private static string claimDate = "05041969";
        private static string claimAmount = "40000";
        private static string claimReportingStatus = "A";
        private static string insuredVehicleVIN = "YS3DD55B5S2024727";
        private static string insuredVehicleModelYear = "2019";
        private static string insuredVehicleMakeAndModel = "HONDA CIVIC2019";
        private static string insuredVehicleDisposition = string.Empty;
        private static string claimDisposition = "Z";
        private static string faultIndicator = "2";
        private static string dateOfFirstPayment = "00000000";
        private static string indicatorCA1 = string.Empty;
        private static string indicatorCA2 = string.Empty;
        private static string indicatorCA3 = string.Empty;
        private static string indicatorCA4 = string.Empty;
        private static string filler7 = string.Empty;
        private static string recordVersionNumber = "1";
        #endregion

        private ILogger logger;

        [TestInitialize]
        public void TestInitialize()
        {
            LicenseConverter.TokenApi = MockRepository.GenerateStub<ITokenApi>();
            this.logger = MockRepository.GenerateStub<ILogger>();

            LicenseConverter.TokenApi.Stub(a => a.Detokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = DriverLicenseNumber1 }))
                .Repeat.Once();
            LicenseConverter.TokenApi.Stub(a => a.Detokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = DriverLicenseNumber2 }))
                .Repeat.Once();
            LicenseConverter.TokenApi.Stub(a => a.Detokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = DriverLicenseNumber3 }))
                .Repeat.Once();
        }

        [TestMethod]
        public void TestJulianDate()
        {
            // This is a little more complex than I'd like, apparently ADO runs in UTC.
            // 'now' is DateTime.UtcNow, but I don't want actual current time for the test.
            var now = new DateTime(2020, 6, 2, 2, 0, 0, DateTimeKind.Utc);
            TimeZoneInfo cstZone = TimeZoneInfo.FindSystemTimeZoneById("Central Standard Time");
            var localNow = TimeZoneInfo.ConvertTimeFromUtc(now, cstZone);
            var lastRunDate = "202004230202313337";
            var utcLastRunDate = new DateTime(2020, 4, 23, 2, 2, 13, DateTimeKind.Utc);
            var localLastRunDate = TimeZoneInfo.ConvertTimeFromUtc(utcLastRunDate, cstZone);

            string actual = new FileHelperEngine<CLUEAutoHeader>().WriteString(new List<CLUEAutoHeader>() { new CLUEAutoHeader().Map(now, lastRunDate, this.logger) });
            actual.ShouldEqual($"##!!SAC#{now.ToString("yy")}{now.DayOfYear.ToString().PadLeft(3, '0')}{now.ToString("HHmm")}CLUE          B50289FTPE11967000WEST BEND MUTUAL INS                                     CLUE_HISTORY                  {localLastRunDate.AddDays(1).ToString("yyyyMMdd")}{localNow.ToString("yyyyMMdd")}                                                                                                        " + Environment.NewLine);
        }

        [TestMethod]
        public void TestCLUEAutoLossTransaction_SubFile()
        {
            var engine = new CLUEAutoEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            List<CLUEAutoLossTransaction> obj = BuildCLUEAutoLossTransactionObjectList();

            string actualSubFile = engine.WriteString(obj.AsEnumerable());
            string expected = BuildExpectedSubFileString();

            actualSubFile.Length.ShouldEqual(740 + 2); // Extra 2 for Environment.NewLine
            actualSubFile.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestCLUEAutoLossTransaction_MainFile()
        {
            var engine = new CLUEAutoEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            string subFile = BuildExpectedSubFileString();

            List<CLUEAutoLossTransaction> actualMainFile = new List<CLUEAutoLossTransaction>();
            var detailEngine = new FixedFileEngine<CLUEAutoLossTransaction>();
            actualMainFile = detailEngine.ReadString(subFile).ToList();

            string actualMainString = detailEngine.WriteString(actualMainFile);
            string expected = BuildExpectedMainFileString();

            actualMainString.Length.ShouldEqual(740 + 2); // Extra 2 for Environment.NewLine
            actualMainString.ShouldEqual(expected);

            LicenseConverter.TokenApi.AssertWasCalled(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything));
            var tokenArgs = LicenseConverter.TokenApi.GetArgumentsForCallsMadeOn(x => x.Detokenize(null, null));

            TokenRequest tokenArgCalled1 = (TokenRequest)tokenArgs[0][0];
            tokenArgCalled1.data.ShouldEqual(DriverLicenseToken1);

            TokenRequest tokenArgCalled2 = (TokenRequest)tokenArgs[1][0];
            tokenArgCalled2.data.ShouldEqual(DriverLicenseToken2);

            TokenRequest tokenArgCalled3 = (TokenRequest)tokenArgs[2][0];
            tokenArgCalled3.data.ShouldEqual(DriverLicenseToken3);
        }

        [TestMethod]
        public void TestHeader_CLUEAuto()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.CLUEAuto);
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var clueAutoHeaders = new List<CLUEAutoHeader> { new CLUEAutoHeader() };
            var engineHeaderText = new FixedFileEngine<CLUEAutoHeader>();
            engine.HeaderText = engineHeaderText.WriteString(clueAutoHeaders);
            var expected =
                "##!!SAC#010000000CLUE          B50289FTPE11967000WEST BEND MUTUAL INS                                     CLUE_HISTORY                  0001010100010101                                                                                                        " +
                Environment.NewLine;
            var actual = engine.WriteString(new List<CLUEAutoHeader>().AsEnumerable());

            actual.Length.ShouldEqual(256 + 2);
            actual.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestFooter_CLUEAuto_10Records()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.CLUEAuto);
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var trailer = new CLUEAutoTrailer();
            trailer.Map(10, DateTime.MinValue);

            var clueAutoHeaders = new List<CLUEAutoTrailer> { trailer };
            var engineFooterText = new FixedFileEngine<CLUEAutoTrailer>();
            engine.FooterText = engineFooterText.WriteString(clueAutoHeaders);
            var expected =
                "##!!SAT#010010001CLUE          B50289FTP000010                                                                                                                                                                                                                  " +
                Environment.NewLine;
            var actual = engine.WriteString(new List<CLUEAutoTrailer>().AsEnumerable());

            actual.Length.ShouldEqual(256 + 2);
            actual.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestFooter_CLUEAuto_10000000Records()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.CLUEAuto);
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var trailer = new CLUEAutoTrailer();
            trailer.Map(10000000, DateTime.MinValue);

            var clueAutoHeaders = new List<CLUEAutoTrailer> { trailer };
            var engineFooterText = new FixedFileEngine<CLUEAutoTrailer>();
            engine.FooterText = engineFooterText.WriteString(clueAutoHeaders);
            var expected =
                "##!!SAT#010010001CLUE          B50289FTP99999910000000                                                                                                                                                                                                          " +
                Environment.NewLine;
            var actual = engine.WriteString(new List<CLUEAutoTrailer>().AsEnumerable());

            actual.Length.ShouldEqual(256 + 2);
            actual.ShouldEqual(expected);
        }

        [TestMethod]
        public async Task Test_PolicyMapping_ValidMapping()
        {
            var xml = this.GetClueAutoPolicyClaimData("data/CLUEAutoPolicyClaimData.xml");
            var serializer = new XmlSerializer(typeof(PolicyRs));
            PolicyRs data = null;
            using (var reader = new StringReader(xml.Result))
            {
                data = (PolicyRs)serializer.Deserialize(reader);
            }

            var file = new CLUEAutoLossTransaction();
            var claimsData = new ClaimsData() { DriverNumber = "1000", DriverType = "LISTED", VehicleNumber = "1000" };
            await data.MapCLUEAutoLossTransaction(file, claimsData);

            file.PolicyHolder1LastName.ShouldEqual("Sample"?.ToUpper());
            file.PolicyHolder1FirstName.ShouldEqual("John"?.ToUpper());
            file.PolicyHolder1MiddleName.ShouldEqual("Q");
            file.PolicyHolder1Suffix.ShouldEqual("Jr."?.ToUpper());
            file.PolicyHolder1AddressHouseNumber.ShouldEqual("123");
            file.PolicyHolder1AddressStreetName.ShouldEqual("N Main St"?.ToUpper());
            file.PolicyHolder1AddressApartmentNumber.ShouldEqual("4A");
            file.PolicyHolder1AddressCity.ShouldEqual("Ann Arbor"?.ToUpper());
            file.PolicyHolder1AddressState.ShouldEqual("MI");
            file.PolicyHolder1AddressZipCode.ShouldEqual("48001");
            file.PolicyHolder1AddressZipCodePlus4.ShouldEqual("1245");
            file.PolicyHolder1DOB.ShouldEqual(new DateTime(1965, 4, 5));
            file.PolicyHolder1DLNumber.ShouldEqual("S1234567890123");
            file.PolicyHolder1DLState.ShouldEqual("WI");
            file.PolicyHolder1Sex.ShouldEqual("M");
            file.PolicyHolder2LastName.ShouldEqual("Sample"?.ToUpper());
            file.PolicyHolder2FirstName.ShouldEqual("Jane"?.ToUpper());
            file.PolicyHolder2MiddleName.ShouldEqual("S");
            file.PolicyHolder2Suffix.ShouldEqual("I");
            file.PolicyHolder2DOB.Value.ShouldEqual(new DateTime(1970, 12, 10));
            file.PolicyHolder2DLNumber.ShouldEqual("S9876543215456");
            file.PolicyHolder2DLState.ShouldEqual("WI");
            file.PolicyHolder2Sex.ShouldEqual("F");
            file.PolicyNumber.ShouldEqual("A123456");
            file.InsuredVehicleModelYear.ShouldEqual("2001");
            file.InsuredVehicleMakeAndModel.ShouldEqual("MAZDA RX-5");
        }

        [DataRow("data/CLUEAutoPolicyRelationshipToCdFNI.xml", "P")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdCN.xml", "H")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdSP.xml", "S")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdCH.xml", "C")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdPA.xml", "F")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdGP.xml", "O")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdRE.xml", "O")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdNR.xml", "X")]
        [DataRow("data/CLUEAutoPolicyRelationshipToCdBlank.xml", "")]
        [TestMethod]
        public async Task Test_VORelationshipMapping_SetsRelationshipToCode(string filePath, string vehicleOperatoRelationship)
        {
            var xml = this.GetClueAutoPolicyClaimData(filePath);
            var serializer = new XmlSerializer(typeof(PolicyRs));
            PolicyRs data = null;
            using (var reader = new StringReader(xml.Result))
            {
                data = (PolicyRs)serializer.Deserialize(reader);
            }

            var file = new CLUEAutoLossTransaction();
            var claimsData = new ClaimsData() { DriverNumber = "1000", DriverType = "LISTED", VehicleNumber = "1000" };
            await data.MapCLUEAutoLossTransaction(file, claimsData);

            file.VehicleOperatorRelationship.ShouldEqual(vehicleOperatoRelationship);
        }

        [DataRow("data/AcordFromUIWithThreeDriverAndCoap.xml")]
        [TestMethod]
        public async Task Test_CoApplicantMapping_CoApplicantSetAsPolicyHolder2(string filePath)
        {
            var xml = this.GetClueAutoPolicyClaimData(filePath);
            var serializer = new XmlSerializer(typeof(PolicyRs));
            PolicyRs data = null;
            using (var reader = new StringReader(xml.Result))
            {
                data = (PolicyRs)serializer.Deserialize(reader);
            }

            var file = new CLUEAutoLossTransaction();
            var claimsData = new ClaimsData() { DriverNumber = "1000", DriverType = "LISTED", VehicleNumber = "1000" };
            await data.MapCLUEAutoLossTransaction(file, claimsData);

            file.PolicyHolder2DLNumber.ShouldEqual("PIY32SP88W7891");
            file.PolicyHolder2DLState.ShouldEqual("MI");
            file.PolicyHolder2DOB.ShouldEqual(DateTime.Parse("07/25/1980"));
            file.PolicyHolder2FirstName.ShouldEqual("TINA");
            file.PolicyHolder2MiddleName.ShouldEqual(null);
            file.PolicyHolder2LastName.ShouldEqual("TURNER");
            file.PolicyHolder2Prefix.ShouldEqual(null);
            file.PolicyHolder2Sex.ShouldEqual("F");
            file.PolicyHolder2SocialSecurityNumber.ShouldEqual("000000000");
            file.PolicyHolder2Suffix.ShouldEqual(string.Empty);
        }

        private static string BuildExpectedMainFileString()
        {
            policyHolder1Prefix = policyHolder1Prefix.PadRight(4);
            policyHolder1LastName = policyHolder1LastName.PadRight(20);
            policyHolder1FirstName = policyHolder1FirstName.PadRight(20);
            policyHolder1MiddleName = policyHolder1MiddleName.PadRight(15);
            policyHolder1Suffix = policyHolder1Suffix.PadRight(3);
            policyHolder1AddressHouseNumber = policyHolder1AddressHouseNumber.PadRight(9);
            policyHolder1AddressStreetName = policyHolder1AddressStreetName.PadRight(20);
            policyHolder1AddressApartmentNumber = policyHolder1AddressApartmentNumber.PadRight(5);
            policyHolder1AddressCity = policyHolder1AddressCity.PadRight(20);
            policyHolder1AddressState = policyHolder1AddressState.PadRight(2);
            policyHolder1AddressZipCode = policyHolder1AddressZipCode.PadRight(5);
            policyHolder1AddressZipCodePlus4 = policyHolder1AddressZipCodePlus4.PadRight(4);
            filler1 = filler1.PadRight(10);
            policyHolder1SocialSecurityNumber = policyHolder1SocialSecurityNumber.PadRight(9);
            policyHolder1DLNumber = DriverLicenseNumber1.PadRight(25);
            policyHolder1DLState = policyHolder1DLState.PadRight(2);
            policyHolder1Sex = policyHolder1Sex.PadRight(1);
            filler2 = filler2.PadRight(28);
            policyHolder2Prefix = policyHolder2Prefix.PadRight(4);
            policyHolder2LastName = policyHolder2LastName.PadRight(20);
            policyHolder2FirstName = policyHolder2FirstName.PadRight(20);
            policyHolder2MiddleName = policyHolder2MiddleName.PadRight(15);
            policyHolder2Suffix = policyHolder2Suffix.PadRight(3);
            policyHolder2SocialSecurityNumber = policyHolder2SocialSecurityNumber.PadRight(9);
            policyHolder2DLNumber = DriverLicenseNumber2.PadRight(25);
            policyHolder2DLState = policyHolder2DLState.PadRight(2);
            policyHolder2Sex = policyHolder2Sex.PadRight(1);
            filler3 = filler3.PadRight(18);
            vehicleOperatorPrefix = vehicleOperatorPrefix.PadRight(4);
            vehicleOperatorLastName = vehicleOperatorLastName.PadRight(20);
            vehicleOperatorFirstName = vehicleOperatorFirstName.PadRight(20);
            vehicleOperatorMiddleName = vehicleOperatorMiddleName.PadRight(15);
            vehicleOperatorSuffix = vehicleOperatorSuffix.PadRight(3);
            vehicleOperatorAddressHouseNumber = vehicleOperatorAddressHouseNumber.PadRight(9);
            vehicleOperatorAddressStreetName = vehicleOperatorAddressStreetName.PadRight(20);
            vehicleOperatorAddressApartmentNumber = vehicleOperatorAddressApartmentNumber.PadRight(5);
            vehicleOperatorAddressCity = vehicleOperatorAddressCity.PadRight(20);
            vehicleOperatorAddressState = vehicleOperatorAddressState.PadRight(2);
            vehicleOperatorAddressZipCode = vehicleOperatorAddressZipCode.PadRight(5);
            vehicleOperatorAddressZipCodePlus4 = vehicleOperatorAddressZipCodePlus4.PadRight(4);
            filler4 = filler4.PadRight(10);
            vehicleOperatorSocialSecurityNumber = vehicleOperatorSocialSecurityNumber.PadRight(1);
            vehicleOperatorDLNumber = DriverLicenseNumber3.PadRight(25);
            vehicleOperatorDLState = vehicleOperatorDLState.PadRight(2);
            vehicleOperatorSex = vehicleOperatorSex.PadRight(1);
            vehicleOperatorRelationship = vehicleOperatorRelationship.PadRight(1);
            filler5 = filler5.PadRight(28);
            contribuitingCompanyIdentificationNumber = contribuitingCompanyIdentificationNumber.PadRight(5);
            policyNumber = policyNumber.PadRight(20);
            policyType = policyType.PadRight(2);
            filler6 = filler6.PadRight(18);
            claimNumber = claimNumber.PadRight(20);
            claimType = claimType.PadRight(2);
            claimAmount = claimAmount.PadLeft(9, '0');
            claimReportingStatus = claimReportingStatus.PadRight(1);
            insuredVehicleVIN = insuredVehicleVIN.PadRight(25);
            insuredVehicleModelYear = insuredVehicleModelYear.PadRight(4);
            insuredVehicleMakeAndModel = insuredVehicleMakeAndModel.PadRight(40);
            insuredVehicleDisposition = insuredVehicleDisposition.PadRight(1);
            claimDisposition = claimDisposition.PadRight(1);
            faultIndicator = faultIndicator.PadRight(1);
            dateOfFirstPayment = dateOfFirstPayment.PadLeft(8, '0');
            indicatorCA1 = indicatorCA1.PadRight(1);
            indicatorCA2 = indicatorCA2.PadRight(1);
            indicatorCA3 = indicatorCA3.PadRight(1);
            indicatorCA4 = indicatorCA4.PadRight(1);
            filler7 = filler7.PadRight(24);
            recordVersionNumber = recordVersionNumber.PadRight(1);

            string inputString =
                policyHolder1Prefix
                + policyHolder1LastName
                + policyHolder1FirstName
                + policyHolder1MiddleName
                + policyHolder1Suffix
                + policyHolder1AddressHouseNumber
                + policyHolder1AddressStreetName
                + policyHolder1AddressApartmentNumber
                + policyHolder1AddressCity
                + policyHolder1AddressState
                + policyHolder1AddressZipCode
                + policyHolder1AddressZipCodePlus4
                + filler1
                + policyHolder1SocialSecurityNumber
                + policyHolder1DOB
                + policyHolder1DLNumber
                + policyHolder1DLState
                + policyHolder1Sex
                + filler2
                + policyHolder2Prefix
                + policyHolder2LastName
                + policyHolder2FirstName
                + policyHolder2MiddleName
                + policyHolder2Suffix
                + policyHolder2SocialSecurityNumber
                + policyHolder2DOB
                + policyHolder2DLNumber
                + policyHolder2DLState
                + policyHolder2Sex
                + filler3
                + vehicleOperatorPrefix
                + vehicleOperatorLastName
                + vehicleOperatorFirstName
                + vehicleOperatorMiddleName
                + vehicleOperatorSuffix
                + vehicleOperatorAddressHouseNumber
                + vehicleOperatorAddressStreetName
                + vehicleOperatorAddressApartmentNumber
                + vehicleOperatorAddressCity
                + vehicleOperatorAddressState
                + vehicleOperatorAddressZipCode
                + vehicleOperatorAddressZipCodePlus4
                + filler4
                + vehicleOperatorSocialSecurityNumber
                + vehicleOperatorDOB
                + vehicleOperatorDLNumber
                + vehicleOperatorDLState
                + vehicleOperatorSex
                + vehicleOperatorRelationship
                + filler5
                + contribuitingCompanyIdentificationNumber
                + policyNumber
                + policyType
                + filler6
                + claimNumber
                + claimType
                + claimDate
                + claimAmount
                + claimReportingStatus
                + insuredVehicleVIN
                + insuredVehicleModelYear
                + insuredVehicleMakeAndModel
                + insuredVehicleDisposition
                + claimDisposition
                + faultIndicator
                + dateOfFirstPayment
                + indicatorCA1
                + indicatorCA2
                + indicatorCA3
                + indicatorCA4
                + filler7
                + recordVersionNumber
                + Environment.NewLine;

            return inputString;
        }

        private static string BuildExpectedSubFileString()
        {
            policyHolder1Prefix = policyHolder1Prefix.PadRight(4);
            policyHolder1LastName = policyHolder1LastName.PadRight(20);
            policyHolder1FirstName = policyHolder1FirstName.PadRight(20);
            policyHolder1MiddleName = policyHolder1MiddleName.PadRight(15);
            policyHolder1Suffix = policyHolder1Suffix.PadRight(3);
            policyHolder1AddressHouseNumber = policyHolder1AddressHouseNumber.PadRight(9);
            policyHolder1AddressStreetName = policyHolder1AddressStreetName.PadRight(20);
            policyHolder1AddressApartmentNumber = policyHolder1AddressApartmentNumber.PadRight(5);
            policyHolder1AddressCity = policyHolder1AddressCity.PadRight(20);
            policyHolder1AddressState = policyHolder1AddressState.PadRight(2);
            policyHolder1AddressZipCode = policyHolder1AddressZipCode.PadRight(5);
            policyHolder1AddressZipCodePlus4 = policyHolder1AddressZipCodePlus4.PadRight(4);
            filler1 = filler1.PadRight(10);
            policyHolder1SocialSecurityNumber = policyHolder1SocialSecurityNumber.PadRight(9, '0');
            policyHolder1DLNumber = DriverLicenseToken1.PadRight(25);
            policyHolder1DLState = policyHolder1DLState.PadRight(2);
            policyHolder1Sex = policyHolder1Sex.PadRight(1);
            filler2 = filler2.PadRight(28);
            policyHolder2Prefix = policyHolder2Prefix.PadRight(4);
            policyHolder2LastName = policyHolder2LastName.PadRight(20);
            policyHolder2FirstName = policyHolder2FirstName.PadRight(20);
            policyHolder2MiddleName = policyHolder2MiddleName.PadRight(15);
            policyHolder2Suffix = policyHolder2Suffix.PadRight(3);
            policyHolder2SocialSecurityNumber = policyHolder2SocialSecurityNumber.PadRight(9, '0');
            policyHolder2DLNumber = DriverLicenseToken2.PadRight(25);
            policyHolder2DLState = policyHolder2DLState.PadRight(2);
            policyHolder2Sex = policyHolder2Sex.PadRight(1);
            filler3 = filler3.PadRight(18);
            vehicleOperatorPrefix = vehicleOperatorPrefix.PadRight(4);
            vehicleOperatorLastName = vehicleOperatorLastName.PadRight(20);
            vehicleOperatorFirstName = vehicleOperatorFirstName.PadRight(20);
            vehicleOperatorMiddleName = vehicleOperatorMiddleName.PadRight(15);
            vehicleOperatorSuffix = vehicleOperatorSuffix.PadRight(3);
            vehicleOperatorAddressHouseNumber = vehicleOperatorAddressHouseNumber.PadRight(9);
            vehicleOperatorAddressStreetName = vehicleOperatorAddressStreetName.PadRight(20);
            vehicleOperatorAddressApartmentNumber = vehicleOperatorAddressApartmentNumber.PadRight(5);
            vehicleOperatorAddressCity = vehicleOperatorAddressCity.PadRight(20);
            vehicleOperatorAddressState = vehicleOperatorAddressState.PadRight(2);
            vehicleOperatorAddressZipCode = vehicleOperatorAddressZipCode.PadRight(5);
            vehicleOperatorAddressZipCodePlus4 = vehicleOperatorAddressZipCodePlus4.PadRight(4);
            filler4 = filler4.PadRight(10);
            vehicleOperatorSocialSecurityNumber = vehicleOperatorSocialSecurityNumber.PadRight(9, '0');
            vehicleOperatorDLNumber = DriverLicenseToken3.PadRight(25);
            vehicleOperatorDLState = vehicleOperatorDLState.PadRight(2);
            vehicleOperatorSex = vehicleOperatorSex.PadRight(1);
            vehicleOperatorRelationship = vehicleOperatorRelationship.PadRight(1);
            filler5 = filler5.PadRight(28);
            contribuitingCompanyIdentificationNumber = contribuitingCompanyIdentificationNumber.PadRight(5);
            policyNumber = policyNumber.PadRight(20);
            policyType = policyType.PadRight(2);
            filler6 = filler6.PadRight(18);
            claimNumber = claimNumber.PadRight(20);
            claimType = claimType.PadRight(2);
            claimAmount = claimAmount.PadLeft(9, '0');
            claimReportingStatus = claimReportingStatus.PadRight(1);
            insuredVehicleVIN = insuredVehicleVIN.PadRight(25);
            insuredVehicleModelYear = insuredVehicleModelYear.PadRight(4);
            insuredVehicleMakeAndModel = insuredVehicleMakeAndModel.PadRight(40);
            insuredVehicleDisposition = insuredVehicleDisposition.PadRight(1);
            claimDisposition = claimDisposition.PadRight(1);
            faultIndicator = faultIndicator.PadRight(1);
            dateOfFirstPayment = dateOfFirstPayment.PadLeft(8, '0');
            indicatorCA1 = indicatorCA1.PadRight(1);
            indicatorCA2 = indicatorCA2.PadRight(1);
            indicatorCA3 = indicatorCA3.PadRight(1);
            indicatorCA4 = indicatorCA4.PadRight(1);
            filler7 = filler7.PadRight(24);
            recordVersionNumber = recordVersionNumber.PadRight(1);

            string inputString =
                policyHolder1Prefix
                + policyHolder1LastName
                + policyHolder1FirstName
                + policyHolder1MiddleName
                + policyHolder1Suffix
                + policyHolder1AddressHouseNumber
                + policyHolder1AddressStreetName
                + policyHolder1AddressApartmentNumber
                + policyHolder1AddressCity
                + policyHolder1AddressState
                + policyHolder1AddressZipCode
                + policyHolder1AddressZipCodePlus4
                + filler1
                + policyHolder1SocialSecurityNumber
                + policyHolder1DOB
                + policyHolder1DLNumber
                + policyHolder1DLState
                + policyHolder1Sex
                + filler2
                + policyHolder2Prefix
                + policyHolder2LastName
                + policyHolder2FirstName
                + policyHolder2MiddleName
                + policyHolder2Suffix
                + policyHolder2SocialSecurityNumber
                + policyHolder2DOB
                + policyHolder2DLNumber
                + policyHolder2DLState
                + policyHolder2Sex
                + filler3
                + vehicleOperatorPrefix
                + vehicleOperatorLastName
                + vehicleOperatorFirstName
                + vehicleOperatorMiddleName
                + vehicleOperatorSuffix
                + vehicleOperatorAddressHouseNumber
                + vehicleOperatorAddressStreetName
                + vehicleOperatorAddressApartmentNumber
                + vehicleOperatorAddressCity
                + vehicleOperatorAddressState
                + vehicleOperatorAddressZipCode
                + vehicleOperatorAddressZipCodePlus4
                + filler4
                + vehicleOperatorSocialSecurityNumber
                + vehicleOperatorDOB
                + vehicleOperatorDLNumber
                + vehicleOperatorDLState
                + vehicleOperatorSex
                + vehicleOperatorRelationship
                + filler5
                + contribuitingCompanyIdentificationNumber
                + policyNumber
                + policyType
                + filler6
                + claimNumber
                + claimType
                + claimDate
                + claimAmount
                + claimReportingStatus
                + insuredVehicleVIN
                + insuredVehicleModelYear
                + insuredVehicleMakeAndModel
                + insuredVehicleDisposition
                + claimDisposition
                + faultIndicator
                + dateOfFirstPayment
                + indicatorCA1
                + indicatorCA2
                + indicatorCA3
                + indicatorCA4
                + filler7
                + recordVersionNumber                
                + Environment.NewLine;

            return inputString;
        }

        private static List<CLUEAutoLossTransaction> BuildCLUEAutoLossTransactionObjectList()
        {
            CLUEAutoLossTransaction item = new CLUEAutoLossTransaction();
            item.PolicyHolder1Prefix = string.Empty;
            item.PolicyHolder1LastName = policyHolder1LastName;
            item.PolicyHolder1FirstName = policyHolder1FirstName;
            item.PolicyHolder1MiddleName = policyHolder1MiddleName;
            item.PolicyHolder1Suffix = policyHolder1Suffix;
            item.PolicyHolder1AddressHouseNumber = policyHolder1AddressHouseNumber;
            item.PolicyHolder1AddressStreetName = policyHolder1AddressStreetName;
            item.PolicyHolder1AddressApartmentNumber = policyHolder1AddressApartmentNumber;
            item.PolicyHolder1AddressCity = policyHolder1AddressCity;
            item.PolicyHolder1AddressState = policyHolder1AddressState;
            item.PolicyHolder1AddressZipCode = policyHolder1AddressZipCode;
            item.PolicyHolder1AddressZipCodePlus4 = policyHolder1AddressZipCodePlus4;
            item.Filler1 = filler1;
            item.PolicyHolder1DOB = new DateTime(1969, 5, 4);
            item.PolicyHolder1DLNumber = DriverLicenseToken1;
            item.PolicyHolder1DLState = policyHolder1DLState;
            item.PolicyHolder1Sex = policyHolder1Sex;
            item.Filler2 = filler2;
            item.PolicyHolder2Prefix = policyHolder2Prefix;
            item.PolicyHolder2LastName = policyHolder2LastName;
            item.PolicyHolder2FirstName = policyHolder2FirstName;
            item.PolicyHolder2MiddleName = policyHolder2MiddleName;
            item.PolicyHolder2Suffix = policyHolder2Suffix;
            item.PolicyHolder2DOB = new DateTime(1945, 8, 7);
            item.PolicyHolder2DLNumber = DriverLicenseToken2;
            item.PolicyHolder2DLState = policyHolder2DLState;
            item.PolicyHolder2Sex = policyHolder2Sex;
            item.Filler3 = filler3;
            item.VehicleOperatorPrefix = vehicleOperatorPrefix;
            item.VehicleOperatorLastName = vehicleOperatorLastName;
            item.VehicleOperatorFirstName = vehicleOperatorFirstName;
            item.VehicleOperatorMiddleName = vehicleOperatorMiddleName;
            item.VehicleOperatorSuffix = vehicleOperatorSuffix;
            item.VehicleOperatorAddressHouseNumber = vehicleOperatorAddressHouseNumber;
            item.VehicleOperatorAddressStreetName = vehicleOperatorAddressStreetName;
            item.VehicleOperatorAddressApartmentNumber = vehicleOperatorAddressApartmentNumber;
            item.VehicleOperatorAddressCity = vehicleOperatorAddressCity;
            item.VehicleOperatorAddressState = vehicleOperatorAddressState;
            item.VehicleOperatorAddressZipCode = vehicleOperatorAddressZipCode;
            item.VehicleOperatorAddressZipCodePlus4 = vehicleOperatorAddressZipCodePlus4;
            item.Filler4 = filler4;
            item.VehicleOperatorDOB = null;
            item.VehicleOperatorDLNumber = DriverLicenseToken3;
            item.VehicleOperatorDLState = vehicleOperatorDLState;
            item.VehicleOperatorSex = vehicleOperatorSex;
            item.VehicleOperatorRelationship = vehicleOperatorRelationship;
            item.Filler5 = filler5;
            item.ContribuitingCompanyIdentificationNumber = contribuitingCompanyIdentificationNumber;
            item.PolicyNumber = policyNumber;
            item.PolicyType = policyType;
            item.Filler6 = filler6;
            item.ClaimNumber = claimNumber;
            item.ClaimType = claimType;
            item.ClaimDate = new DateTime(1969, 5, 4);
            item.ClaimAmount = int.Parse(claimAmount);
            item.ClaimReportingStatus = claimReportingStatus;
            item.InsuredVehicleVIN = insuredVehicleVIN;
            item.InsuredVehicleModelYear = insuredVehicleModelYear;
            item.InsuredVehicleMakeAndModel = insuredVehicleMakeAndModel;
            item.InsuredVehicleDisposition = insuredVehicleDisposition;
            item.ClaimDisposition = claimDisposition;
            item.FaultIndicator = faultIndicator;
            item.DateOfFirstPayment = null;
            item.CAIndicator1 = indicatorCA1;
            item.CAIndicator2 = indicatorCA2;
            item.CAIndicator3 = indicatorCA3;
            item.CAIndicator4 = indicatorCA4;
            item.Filler7 = filler7;
            item.RecordVersionNumber = recordVersionNumber;

            List<CLUEAutoLossTransaction> list = new List<CLUEAutoLossTransaction>();
            list.Add(item);

            return list;
        }

        private async Task<string> GetClueAutoPolicyClaimData(string acordXml)
        {
            using (var sr = new StreamReader(acordXml))
            {
                var line = await sr.ReadToEndAsync();
                return line;
            }
        }
    }
}