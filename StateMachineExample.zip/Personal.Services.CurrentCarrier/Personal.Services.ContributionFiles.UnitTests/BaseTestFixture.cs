﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="BaseTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System.IO;
    using System.Xml.Serialization;
    using Personal.Services.ContributionFiles.FileHelpers.Models;

    public abstract class BaseTestFixture
    {
        protected string GetPolicyData(string filename)
        {
            using (var sr = new StreamReader($"data/{filename}"))
            {
                var line = sr.ReadToEnd();
                return line.Replace("xmlns=\"http://www.acord.org/schema/PC/xml/2\"", string.Empty);
            }
        }

        protected PolicyRs GetPolicyRs(string filename)
        {
            var policyRs = new PolicyRs();
            var serializer = new XmlSerializer(typeof(PolicyRs));
            var xml = this.GetPolicyData(filename);

            using (var reader = new StringReader(xml.Replace("xmlns=\"http://www.acord.org/schema/PC/xml/2\"", string.Empty)))
            {
                policyRs = (PolicyRs)serializer.Deserialize(reader);
            }

            return policyRs;
        }
    }
}