﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="MessagingTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using FileHelpers.ServiceInterfaces;
    using MassTransit;
    using MessageService.Core;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Service.Api.Storage;
    using Rhino.Mocks;
    using Sagas.MessageMachine;
    using Should;
    using WebJob;
    using WestBend.Core;

    [TestClass]
    public class MessagingTestFixture
    {
        [TestMethod]
        public void TestServiceBusInit()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            messageService.Stub(a => a.Initialize(new CurrentCarrierMessageMachine(logger, null), string.Empty, string.Empty, null)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var serviceBusInit = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = serviceBusInit.RegisterTransactionCommitCurrentCarrierBusInstance(new ServiceBusSettings());
            
            bus.ShouldNotBeNull();
        }

        // CLUE Auto tests
        [TestMethod]
        public void TestRegistrationAtFaultCLUEAuto()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            var processor = MockRepository.GenerateMock<IClueAutoClaimEventProcessor>();
            messageService.Stub(a => a.Initialize(new ClaimAtFaultCLUEAutoMessageMachine(logger, processor), string.Empty, string.Empty, (ServiceBusSettings)null, string.Empty)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var init = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = init.RegisterClaimAtFaultCLUEAutoBus(new ServiceBusSettings());
            bus.ShouldNotBeNull();
        }

        [TestMethod]
        public void TestRegistrationStatusChangedCLUEAuto()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            var processor = MockRepository.GenerateMock<IClueAutoClaimEventProcessor>();
            messageService.Stub(a => a.Initialize(new ClaimStatusChangedCLUEAutoMessageMachine(null, processor), string.Empty, string.Empty, (ServiceBusSettings)null, string.Empty)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var init = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = init.RegisterClaimStatusChangedCLUEAutoBus(new ServiceBusSettings());
            bus.ShouldNotBeNull();
        }

        [TestMethod]
        public void TestRegistrationFinancialTransactionCommittedCLUEAuto()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            var processor = MockRepository.GenerateMock<IClueAutoClaimEventProcessor>();
            messageService.Stub(a => a.Initialize(new FinancialTransactionCommittedCLUEAutoMessageMachine(null, processor), string.Empty, string.Empty, (ServiceBusSettings)null, string.Empty)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var init = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = init.RegisterFinancialTransactionCommittedCLUEAutoBus(new ServiceBusSettings());
            bus.ShouldNotBeNull();
        }

        [TestMethod]
        public void TestRegistrationClaimsPartyChangedCLUEAuto()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            var processor = MockRepository.GenerateMock<IClueAutoClaimEventProcessor>();
            messageService.Stub(a => a.Initialize(new ClaimPartyChangedCLUEAutoMessageMachine(null, processor), string.Empty, string.Empty, (ServiceBusSettings)null, string.Empty)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var init = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = init.RegisterClaimPartyChangedCLUEAutoBus(new ServiceBusSettings());
            bus.ShouldNotBeNull();
        }

        [TestMethod]
        public void TestRegistrationOffsetOnsetCLUEAuto()
        {
            var logger = MockRepository.GenerateMock<ILogger>();
            var messageService = MockRepository.GenerateMock<IMessageService>();
            var processor = MockRepository.GenerateMock<IClueAutoClaimEventProcessor>();
            messageService.Stub(a => a.Initialize(new OffsetOnsetCLUEAutoMessageMachine(null, processor), string.Empty, string.Empty, (ServiceBusSettings)null, string.Empty)).Return(MockRepository.GenerateStub<IBusControl>()).IgnoreArguments();
            var policyStore = MockRepository.GenerateMock<IPolicyStoreApi>();
            var storageManager = MockRepository.GenerateMock<IStorageManager>();

            var init = new MessagingServiceBusInitializer(logger, messageService, policyStore, storageManager, null);
            var bus = init.RegisterOffsetOnsetCLUEAutoBus(new ServiceBusSettings());
            bus.ShouldNotBeNull();
        }
    }
}