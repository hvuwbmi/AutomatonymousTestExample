﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IsAddressSameTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.SpecificationsTest
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;
    using Should;

    [TestClass]
    public class IsAddressSameTestFixture
    {
        [TestMethod]
        public void Test_IsAddressSame_BothNull_ReturnsTrue()
        {
            // arrange
            // act
            var result = new IsAddressSame().IsSatisfiedBy(null, null);

            // assert
            result.ShouldBeTrue();
        }

        [TestMethod]
        public void Test_IsAddressSame_FirstNull_ReturnsFalse()
        {
            // arrange
            // act
            var result = new IsAddressSame().IsSatisfiedBy(null, new Addr());

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAddressSame_SecondNull_ReturnsFalse()
        {
            // arrange
            // act
            var result = new IsAddressSame().IsSatisfiedBy(new Addr(), null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAddressSame_BothStandardized_SameAddress_ReturnsTrue()
        {
            // arrange
            var address1 = this.GetStandardizedAddressVariety1();
            var address2 = this.GetStandardizedAddressVariety1();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeTrue();
        }

        [TestMethod]
        public void Test_IsAddressSame_BothStandardized_DifferentStreetAddress_ReturnsFalse()
        {
            // arrange
            var address1 = this.GetStandardizedAddressVariety1();
            var address2 = this.GetStandardizedAddressVariety2();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAddressSame_FirstStandardized_DifferentStreets_ReturnsFalse()
        {
            // arrange
            var address1 = this.GetStandardizedAddressVariety1();
            var address2 = this.GetNonStandardizedAddressVariety1();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAddressSame_FirstStandardized_SameStreets_ReturnsTrue()
        {
            // arrange
            var address1 = this.GetStandardizedAddressVariety1();
            var address2 = this.GetNonStandardizedAddressMatchStandardized1();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeTrue();
        }

        [TestMethod]
        public void Test_IsAddressSame_SecondStandardized_DifferentStreets_ReturnsFalse()
        {
            // arrange
            var address1 = this.GetNonStandardizedAddressVariety1();
            var address2 = this.GetStandardizedAddressVariety1();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAddressSame_SecondStandardized_SameStreets_ReturnsTrue()
        {
            // arrange
            var address1 = this.GetNonStandardizedAddressMatchStandardized1();
            var address2 = this.GetStandardizedAddressVariety1();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeTrue();
        }

        [TestMethod]
        public void Test_IsAddressSame_NeitherStandardized_DifferentAddresses_ReturnsFalse()
        {
            // arrange
            var address1 = this.GetNonStandardizedAddressVariety1();
            var address2 = this.GetNonStandardizedAddressVariety2();

            // act
            var result = new IsAddressSame().IsSatisfiedBy(address1, address2);

            // assert
            result.ShouldBeFalse();
        }

        internal Addr GetStandardizedAddressVariety1()
        {
            return new Addr
            {
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeStatus = "Accepted",
                                WBAddrStandardizeStreetNumber = "123",
                                WBAddrStandardizeLeadingDirectional = "N",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitNumber = "1A"
                            }
                        }
                    }
                },
                City = "Townsville",
                StateProvCd = "WI",
                PostalCode = "53101-1977"
            };
        }

        internal Addr GetStandardizedAddressVariety2()
        {
            return new Addr
            {
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeStatus = "Accepted",
                                WBAddrStandardizeStreetNumber = "234",
                                WBAddrStandardizeLeadingDirectional = "N",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitNumber = "1A"
                            }
                        }
                    }
                },
                City = "Townsville",
                StateProvCd = "WI",
                PostalCode = "53101-1977"
            };
        }

        internal Addr GetNonStandardizedAddressVariety1()
        {
            return new Addr
            {
                Addr1 = "456 Second St",
                City = "Townsville",
                StateProvCd = "WI",
                PostalCode = "53101-1977"
            };
        }

        internal Addr GetNonStandardizedAddressVariety2()
        {
            return new Addr
            {
                Addr1 = "789 Second St",
                City = "Townsville",
                StateProvCd = "WI",
                PostalCode = "53101-1977"
            };
        }

        internal Addr GetNonStandardizedAddressMatchStandardized1()
        {
            return new Addr
            {
                Addr1 = "123 N Main St",
                City = "Townsville",
                StateProvCd = "WI",
                PostalCode = "53101-1977"
            };
        }
    }
}
