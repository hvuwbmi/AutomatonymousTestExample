﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ShouldCreateContributionFileTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.SpecificationsTest
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;
    using Should;

    [TestClass]
    public class ShouldCreateContributionFileTestFixture
    {
        [TestMethod]
        public void Test_ShouldCreateContributionFile_CurrentPolicyRsNull_ReturnsFalse()
        {
            // arrange
            // act
            var result = new ShouldCreateContributionFile().IsSatisfiedBy(null, null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_ShouldCreateContributionFile_CurrentPolicyArrayNull_ReturnsFalse()
        {
            // arrange
            var currentPolicy = new PolicyRs
            {
                Policy = null
            };

            // act
            var result = new ShouldCreateContributionFile().IsSatisfiedBy(currentPolicy, null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_ShouldCreateContributionFile_CurrentPolicy0Null_ReturnsFalse()
        {
            // arrange
            var currentPolicy = new PolicyRs
            {
                Policy = new PolicyRsPolicy[]
                {
                    null
                }
            };

            // act
            var result = new ShouldCreateContributionFile().IsSatisfiedBy(currentPolicy, null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_ShouldCreateContributionFile_CurrentPolicyNullLOB_ReturnsFalse()
        {
            // arrange
            var currentPolicy = new PolicyRs
            {
                BusinessPurposeTypeCd = "NBQ",
                Policy = new PolicyRsPolicy[]
                {
                    new PolicyRsPolicy
                    {
                        PersAutoLineBusiness = null
                    }
                }
            };

            // act
            var result = new ShouldCreateContributionFile().IsSatisfiedBy(currentPolicy, null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_ShouldCreateContributionFile_CurrentPurposeUnknown_ReturnsFalse()
        {
            // arrange
            var currentPolicy = new PolicyRs
            {
                BusinessPurposeTypeCd = "???"
            };

            // act
            var result = new ShouldCreateContributionFile().IsSatisfiedBy(currentPolicy, null);

            // assert
            result.ShouldBeFalse();
        }
    }
}
