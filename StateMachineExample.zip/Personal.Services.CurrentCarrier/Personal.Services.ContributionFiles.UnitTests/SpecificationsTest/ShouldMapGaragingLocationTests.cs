﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="ShouldMapGaragingLocationTests.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.SpecificationsTest
{
    using System.IO;
    using System.Xml.Serialization;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;

    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public class ShouldMapGaragingLocationTests
    {
        private Addr garagingAddress;
        private Addr mailingAddress;

        #region Additional test attributes
        
        // Use TestInitialize to run code before running each test 
        [TestInitialize]
        public void MyTestInitialize()
        {
            this.garagingAddress = this.GetAddress();
            this.mailingAddress = this.GetAddress();
        }
        #endregion

        [TestMethod]
        public void GaragingLocationAndMailingLocationSame_ReturnFalse()
        {
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationNull_ReturnFalse()
        {
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(null, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationValidMailingLocationNull_ReturnTrue()
        {
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, null));
        }

        [TestMethod]
        public void BothAddressesNull_ReturnFalse()
        {
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(null, null));
        }

        [TestMethod]
        public void BothAddressesStandardizedWithSameInfo_ReturnFalse()
        {
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationStandardizedMailingAddressNotStandardizedButBothSame_ReturnFalse()
        {
            this.mailingAddress.AddrExt = null;
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationNotStandardizedMailingAddressStandardizedButBothSame_ReturnFalse()
        {
            this.garagingAddress.AddrExt = null;
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationStandardizedMailingAddressNotStandardizedButNotSame_ReturnTrue()
        {
            this.mailingAddress.Addr1 = "Different Address";
            this.mailingAddress.AddrExt = null;
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void GaragingLocationNotStandardizedMailingAddressStandardizedButNotSame_ReturnTrue()
        {
            this.garagingAddress.Addr1 = "Different Address";
            this.garagingAddress.AddrExt = null;
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedStreetNumberDifferent_ReturnTrue()
        {
            this.garagingAddress.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeStreetNumber = "456";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedLeadingDirectionalDifferent_ReturnTrue()
        {
            this.garagingAddress.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeLeadingDirectional = "NE";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedStreetNameDifferent_ReturnTrue()
        {
            this.garagingAddress.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeStreetName = "Different Street";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedStreetTypeCdDifferent_ReturnTrue()
        {
            this.garagingAddress.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeStreetTypeCd = "Blvd";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedUnitNumberDifferent_ReturnTrue()
        {
            this.garagingAddress.AddrExt[0].WBAddressStandardization[0].WBAddrStandardizeUnitNumber = "987";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedCityDifferent_ReturnTrue()
        {
            this.garagingAddress.City = "London";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedStateProvCdDifferent_ReturnTrue()
        {
            this.garagingAddress.StateProvCd = "CA";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesStandardizedStreetGaragedPostalCodeDifferent_ReturnTrue()
        {
            this.garagingAddress.PostalCode = "00007";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesNotStandardizedGaragingAddr1Different_ReturnTrue()
        {
            this.garagingAddress.AddrExt = null;
            this.mailingAddress.AddrExt = null;
            this.garagingAddress.Addr1 = "007 Secret Agent St";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesNotStandardizedMailingAddr1Different_ReturnTrue()
        {
            this.garagingAddress.AddrExt = null;
            this.mailingAddress.AddrExt = null;
            this.mailingAddress.Addr1 = "007 Secret Agent St";
            Assert.IsTrue(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        [TestMethod]
        public void BothAddressesNotStandardizedGaragingAddr1Same_ReturnFalse()
        {
            this.garagingAddress.AddrExt = null;
            this.mailingAddress.AddrExt = null;
            Assert.IsFalse(new ShouldMapGaragingLocation().IsSatisfiedBy(this.garagingAddress, this.mailingAddress));
        }

        private Addr GetAddress()
        {
            var xml = @"<Addr id='A0C3CF8876B09402292F9ED9E0F9A9B42'>
                          <AddrTypeCd>MailingAddress</AddrTypeCd>
                          <Addr1>123 N Main St</Addr1>
                          <City>Ann Arbor</City>
                          <StateProvCd>MI</StateProvCd>
                          <PostalCode>48104-1665</PostalCode>
                          <CountryCd>USA</CountryCd>
                          <Latitude>42.6274</Latitude>
                          <Longitude>-82.5536</Longitude>
                          <County>Washtenaw County</County>
                          <AddrExt id='A7DF3D02A41DF4046B39A28612F853BD0'>
                            <WBAddressStandardization id='W15CF463A0DB749A5B1DB74A6273CE4B4'>
                              <WBAddrStandardizeStreetName>Main</WBAddrStandardizeStreetName>
                              <WBAddrStandardizeStreetTypeCd>St</WBAddrStandardizeStreetTypeCd>
                              <WBAddrStandardizeStreetNumber>123</WBAddrStandardizeStreetNumber>
                              <WBConfidence>99</WBConfidence>
                              <WBAddrStandardizeLeadingDirectional>N</WBAddrStandardizeLeadingDirectional>
                              <WBAddrStandardizeStatus>Accepted</WBAddrStandardizeStatus>
                            </WBAddressStandardization>
                          </AddrExt>
                        </Addr>";

            var serializer = new XmlSerializer(typeof(Addr));
            using (var reader = new StringReader(xml))
            {
                var data = (Addr)serializer.Deserialize(reader);
                return data;
            }
        }
    }
}
