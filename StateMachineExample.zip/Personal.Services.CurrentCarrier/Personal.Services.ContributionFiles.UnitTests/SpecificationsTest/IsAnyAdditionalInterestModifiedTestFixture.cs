﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="IsAnyAdditionalInterestModifiedTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.SpecificationsTest
{
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.Rules.Specification;
    using Should;

    [TestClass]
    public class IsAnyAdditionalInterestModifiedTestFixture
    {
        [TestMethod]
        public void Test_IsAnyAdditionalInterestModified_PreviousTransactionNull_ReturnsFalse()
        {
            // arrange
            // act
            var result = new IsAnyAdditionalInterestModified().IsSatisfiedBy(new PolicyRs(), null);

            // assert
            result.ShouldBeFalse();
        }

        [TestMethod]
        public void Test_IsAnyAdditionalInterestModified_InterestFirstNameModified_ReturnsTrue()
        {
            // arrange
            var policy1 = this.CreatePriorTransaction();
            var policy2 = this.CreateCurrentTransaction();

            // act
            var result = new IsAnyAdditionalInterestModified().IsSatisfiedBy(policy2, policy1);

            // assert
            result.ShouldBeTrue();
        }

        internal PolicyRs CreatePriorTransaction()
        {
            return new PolicyRs
            {
                BusinessPurposeTypeCd = "NBQ",
                Policy = new PolicyRsPolicy[]
                {
                    new PolicyRsPolicy
                    {
                        PersAutoLineBusiness = new PolicyRsPolicyPersAutoLineBusiness[]
                        {
                            new PolicyRsPolicyPersAutoLineBusiness
                            {
                                Vehicle = new PolicyRsPolicyPersAutoLineBusinessVehicle[]
                                {
                                    new PolicyRsPolicyPersAutoLineBusinessVehicle
                                    {
                                        id = "V001",
                                        AdditionalInterest = new PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest[]
                                        {
                                            new PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest
                                            {
                                                id = "AI001",
                                                GivenName = "Name1",
                                                Surname = "Surname",
                                                AccountNumberId = "123123"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
        }

        internal PolicyRs CreateCurrentTransaction()
        {
            return new PolicyRs
            {
                BusinessPurposeTypeCd = "PCH",
                ModInfo = new PolicyRsModInfo[]
                {
                    new PolicyRsModInfo
                    {
                        IdRef = "AI001",
                        ActionCd = "M"
                    }
                },
                Policy = new PolicyRsPolicy[]
                {
                    new PolicyRsPolicy
                    {
                        PersAutoLineBusiness = new PolicyRsPolicyPersAutoLineBusiness[]
                        {
                            new PolicyRsPolicyPersAutoLineBusiness
                            {
                                Vehicle = new PolicyRsPolicyPersAutoLineBusinessVehicle[]
                                {
                                    new PolicyRsPolicyPersAutoLineBusinessVehicle
                                    {
                                        id = "V001",
                                        AdditionalInterest = new PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest[]
                                        {
                                            new PolicyRsPolicyPersAutoLineBusinessVehicleAdditionalInterest
                                            {
                                                id = "AI001",
                                                GivenName = "Name2",
                                                Surname = "Surname",
                                                AccountNumberId = "123123"
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            };
        }
    }
}
