﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PolicyEnricherForNonRenewalTests.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.Utilities
{
    using System;
    using FileHelpers.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.Utilities;

    [TestClass]
    public class PolicyEnricherForNonRenewalTests : BaseTestFixture
    {
        [ExpectedException(typeof(ArgumentNullException))]
        public void Constructor_NullPolicyResponse_ThrowsArgumentNullException()
        {
            PolicyEnricherForNonRenewal enricher = new PolicyEnricherForNonRenewal(null, null);
        }

        [TestMethod]
        public void PolicyNoVehicleData_Enrich_RetainsNoVehicles()
        {
            PolicyRs policyResponse = this.GetPolicyRs("PolicyNoVehicleData.xml");
            var enricher = new PolicyEnricherForNonRenewal(policyResponse, null);
            enricher.Enrich();

            Assert.AreEqual(new DateTime(2020, 8, 20), policyResponse.TransactionEffectiveDate, "TransactionEffectiveDate");
            Assert.AreEqual(1, policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length, "Drivers");
            Assert.IsNull(policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle, "Vehicles");
        }

        [TestMethod]
        public void CancelledPolicy_Enrich_RetainsCancelledRisks()
        {
            PolicyRs policyResponse = this.GetPolicyRs("Cancel/CancelVehicleNullRef.xml");
            var enricher = new PolicyEnricherForNonRenewal(policyResponse, null);
            enricher.Enrich();

            Assert.AreEqual(new DateTime(2020, 12, 14), policyResponse.TransactionEffectiveDate, "TransactionEffectiveDate");
            Assert.AreEqual(1, policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length, "Drivers");
            Assert.AreEqual(1, policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle.Length, "Vehicles");
        }

        [TestMethod]
        public void EndorsementWithDeletedRisksNewBusiness_Enrich_RetainsDeletedRisks()
        {
            PolicyRs policyResponse = this.GetPolicyRs("Endorsements/EndorsementWithDeletedRisksNewBusiness.xml");
            var enricher = new PolicyEnricher(policyResponse);
            enricher.Enrich();

            Assert.AreEqual(new DateTime(2020, 1, 24), policyResponse.TransactionEffectiveDate, "TransactionEffectiveDate");
            Assert.AreEqual(2, policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length, "Drivers");
            Assert.AreEqual(2, policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle.Length, "Vehicles");
        }

        [TestMethod]
        public void EndorsementWithDeletedRisksOnCurrentTransaction_Enrich_RetainsDeletedRisks()
        {
            PolicyRs policyResponse = this.GetPolicyRs("Endorsements/EndorsementWithDeletedRisksOnCurrentTransaction.xml");
            var enricher = new PolicyEnricher(policyResponse);
            enricher.Enrich();

            Assert.AreEqual(new DateTime(2020, 2, 29), policyResponse.TransactionEffectiveDate, "TransactionEffectiveDate");
            Assert.AreEqual(2, policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length, "Drivers");
            Assert.AreEqual(3, policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle.Length, "Vehicles");
        }

        [TestMethod]
        public void EndorsementWithDeletedRisksOnPreviousTransaction_Enrich_RemovesDeletedRisks()
        {
            PolicyRs policyResponse = this.GetPolicyRs("Endorsements/EndorsementWithDeletedRisksOnPreviousTransaction.xml");
            var enricher = new PolicyEnricherForNonRenewal(policyResponse, null);
            enricher.Enrich();

            Assert.AreEqual(new DateTime(2021, 1, 24), policyResponse.TransactionEffectiveDate, "TransactionEffectiveDate");
            Assert.AreEqual(1, policyResponse.Policy[0].PersAutoLineBusiness[0].Driver.Length, "Drivers");
            Assert.AreEqual(2, policyResponse.Policy[0].PersAutoLineBusiness[0].Vehicle.Length, "Vehicles");
        }
    }
}