﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoClaimsEventProcessorTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using FileHelpers.Models;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using FileHelpers.ServiceInterfaces.Impls;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class ClueAutoClaimsEventProcessorTestFixture
    {
        private ILogger mockLogger;
        private IStorageManager storageManagerMock;
        private IMapperService mapperServiceMock;
        private IClueAutoClaimEventProcessor claimEventProcessor;

        [TestInitialize]
        public void Init()
        {
            this.mockLogger = MockRepository.GenerateMock<ILogger>();
            this.storageManagerMock = MockRepository.GenerateMock<IStorageManager>();
            this.mapperServiceMock = MockRepository.GenerateMock<IMapperService>();
            this.claimEventProcessor = new ClueAutoClaimEventProcessor(this.mockLogger, this.mapperServiceMock, this.storageManagerMock);
        }

        [TestMethod]
        public void InitTest()
        {
            var processor = new ClueAutoClaimEventProcessor(null, null, null);
            processor.ShouldNotBeNull();
        }

        [TestMethod]
        public async Task AtFaultNoneFoundTest()
        {
            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.mapperServiceMock.Stub(service => service.Map(new AtFaultDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessAtFaultEvent(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
        }

        [TestMethod]
        public async Task AtFaultFoundTest()
        {
            var dateTimeString = "202002190000000000";  // DateTime.Now.ToString("yyyyMMddHHmmssffff");

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'ClueAuto' and RowKey eq '1LR2'"))
                .Return(
                    Task.FromResult(
                        new List<JObject>()
                        {
                            new JObject(
                                new JProperty("RunDate", dateTimeString))
                        }));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'ClueAuto' and ClaimNumber eq 'CL12345' and CreateDate ge '202002190000000000'"))
                .Return(
                    Task.FromResult(
                        new List<JObject>()
                        {
                            new JObject(
                                new JProperty("CreateDate", DateTime.Now.AddDays(-1).ToString("yyyyMMddHHmmssffff")),
                                new JProperty("ClaimNumber", "AS1223")),
                            new JObject(
                                new JProperty("CreateDate", DateTime.Now.AddDays(-2).ToString("yyyyMMddHHmmssffff")),
                                new JProperty("ClaimNumber", "AS1234"))
                        }));

            this.storageManagerMock
                .Stub(storage => storage.DeleteRecordAsync(string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(Task.FromResult(new JObject()));

            this.storageManagerMock
                .Stub(storage => storage.DeleteFileAsync(string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(Task.FromResult(string.Empty));

            this.mapperServiceMock.Stub(service => service.Map(new AtFaultDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessAtFaultEvent(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
            this.storageManagerMock.AssertWasCalled(storage => storage.DeleteRecordAsync(string.Empty, string.Empty, string.Empty), options => options.IgnoreArguments().Repeat.Times(1));
        }

        [TestMethod]
        public async Task AtFaultMultiFoundTest()
        {
            var dateTimeString = "202002190000000000";  // DateTime.Now.ToString("yyyyMMddHHmmssffff");

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'ClueAuto' and RowKey eq '1LR2'"))
                .Return(
                    Task.FromResult(
                        new List<JObject>
                        {
                            new JObject(
                                new JProperty("RunDate", dateTimeString))
                        }));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'ClueAuto' and ClaimNumber eq 'CL12345' and CreateDate ge '202002190000000000'"))
                .Return(Task.FromResult(
                        new List<JObject>
                        {
                                new JObject(
                                    new JProperty("CreateDate", DateTime.Now.AddDays(-1).ToString("yyyyMMddHHmmssffff")),
                                    new JProperty("ClaimNumber", "AS1223")),
                                new JObject(
                                    new JProperty("CreateDate", DateTime.Now.AddDays(-2).ToString("yyyyMMddHHmmssffff")),
                                    new JProperty("ClaimNumber", "AS1234")),
                                new JObject(
                                    new JProperty("CreateDate", DateTime.Now.AddDays(-3).ToString("yyyyMMddHHmmssffff")),
                                    new JProperty("ClaimNumber", "AS1234"))
                        }));

            this.storageManagerMock
                .Stub(storage => storage.DeleteRecordAsync(string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(Task.FromResult(new JObject()));

            this.storageManagerMock
                .Stub(storage => storage.DeleteFileAsync(string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(Task.FromResult(string.Empty));

            this.mapperServiceMock.Stub(service => service.Map(new AtFaultDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessAtFaultEvent(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new AtFaultDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
            this.storageManagerMock.AssertWasCalled(storage => storage.DeleteRecordAsync(string.Empty, string.Empty, string.Empty), options => options.IgnoreArguments());
            this.storageManagerMock.AssertWasCalled(storage => storage.DeleteFileAsync(string.Empty, string.Empty, string.Empty), options => options.IgnoreArguments());
        }

        [TestMethod]
        public async Task ClaimPartyChangedNoneFoundTest()
        {
            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.mapperServiceMock.Stub(service => service.Map(new ClaimPartyChangedDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessClaimPartyChangedEvent(new ClaimPartyChangedDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new ClaimPartyChangedDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
        }

        [TestMethod]
        public async Task FinancialTransactionCommittedNoneFoundTest()
        {
            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.mapperServiceMock.Stub(service => service.Map(new FinancialTransactionCommittedDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessFinancialTransactionCommittedEvent(new FinancialTransactionCommittedDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new FinancialTransactionCommittedDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
        }

        [TestMethod]
        public async Task OffsetOnsetNoneFoundTest()
        {
            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.mapperServiceMock.Stub(service => service.Map(new OffsetOnsetDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessOffsetOnsetEvent(new OffsetOnsetDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new OffsetOnsetDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
        }

        [TestMethod]
        public async Task StatusChangedFoundTest()
        {
            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.storageManagerMock
                .Stub(storage => storage.ReadRecordFilteredAsync(string.Empty, string.Empty))
                .IgnoreArguments().Return(Task.FromResult(new List<JObject>()));

            this.mapperServiceMock.Stub(service => service.Map(new OffsetOnsetDto())).IgnoreArguments().Return(Task.FromResult(new ClueAutoData()));

            var result = await this.claimEventProcessor.ProcessOffsetOnsetEvent(new OffsetOnsetDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" });

            result.ShouldBeTrue();
            this.mapperServiceMock.AssertWasCalled(service => service.Map(new OffsetOnsetDto() { ClaimNumber = "CL12345", ClaimType = "AtFault" }), options => options.IgnoreArguments());
        }
    }
}