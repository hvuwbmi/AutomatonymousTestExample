﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CoverageTypeTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using FileHelpers.Models;
    using FileHelpers.Rules;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Should;

    [TestClass]
    public class CoverageTypeTestFixture
    {
        [TestMethod]
        public void Test_GetLimitAmount_CurrencyAndInteger()
        {
            var limit = new CoverageLimit
            {
                FormatCurrencyAmt = new FormatCurrencyAmt[]
                {
                    new FormatCurrencyAmt
                    {
                        Amt = "123"
                    }
                },
                FormatInteger = "456"
            };

            var amount = limit.GetLimitAmount();

            amount.ShouldEqual(123);
        }

        [TestMethod]
        public void Test_GetLimitAmount_Currency()
        {
            var limit = new CoverageLimit
            {
                FormatCurrencyAmt = new FormatCurrencyAmt[]
                {
                    new FormatCurrencyAmt
                    {
                        Amt = "987"
                    }
                }
            };

            var amount = limit.GetLimitAmount();

            amount.ShouldEqual(987);
        }

        [TestMethod]
        public void Test_GetLimitAmount_Integer()
        {
            var limit = new CoverageLimit
            {
                FormatInteger = "6548"
            };

            var amount = limit.GetLimitAmount();

            amount.ShouldEqual(6548);
        }

        [TestMethod]
        public void Test_GetLimitAmount_Neither()
        {
            var limit = new CoverageLimit();

            var amount = limit.GetLimitAmount();

            amount.ShouldEqual(0);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_BI_Individual()
        {
            var coverage = new Coverage
            {
                CoverageCd = "BI",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "BIEachPers"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "2000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("BI", CoverageTypeRules.CoverageLimitType.Individual);

            limit.ShouldEqual(1000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_BI_Occurrence()
        {
            var coverage = new Coverage
            {
                CoverageCd = "BI",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "BIEachPers"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "2000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("BI", CoverageTypeRules.CoverageLimitType.Occurrence);

            limit.ShouldEqual(2000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_CS_CSL()
        {
            var coverage = new Coverage
            {
                CoverageCd = "CS",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "CSL"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "2000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("CS", CoverageTypeRules.CoverageLimitType.CSL);

            limit.ShouldEqual(1000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_MP_Ind()
        {
            var coverage = new Coverage
            {
                CoverageCd = "MP",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1500",
                        LimitAppliesToCd = "PerPerson"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("MP", CoverageTypeRules.CoverageLimitType.Occurrence);
            limit.ShouldEqual(1500);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_NB_IndOcc()
        {
            var coverage = new Coverage
            {
                CoverageCd = "NB",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "100000",
                        LimitAppliesToCd = "PerPerson"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "300000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("NB", CoverageTypeRules.CoverageLimitType.Individual);
            limit.ShouldEqual(100000);

            var limit2 = coverage.GetCoverageLimit("NB", CoverageTypeRules.CoverageLimitType.Occurrence);
            limit2.ShouldEqual(300000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_RR_IndOcc()
        {
            var coverage = new Coverage
            {
                CoverageCd = "RR",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "500",
                        LimitAppliesToCd = "PerDay"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "EachClaim"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("RR", CoverageTypeRules.CoverageLimitType.Individual);
            limit.ShouldEqual(500);

            var limit2 = coverage.GetCoverageLimit("RR", CoverageTypeRules.CoverageLimitType.Occurrence);
            limit2.ShouldEqual(1000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_UP_Occurrence()
        {
            var coverage = new Coverage
            {
                CoverageCd = "UP",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "BIEachPers"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "2000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("UP", CoverageTypeRules.CoverageLimitType.Occurrence);

            limit.ShouldEqual(2000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_UM_EachClaimCSL()
        {
            var coverage = new Coverage
            {
                CoverageCd = "UM",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "BIEachPers"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "4000",
                        LimitAppliesToCd = "PerAcc"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("UM", CoverageTypeRules.CoverageLimitType.CSL);

            limit.ShouldEqual(4000);
        }

        [TestMethod]
        public void Test_GetCoverageLimit_UM_CSL()
        {
            var coverage = new Coverage
            {
                CoverageCd = "UM",
                Limit = new CoverageLimit[]
                {
                    new CoverageLimit
                    {
                        FormatInteger = "1000",
                        LimitAppliesToCd = "BIEachPers"
                    },
                    new CoverageLimit
                    {
                        FormatInteger = "4500",
                        LimitAppliesToCd = "CSL"
                    }
                }
            };

            var limit = coverage.GetCoverageLimit("UM", CoverageTypeRules.CoverageLimitType.CSL);

            limit.ShouldEqual(4500);
        }
    }
}
