﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BuildCurrentCarrierOutputRequestHandlerTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.RequestTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Threading.Tasks;
    using FileHelpers.FileHelperExtensions;
    using FileHelpers.Models;
    using FileHelpers.Requests;
    using FileHelpers.Requests.Handlers;
    using FileHelpers.ServiceInterfaces;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class BuildCurrentCarrierOutputRequestHandlerTestFixture
    {
        [TestInitialize]
        public void TestInitialize()
        {
            LicenseConverter.TokenApi = MockRepository.GenerateStub<ITokenApi>();
            LicenseConverter.TokenApi.Stub(a => a.Detokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = "S1234567890123" }));
        }

        [TestMethod]
        public async Task Test0Records()
        {
            // arrange
            var storageManagerStub = MockRepository.GenerateStub<IStorageManager>();
            var loggerStub = MockRepository.GenerateStub<ILogger>();

            storageManagerStub.Stub(a => a.ReadRecordFilteredAsync("a", "q")).IgnoreArguments().Return(this.GetEmptyData());
            storageManagerStub.Stub(a => a.UpdateRecordAsync(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<JObject>.Is.Anything))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = Task<LastRunDate>.Run(() => { return new JObject { new JProperty("RunDate", DateTime.Now.ToString()) }; });
                });

            // act
            var handler =
                new BuildCurrentCarrierOutputRequestHandler(storageManagerStub, new EngineFactory(), loggerStub);
            var fileOutput =
                await handler.Handle(
                    new BuildCurrentCarrierOutput { ApimKey = string.Empty, RunForDate = "202004231302313337" },
                    new CancellationToken());

            // assert
            fileOutput.ShouldNotBeEmpty();
            fileOutput = Regex.Replace(fileOutput, "##!!SAC[^\n]*\n", "{{HEADERORFOOTER}}" + Environment.NewLine, RegexOptions.IgnoreCase, TimeSpan.FromSeconds(10));

            string correctResults = await this.LoadFromFile("Handlers/Handle0RecordsTestResults.txt");

            fileOutput.ShouldContain("B50289FTP000000");
        }

        [TestMethod]
        public async Task TestSortOrder()
        {
            var storageManagerStub = MockRepository.GenerateStub<IStorageManager>();
            storageManagerStub.Stub(a => a.ReadRecordFilteredAsync("a", "q"))
                .IgnoreArguments()
                .Return(this.GetSortOrderData());
            storageManagerStub.Stub(a => a.UpdateRecordAsync(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<JObject>.Is.Anything))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = Task<LastRunDate>.Run(() => { return new JObject { new JProperty("RunDate", DateTime.Now.ToString()) }; });
                });

            storageManagerStub.Stub(a => a.ReadFileAsync(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = LoadFromFile((string)a.Arguments[2]);
                });

            storageManagerStub.Stub(s => s.CreateFileAsync(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .IgnoreArguments()
                .Return(Task.FromResult(string.Empty));

            var loggerStub = MockRepository.GenerateStub<ILogger>();

            var handler =
                new BuildCurrentCarrierOutputRequestHandler(storageManagerStub, new EngineFactory(), loggerStub);
            var fileOutput =
                await handler.Handle(
                    new BuildCurrentCarrierOutput { ApimKey = string.Empty, RunForDate = "202004231302313337" },
                    new CancellationToken());

            // Because the file header has date/time in it, we need to regex it away.
            fileOutput = Regex.Replace(fileOutput, "##[^\n]*\n", "{{HEADERORFOOTER}}" + Environment.NewLine, RegexOptions.IgnoreCase, TimeSpan.FromSeconds(10));

            string correctResults = await this.LoadFromFile("CCSortTestResults.txt");

            fileOutput.ShouldEqual(correctResults);
            loggerStub.AssertWasCalled(l => l.Log("PL.CurrentCarrier", System.Diagnostics.TraceEventType.Information, "6 policies found to be added to current carrier file output - last run date is 202004231302313337", null, null, string.Empty, true));
            loggerStub.AssertWasCalled(l => l.Log("PL.CurrentCarrier", System.Diagnostics.TraceEventType.Information, "36 policies added to current carrier file output", null, null, string.Empty, true));
        }
        
        [TestMethod]
        public void TestHeaderFooter()
        {
            var engineFactory = new EngineFactory();
            global::FileHelpers.MultiRecordEngine engine = engineFactory.CreateEngine(EngineFactory.EngineType.CurrentCarrier);
            var dataString =
                "VR0100964                    PA00010101                           02                                                                  00010101   000000                                                                                                               0000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + Environment.NewLine +
                "SJ0100964A123456             PA20190123A1Sample                      John                Q              Sr 19650405000000000M9RZ3L9GIZ30123           WI                         jsample@gmail.com                                           I                                                            000000000                                                          00000000000000000000000M                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + Environment.NewLine + 
                "NP0100964                    PA00010101WEST BEND MUTUAL INSM  15350000101010001010100010101000000000000000                                                                  000000000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         " + Environment.NewLine;

            List<object> fileData = new List<object>();
            fileData.AddRange(engine.ReadString(dataString));

            var loggerStub = MockRepository.GenerateStub<ILogger>();
            var handler = new BuildCurrentCarrierOutputRequestHandler(null, engineFactory, loggerStub);

            // Note: The & characters are going to vary every time the test is run (date/time fields), we don't want to fail because of them.
            var expected =
                "##!!SAC#&&&&&&&&&CARR          B50289FTPA00052002WEST BEND MUTUAL INS                                     CC_HISTORY                    &&&&&&&&&&&&&&&&0100                                                                                                    " + Environment.NewLine +
                "VR0100964                    PA00010101                           02 00000000                                                         00010101   000000                                                                                                               0000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    " + Environment.NewLine +
                "SJ0100964A123456             PA20190123A1Sample                      John                Q              Sr 19650405000000000MS1234567890123           WI                         jsample@gmail.com                                           I                                                            000000000                                                          00000000000000000000000M                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  " + Environment.NewLine + 
                "NP0100964                    PA00010101WEST BEND MUTUAL INSM  15350000101010001010100010101000000000000000                                                                  000000000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         " + Environment.NewLine +
                "##!!SAT#&&&&&&&&&CARR          B50289FTP000003                                                                                                                                                                                                                  " + Environment.NewLine;

            var finalFile = handler.WriteFinalFile(fileData, "202004231302313337");

            // Can't check against expected, the timestamp is going to vary.
            finalFile.ShouldContain("CARR          B50289FTPA00052002WEST BEND MUTUAL INS                                     CC_HISTORY                    ");
            finalFile.ShouldContain("VR0100964                    PA00010101                           02 00000000                                                         00010101   000000                                                                                                               0000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    ");
            finalFile.ShouldContain("SJ0100964A123456             PA20190123A1Sample                      John                Q              Sr 19650405000000000MS1234567890123           WI                         jsample@gmail.com                                           I                                                            000000000                                                          00000000000000000000000M                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                  ");
            finalFile.ShouldContain("NP0100964                    PA00010101WEST BEND MUTUAL INSM  15350000101010001010100010101000000000000000                                                                  000000000000000000                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                         ");
            finalFile.ShouldContain("CARR          B50289FTP000003         ");
            LicenseConverter.TokenApi.AssertWasCalled(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything));
            var tokenArgs = LicenseConverter.TokenApi.GetArgumentsForCallsMadeOn(x => x.Detokenize(null, null));
            TokenRequest tokenArgCalled = (TokenRequest)tokenArgs[0][0];
            tokenArgCalled.data.ShouldEqual("9RZ3L9GIZ30123");
        }

        private async Task<List<JObject>> GetEmptyData()
        {
            return new List<JObject>();
        }

        private async Task<List<JObject>> GetSortOrderData()
        {
            JObject jsonResult = JObject.Parse(await this.LoadFromFile("SortOrderGetFiltered.json"));

            List<JObject> listResults = new List<JObject>();

            foreach (var j in jsonResult["value"])
            {
                listResults.Add(j as JObject);
            }

            return listResults;
        }

        private async Task<string> LoadFromFile(string filename)
        {
            using (var sr = new StreamReader("data/" + filename))
            {
                var line = await sr.ReadToEndAsync();
                return line;
            }
        }
    }
}