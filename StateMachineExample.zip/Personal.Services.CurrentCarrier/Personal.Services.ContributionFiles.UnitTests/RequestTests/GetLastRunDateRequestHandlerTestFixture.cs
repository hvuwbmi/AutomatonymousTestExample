﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="GetLastRunDateRequestHandlerTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.RequestTests
{
    using System;
    using System.Collections.Generic;
    using System.Threading;
    using System.Threading.Tasks;
    using FileHelpers.Models;
    using FileHelpers.Requests;
    using FileHelpers.Requests.Handlers;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Rhino.Mocks;
    using Should;

    [TestClass]
    public class GetLastRunDateRequestHandlerTestFixture
    {
        [TestMethod]
        public async Task TestNoDataFound()
        {
            var storageManagerStub = MockRepository.GenerateStub<IStorageManager>();
            storageManagerStub.Stub(a => a.ReadRecordFilteredAsync("a", "q")).IgnoreArguments().Return(this.GetEmptyData());
            var handler = new GetLastRunDateRequestHandler(storageManagerStub);
            var response = await handler.Handle(new GetRunDateRequest(), new CancellationToken());
            response.ShouldNotBeNull();
            response.ShouldEqual(DateTime.MinValue.ToString("yyyyMMddhhmmssffff"));
        }

        [TestMethod]
        public async Task TestDataFound()
        {
            var now = DateTime.Now;
            var storageManagerStub = MockRepository.GenerateStub<IStorageManager>();
            storageManagerStub.Stub(a => a.ReadRecordFilteredAsync("a", "q")).IgnoreArguments().Return(this.GetData(now));
            var handler = new GetLastRunDateRequestHandler(storageManagerStub);
            var response = await handler.Handle(new GetRunDateRequest(), new CancellationToken());
            response.ShouldNotBeNull();
            response.ShouldEqual(now.ToString("yyyyMMddhhmmssffff"));
        }

        private async Task<List<JObject>> GetData(DateTime now)
        {
            return new List<JObject>
            {
                new JObject(
                    new JProperty("RunDate", now.ToString("yyyyMMddhhmmssffff")))
            };
        }

        private async Task<List<JObject>> GetEmptyData()
        {
            return new List<JObject>();
        }
    }
}