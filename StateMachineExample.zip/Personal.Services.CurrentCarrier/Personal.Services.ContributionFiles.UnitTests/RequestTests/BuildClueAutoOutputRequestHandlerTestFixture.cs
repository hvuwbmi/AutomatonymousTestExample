﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="BuildClueAutoOutputRequestHandlerTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.RequestTests
{
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Text.RegularExpressions;
    using System.Threading;
    using System.Threading.Tasks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.Requests;
    using Personal.Services.ContributionFiles.FileHelpers.Requests.Handlers;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class BuildClueAutoOutputRequestHandlerTestFixture
    {
        [TestInitialize]
        public void TestInitialize()
        {
        }

        [TestMethod]
        public async Task Test0Records()
        {
            // arrange
            var storageManagerStub = MockRepository.GenerateStub<IStorageManager>();
            var loggerStub = MockRepository.GenerateStub<ILogger>();

            storageManagerStub.Stub(a => a.ReadRecordFilteredAsync("a", "q")).IgnoreArguments().Return(this.GetEmptyData());
            storageManagerStub.Stub(a => a.UpdateRecordAsync(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<JObject>.Is.Anything))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = Task<LastRunDate>.Run(() => { return new JObject { new JProperty("RunDate", DateTime.Now.ToString()) }; });
                });

            // act
            var handler =
                new BuildClueAutoOutputRequestHandler(storageManagerStub, new EngineFactory(), loggerStub);
            var fileOutput =
                await handler.Handle(
                    new BuildClueAutoOutput { ApimKey = string.Empty, RunForDate = "202004231302313337" },
                    new CancellationToken());

            // assert
            fileOutput.ShouldNotBeEmpty();
            fileOutput = Regex.Replace(fileOutput, "##!!SAC[^\n]*\n", "{{HEADERORFOOTER}}" + Environment.NewLine, RegexOptions.IgnoreCase, TimeSpan.FromSeconds(10));

            string correctResults = await this.LoadFromFile("Handlers/Handle0RecordsClueAutoTestResults.txt");

            fileOutput.ShouldContain("B50289FTP000000");
        }

        private async Task<List<JObject>> GetEmptyData()
        {
            return new List<JObject>();
        }

        private async Task<string> LoadFromFile(string filename)
        {
            using (var sr = new StreamReader("data/" + filename))
            {
                var line = await sr.ReadToEndAsync();
                return line;
            }
        }
    }
}
