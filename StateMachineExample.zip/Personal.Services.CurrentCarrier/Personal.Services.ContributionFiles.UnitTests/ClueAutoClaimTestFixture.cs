﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ClueAutoClaimTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System;
    using System.IO;
    using System.Threading.Tasks;
    using System.Xml.Serialization;
    using FileHelpers.FileMappers.CLUEAuto;
    using FileHelpers.Models;
    using FileHelpers.Models.Dtos;
    using FileHelpers.ServiceInterfaces;
    using FileHelpers.ServiceInterfaces.Impls;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;
    using WestBend.Core.Service.GeocodeUSAddress;
    using WestBend.Core.Service.MessageContracts;
    using GetFullClaimResponse = FileHelpers.Models.Claims.GetFullClaimResponse;

    [TestClass]
    public class ClueAutoClaimTestFixture
    {
        [TestMethod]
        public async Task UnlistedDriverTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetUnlistedClaim());

            GetFullClaimResponse response = null;
            var claimXml = await claimApiMock.ClaimOrchestratorLogicApp(string.Empty, string.Empty);
            XmlSerializer serializer = new XmlSerializer(typeof(GetFullClaimResponse));

            using (StringReader sr = new StringReader(claimXml))
            {
                response = (GetFullClaimResponse)serializer.Deserialize(sr);
            }

            var file = new CLUEAutoLossTransaction();
            var reserves = await response.GetClaimReserves();
            reserves.ShouldNotBeNull();
            reserves.Length.ShouldEqual(2);
            var data = await response.Map(file, reserves[0], null);

            data.ShouldNotBeNull();
            data.DriverType.ShouldEqual("Unlisted");
            data.DriverNumber.ShouldEqual("0");
            data.VehicleNumber.ShouldEqual("1000");

            file.ClaimNumber.ShouldEqual("DA01071");
            file.VehicleOperatorAddressHouseNumber.ShouldEqual("555");
            file.VehicleOperatorAddressStreetName.ShouldEqual("1ST AVENUE");
            file.VehicleOperatorLastName.ShouldEqual("DOE");
            file.VehicleOperatorFirstName.ShouldEqual("JOHN");
            file.ClaimDisposition.ShouldEqual("O");
            file.InsuredVehicleVIN.ShouldEqual(string.Empty);
            file.VehicleOperatorSex.ShouldEqual("M");
            file.ClaimAmount.ShouldEqual(85000);
            file.ClaimType.ShouldEqual("PD");
        }

        [TestMethod]
        public async Task ListedDriverTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetListedClaim());

            GetFullClaimResponse response = null;
            var claimXml = await claimApiMock.ClaimOrchestratorLogicApp(string.Empty, string.Empty);
            XmlSerializer serializer = new XmlSerializer(typeof(GetFullClaimResponse));

            using (StringReader sr = new StringReader(claimXml))
            {
                response = (GetFullClaimResponse)serializer.Deserialize(sr);
            }

            var file = new CLUEAutoLossTransaction();
            var reserves = await response.GetClaimReserves();
            reserves.ShouldNotBeNull();
            reserves.Length.ShouldEqual(2);
            var data = await response.Map(file, reserves[1], null);

            data.ShouldNotBeNull();
            data.DriverType.ShouldEqual("Listed");
            data.DriverNumber.ShouldEqual("1000");
            data.VehicleNumber.ShouldEqual("1000");

            file.ClaimNumber.ShouldEqual("DA00963");
            file.VehicleOperatorAddressHouseNumber.ShouldEqual("123");
            file.VehicleOperatorAddressStreetName.ShouldEqual("MAIN ST");
            file.VehicleOperatorLastName.ShouldEqual("SMITH");
            file.VehicleOperatorFirstName.ShouldEqual("JANE");
            file.ClaimDisposition.ShouldEqual("O");
            file.InsuredVehicleVIN.ShouldEqual(string.Empty);
            file.VehicleOperatorSex.ShouldEqual(string.Empty);
            file.ClaimAmount.ShouldEqual(30000);
            file.ClaimType.ShouldEqual("GL");
        }

        [TestMethod]
        public async Task FilterNegativeTotalAmountReservesTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetNegativeTotalAmountsClaimReserveData());

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetNegativeClaimReservesAcordData());

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);
            ClueAutoData response = await mapperService.Map(new ClaimsDto() { ClaimNumber = "QA03941", PolicyNumber = "A553582", DateOfLoss = new DateTime(2019, 7, 8) });

            var file = response.Container;

            string correctResults = await this.GetNegativeTotalAmountsResults();

            Assert.AreEqual(correctResults, file);
        }

        [TestMethod]
        public async Task MergeClaimReserves_NoClaims_NullException()
        {
            // arrange
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Claim_NullException_DA01712.xml"));

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Policy_NullException_A920379.xml"));

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);

            // act
            ClueAutoData response = await mapperService.Map(new ClaimsDto { ClaimNumber = "DA01712", PolicyNumber = "A920379", DateOfLoss = new DateTime(2020, 4, 7) });

            // assert
            Assert.IsNull(response);
        }

        [TestMethod]
        public async Task MergeClaimReserves_TravelNet_NoVehicles_NoException()
        {
            // arrange
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Claim_QA11455.xml"));

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Policy_B136025.xml"));

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(string.Empty, string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);

            // act
            ClueAutoData response = await mapperService.Map(new ClaimsDto { ClaimNumber = "QA11455", PolicyNumber = "B136025", DateOfLoss = new DateTime(2020, 4, 7) });

            // assert
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Container);

            Assert.AreEqual(
                "    BURGESS             MARY                                  2535     W MORSE DR               ANTHEM              AZ850861880          00000000002081969AX9SF4653                AZM                                                                                          00000000000000000                                                  BURGESS             MARY                JANE           SEA2535     W MORSE DR               ANTHEM              AZ850861880          000000000010119830HBR2345                 WIF                             00964B136025             PA                  QA11455             TL04132020000010000A                         0000                                         OU00000000                            2" + Environment.NewLine,
                response.Container);
        }

        [TestMethod]
        public async Task MergeClaimReserves_GenderNonBinary_ProperMapping()
        {
            // arrange
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Claim_QA11237.xml"));

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Policy_B035684.xml"));

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(string.Empty, string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);

            // act
            ClueAutoData response = await mapperService.Map(new ClaimsDto { ClaimNumber = "QA11237", PolicyNumber = "B035684", DateOfLoss = new DateTime(2020, 4, 7) });

            // assert
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Container);

            Assert.AreEqual(
                "    2DRIVER1VEH         MARINABATT          A              III7350     N DOBSON RD         120  SCOTTSDALE          AZ852562712          000000000091619255YW9BP13T9098            AZ                                 STAFFORD            KELLY                              1ST00000000005101979CRO8X4321                AZF                      2DRIVER1VEH         MARINABATT          A              III7350     N DOBSON RD         120  SCOTTSDALE          AZ852562712          00000000000000000                            P                            00964B035684             PA                  QA11237             BI03092020025500000A5N3ZA0NE1A1111111        2010INFINITI QX56                            SA00000000                            2" + Environment.NewLine,
                response.Container);
        }

        [TestMethod]
        public async Task MergeClaimReserves_DateOfLoss_ProperMapping()
        {
            // arrange
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Claim_QA11478.xml"));

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.RetrieveFileResults("data/claims/Policy_B128521.xml"));

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(string.Empty, string.Empty, string.Empty, string.Empty))
                .IgnoreArguments()
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);

            // act
            ClueAutoData response = await mapperService.Map(new ClaimsDto { ClaimNumber = "QA11478", PolicyNumber = "B128521", DateOfLoss = new DateTime(2020, 4, 7) });

            // assert
            Assert.IsNotNull(response);
            Assert.IsNotNull(response.Container);

            Assert.AreEqual(
                "    STANDAGE            MARY                                  9116     W HEBER RD               TOLLESON            AZ853535563          00000000003011949                                                            STANDAGE            MIRANDA                               00000000007051990ZATXFH52JE7829           AZF                      STANDAGE            MARY                                  9116     W HEBER RD               TOLLESON            AZ853535563          00000000001011967                                                         00964B128521             PA                  QA11478             CO04202020000000000A1C4RJFAG7LC121288        2020JEEP GRAND CHEROKEE LAREDO/LAREDO E/UPLD OA00000000                            2" + Environment.NewLine,
                response.Container);
        }

        [TestMethod]
        public async Task TwoDriverTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetTwoDriverOnClaimData());
            
            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetTwoDriverOnClaimPolicyData());
            
            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);
            ClueAutoData response = await mapperService.Map(new ClaimsDto() { ClaimNumber = "QA04216", PolicyNumber = "A575813", DateOfLoss = new DateTime(2019, 7, 8) });

            var file = response.Container;
            
            string correctResults = await this.GetTwoDriverOnClaimResults();

            Assert.AreEqual(correctResults, file);
        }

        [TestMethod]
        public async Task RolledPaymentsTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetRolledPaymentsClaimData());

            var policyApiMock = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApiMock.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments()
                .Return(this.GetRolledPaymentsPolicyData());

            var fileWriterMock = MockRepository.GenerateMock<IFileWriter>();
            fileWriterMock.Stub(a => a.WriteClueAuto(Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything, Arg<string>.Is.Anything))
                .Return(null)
                .WhenCalled(a =>
                {
                    a.ReturnValue = ReturnMapperServiceResponse((string)a.Arguments[0], (string)a.Arguments[1], (string)a.Arguments[2], (string)a.Arguments[3]);
                });

            var logger = MockRepository.GenerateMock<ILogger>();

            IMapperService mapperService = new MapperService(policyApiMock, fileWriterMock, logger, claimApiMock);
            ClueAutoData response = await mapperService.Map(new ClaimsDto() { ClaimNumber = "QA04216", PolicyNumber = "A575813", DateOfLoss = new DateTime(2019, 7, 8) });

            var file = response.Container;

            string correctResults = await this.GetRolledPaymentsResults();

            Assert.AreEqual(correctResults, file);
        }

        [TestMethod]
        public async Task MapperTest()
        {
            var claimApiMock = MockRepository.GenerateMock<IClaimsClaim>();
            claimApiMock.Stub(a => a.ClaimOrchestratorLogicApp(string.Empty, string.Empty)).IgnoreArguments().Return(this.GetListedClaim());
            var logger = MockRepository.GenerateMock<ILogger>();
            var policyApi = MockRepository.GenerateMock<IPolicyStoreApi>();
            policyApi.Stub(a => a.GetPolicyRequest(string.Empty, string.Empty, string.Empty)).IgnoreArguments().Return(this.GetPolicyData());
            var fileWriter = MockRepository.GenerateMock<IFileWriter>();
            fileWriter.Stub(a => a.WriteClueAuto(string.Empty, string.Empty, string.Empty, string.Empty)).IgnoreArguments().Return(this.GetClueAutoData());

            var mapper = new MapperService(policyApi, fileWriter, logger, claimApiMock);
            var response = await mapper.Map(new ClaimsDto() { ClaimNumber = "D12354", PolicyNumber = "A12345", DateOfLoss = new DateTime(2019, 5, 1) });

            response.ShouldNotBeNull();
            fileWriter.AssertWasCalled(
                a => a.WriteClueAuto(string.Empty, string.Empty, string.Empty, string.Empty),
                options =>
                {
                    options.IgnoreArguments();
                    options.Repeat.Times(1);
                });
        }

        private Task<ClueAutoData> GetClueAutoData()
        {
            return Task.FromResult(new ClueAutoData());
        }

        private Task<string> GetUnlistedClaim()
        {
            using (var sr = new StreamReader("data/claimUnlisted.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetListedClaim()
        {
            using (var sr = new StreamReader("data/claimsListed.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetPolicyData()
        {
            using (var sr = new StreamReader("data/AcordForClaimListed.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetNegativeClaimReservesAcordData()
        {
            using (var sr = new StreamReader("data/AcordForClaimWithNegativeReserveTotals.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetTwoDriverOnClaimPolicyData()
        {
            using (var sr = new StreamReader("data/AcordForCLUEAutoTwoDriverOnClaimPolicy.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetRolledPaymentsPolicyData()
        {
            using (var sr = new StreamReader("data/AcordForCLUEAutoRolledPayments.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetTwoDriverOnClaimData()
        {
            using (var sr = new StreamReader("data/ClaimForCLUEAutoTwoDriverOnClaim.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetNegativeTotalAmountsClaimReserveData()
        {
            using (var sr = new StreamReader("data/ClaimWithNegativeReserveTotals.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetRolledPaymentsClaimData()
        {
            using (var sr = new StreamReader("data/ClaimForCLUEAutoRolledPayments.xml"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetTwoDriverOnClaimResults()
        {
            using (var sr = new StreamReader("data/TwoVehicleClaimResults.txt"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetNegativeTotalAmountsResults()
        {
            using (var sr = new StreamReader("data/NegativeTotalAmountsResults.txt"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> GetRolledPaymentsResults()
        {
            using (var sr = new StreamReader("data/RolledPaymentsResults.txt"))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult<string>(line);
            }
        }

        private Task<string> RetrieveFileResults(string pathname)
        {
            using (var sr = new StreamReader(pathname))
            {
                var line = sr.ReadToEnd();
                return Task.FromResult(line);
            }
        }

        private Task<ClueAutoData> ReturnMapperServiceResponse(string storableFile, string claimNumber, string policyNumber, string claimType)
        {
            // This is tweaking BlobFileWriter.WriteClueAuto
            var dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmssffff");
            var fileName = "ClueAuto" + dateTimeString + ".txt";

            var rowKey = $"{claimNumber}.{policyNumber}.{dateTimeString}";

            var clueAutoData = new ClueAutoData()
            {
                CreateDate = dateTimeString,
                PolicyNumber = policyNumber,
                Container = storableFile,
                Folder = null,
                Name = fileName,
                ClaimNumber = claimNumber
            };

            return Task.FromResult<ClueAutoData>(clueAutoData);
        }
    }
}