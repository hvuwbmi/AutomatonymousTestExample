﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="AddressTypeTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using FileHelpers.FileMappers.CurrentCarrier;
    using FileHelpers.Models;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Should;

    [TestClass]
    public class AddressTypeTestFixture
    {
        [TestMethod]
        public void Test_AddressMap_NP01_AddressStandardized()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "532144578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "0",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A",
                                WBAddrStandardizeStatus = "Accepted"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierPolicyInfoNP01();

            // act
            address.Map(file);

            // assert
            file.PolicyholderAddressAptNumber.ShouldEqual("4A");
            file.PolicyholderAddressCity.ShouldEqual("Pewaukee");
            file.PolicyholderAddressNumber.ShouldEqual("12345");
            file.PolicyholderAddressState.ShouldEqual("WI");
            file.PolicyholderAddressStreetName.ShouldEqual("Main St");
            file.PolicyholderAddressZip.ShouldEqual("53214");
            file.PolicyholderAddressZip4.ShouldEqual(string.Empty);
        }

        [TestMethod]
        public void Test_AddressMap_NP01_AddressStandardized_Overridden()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "532144578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "1",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierPolicyInfoNP01();

            // act
            address.Map(file);

            // assert
            file.PolicyholderAddressAptNumber.ShouldEqual(null);
            file.PolicyholderAddressCity.ShouldEqual("Pewaukee");
            file.PolicyholderAddressNumber.ShouldEqual(null);
            file.PolicyholderAddressState.ShouldEqual("WI");
            file.PolicyholderAddressStreetName.ShouldEqual("23456 Third Ave Unit 8");
            file.PolicyholderAddressZip.ShouldEqual("53214");
            file.PolicyholderAddressZip4.ShouldEqual(string.Empty);
        }

        [TestMethod]
        public void Test_AddressMap_NP01_Line1()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "747 Ridge Dr Apt 5B",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "532144578"
            };

            var file = new CurrentCarrierPolicyInfoNP01();

            // act
            address.Map(file);

            // assert
            file.PolicyholderAddressAptNumber.ShouldEqual(null);
            file.PolicyholderAddressCity.ShouldEqual("Pewaukee");
            file.PolicyholderAddressNumber.ShouldEqual(null);
            file.PolicyholderAddressState.ShouldEqual("WI");
            file.PolicyholderAddressStreetName.ShouldEqual("747 Ridge Dr Apt 5B");
            file.PolicyholderAddressZip.ShouldEqual("53214");
            file.PolicyholderAddressZip4.ShouldEqual(string.Empty);
        }

        [TestMethod]
        public void Test_AddressMap_FP01_AddressStandardized()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "0",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A",
                                WBAddrStandardizeStatus = "Accepted"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierFIRStPolicyInfoFP01();

            // act
            address.Map(file);

            // assert
            file.AgentAddressAptNumber.ShouldEqual("4A");
            file.AgentAddressCity.ShouldEqual("Pewaukee");
            file.AgentAddressNumber.ShouldEqual("12345");
            file.AgentAddressState.ShouldEqual("WI");
            file.AgentAddressStreetName.ShouldEqual("Main St");
            file.AgentAddressZip.ShouldEqual("53214");
            file.AgentAddressZip4.ShouldEqual("4578");
        }

        [TestMethod]
        public void Test_AddressMap_FP01_AddressStandardized_Overridden()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "1",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierFIRStPolicyInfoFP01();

            // act
            address.Map(file);

            // assert
            file.AgentAddressAptNumber.ShouldEqual(null);
            file.AgentAddressCity.ShouldEqual("Pewaukee");
            file.AgentAddressNumber.ShouldEqual(null);
            file.AgentAddressState.ShouldEqual("WI");
            file.AgentAddressStreetName.ShouldEqual("23456 Third Ave Unit 8");
            file.AgentAddressZip.ShouldEqual("53214");
            file.AgentAddressZip4.ShouldEqual("4578");
        }

        [TestMethod]
        public void Test_AddressMap_FP01_Line1()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "747 Ridge Dr Apt 5B",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578"
            };

            var file = new CurrentCarrierFIRStPolicyInfoFP01();

            // act
            address.Map(file);

            // assert
            file.AgentAddressAptNumber.ShouldEqual(null);
            file.AgentAddressCity.ShouldEqual("Pewaukee");
            file.AgentAddressNumber.ShouldEqual(null);
            file.AgentAddressState.ShouldEqual("WI");
            file.AgentAddressStreetName.ShouldEqual("747 Ridge Dr Apt 5B");
            file.AgentAddressZip.ShouldEqual("53214");
            file.AgentAddressZip4.ShouldEqual("4578");
        }

        [TestMethod]
        public void Test_AddressMap_FR01_AddressStandardized()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "0",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A",
                                WBAddrStandardizeStatus = "Accepted"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierFIRSTPropertyInfoFR01();

            // act
            address.Map(file);

            // assert
            file.FinanceCompany1AddressAptNumber.ShouldEqual("4A");
            file.FinanceCompany1AddressCity.ShouldEqual("Pewaukee");
            file.FinanceCompany1AddressNumber.ShouldEqual("12345");
            file.FinanceCompany1AddressState.ShouldEqual("WI");
            file.FinanceCompany1AddressStreetName.ShouldEqual("Main St");
            file.FinanceCompany1AddressZipCode.ShouldEqual("53214");
            file.FinanceCompany1AddressZipCode4.ShouldEqual("4578");
        }

        [TestMethod]
        public void Test_AddressMap_FR01_AddressStandardized_Overridden()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "23456 Third Ave Unit 8",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578",
                AddrExt = new AddrAddrExt[]
                {
                    new AddrAddrExt
                    {
                        PostalCodePlusFour = "53214-4578",
                        WBAddressStandardization = new AddrAddrExtWBAddressStandardization[]
                        {
                            new AddrAddrExtWBAddressStandardization
                            {
                                WBAddrStandardizeInd = "1",
                                WBAddrOverrideInd = "1",
                                WBAddrStandardizeStreetName = "Main",
                                WBAddrStandardizeStreetNumber = "12345",
                                WBAddrStandardizeStreetTypeCd = "St",
                                WBAddrStandardizeUnitLabel = "Apt",
                                WBAddrStandardizeUnitNumber = "4A"
                            }
                        }
                    }
                }
            };

            var file = new CurrentCarrierFIRSTPropertyInfoFR01();

            // act
            address.Map(file);

            // assert
            file.FinanceCompany1AddressAptNumber.ShouldEqual(null);
            file.FinanceCompany1AddressCity.ShouldEqual("Pewaukee");
            file.FinanceCompany1AddressNumber.ShouldEqual(null);
            file.FinanceCompany1AddressState.ShouldEqual("WI");
            file.FinanceCompany1AddressStreetName.ShouldEqual("23456 Third Ave Unit 8");
            file.FinanceCompany1AddressZipCode.ShouldEqual("53214");
            file.FinanceCompany1AddressZipCode4.ShouldEqual("4578");
        }

        [TestMethod]
        public void Test_AddressMap_FR01_Line1()
        {
            // arrange
            Addr address = new Addr
            {
                Addr1 = "747 Ridge Dr Apt 5B",
                City = "Pewaukee",
                StateProvCd = "WI",
                PostalCode = "53214-4578"
            };

            var file = new CurrentCarrierFIRSTPropertyInfoFR01();

            // act
            address.Map(file);

            // assert
            file.FinanceCompany1AddressAptNumber.ShouldEqual(null);
            file.FinanceCompany1AddressCity.ShouldEqual("Pewaukee");
            file.FinanceCompany1AddressNumber.ShouldEqual(null);
            file.FinanceCompany1AddressState.ShouldEqual("WI");
            file.FinanceCompany1AddressStreetName.ShouldEqual("747 Ridge Dr Apt 5B");
            file.FinanceCompany1AddressZipCode.ShouldEqual("53214");
            file.FinanceCompany1AddressZipCode4.ShouldEqual("4578");
        }
    }
}
