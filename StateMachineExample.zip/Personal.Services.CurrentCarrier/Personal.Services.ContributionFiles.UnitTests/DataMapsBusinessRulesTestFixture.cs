﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="DataMapsBusinessRulesTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using FileHelpers.Rules;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Should;

    [TestClass]
    public class DataMapsBusinessRulesTestFixture
    {
        [TestMethod]
        [DataRow(true, "A")]
        [DataRow(false, "N")]
        public void FaultIndicatorTests(bool value1, string value2)
        {
            var response = ClueFaultIndicatorClaimClaimAtFaultRule.GetClueFaultIndicatorCode(value1);
            response.ShouldEqual(value2);
        }

        [TestMethod]
        [DataRow("O", "O")]
        [DataRow("C", "C")]
        [DataRow("E", "W")]
        [DataRow("N", "W")]
        [DataRow("S", "S")]
        public void ClaimDispositionTests(string value1, string value2)
        {
            var response = ClueClaimDispositionClaimStatusCodeRule.GetClueClaimDispositionCode(value1);
            response.ShouldEqual(value2);
        }

        [TestMethod]
        [DataRow("CSL", "BI", "")]
        [DataRow("CSLENO", "BI", "")]
        [DataRow("CSLNNO", "BI", "")]
        [DataRow("BI", "BI", "")]
        [DataRow("BIENO", "BI", "")]
        [DataRow("BINNO", "BI", "")]
        [DataRow("BIMGP", "BI", "")]
        [DataRow("COLL", "CO", "")]
        [DataRow("COLLENO", "CO", "")]
        [DataRow("COLLNNO", "CO", "")]
        [DataRow("ALCCOLL", "CO", "")]
        [DataRow("CDRCOLL", "CO", "")]
        [DataRow("OTC", "CP", "")]
        [DataRow("OTCENO", "CP", "")]
        [DataRow("OTCNNO", "CP", "")]
        [DataRow("ALCOTC", "CP", "")]
        [DataRow("CDROTC", "CP", "")]
        [DataRow("OTC", "GL", "03")]
        [DataRow("OTCENO", "GL", "03")]
        [DataRow("OTCNNO", "GL", "03")]
        [DataRow("MP", "MP", "")]
        [DataRow("MPENO", "MP", "")]
        [DataRow("MPNNO", "MP", "")]
        [DataRow("PD", "PD", "")]
        [DataRow("APD", "PD", "")]
        [DataRow("PPI", "PD", "")]
        [DataRow("PDENO", "PD", "")]
        [DataRow("PDNNO", "PD", "")]
        [DataRow("PIPMED", "PI", "")]
        [DataRow("PIPMEDENO", "PI", "")]
        [DataRow("PIPMEDNNO", "PI", "")]
        [DataRow("PIPWKLOSS", "PI", "")]
        [DataRow("PIPWKLOSSENO", "PI", "")]
        [DataRow("PIPWKLOSSNNO", "PI", "")]
        [DataRow("PIPALLOTHER", "PI", "")]
        [DataRow("PIPALLOTHERENO", "PI", "")]
        [DataRow("PIPALLOTHERNNO", "PI", "")]
        [DataRow("TRNSEXP", "RR", "")]
        [DataRow("TLN", "TL", "")]
        [DataRow("UMCSL", "UM", "")]
        [DataRow("UMCSLNNO", "UM", "")]
        [DataRow("UMSP", "UM", "")]
        [DataRow("UMSPNNO", "UM", "")]
        [DataRow("UMPD", "UM", "")]
        [DataRow("UMPDNNO", "UM", "")]
        [DataRow("UNDMCSL", "UN", "")]
        [DataRow("UNDMCSLNNO", "UN", "")]
        [DataRow("UNDMSP", "UN", "")]
        [DataRow("UNDMSPNNO", "UN", "")]
        [DataRow("ODDDDDD", "OT", "")]
        [DataRow("BIFRE", "OT", "")]
        public void ClaimTypeTests(string value1, string value2, string value3)
        {
            var response = ClueClaimTypeClaimTypeRule.GetClueClaimTypeCode(value1, value3);
            response.ShouldEqual(value2);
        }

        [TestMethod]
        [DataRow("FNI", "P")]
        [DataRow("CN", "H")]
        [DataRow("SP", "S")]
        [DataRow("CH", "C")]
        [DataRow("PA", "F")]
        [DataRow("GP", "O")]
        [DataRow("RE", "O")]
        [DataRow("NR", "X")]
        [DataRow("", "")]
        public void VROTests(string value1, string value2)
        {
            var response = AcordVROToClueAutoVRO.TransformAcordVROToClueAutoVRO(value1);
            response.ShouldEqual(value2);
        }
    }
}