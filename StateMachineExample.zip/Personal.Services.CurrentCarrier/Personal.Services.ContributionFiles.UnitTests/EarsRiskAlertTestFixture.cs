﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="EarsRiskAlertTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using global::FileHelpers;
    using FileHelpers.FileHelperExtensions;
    using FileHelpers.FileMappers.EarsRiskAlert;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Should;

    [TestClass]
    public class EarsRiskAlertTestFixture
    {
        #region Private Variables
        private static readonly string DriverLicenseToken1 = "9RZ3L9GIZ30001";
        #endregion

        [TestMethod]
        public void TestEarsRiskAlert_SubFile()
        {
            var engine = new EarsRiskAlertEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var obj = BuildEarsDetailRequestList();

            string actualSubfile = engine.WriteString(obj.AsEnumerable());
            string expected =
                "WI9RZ3L9GIZ30001        SMITH                    JOHN                Q                   19650224530271954123 S. MAIN ST           M A123456                         20200520  quoteback                                                                       R        110000000611852                          "
                + Environment.NewLine;

            actualSubfile.Length.ShouldEqual(305 + 2);
            actualSubfile.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestEarsRiskAlert_MainFile()
        {
            var engine = new EarsRiskAlertEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var earsHeaders = new List<EarsRiskAlertHeader> { new EarsRiskAlertHeader() };
            var engineHeaderText = new FixedFileEngine<EarsRiskAlertHeader>();
            engine.HeaderText = engineHeaderText.WriteString(earsHeaders);
            var earsTrailers = new List<EarsRiskAlertTrailer> { new EarsRiskAlertTrailer() };
            var engineTrailerText = new FixedFileEngine<EarsRiskAlertTrailer>();
            engine.FooterText = engineTrailerText.WriteString(earsTrailers);

            var obj = BuildEarsDetailRequestList();

            // This is not actually going through Map at this point, the DL is expected to be the token here.
            string actualMainfile = engine.WriteString(obj.AsEnumerable());
            string expected =
                "FH00010101DRPL NEW PLAT                   611852   0800                                                                                                                                                                                                                                                          " + Environment.NewLine +
                "WI9RZ3L9GIZ30001        SMITH                    JOHN                Q                   19650224530271954123 S. MAIN ST           M A123456                         20200520  quoteback                                                                       R        110000000611852                          " + Environment.NewLine +
                "FT               0EXPLORE                                DR                                                                                                                                                                                                                                                      " + Environment.NewLine;

            actualMainfile.Length.ShouldEqual((305 + 2) * 3);
            actualMainfile.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestEarsRiskAlert_Header()
        {
            var engine = new EarsRiskAlertEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var earsHeaders = new List<EarsRiskAlertHeader> { new EarsRiskAlertHeader() };
            var engineHeaderText = new FixedFileEngine<EarsRiskAlertHeader>();
            engine.HeaderText = engineHeaderText.WriteString(earsHeaders);
            var expected = 
                "FH00010101DRPL NEW PLAT                   611852   0800                                                                                                                                                                                                                                                          "
                + Environment.NewLine;
            var actual = engine.WriteString(new List<EarsRiskAlertDetailRequest>().AsEnumerable());

            actual.Length.ShouldEqual(305 + 2);
            actual.ShouldEqual(expected);
        }

        [TestMethod]
        public void TestEarsRiskAlert_Footer()
        {
            var engine = new EarsRiskAlertEngineFactory().CreateEngine();
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();

            var earsTrailers = new List<EarsRiskAlertTrailer> { new EarsRiskAlertTrailer() };
            var engineTrailerText = new FixedFileEngine<EarsRiskAlertTrailer>();
            engine.FooterText = engineTrailerText.WriteString(earsTrailers);
            var expected =
                "FT               0EXPLORE                                DR                                                                                                                                                                                                                                                      "
                + Environment.NewLine;
            var actual = engine.WriteString(new List<EarsRiskAlertDetailRequest>().AsEnumerable());

            actual.Length.ShouldEqual(305 + 2);
            actual.ShouldEqual(expected);
        }

        private static List<EarsRiskAlertDetailRequest> BuildEarsDetailRequestList()
        {
            var list = new List<EarsRiskAlertDetailRequest>
            {
                new EarsRiskAlertDetailRequest
                {
                    LicenseState = "WI",
                    LicenseNumber = DriverLicenseToken1,
                    LastName = "SMITH",
                    FirstName = "JOHN",
                    MiddleName = "Q",
                    BirthDate = new DateTime(1965, 2, 24),
                    ZipCode = "530271954",
                    StreetAddress = "123 S. MAIN ST",
                    Gender = "M",
                    PolicyNumber = "A123456",
                    PolicyExpirationDate = new DateTime(2020, 5, 20),
                    Quoteback = "quoteback",
                    IncludeInEars = true,
                    IncludeInRiskAlert = true
                }
            };

            return list;
        }
    }
}
