﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="SpaceDateConverterYYYYMMDDTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------
namespace Personal.Services.ContributionFiles.UnitTests.ConverterTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;

    [TestClass]
    public class SpaceDateConverterYYYYMMDDTestFixture
    {
        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_StringToField_null()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldObj = converter.StringToField(null);

            // assert
            Assert.IsNull(fieldObj);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_StringToField_8spaces()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldObj = converter.StringToField("        ");

            // assert
            Assert.IsNull(fieldObj);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_StringToField_ValidDate()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldObj = converter.StringToField("20200116");

            // assert
            Assert.IsNotNull(fieldObj);
            Assert.IsInstanceOfType(fieldObj, typeof(DateTime));

            var fieldDate = (DateTime)fieldObj;
            Assert.AreEqual(2020, fieldDate.Year);
            Assert.AreEqual(1, fieldDate.Month);
            Assert.AreEqual(16, fieldDate.Day);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_StringToField_InvalidDate()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldObj = converter.StringToField("20200199");

            // assert
            Assert.IsNull(fieldObj);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_FieldToString_null()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldStr = converter.FieldToString(null);

            // assert
            Assert.AreEqual("        ", fieldStr);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_FieldToString_ValidDate()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();

            // act
            var fieldStr = converter.FieldToString(new DateTime(2020, 1, 21));

            // assert
            Assert.AreEqual("20200121", fieldStr);
        }

        [TestMethod]
        public void SpaceDateConverterYYYYMMDD_FieldToString_RandomString()
        {
            // arrange
            var converter = new SpaceDateConverterYYYYMMDD();
            bool caughtException = false;

            // act
            try
            {
                var fieldStr = converter.FieldToString("abcdef");
            }
            catch (FormatException)
            {
                caughtException = true;
            }

            Assert.IsTrue(caughtException);
        }
    }
}
