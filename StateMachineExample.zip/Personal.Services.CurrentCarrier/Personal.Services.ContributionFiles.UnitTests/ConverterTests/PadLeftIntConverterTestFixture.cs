﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="PadLeftIntConverterTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.ConverterTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;

    [TestClass]
    public class PadLeftIntConverterTestFixture
    {
        [TestMethod]
        public void PadLeftIntConverter_StringToField_null()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);
            bool caughtException = false;

            // act
            try
            {
                var fieldObj = converter.StringToField(null);
            }
            catch (ArgumentNullException)
            {
                caughtException = true;
            }

            // assert
            Assert.IsTrue(caughtException);
        }

        [TestMethod]
        public void PadLeftIntConverter_StringToField_ValidNumber()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);

            // act
            var fieldObj = converter.StringToField("00001234");

            // assert
            Assert.IsNotNull(fieldObj);

            int field = (int)fieldObj;
            Assert.AreEqual(1234, field);
        }

        [TestMethod]
        public void PadLeftIntConverter_StringToField_Characters()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);
            bool caughtException = false;

            // act
            try
            {
                var fieldObj = converter.StringToField("abcdefgh");
            }
            catch (FormatException)
            {
                caughtException = true;
            }

            // assert
            Assert.IsTrue(caughtException);
        }

        [TestMethod]
        public void PadLeftIntConverter_FieldToString_null()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);
            bool caughtException = false;

            // act
            try
            {
                var fieldStr = converter.FieldToString(null);
            }
            catch (NullReferenceException)
            {
                caughtException = true;
            }

            // assert
            Assert.IsTrue(caughtException);
        }

        [TestMethod]
        public void PadLeftIntConverter_FieldToString_ValidNumber()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);

            // act
            var fieldStr = converter.FieldToString(4567);

            // assert
            Assert.AreEqual("00004567", fieldStr);
        }

        [TestMethod]
        public void PadLeftIntConverter_FieldToString_Characters()
        {
            // arrange
            var converter = new PadLeftIntConverter(8);

            // act
            var fieldStr = converter.FieldToString("abcd");

            // assert
            Assert.AreEqual("0000abcd", fieldStr);
        }
    }
}
