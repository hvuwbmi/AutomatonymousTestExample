﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="LicenseConverterTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.ConverterTests
{
    using System;
    using System.Collections.Generic;
    using System.Threading.Tasks;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;
    using Personal.Services.ContributionFiles.FileHelpers.Models;
    using Personal.Services.ContributionFiles.FileHelpers.ServiceInterfaces;
    using Refit;
    using Rhino.Mocks;
    using WestBend.Core;

    [TestClass]
    public class LicenseConverterTestFixture
    {
        [TestMethod]
        public void LicenseConverter_StringToField_FirstSuccess()
        {
            // arrange
            var converter = new LicenseConverter();
            ITokenApi tokenApi = MockRepository.GenerateMock<ITokenApi>();
            TokenResponse response = new TokenResponse { data = "LICENSE1" };
            tokenApi
                .Expect(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything))
                .Return(Task.FromResult(response));
            LicenseConverter.TokenApi = tokenApi;

            // act
            var fieldObj = converter.StringToField("TOKEN1");

            // assert
            Assert.IsNotNull(fieldObj);
            Assert.AreEqual("LICENSE1", fieldObj);
            tokenApi.VerifyAllExpectations();
        }

        [TestMethod]
        public async Task LicenseConverter_StringToField_SecondSuccess()
        {
            // arrange
            var converter = new LicenseConverter();
            ITokenApi tokenApi = MockRepository.GenerateMock<ITokenApi>();
            ILogger logger = MockRepository.GenerateMock<ILogger>();
            TokenResponse response = new TokenResponse { data = "LICENSE2" };

            tokenApi
                .Expect(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything))
                .Throw(this.BuildException())
                .Repeat.Once();

            tokenApi
                .Expect(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything))
                .Return(Task.FromResult(response))
                .Repeat.Once();

            logger.Expect(x => x.Log(
                Arg.Is("PL.CurrentCarrier"),
                Arg.Is(System.Diagnostics.TraceEventType.Warning),
                Arg.Is("Retrying detokenizer, attempt 1"),
                Arg<IDictionary<string, string>>.Is.Null,
                Arg<ApiException>.Is.Anything,
                Arg.Is(string.Empty),
                Arg.Is(true)));

            LicenseConverter.TokenApi = tokenApi;
            LicenseConverter.Logger = logger;

            // act
            var fieldObj = converter.StringToField("TOKEN1");

            // assert
            Assert.IsNotNull(fieldObj);
            Assert.AreEqual("LICENSE2", fieldObj);
            tokenApi.VerifyAllExpectations();
            logger.VerifyAllExpectations();
        }

        [TestMethod]
        [TestCategory("SlowTest")]
        public async Task LicenseConverter_StringToField_FiveFailures()
        {
            // The number of failures matches the number of attempts the LicenseConverter makes.
            // arrange
            var converter = new LicenseConverter();
            ITokenApi tokenApi = MockRepository.GenerateMock<ITokenApi>();
            ILogger logger = MockRepository.GenerateMock<ILogger>();
            TokenResponse response = new TokenResponse { data = "LICENSE2" };

            tokenApi
                .Expect(x => x.Detokenize(Arg<TokenRequest>.Is.Anything, Arg<string>.Is.Anything))
                .Throw(this.BuildException())
                .Repeat.Times(5);

            for (int retryCount = 1; retryCount <= 5; retryCount++)
            {
                logger.Expect(x => x.Log(
                    Arg.Is("PL.CurrentCarrier"),
                    Arg.Is(System.Diagnostics.TraceEventType.Warning),
                    Arg.Is($"Retrying detokenizer, attempt {retryCount}"),
                    Arg<IDictionary<string, string>>.Is.Null,
                    Arg<ApiException>.Is.Anything,
                    Arg.Is(string.Empty),
                    Arg.Is(true)));
            }

            LicenseConverter.TokenApi = tokenApi;
            LicenseConverter.Logger = logger;
            bool caughtException = false;

            // act
            try
            {
                var fieldObj = converter.StringToField("TOKEN1");
            }
            catch (Exception)
            {
                caughtException = true;
            }

            // assert
            Assert.IsTrue(caughtException);
            tokenApi.VerifyAllExpectations();
            logger.VerifyAllExpectations();
        }

        [TestMethod]
        public void LicenseConverter_FieldToString_null()
        {
            // arrange
            var converter = new LicenseConverter();

            // act
            var outputStr = converter.FieldToString(null);

            // assert
            Assert.AreEqual(string.Empty, outputStr);
        }

        [TestMethod]
        public void LicenseConverter_FieldToString_RandomString()
        {
            // arrange
            var converter = new LicenseConverter();

            // act
            var outputStr = converter.FieldToString("abc123");

            // assert
            Assert.AreEqual("abc123", outputStr);
        }

        private AggregateException BuildException()
        {
            return new AggregateException();
        }
    }
}
