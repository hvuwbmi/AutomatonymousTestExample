﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="NullDateConverterTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.ConverterTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;

    [TestClass]
    public class NullDateConverterTestFixture
    {
        [TestMethod]
        public void NullDateConverter_StringToField_null()
        {
            // arrange
            var converter = new NullDateConverter();

            // act
            var outputObj = converter.StringToField(null);

            // assert
            Assert.IsNull(outputObj);
        }

        [TestMethod]
        public void NullDateConverter_StringToField_ValidDate()
        {
            // arrange
            var converter = new NullDateConverter();

            // act
            var outputObj = converter.StringToField("20200225");

            // assert
            Assert.IsNotNull(outputObj);
            Assert.IsInstanceOfType(outputObj, typeof(DateTime));
            var outputDate = (DateTime)outputObj;

            Assert.AreEqual(2020, outputDate.Year);
            Assert.AreEqual(2, outputDate.Month);
            Assert.AreEqual(25, outputDate.Day);
        }

        [TestMethod]
        public void NullDateConverter_StringToField_InvalidDate()
        {
            // arrange
            var converter = new NullDateConverter();

            // act
            var outputObj = converter.StringToField("20200299");

            // assert
            Assert.IsNull(outputObj);
        }

        [TestMethod]
        public void NullDateConverter_FieldToString_null()
        {
            // arrange
            var converter = new NullDateConverter();

            // act
            var outputStr = converter.FieldToString(null);

            // assert
            Assert.AreEqual(string.Empty, outputStr);
        }

        [TestMethod]
        public void NullDateConverter_FieldToString_ValidDateString()
        {
            // arrange
            var converter = new NullDateConverter();

            // act
            var outputStr = converter.FieldToString(new DateTime(2020, 2, 25));

            // assert
            Assert.AreEqual("20200225", outputStr);
        }
    }
}
