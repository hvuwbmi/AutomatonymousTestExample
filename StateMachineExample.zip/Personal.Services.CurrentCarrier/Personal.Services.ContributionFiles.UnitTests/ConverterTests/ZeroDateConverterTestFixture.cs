﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="ZeroDateConverterTestFixture.cs" company="West Bend">
// Copyright (c) 2020 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests.ConverterTests
{
    using System;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Personal.Services.ContributionFiles.FileHelpers.FileHelperExtensions;

    [TestClass]
    public class ZeroDateConverterTestFixture
    {
        [TestMethod]
        public void ZeroDateConverter_StringToField_ValidDateString()
        {
            // arrange
            var converter = new ZeroDateConverter();
            var inputDate = "20200227";

            // act
            var outputObj = converter.StringToField(inputDate);

            // assert
            Assert.IsNotNull(outputObj);
            Assert.IsInstanceOfType(outputObj, typeof(DateTime));

            var outputDate = (DateTime)outputObj;
            Assert.AreEqual(2020, outputDate.Year);
            Assert.AreEqual(2, outputDate.Month);
            Assert.AreEqual(27, outputDate.Day);
        }

        [TestMethod]
        public void ZeroDateConverter_StringToField_InvalidDateString()
        {
            // arrange
            var converter = new ZeroDateConverter();
            var inputDate = "20200299";

            // act
            var outputObj = converter.StringToField(inputDate);

            // assert
            Assert.IsNull(outputObj);
        }

        [TestMethod]
        public void ZeroDateConverter_StringToField_null()
        {
            // arrange
            var converter = new ZeroDateConverter();

            // act
            var outputObj = converter.StringToField(null);

            // assert
            Assert.IsNull(outputObj);
        }

        [TestMethod]
        public void ZeroDateConverter_StringToField_Zeroes()
        {
            // arrange
            var converter = new ZeroDateConverter();

            // act
            var outputObj = converter.StringToField("00000000");

            // assert
            Assert.IsNull(outputObj);
        }

        [TestMethod]
        public void ZeroDateConverter_FieldToString_null()
        {
            // arrange
            var converter = new ZeroDateConverter();

            // act
            var outputStr = converter.FieldToString(null);

            // assert
            Assert.AreEqual("00000000", outputStr);
        }

        [TestMethod]
        public void ZeroDateConverter_FieldToString_fromValidDate()
        {
            // arrange
            var converter = new ZeroDateConverter();

            // act
            var outputStr = converter.FieldToString(new DateTime(2020, 2, 25));

            // assert
            Assert.AreEqual("20200225", outputStr);
        }
    }
}
