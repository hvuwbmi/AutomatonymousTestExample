﻿// --------------------------------------------------------------------------------------------------------------------
// <copyright file="EarsRiskInboundTestFixture.cs" company="West Bend">
// Copyright (c) 2019 West Bend
// </copyright>
// --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.UnitTests
{
    using System;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using global::FileHelpers;
    using FileHelpers.FileHelperExtensions;
    using FileHelpers.FileMappers.EarsRiskInbound;
    using FileHelpers.Models;
    using FileHelpers.ServiceInterfaces;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Rhino.Mocks;
    using Should;

    [TestClass]
    public class EarsRiskInboundTestFixture
    {
        [TestMethod]
        public void TestCreateEngine()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();
            engine.ShouldBeType<MultiRecordEngine>();
        }

        [TestMethod]
        public void TestHeader()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.BuildHeaderString();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInboundHeader)list.First();

            file.RecordId.ShouldEqual("FH");
            file.FileDate.ShouldEqual(new DateTime(2019, 4, 15));
            file.FileIdCode.ShouldEqual("02");
            file.SenderName.ShouldEqual("EXPLORE");
            file.Version.ShouldEqual("01");
            file.Reserved1.Length.ShouldEqual(59);
            file.Reserved2.Length.ShouldEqual(70);
        }

        [TestMethod]
        public void TestTrailer()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.BuildTrailerString();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInboundTrailer)list.First();

            file.RecordId.ShouldEqual("FT");
            file.TotalRecords.ShouldEqual(7);
            file.TotalDrivers.ShouldEqual(1);
            file.FileIdCode.ShouldEqual("02");
            file.ReceivingName.Trim().ShouldEqual("West Bend Mutual");
            file.ReceivingNumber.ShouldEqual("123456789");
            file.Reserved1.Length.ShouldEqual(91);
        }

        [TestMethod]
        public void Test01()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build01String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound01)list.First();

            file.RecordId.ShouldEqual("01");
            file.LicenseState.ShouldEqual("WI");
            file.LicenseNumber.Trim().ShouldEqual("P124-7683-573897");
            file.Reserved1.Length.ShouldEqual(8);
            file.QuoteBack.Trim().ShouldEqual("A1234560001123456789P124-7683-573897WI");
            file.Reserved2.Length.ShouldEqual(8);
            file.ReportType.ShouldEqual("E");
            file.Reserved3.Length.ShouldEqual(2);
            file.Reserved4.Length.ShouldEqual(25);
        }

        [TestMethod]
        public void Test02()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build02String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound02)list.First();

            file.RecordId.ShouldEqual("02");
            file.City.Trim().ShouldEqual("West Bend");
            file.FirstName.Trim().ShouldEqual("Unit");
            file.LastName.Trim().ShouldEqual("Test");
            file.MiddleName.Trim().ShouldEqual("Mstest");
            file.State.ShouldEqual("WI");
            file.ZipCode.ShouldEqual("53222");
        }

        [TestMethod]
        public void Test03()
        {
            var stub = MockRepository.GenerateStub<ITokenApi>();
            stub.Stub(a => a.Tokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = "tok33424332" }))
                .Repeat.Once();

            ReverseLicenseConverter.TokenApi = stub;
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build03String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound03)list.First();

            file.RecordId.ShouldEqual("03");
            file.AccountNumber.Trim().ShouldEqual("0023456");
            file.Alias.Trim().ShouldEqual(string.Empty);
            file.BirthDate.Trim().ShouldEqual("19760602");
            file.EyeColor.Trim().ShouldEqual("BLUE");
            file.Gender.ShouldEqual("M");
            file.PreviousLicense.ShouldEqual("tok33424332");
        }

        [TestMethod]
        public void Test04()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build04String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound04)list.First();

            file.RecordId.ShouldEqual("04");
            file.CdlLicenseStatus.Trim().ShouldEqual("Valid");
            file.LicenseClass.Trim().ShouldEqual("Class");
            file.LicenseExpDate.ShouldEqual(new DateTime(2019, 12, 31));
            file.LicenseIssueDate.ShouldEqual(new DateTime(2010, 1, 1));
            file.PersonalLicenseStatus.Trim().ShouldEqual("Valid");
            file.LicenseType.Trim().ShouldEqual("Operator");
        }

        [TestMethod]
        public void Test05()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build05String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound05)list.First();

            file.RecordId.ShouldEqual("05");
            file.EndorseRestType1.ShouldEqual("RS");
            file.LicenseClass.Trim().ShouldEqual("Class");
            file.EndorseRestType2.ShouldEqual("RS");
            file.EndorseRestType3.ShouldEqual("EN");
            file.EndorseRestType4.ShouldEqual("EN");
            file.EndorseRestrict1.Trim().ShouldEqual("Glasses");
            file.EndorseRestrict2.Trim().ShouldEqual("Day");
            file.EndorseRestrict3.Trim().ShouldEqual("Nighttime");
            file.EndorseRestrict4.Trim().ShouldEqual("Booster");
        }

        [TestMethod]
        public void Test06()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build06String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound06)list.First();

            file.RecordId.ShouldEqual("06");
            file.CustomerCode.ShouldEqual("0000000342");
            file.IncidentDescription.Trim().ShouldEqual("Speeding +10");
            file.IncidentEndDate.ShouldEqual(new DateTime(2012, 5, 24));
            file.IncidentStartDate.ShouldEqual(new DateTime(2012, 5, 2));
            file.IncidentPoints.ShouldEqual(4);
            file.IncidentResult.Trim().ShouldEqual("Violation");
            file.NationalCode.Trim().ShouldEqual("444");
            file.StateCode.Trim().ShouldEqual("453");
        }

        [TestMethod]
        public void Test07()
        {
            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString = this.Build07String();
            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(1);

            var file = (EarsRiskAlertInbound07)list.First();

            file.RecordId.ShouldEqual("07");
            file.MiscText.Trim().ShouldEqual("Some very random text");
        }

        [TestMethod]
        public void TestAllParts()
        {
            var stub = MockRepository.GenerateStub<ITokenApi>();
            stub.Stub(a => a.Tokenize(null, null)).IgnoreArguments()
                .Return(Task.FromResult(new TokenResponse { data = "tok33424332" }))
                .Repeat.Once();

            ReverseLicenseConverter.TokenApi = stub;

            var engine = new EngineFactory().CreateEngine(EngineFactory.EngineType.EarsInbound);
            engine.ShouldNotBeNull();

            var recordString =
                this.BuildHeaderString()
                + this.Build01String()
                + this.Build02String()
                + this.Build03String()
                + this.Build04String()
                + this.Build05String()
                + this.Build06String()
                + this.Build07String()
                + this.BuildTrailerString();

            var list = engine.ReadString(recordString);

            list.Length.ShouldEqual(9);
        }

        private string BuildHeaderString()
        {
            var sb = new StringBuilder();
            sb.Append("FH");
            sb.Append("20190415");
            sb.Append("02");
            sb.Append("EXPLORE");
            sb.Append(string.Empty.PadLeft(59));
            sb.Append("01");
            sb.Append(string.Empty.PadLeft(70));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string BuildTrailerString()
        {
            var sb = new StringBuilder();
            sb.Append("FT");
            sb.Append("1".PadLeft(6, '0'));
            sb.Append("7".PadLeft(10, '0'));
            sb.Append("West Bend Mutual".PadRight(30));
            sb.Append("123456789");
            sb.Append("02");
            sb.Append(string.Empty.PadLeft(91));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build01String()
        {
            var sb = new StringBuilder();
            sb.Append("01");
            sb.Append("WI");
            sb.Append("P124-7683-573897".PadRight(22));
            sb.Append(string.Empty.PadRight(8));
            sb.Append("A1234560001123456789P124-7683-573897WI".PadRight(80));
            sb.Append(string.Empty.PadLeft(8));
            sb.Append("E");
            sb.Append(string.Empty.PadLeft(2));
            sb.Append(string.Empty.PadLeft(25));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build02String()
        {
            var sb = new StringBuilder();
            sb.Append("02");
            sb.Append("Test".PadRight(15));
            sb.Append(string.Empty.PadRight(10));
            sb.Append("Unit".PadRight(14));
            sb.Append(string.Empty.PadRight(6));
            sb.Append("Mstest".PadRight(15));
            sb.Append(string.Empty.PadLeft(5));
            sb.Append("111 main st".PadRight(25));
            sb.Append("West Bend".PadRight(20));
            sb.Append("WI");
            sb.Append("53222");
            sb.Append(string.Empty.PadLeft(31));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build03String()
        {
            var sb = new StringBuilder();
            sb.Append("03");
            sb.Append("19760602");
            sb.Append("100");
            sb.Append("072");
            sb.Append("BLUE");
            sb.Append(string.Empty.PadLeft(19));
            sb.Append("1234567898".PadRight(30));
            sb.Append("01/01/2019");
            sb.Append("P-1234-12345".PadRight(22));
            sb.Append("M");
            sb.Append("23456".PadLeft(7, '0'));
            sb.Append(string.Empty.PadLeft(41));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build04String()
        {
            var sb = new StringBuilder();
            sb.Append("04");
            sb.Append("Class".PadRight(20));
            sb.Append(string.Empty.PadLeft(1));
            sb.Append("20100101");
            sb.Append("20191231");
            sb.Append("Valid".PadRight(15));
            sb.Append("Valid".PadRight(15));
            sb.Append("Operator".PadRight(20));
            sb.Append(string.Empty.PadLeft(61));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build05String()
        {
            var sb = new StringBuilder();
            sb.Append("05");
            sb.Append("Class".PadRight(20));
            sb.Append("RS");
            sb.Append("Glasses".PadRight(20));
            sb.Append("RS");
            sb.Append("Day".PadRight(20));
            sb.Append("EN");
            sb.Append("Nighttime".PadRight(20));
            sb.Append("EN");
            sb.Append("Booster".PadRight(20));
            sb.Append(string.Empty.PadLeft(40));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build06String()
        {
            var sb = new StringBuilder();
            sb.Append("06");
            sb.Append("Violation".PadRight(10));
            sb.Append("342".PadLeft(10, '0'));
            sb.Append("20120502");
            sb.Append("Speeding +10".PadRight(80));
            sb.Append("20120524");
            sb.Append("004");
            sb.Append(string.Empty.PadRight(1));
            sb.Append("453".PadRight(10));
            sb.Append("444".PadRight(6));
            sb.Append(string.Empty.PadLeft(9));
            sb.Append(string.Empty.PadLeft(3));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }

        private string Build07String()
        {
            var sb = new StringBuilder();
            sb.Append("07");
            sb.Append("Some very random text".PadRight(123));
            sb.Append(string.Empty.PadLeft(25));
            sb.Append(Environment.NewLine);

            return sb.ToString();
        }
    }
}