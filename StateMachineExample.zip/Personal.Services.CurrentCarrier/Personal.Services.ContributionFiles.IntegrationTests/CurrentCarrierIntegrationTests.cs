﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="CurrentCarrierIntegrationTests.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.IntegrationTests
{
    using System;
    using System.Collections.Generic;
    using System.Configuration;
    using System.Linq;
    using System.Threading.Tasks;
    using FileHelpers.FileMappers;
    using FileHelpers.Models;
    using FileHelpers.ServiceInterfaces;
    using FileHelpers.ServiceInterfaces.Impls;
    using Microsoft.VisualStudio.TestTools.UnitTesting;
    using Newtonsoft.Json.Linq;
    using Personal.Service.Api.Storage;
    using Refit;
    using Rhino.Mocks;
    using Should;
    using WestBend.Core;

    [TestClass]
    public class CurrentCarrierIntegrationTests : BaseTestFixture
    {
        private IStorageManager storageManager;

        [TestInitialize]
        public void TestInitialize()
        {
            this.storageManager = new StorageManager(ConfigurationManager.AppSettings["ApimUrl"], ConfigurationManager.AppSettings["ApimSubscriptionKey"]);
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task BlobWriterTest()
        {
            var blobFileWriter = new BlobFileWriter(
                "LexisNexis.CurrentCarrier",
                this.storageManager);
            blobFileWriter.ShouldNotBeNull();

            var uri = await blobFileWriter.WriteCurrentCarrier("This is a test", "A12", "00", "1");
            uri.ShouldNotBeNull();
            uri.Folder.ShouldContain("LexisNexis.CurrentCarrier");
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task ReadRecordFilteredAsyncTest()
        {
            var results = await this.storageManager.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'CurrentCarrier' and CreateDate gt '0'");

            results.ShouldNotBeNull();
            results.Count.ShouldBeGreaterThan(0);
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task ReadRecordFilteredAsync_ForRunDate_Test()
        {
            var results = await this.storageManager.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'CurrentCarrier' and RowKey eq '1LR2'");

            results.ShouldNotBeNull();
            results.Count.ShouldEqual(1);
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task MapperServiceTest()
        {
            var blobFileWriter = new BlobFileWriter(
                "LexisNexis.CurrentCarrier",
                this.storageManager);

            var service = new MapperService(RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]), blobFileWriter, MockRepository.GenerateMock<ILogger>(), null);
            service.ShouldNotBeNull();

            var uri = await service.Map("A686035", "00", "3");

            uri.ShouldNotBeNull();
            uri.Folder.ShouldContain("LexisNexis.CurrentCarrier");
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task MapperServiceBigAcordTest()
        {
            var blobFileWriter = new BlobFileWriter(
                "LexisNexis.CurrentCarrier",
                this.storageManager);

            var service = new MapperService(RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]), blobFileWriter, MockRepository.GenerateMock<ILogger>(), null);
            service.ShouldNotBeNull();

            var uri = await service.Map("A683400", "00", "1");
            uri.ShouldNotBeNull();
            uri.Folder.ShouldContain("LexisNexis.CurrentCarrier");
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task RefitMultiProjectTest()
        {
            var api = RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]);
            api.ShouldNotBeNull();
            var data = await api.GetPolicyRequest("A513624", "00", "1", ConfigurationManager.AppSettings["ApimSubscriptionKey"]);

            data.ShouldNotBeNull();
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task MapperServiceProjectTest()
        {
            var blobFileWriter = new BlobFileWriter(
                "LexisNexis.CurrentCarrier",
                this.storageManager);

            var service = new MapperService(RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]), blobFileWriter, MockRepository.GenerateMock<ILogger>(), null);

            service.ShouldNotBeNull();

            var uri = await service.Map("A513724", "00", "1");

            uri.ShouldNotBeNull();
            uri.Folder.ShouldContain("LexisNexis.CurrentCarrier");
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task MapperServiceTest2()
        {
            var blobFileWriter = MockRepository.GenerateStub<IFileWriter>();
            blobFileWriter.Stub(a => a.WriteCurrentCarrier("text", "A12", "00", "1")).IgnoreArguments().Return(this.GetCurrentData("http://localhost/LexisNexis.CurrentCarrier/file.txt"));
            var apiStub = MockRepository.GenerateStub<IPolicyStoreApi>();
            apiStub.Stub(a => a.GetPolicyRequest("222", "00", "1", "key")).IgnoreArguments().Return(this.GetData());

            var service = new MapperService(RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]), blobFileWriter, MockRepository.GenerateMock<ILogger>(), null);
            service.ShouldNotBeNull();

            var uri = await service.Map("A513624", "00", "1");

            uri.ShouldNotBeNull();
            uri.Folder.ShouldContain("LexisNexis.CurrentCarrier/");
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task RefitMultiProjectTest2()
        {
            var api = RestService.For<IPolicyStoreApi>(ConfigurationManager.AppSettings["ApimUrl"]);
            api.ShouldNotBeNull();
            var data = await api.GetPolicyRequest("A513624", "00", "1", ConfigurationManager.AppSettings["ApimSubscriptionKey"]);

            data.ShouldNotBeNull();
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task ReadAzureTableTest()
        {
            var escapedFilter = Uri.EscapeUriString("PartitionKey eq 'CurrentCarrier' and RowKey eq '1LR2'");

            List<JObject> response = await this.storageManager.ReadRecordFilteredAsync("ThirdPartyContribution", "PartitionKey eq 'CurrentCarrier' and RowKey eq '1LR2'");
            
            LastRunDate lastRunDate = response.FirstOrDefault()?.ToObject<LastRunDate>();

            lastRunDate.ShouldNotBeNull();
        }

        [TestMethod]
        [TestCategory("Integration")]
        [Description("This test will start to fail once we add a run date to the table for clue auto.  Once that happens set test to not null and delete this comment")]
        public async Task ReadAzureTableTest2()
        {
            var escapedFilter = Uri.EscapeUriString($"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and RowKey eq '{Constants.Azure.TableStorage.RunDateRowKey}'");

            List<JObject> response = await this.storageManager.ReadRecordFilteredAsync("ThirdPartyContribution", $"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and RowKey eq '{Constants.Azure.TableStorage.RunDateRowKey}'");

            LastRunDate lastRunDate = response.FirstOrDefault()?.ToObject<LastRunDate>();

            lastRunDate.ShouldNotBeNull();
        }

        [TestMethod]
        [TestCategory("Integration")]
        public async Task ReadAzureTableTest3()
        {
            var dateTimeString = DateTime.Now.ToString("yyyyMMddHHmmssffff");

            List<JObject> response = await this.storageManager.ReadRecordFilteredAsync(
                "ThirdPartyContribution",
                $"PartitionKey eq '{Constants.Azure.TableStorage.ClueAutoPartitionKey}' and ClaimNumber eq 'A123456' and ClaimType eq 'AtFault' and CreateDate gt '{dateTimeString}'");

            ClueAutoData clueAutoData = response.FirstOrDefault()?.ToObject<ClueAutoData>();

            clueAutoData.ShouldBeNull();
        }

        private async Task<CurrentCarrierData> GetCurrentData(string path)
        {
            return new CurrentCarrierData()
            {
                Container = string.Empty,
                CreateDate = DateTime.Now.ToString("yyyyMMddHHmmssffff"),
                Folder = "LexisNexis.CurrentCarrier/",
                Name = "file.txt"
            };
        }
    }
}