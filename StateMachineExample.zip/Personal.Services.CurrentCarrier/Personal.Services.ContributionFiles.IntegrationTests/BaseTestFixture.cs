﻿//  --------------------------------------------------------------------------------------------------------------------
//  <copyright file="BaseTestFixture.cs" company="West Bend">
//    Copyright (c) 2019 West Bend
//  </copyright>
//  --------------------------------------------------------------------------------------------------------------------

namespace Personal.Services.ContributionFiles.IntegrationTests
{
    using System.IO;
    using System.Threading.Tasks;

    public abstract class BaseTestFixture
    {
        protected async Task<string> GetData()
        {
            using (var sr = new StreamReader("data/acord.xml"))
            {
                var line = await sr.ReadToEndAsync();
                return line;
            }
        }
    }
}
