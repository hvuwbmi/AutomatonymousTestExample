﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace QA.TestEngineTests
{
    [TestFixture]
    class EngineTests
    {
        private Random rand = new Random();

        [SetUp]
        public void RandomWait()
        {
            var waitTime = rand.Next(0, 30000);
            Thread.Sleep(waitTime);
        }

        static string[] Home_And_Highway_Smoke_Tests =
        {
            "Home_And_Highway_Smoke.xml"
        };

        [Test, TestCaseSource("Home_And_Highway_Smoke_Tests"), Parallelizable(ParallelScope.All)] 
        public void Home_And_Highway_Smoke(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\" + engineTestFile, "InternetExplorer"), "Test Engine Test: " + engineTestFile + "  FAILED" );
        }

        static string[] Choice_Quote_Tests_MI =
        {
            "Choice_AutoQuote_MI.xml",
            "Choice_HomeQuote_MI.xml",
            "Choice_PackageQuote_MI.xml"
        };

        [Test, TestCaseSource("Choice_Quote_Tests_MI"), Parallelizable(ParallelScope.All)]
        public void Choice_Quote_MI(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] Choice_Smoke_MI_Tests =
        {
            "Choice_Auto_Smoke_NB_MI.xml",
            "Choice_Home_Smoke_MI.xml",
            "Choice_Package_Smoke_MI.xml",
            "Choice_Auto_AppPrefill_Smoke_MI.xml",
            "Choice_Auto_Smoke_NB_CAN_Reinstate_MI.xml",
            "Choice_Auto_Smoke_NB_CAN_Reissue_MI.xml",
            "Choice_Auto_Smoke_NB_CAN_Rewrite_MI.xml",
            "Choice_Auto_Smoke_NB_END_MI.xml"
        };

        [Test, TestCaseSource("Choice_Smoke_MI_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Smoke_MI(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] Choice_Auto_Smoke_AZ_Tests =
        {
            "Choice_Auto_Smoke_NB_AZ.xml",            
            "Choice_Auto_Smoke_AppPrefill_NB_AZ.xml",
            "Choice_Auto_Smoke_NB_END_AZ.xml",
            "Choice_Auto_Smoke_NB_CAN_Reinstate_AZ.xml",
            "Choice_Auto_Smoke_NB_CAN_Reissue_AZ.xml",
            "Choice_Auto_Smoke_NB_CAN_Rewrite_AZ.xml",
            "Choice_Auto_Smoke_NB_NonRenew_AZ.xml"
        };

        [Test, TestCaseSource("Choice_Auto_Smoke_AZ_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Auto_Smoke_AZ(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] IE_Choice_Auto_Smoke_AZ_Tests =
        {
            "IE_Choice_Auto_Smoke_AZ.xml",
            "IE_Choice_Search_Smoke.xml"
        };

        [Test, TestCaseSource("IE_Choice_Auto_Smoke_AZ_Tests"), Parallelizable(ParallelScope.All)]
        public void IE_Choice_Auto_Smoke_AZ(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\" + engineTestFile, "InternetExplorer", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] Choice_Auto_Regression_AZ_Tests =
        {
            "Choice_Auto_Regr1_AZ.xml",
            "Choice_Auto_Regr2_AZ.xml",
            "Choice_Auto_Regr3_AZ.xml",
            "Choice_Auto_Regr4_AZ.xml",
            "Choice_Auto_Regr5_AZ.xml",
            "Choice_Auto_Renew_Manual_Regr_AZ.xml"
        };

        [Test, TestCaseSource("Choice_Auto_Regression_AZ_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Auto_Regression_AZ(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Regression\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] Choice_Home_Smoke_AZ_Tests =
        {
            "Choice_Home_Quote_AZ.xml",
            "Choice_Home_Smoke_NB_AZ.xml",
            "Choice_Home_Smoke_NB_END_AZ.xml",
            "Choice_Home_Smoke_NB_Cancel_Reinstate_AZ.xml",
            "Choice_Home_Smoke_NB_Cancel_Reissue_AZ.xml",
            "Choice_Home_Smoke_NB_Cancel_Rewrite_AZ.xml",
            "Choice_Home_Smoke_NB_NonRenew_AZ.xml"
        };

        [Test, TestCaseSource("Choice_Home_Smoke_AZ_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Home_Smoke_AZ(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        // leave this as is as Billing team uses these scripts
        static string[] TEST_Choice_PaymentTypeSmoke_Tests =
        {
            "TEST_Choice_Search_Smoke.xml",
            "TEST_Choice_CreateAuto_Monthly_MI.xml",
            "TEST_Choice_CreateAuto_PayinFull_MI.xml",
            "TEST_Choice_CreateAuto_PayInFull-NoPrior_MI.xml",
            "TEST_Choice_CreateAuto_SemiA_MI.xml"
        };

        [Test, TestCaseSource("TEST_Choice_PaymentTypeSmoke_Tests"), Parallelizable(ParallelScope.All)]
        public void TEST_Choice_PaymentTypeSmoke(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Functional\" + engineTestFile, "Chrome"), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        static string[] Choice_Auto_Regression_MI_Tests =
        {
            "Choice_Auto_Regr1_MI.xml",
            "Choice_Auto_Regr2_MI.xml",
            "Choice_Auto_Regr3_MI.xml",
            "Choice_Auto_Regr4_MI.xml",
            "Choice_Auto_Regr5_MI.xml"
        };

        [Test, TestCaseSource("Choice_Auto_Regression_MI_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Auto_Regression_MI(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Regression\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }

        [Test]
        public void SearchAndLoadChoicePolicy()
        {
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected or parameter is set in cmd.");
            var searchPolicyGlobalVars = TestContext.Parameters["globalVariables"];

            //This logic adds searchPolicyNumber global var to globalVariables depending on wbconnect url
            if (searchPolicyGlobalVars.IndexOf("int.wbconnect", StringComparison.OrdinalIgnoreCase) > -1)
            {
                searchPolicyGlobalVars += ";searchPolicyNumber=A691569";
            }
            else if (searchPolicyGlobalVars.IndexOf("test.wbconnect", StringComparison.OrdinalIgnoreCase) > -1)
            {
                searchPolicyGlobalVars += ";searchPolicyNumber=A967963";
            }
            Assert.IsTrue(searchPolicyGlobalVars.Contains("searchPolicyNumber"), "Search Policy Number Data Not Available For Current Run Settings.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Smoke\Choice_Auto_Smoke_Search.xml", "Chrome", searchPolicyGlobalVars), "WBConnect Search And Load Choice Policy Test Failed. Check Attachments For Details.");
        }

        static string[] Choice_Functional_Tests =
        {
           "TEST_US120729-NB_OrderReports_AZ.xml"  
        };

        [Test, TestCaseSource("Choice_Functional_Tests"), Parallelizable(ParallelScope.All)]
        public void Choice_Functional_Test(string engineTestFile)
        {
            Environment.CurrentDirectory = TestContext.CurrentContext.TestDirectory;
            Assert.IsTrue(!string.IsNullOrEmpty(TestContext.Parameters["globalVariables"]), "test parameter: globalVariables is not set. Please be sure runsettings is selected.");
            Assert.IsTrue(Util.ExecuteTestEngine(@"TestFiles\TestLists\PLChoice\Functional\" + engineTestFile, "Chrome", TestContext.Parameters["globalVariables"]), "Test Engine Test: " + engineTestFile + "  FAILED");
        }
    }
}