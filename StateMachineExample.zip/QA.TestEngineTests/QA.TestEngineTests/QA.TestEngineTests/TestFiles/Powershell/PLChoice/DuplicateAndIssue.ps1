﻿#=====================================================================================================================================
#
#This Script Duplicates and Issues a New Business Policy. The Duplicated policy is in NB Issued Status.
#
#=====================================================================================================================================

param([string]$PolicyNum = "", [string]$URI = "", [string]$SubscriptionKey = "")
$ErrorActionPreference = "Stop"

#DuplicatePolicyAPI
$DuplicateAPIResponse = Invoke-RestMethod -Method "Get" -Uri "$URI/personal/policy/orchestration/DuplicatePolicy/$PolicyNum/00/1" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey}  
$ErrorActionPreference = "Stop"

$DuplicatedPolicy = $DuplicateAPIResponse.SelectSingleNode("//OnlineData.autoSaveDataRs").Attributes["policyNumber"].Value

Write-Host "DuplicatedPolicy:$DuplicatedPolicy"

#=====================================================================================================================================

#GetPolicyAPI

[xml]$GetPolicyResponse = Invoke-RestMethod -Method "Get" -Uri "$URI/personal/policy/store/load/$DuplicatedPolicy/00/1" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} 
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $GetPolicyResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$GetPolicyBody = $GetPolicyResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "GetPolicyRs : $GetPolicyBody"

#=====================================================================================================================================

#RulesOrchestrationAPI

$RulesBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$GetPolicyBody+'</PolicyRq>'

$SuitabilityResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/rules/orchestrator/manual/paths/invoke" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $RulesBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $SuitabilityResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$SuitabilityBody = $SuitabilityResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "SuitabilityResponse : $SuitabilityBody"

#=====================================================================================================================================

#RatingOrchestrationAPI

$RatingBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$SuitabilityBody+'</PolicyRq>'

[xml]$RatingResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/rating/orchestrator/manual/paths/invoke" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $RatingBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $RatingResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$RatingResponseBody = $RatingResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "RatingResponse : $RatingResponseBody"

#=====================================================================================================================================

#ReleasePolicyAPI

$ReleasePolBody = '<PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$RatingResponseBody+'</PolicyRq>'

[xml]$ReleasePolicy = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/policy/orchestration/ReleasePolicy" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $ReleasePolBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $ReleasePolicy.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$ReleasePolicyBody = $ReleasePolicy.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "ReleasePolicyResponse : $ReleasePolicyBody"

#=====================================================================================================================================

#UnderwritingRulesLUCIAPI

$LUCIBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$ReleasePolicyBody+'</PolicyRq>'

[xml]$LUCIResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/rules/orchestrator/Underwriting" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $LUCIBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $LUCIResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$UWLUCIResponse = $LUCIResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "LUCIResponse : $UWLUCIResponse"

#=====================================================================================================================================

#BindAPI

$BindBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$UWLUCIResponse+'</PolicyRq>'

[xml]$BindResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/policy/orchestration/BindPolicy" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $BindBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $BindResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$BindAPIResponse = $BindResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "BindResponse : $BindAPIResponse"

#=====================================================================================================================================

#IssuePolicyAPI

$IssueBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$BindAPIResponse+'</PolicyRq>'

[xml]$IssueResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/policy/orchestration/IssuePolicy" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $IssueBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $IssueResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$IssueAPIResponse = $IssueResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "IssueResponse : $IssueAPIResponse"
#=====================================================================================================================================

#CommitPolicyAPI

$CommitPolicybody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$IssueAPIResponse+'</PolicyRq>'

$CommitPolicyResponse = Invoke-RestMethod -Method "Post" -Uri "$URI/personal/policy/orchestration/Commit" -Headers @{'Ocp-Apim-Subscription-Key' = $SubscriptionKey} -ContentType "text/xml" -Body $CommitPolicybody
$ErrorActionPreference = "Stop"

<#Write-Host "CommitAPIResponse : $CommitResponse"#>
#=====================================================================================================================================

<#$statusNode = $CommitPolicyResponse.SelectSingleNode("//ManuScript.getValueRs").Attributes["value"].Value

if ($statusNode -eq "0")
{
    1
}
else
{
    0
}#>

$status = $CommitPolicyResponse.SelectSingleNode("//ManuScript.getValueRs").Attributes["status"].Value

if ($status -eq 'success')
{
    1
}
else
{
    0
}

#=====================================================================================================================================

#SaveAPI

<#$SaveBody = '<?xml version="1.0" encoding="utf-8"?>
                <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
                    <BusinessPurposeTypeCd>NBQ</BusinessPurposeTypeCd>
                    <TransactionEffectiveDt>2020-06-19T00:00:00.000</TransactionEffectiveDt>
                    <SourceSystem id="S52ECC13CD09C4E269A25F8EAD0775708">
                        <SourceSystemCd>WB</SourceSystemCd>
                        <SourceSystemQualifierCd>LR</SourceSystemQualifierCd>
                    </SourceSystem>
                    <TransactionSeqNumber>1</TransactionSeqNumber>'+$UWLUCIResponse+'</PolicyRq>'

[xml]$SaveResponse = Invoke-RestMethod -Method "Post" -Uri "https://qa-api.wbmi.com/personal/policy/orchestration/SavePolicy" -Headers @{'Ocp-Apim-Subscription-Key' = '9440742764af4951807a36ac89131afb'} -ContentType "text/xml" -Body $SaveBody
$ErrorActionPreference = "Stop"

[System.Xml.XmlNamespaceManager]$nsmgr = $SaveResponse.NameTable
$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
$SaveAPIResponse = $SaveResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "SaveResponse : $SaveAPIResponse"#>

#=====================================================================================================================================

#OrderAcordAPI

#$OrderBody = '<?xml-stylesheet type="text/xsl" href="file:///h:/personal%20lines%20analytics/acord%20stuff/schema%20and%20xml%20versions/sample%20xmls/getdistinctelementandxpath2.xslt"?>
               # <PolicyRq xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns="http://www.acord.org/schema/PC/xml/2">
               # $GetPolicyBody
               # </PolicyRq>'

#[xml]$OrderAcordResponse = Invoke-RestMethod -Method "Post" -Uri "https://qa-api.wbmi.com/personal/transform/AcordOrdering/OrderAcord" -Headers @{'Ocp-Apim-Subscription-Key' = '9440742764af4951807a36ac89131afb'} -ContentType "text/xml" -Body $OrderBody
#$ErrorActionPreference = "Stop"
#[System.Xml.XmlNamespaceManager]$nsmgr = $OrderAcordResponse.NameTable
#$nsmgr.AddNamespace("acord", "http://www.acord.org/schema/PC/xml/2")
#$OrderPolicyBody = $OrderAcordResponse.SelectSingleNode("//acord:Policy", $nsmgr).OuterXml

#Write-Host "OrderAcordRs : $OrderAcordResponse"

#=====================================================================================================================================