﻿#This Script Queries Staging databse of Insights to verify a given Policy information

param([string]$policyNum = "A563102", [string]$expectedType = "New", [string]$expectedChange = "Committed", [string]$expectedPolicyStatus = "Inforce")

$connectionString = "Data Source=172.17.3.140,26433;User ID=TESTPL; Password=9hKkLnIJwsgLjv8X0Urj; Initial Catalog=YodilIDS_Staging"

$sqlCommand = "SELECT * FROM Policy.Policy WHERE policy.PolicyNumber = 'A765686'"
    
        $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
        $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
   
        $connection.Open()

        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataSet) | Out-Null

        $connection.Close()

        $type = $dataset.Tables[0].Rows[0].type
        $change = $dataset.Tables[0].Rows[0].change
        $policystatus = $dataset.Tables[0].Rows[0].policystatus
        
        
        Write-Host "Type: $type"
        Write-Host "Change: $change"
        Write-Host "PolicyStatus: $policystatus"
       
        if($type -eq $expectedType)   
        {
           if($policystatus -eq $expectedPolicyStatus)
           {
             if($change -eq $expectedChange)
             {
                1
             }
           }   
        }
        else
        {
            0
        }