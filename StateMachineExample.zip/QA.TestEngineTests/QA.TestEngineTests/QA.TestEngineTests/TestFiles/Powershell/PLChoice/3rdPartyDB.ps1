﻿#This Script Queries 3rd party database to verify the Rating response elements retured for that policy

param([string]$policyNum = "A815959", [string]$expectedPayPlan = "QT", [int]$expectedTotalPremium = "9620", [string]$expectedRatingStatus = "PASS", [string]$expectedAgencyCode = "48508", [string]$ThirdPartyDBSource = "")

$ErrorActionPreference = "Stop"

$connectionString = "Data Source=$ThirdPartyDBSource; Integrated Security=SSPI; Initial Catalog=ThirdPartyIntegration"    

$sqlCommand = "use ThirdPartyIntegration
    select top 1 rc.RequestActionCategory,cast(req.RequestMessage as xml) reqxml,cast(rd.ResponseMessage as xml) respxml
    from Request req with(NOLOCK)
    inner join requestAction ra with(NOLOCK) on ra.RequestActionID = req.RequestActionID
    INNER JOIN RequestActionCategory rc with(NOLOCK) on Rc.RequestActionCategoryID = ra.RequestActionCategoryID
    left JOIN Response r with(nolock) on req.RequestID = r.RequestID
    left join ThirdPartyIntegration.dbo.ResponseDetail rd with(NOLOCK) ON r.ResponseID = rd.ResponseID
    left join RequestStatus rs with(NOLOCK) on rs.RequestStatusID = req.RequestStatusID
    where RequestActionCategory = 'Rating' and RequestCode1 in ('$policyNum') order by req.RequestID desc"

        $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
        $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)

        $connection.Open()

        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
		$adapter.SelectCommand.CommandTimeout=60
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataSet) | Out-Null

        $connection.Close()

        [xml]$ratingReq = $dataset.Tables[0].Rows[0].reqxml
        [xml]$ratingRes = $dataset.Tables[0].Rows[0].respxml 
               
        $reqPolicyNumber = $ratingReq.rate.PolicyNumber
        $reqPayPlan = $ratingReq.SelectSingleNode("/rate/c[@i=0]/m[@n=""PayPlan""]/@v").Value
        $policyMod = $ratingReq.SelectSingleNode("/rate/c[@i=0]/m[@n=""PolMod""]/@v").Value
        $polEffDate = $ratingReq.SelectSingleNode("/rate/c[@i=0]/m[@n=""PolEffDate""]/@v").Value
        $polExpDate = $ratingReq.SelectSingleNode("/rate/c[@i=0]/m[@n=""PolExpDate""]/@v").Value
        $agencyCode = $ratingReq.SelectSingleNode("/rate/c[@i=0]/m[@n=""AgencyCode""]/@v").Value
        $resPolicyNumber = $ratingRes.result.PolicyNumber
        $resStatus = $ratingRes.result.program.status
        $totalPolicyPremium = $ratingRes.SelectSingleNode("/result/program/c/m[@i=""TOTAL POLICY PREMIUM""]/@v").Value
        $resPayPlan = $ratingRes.SelectSingleNode("/result/program/c/m[@i=""PAY PLAN CODE""]/@v").Value 

        Write-Host "ReqPolicyNumber: $reqPolicyNumber"
        Write-Host "ReqPayPlan: $reqPayPlan"
        Write-Host "PolicyMod: $policyMod"
        Write-Host "PolEffDate: $polEffDate"
        Write-Host "PolExpDate: $polExpDate"
        Write-Host "AgencyCode: $agencyCode"
        Write-Host "ResPolicyNumber: $resPolicyNumber"
        Write-Host "ResStatus: $resStatus"
        Write-Host "TotalPolicyPremium: $totalPolicyPremium"
        Write-Host "ResPayPlan: $resPayPlan"
      
        $passed = 1
        if($reqPolicyNumber -eq $policyNum)
        {
            Write-Host "Policy Number's match"
        }
        else
        {
            Write-Host "Policy Number's do not match, RequestPolNum: $reqPolicyNumber; Actual: $policyNum"
			$passed = 0
		}

             if($resPayPlan -eq $expectedPayPlan)
             {
                    Write-Host "Pay Plan value match"
             }
             else
             {
                  Write-Host "Pay Plan value does not match, RatingReq: $reqPayPlan; RatingRes: $resPayPlan; Expected: $expectedPayPlan"
				$passed = 0
			 }

             if($totalPolicyPremium -eq $expectedTotalPremium)
             {
                  Write-Host "Total Premium matches"
             }
             else
             {
                  Write-Host "Total Premium does not match, Actual: $totalPolicyPremium; Expected: $expectedTotalPremium"
				$passed = 0
			 }

             if($resStatus -eq $expectedRatingStatus)
             {
                  Write-Host "Rating status: PASS"
             }
             else
             {
                  Write-Host "Rating status: FAIL"
				$passed = 0
			}

             if($agencyCode -eq $expectedAgencyCode)
             {
                  Write-Host "Agency code match"
             }
             else
             {
                  Write-Host "Agency code does not match, Actual: $agencyCode; Expected: $expectedAgencyCode"
				$passed = 0
			 }
			 
			$passed 