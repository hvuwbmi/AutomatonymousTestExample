﻿#This Script Queries ExampleData to verify a given PolicyNumber Exists

param([string]$policyNum = "A772784", [string]$expectedPolicyStatus = "Inforce", [string]$expectedTransactionStatus = "Committed", [string]$expectedWrittenPremium = "1234.0000", [string]$expectedChangePremium = "1234.0000")

$connectionString = "Data Source=172.17.0.4,50690;User ID=ATest01SQL; Password=Cc7uCwzBH8; Initial Catalog=ExampleData"
   
    $sqlCommand = "SELECT  h.policynumber, 
		               h.policystatus,
		               h.transactionstatus,
		               h.type, 
		               h.change, 
		               h.state,
		               cast(h.policyeffectivedate as date) poleffdt,
		               cast(h.transactioneffectivedate as date) trxeffdt,
		               cast(h.offsetdate as date) offsetdt,
		               cast(h.expirationdate as date) expirydt,
		               cast(h.cancellationdate as date) canceldt,
		               cast(h.changedate as date) changedt,
		               h.previouspremium,
		               h.writtenpremium,
		               h.changepremium,
		               CAST(DECOMPRESS(h.ZippedXML) as xml) policyxml
            from ExampleData.dbo.History h with (nolock) 
            where PolicyNumber = '$policyNum'"
 
        $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
        $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
   
        $connection.Open()

        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataSet) | Out-Null

        $connection.Close()


        $resPolicyNum = $dataset.Tables[0].Rows[0].policynumber
        $resPolicyStatus = $dataset.Tables[0].Rows[0].policystatus
        $resTransactionStatus = $dataset.Tables[0].Rows[0].transactionstatus
        $resWrittenPremium = $dataset.Tables[0].Rows[0].writtenpremium
        $resChangePremium = $dataset.Tables[0].Rows[0].changepremium
     
        Write-Host "ResPolicyNum: $resPolicyNum"
        Write-Host "ResPolicyStatus: $resPolicyStatus"
        Write-Host "ResTransactionStatus: $resTransactionStatus"
        Write-Host "ResWrittenPremium: $resWrittenPremium"
        Write-Host "ResChangePremium: $resChangePremium"
       

       $passed = 1

       if($policyNum -eq $resPolicyNum)
       {
            Write-Host "Policy numbers match"
       }
       else
       {
            Write-Host "Policy numbers do not match, Expected:$policyNum Actual:$resPolicyNum"
            $passed = 0
       }

       if($expectedPolicyStatus -eq $resPolicyStatus)
       {
            Write-Host "Policy status match"
       }
       else
       {
            Write-Host "Policy status does not match, Expected:$expectedPolicyStatus Actual:$resPolicyStatus"
            $passed = 0
       }
        
        if($expectedTransactionStatus -eq $resTransactionStatus)
      {
            Write-Host "Transaction Status match"
       }
       else
       {
            Write-Host "Transaction Status does not match, Expected:$expectedTransactionStatus Actual:$resTransactionStatus"
            $passed = 0
       }

        if($expectedWrittenPremium -eq $resWrittenPremium)
       {
            Write-Host "Written Premium match"
       }
       else
       {
            Write-Host "Written Premium does not match, Expected:$expectedWrittenPremium Actual:$resWrittenPremium"
            $passed = 0
       }

       if($expectedChangePremium -eq $resChangePremium)
      {
            Write-Host "Change Premium match"
       }
       else
       {
            Write-Host "Change Premium does not match, Expected:$expectedChangePremium Actual:$resChangePremium"
            $passed = 0
       }

       $passed