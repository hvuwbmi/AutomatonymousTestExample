﻿#This Script Queries ExampleData to verify a given PolicyNumber Exists

param([string]$policyNum = "A816716", [string]$message = "foo", [int]$expectedQuoteId)

$connectionString = "Data Source=172.17.0.4,50690;User ID=ATest01SQL; Password=Cc7uCwzBH8; Initial Catalog=ExampleData"
   
    $sqlCommand = "SELECT TOP 1 quoteid FROM ExampleData.dbo.History WITH(nolock) WHERE PolicyNumber = '$policyNum' ORDER BY TransactionDate DESC"


        $connection = new-object system.data.SqlClient.SQLConnection($connectionString)
        $command = new-object system.data.sqlclient.sqlcommand($sqlCommand,$connection)
   
        $connection.Open()

        $adapter = New-Object System.Data.sqlclient.sqlDataAdapter $command
        $dataset = New-Object System.Data.DataSet
        $adapter.Fill($dataSet) | Out-Null

        $connection.Close()

        $quoteId = $dataset.Tables[0].Rows[0].QuoteID
        


        Write-Host "QuoteID: $quoteId"
        Write-Host "Message: $message"

        if($quoteId -eq $expectedQuoteId)
        {
            1
        }
        else
        {
            0
        }