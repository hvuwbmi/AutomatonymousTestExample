﻿param([string]$testOut = "1")

Write-Host "Running with a: $testOut"

$testOut