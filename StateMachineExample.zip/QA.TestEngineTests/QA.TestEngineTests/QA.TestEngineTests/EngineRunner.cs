﻿using NUnit.Framework;
using System;
using TestEngine;


namespace QA.TestEngineTests
{
    
    public class EngineRunner
    {
        public string OutputDirectory { get; set; } = "";
        public bool Run(string testEngineFile, string browser, string globalVariables)
        {
            TestEngine.TestEngine engine;
            if(!string.IsNullOrEmpty(globalVariables))
            {
                engine = new TestEngine.TestEngine(browser, 500, 60, globalVariables);
            }
            else
            {
                engine = new TestEngine.TestEngine(browser, 500, 60);
            }

            var pass = engine.RunTestFile(testEngineFile, TestContext.CurrentContext.TestDirectory, false);
            OutputDirectory = engine.OutputDirectory;
            return pass;
        }
    }
}
